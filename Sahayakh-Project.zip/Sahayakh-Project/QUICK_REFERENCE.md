# Sahayakh Quick Reference Guide

## 🎯 One-Page Overview

**Sahayakh** = Gig economy platform like TaskRabbit, Urban Company, or Swiggy Genie

### Three Apps in One Platform:

| App | Users | Function | Core Feature |
|-----|-------|----------|--------------|
| **Helper App** | Workers/Gig workers | Earn money completing tasks | Accept task → Navigate → Complete → Get paid |
| **Customer App** | People needing help | Book helpers for tasks | Create task → Find helper → Track → Pay & rate |
| **Admin Dashboard** | Operations team | Manage entire platform | Monitor KPIs → Approve helpers → Resolve disputes |

---

## 💰 Business Model

```
Task amount:    ₹100 (customer pays)
Sahayakh fee:   ₹15 (you keep - 15%)
Helper earns:   ₹85 (they keep - 85%)
```

**Revenue:** 15% of every transaction

---

## 📱 What's in Each App

### Helper App Features
- Browse nearby tasks
- Accept/reject
- Real-time tracking to location
- OTP verification
- Task completion with photos
- Instant payment
- Earnings dashboard

### Customer App Features
- Create tasks (personal/business)
- Search helpers by rating/distance
- View helper profiles
- Live tracking on map
- Chat with helper
- Rate & review
- Task history

### Admin Dashboard Features
- Real-time KPIs & metrics
- Helper approvals & verification
- Task assignment & management
- Dispute resolution
- Payout processing
- Dynamic pricing setup

---

## 🚀 Your Project Folder

```
Sahayakh-Project/
├── prototypes/
│   ├── INDEX.html              ← Start here (navigation hub)
│   ├── sahayakh-helper-app.html
│   ├── sahayakh-app.html
│   └── sahayakh-admin-dashboard.html
├── README.md                   ← What is Sahayakh?
├── GETTING_STARTED.md          ← What to do next
├── PROJECT_STRUCTURE.md        ← Complete feature list
└── TECH_STACK.md              ← Technology recommendations
```

---

## 📊 Key Metrics

| Metric | Target |
|--------|--------|
| Helper rating | 4.5+ / 5.0 |
| Task completion | 95%+ |
| Dispute rate | <2% |
| Payment success | 99%+ |
| User growth | 10% MoM |

---

## 🛠️ Tech Stack (Recommended)

| Layer | Technology |
|-------|-----------|
| Backend | Node.js + Express |
| Database | PostgreSQL + Redis |
| Mobile | React Native |
| Web Admin | React + Vite |
| Payments | Razorpay |
| Maps | Google Maps API |
| Hosting | AWS / DigitalOcean |

---

## 📈 Development Timeline

| Phase | Duration | Status |
|-------|----------|--------|
| 1. Prototyping | 2 weeks | ✅ DONE |
| 2. User Feedback | 1-2 weeks | → NEXT |
| 3. Backend API | 4-6 weeks | → Then |
| 4. Mobile Apps | 4-6 weeks | → Then |
| 5. Testing & Launch | 2-3 weeks | → Finally |

**Total: ~3-4 months for MVP**

---

## 🎯 Next Steps (Pick One)

### Option A: Validate Idea First (Recommended)
1. Share prototypes with 10-20 potential users
2. Get feedback on features & pricing
3. Refine based on feedback
4. Then start development

### Option B: Start Development Immediately
1. Design database schema
2. Build backend API
3. Develop mobile apps
4. Deploy & launch MVP

---

## 💡 Similar Platforms (For Inspiration)

| Platform | Country | Focus |
|----------|---------|-------|
| TaskRabbit | USA | General tasks |
| Urban Company | India | Home services |
| Swiggy Genie | India | Quick deliveries |
| Airtasker | Australia | Any task |
| Handy | USA | Home services |

---

## 🎬 How Each App Works

### Helper App Flow
```
Go Online
  ↓
[Browse Tasks]
  ↓
Accept Task
  ↓
Navigate to Location
  ↓
Reach & Verify (OTP)
  ↓
Complete Task (Checklist + Photos)
  ↓
Submit & Get Paid
  ↓
Rate Customer
  ↓
View Earnings
```

### Customer App Flow
```
Create Task
  ↓
Search Helpers
  ↓
View Profiles
  ↓
Book Helper
  ↓
Track Live
  ↓
Complete & Pay
  ↓
Rate Helper
```

### Admin Flow
```
Dashboard Overview
  ↓
[Manage]
├─ Approve Helpers
├─ Resolve Disputes
├─ Process Payouts
├─ Assign Tasks
└─ Set Pricing
```

---

## 📋 Features Checklist

### MVP (Minimum Viable Product)
- [x] User registration & login
- [x] Task creation & posting
- [x] Helper search & filtering
- [x] Task acceptance & tracking
- [x] Payment processing
- [x] Ratings & reviews
- [x] Basic admin controls

### Post-MVP Features
- [ ] Advanced matching algorithm
- [ ] Subscription plans
- [ ] Referral rewards
- [ ] Insurance coverage
- [ ] Advanced analytics
- [ ] Multi-language support
- [ ] Regional variations

---

## 🔐 Key Security Features

- Phone verification (OTP)
- Identity verification (Aadhaar/PAN)
- Background checks for helpers
- Payment encryption
- Data privacy
- Dispute resolution system
- Fraud detection

---

## 📊 Expected Unit Economics

```
Task Average: ₹250
  ├─ Helper earns: ₹212.50 (85%)
  └─ Sahayakh earns: ₹37.50 (15%)

Monthly (1000 tasks):
  ├─ Total volume: ₹250,000 (GMV)
  ├─ Helper payouts: ₹212,500
  └─ Your revenue: ₹37,500
```

---

## 🌍 Expansion Path

### City 1 (Months 1-3)
- Launch in 1 tier-2 city
- Get 100 helpers active
- 500+ customer bookings
- Validate product

### Cities 2-3 (Months 4-6)
- Replicate in 2 more cities
- Same playbook
- Local market adjustments

### National Scale (Months 7+)
- 10+ cities
- Local ops teams
- Customer support hubs

---

## ❓ Common Questions

**Q: How do I make money?**  
A: Take 15% of each task amount. ₹100 task = ₹15 for you.

**Q: How long to build?**  
A: ~3-4 months for MVP with experienced team.

**Q: What's the biggest challenge?**  
A: Getting critical mass of helpers & customers simultaneously.

**Q: Can I start in my city?**  
A: Yes! Start small, validate, then scale.

**Q: Do I need funding?**  
A: For MVP: Maybe $10-20K for development. For growth: Much more.

**Q: What if someone gets hurt?**  
A: Background checks, insurance, T&Cs, support system.

---

## 📚 Documents to Read

1. **README.md** (5 min)
   - Overview of Sahayakh

2. **GETTING_STARTED.md** (10 min)
   - Your next steps

3. **PROJECT_STRUCTURE.md** (20 min)
   - All features documented

4. **TECH_STACK.md** (20 min)
   - Technology deep dive

5. **Explore Prototypes** (30 min)
   - See it in action

---

## ✅ Checklist Before Starting Development

- [ ] Validated with 10+ potential users
- [ ] Confirmed demand in your city
- [ ] Team assembled (backend, mobile, design)
- [ ] Tech stack finalized
- [ ] Database schema designed
- [ ] API specification written
- [ ] Development timeline agreed
- [ ] Hosting provider chosen
- [ ] Budget approved

---

## 🎓 Learning Resources

**Backend:** Express.js docs, PostgreSQL docs, Socket.IO docs  
**Mobile:** React Native docs, React Navigation  
**DevOps:** Docker, Kubernetes, GitHub Actions  
**System Design:** System Design Primer on GitHub  
**Business:** Stratechery, Benedict Evans

---

## 🚀 You're Ready!

You have:
✅ Complete prototypes  
✅ Feature documentation  
✅ Tech recommendations  
✅ Development roadmap  
✅ Everything to get started  

**Start here:** Open `prototypes/INDEX.html` in your browser!

---

**Last Updated:** September 2026  
**Project:** Sahayakh - Gig Economy Platform  
**Status:** Ready to Validate / Develop
