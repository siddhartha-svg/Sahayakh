# Test Implementation Guide - Running & Extending the Test Suite

---

## 🚀 Quick Start (5 minutes)

### 1. Install Dependencies
```bash
cd packages/backend
npm install
```

### 2. Setup Test Environment
```bash
# Copy test environment file
cp .env.example .env.test

# Update .env.test with test database credentials
# DATABASE_URL=postgresql://test:test@localhost:5432/sahayakh_test
# REDIS_URL=redis://localhost:6379/1
```

### 3. Start Services
```bash
# Start PostgreSQL (ensure it's running)
# Option A: Docker
docker run --name postgres-test -e POSTGRES_PASSWORD=test -d postgres:14

# Option B: Local installation
pg_ctl start

# Start Redis
# Option A: Docker
docker run --name redis-test -d redis:7

# Option B: Local installation
redis-server

# Verify connections
psql postgres -c "SELECT 1"  # Should return 1
redis-cli ping                 # Should return PONG
```

### 4. Create Test Database
```bash
createdb -U postgres sahayakh_test
```

### 5. Run Tests
```bash
# Run all tests
npm test

# Expected output: All 67+ tests passing
# Test Suites: 5 passed, 5 total
# Tests: 67 passed, 67 total
```

---

## 📊 Understanding the Test Files

### File 1: matching-engine.test.ts
**Focus**: Helper matching and scoring

**Key Concepts**:
- Distance calculation between points
- Rating-based sorting
- Service radius filtering
- Suspension status checks

**Dependencies**:
- `taskService.getNearbyHelpers()` - Get sorted helper list
- Database tables: users, helpers, tasks

**Run Only This File**:
```bash
npm test -- matching-engine.test.ts
```

**If Failing**:
- Check helpers table exists and has data
- Verify location_point is valid JSON
- Ensure suspended helpers are marked correctly

---

### File 2: task-state-machine.test.ts
**Focus**: Task status transitions and lifecycle

**Key Concepts**:
- Valid state sequence
- State transition validation
- Helper assignment requirement
- Cancellation scenarios

**State Diagram**:
```
                    ┌─────────────────┐
                    │   unassigned    │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │   confirmed     │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │   started       │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │  otp_pending    │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │  in_progress    │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
            ┌──────▶│  completed      │◀────┐
            │       └────────┬────────┘      │
            │                │               │
            │        ┌────────▼────────┐     │
            │        │   disputed      │     │
            │        └────────┬────────┘     │
            │                 │              │
            └─────────────────┘              │
                  (after resolution)        │
                                            │
                             (direct completion)
```

**Dependencies**:
- Database tables: users, helpers, tasks

**Run Only This File**:
```bash
npm test -- task-state-machine.test.ts
```

**If Failing**:
- Verify task table schema includes all status values
- Check helper_id relationship is properly constrained
- Ensure updated_at timestamp is tracked

---

### File 3: fee-payout-calculations.test.ts
**Focus**: Pricing and financial calculations

**Key Concepts**:
- Fare calculation formula
- Fee deduction logic
- Minimum fare enforcement
- Business multiplier application
- Payout balance tracking

**Calculation Formula**:
```
Base Calculation:
  subtotal = base_fare + (distance × per_km_rate) + (time × per_minute_rate)

Minimum Fare:
  if subtotal < minimum_fare:
    final_amount = minimum_fare
  else:
    final_amount = subtotal

Business Multiplier:
  if task_type == 'business':
    final_amount = final_amount × business_multiplier

Fee & Payout:
  platform_fee = round(final_amount × platform_fee_percent / 100)
  helper_earns = final_amount - platform_fee

Balance Tracking:
  available = sum(completed_payments.helper_payout) - sum(completed_payouts)
```

**Test Values** (from default pricing config):
- Base fare: ₹40
- Per km: ₹15
- Per minute: ₹2.5
- Minimum: ₹80
- Platform fee: 15%
- Business multiplier: 1.25x

**Dependencies**:
- Database tables: pricing_configs, payments, payouts

**Run Only This File**:
```bash
npm test -- fee-payout-calculations.test.ts
```

**If Failing**:
- Verify pricing_configs table has 'current' config
- Check payment_amounts match calculation logic
- Ensure rounding is correct (use Math.round)

---

### File 4: full-lifecycle.test.ts
**Focus**: Complete task workflow from creation to payout

**Workflow Phases**:

**Phase 1: Task Creation** (unassigned)
```
Customer creates task
  → task_id generated
  → status = unassigned
  → helper_id = null
```

**Phase 2: Helper Assignment** (confirmed)
```
Helper accepts request
  → task_request.status = accepted
  → task.status = confirmed
  → task.helper_id = assigned
```

**Phase 3: Task Progression** (started → otp_pending → in_progress)
```
Helper on the way: started
Helper arrived: otp_pending
OTP verified: in_progress
```

**Phase 4: Completion** (completed)
```
Work finished
  → task.status = completed
  → payment created with amounts
```

**Phase 5: Payout** (pending → completed)
```
Helper requests withdrawal
  → payout.status = pending
Admin processes
  → payout.status = completed
Balance updated
  → available = earned - paid
```

**Dependencies**:
- All database tables
- Complete schema with all relationships

**Run Only This File**:
```bash
npm test -- full-lifecycle.test.ts
```

**If Failing**:
- Verify all table relationships exist
- Check payment calculation matches fee logic
- Ensure payout queries aggregate correctly

---

### File 5: e2e-flows.test.ts
**Focus**: Real-world user scenarios

**Scenario 1: Customer Creates and Completes Task**
```
1. Customer registers
2. Customer creates task
3. System gets available helpers (sorted)
4. Customer selects helper
5. Helper accepts
6. Task confirmed and work begins
7. Task completed
8. Payment processed
9. Customer rates helper
```

**Scenario 2: Helper Workflow**
```
1. Helper registers
2. Task request received
3. Helper accepts
4. Work completed
5. Payment earned
6. Helper requests payout
7. Payout processed
8. Balance updated
```

**Scenario 3: Decline & Retry**
```
1. First helper declines
2. Second helper receives request
3. Second helper accepts
4. Task confirmed with second helper
```

**Scenario 4: Concurrent Tasks**
```
1. Two customers create tasks
2. Two helpers accept different tasks
3. Both tasks progress independently
4. Both create separate payments
5. Both helpers have separate payouts
```

**Dependencies**:
- All previous components working
- Complete user and task flows

**Run Only This File**:
```bash
npm test -- e2e-flows.test.ts
```

**If Failing**:
- Check helper selection logic
- Verify request/decline flow
- Ensure concurrent tasks don't interfere

---

## 🔧 Extending the Tests

### Add a New Test Case

**Example: Test minimum payout enforcement**

```typescript
// In fee-payout-calculations.test.ts

it('should reject payout requests below ₹100', async () => {
  // Arrange
  const helperId = uuidv4();
  const minimumPayout = 100;
  const requestedAmount = 50;

  // Act
  const canRequest = requestedAmount >= minimumPayout;

  // Assert
  expect(canRequest).toBe(false);
  expect(requestedAmount).toBeLessThan(minimumPayout);
});
```

### Add a New Test File

**Template: tests/new-feature.test.ts**

```typescript
import request from 'supertest';
import { initializeDatabase, getPool, closeDatabase } from '../src/config/database';
import { initializeRedis, getRedis, closeRedis } from '../src/config/redis';
import app from '../src/index';
import { v4 as uuidv4 } from 'uuid';

describe('New Feature Name', () => {
  let pool: any;
  let redis: any;

  beforeAll(async () => {
    await initializeDatabase();
    await initializeRedis();
    pool = getPool();
    redis = getRedis();

    // Create required tables
    // await pool.query('CREATE TABLE ...');
  });

  afterAll(async () => {
    // Clean up
    // await pool.query('DROP TABLE IF EXISTS ...');
    await closeDatabase();
    await closeRedis();
  });

  afterEach(async () => {
    await redis.flushdb();
    // await pool.query('DELETE FROM ...');
  });

  describe('Specific Functionality', () => {
    it('should do something', async () => {
      // Arrange: Setup
      // Act: Execute
      // Assert: Verify
    });
  });
});
```

### Common Test Patterns

**Pattern 1: Insert & Verify**
```typescript
it('should create record', async () => {
  const id = uuidv4();
  const result = await pool.query(
    'INSERT INTO users (id, name) VALUES ($1, $2) RETURNING *',
    [id, 'John']
  );
  expect(result.rows[0].name).toBe('John');
});
```

**Pattern 2: Update & Check**
```typescript
it('should update status', async () => {
  // First insert
  const id = uuidv4();
  await pool.query(
    'INSERT INTO tasks (id, status) VALUES ($1, $2)',
    [id, 'pending']
  );

  // Then update
  const result = await pool.query(
    'UPDATE tasks SET status = $1 WHERE id = $2 RETURNING *',
    ['completed', id]
  );

  // Verify
  expect(result.rows[0].status).toBe('completed');
});
```

**Pattern 3: Calculate & Assert**
```typescript
it('should calculate correctly', async () => {
  const distance = 5;
  const rate = 15;
  const cost = distance * rate;
  expect(cost).toBe(75);
});
```

**Pattern 4: Query Multiple Records**
```typescript
it('should sum earnings', async () => {
  // Insert multiple payments
  for (let i = 0; i < 3; i++) {
    await pool.query(
      'INSERT INTO payments (amount) VALUES ($1)',
      [100]
    );
  }

  // Query all
  const result = await pool.query('SELECT SUM(amount) FROM payments');
  expect(result.rows[0].sum).toBe('300');
});
```

---

## 🐛 Debugging Failed Tests

### Step 1: Run Test with Verbose Output
```bash
npm test -- --verbose matching-engine.test.ts
```

### Step 2: Run Single Test
```bash
npm test -- --testNamePattern="should score helpers by distance"
```

### Step 3: Add Console Logs
```typescript
it('should do something', async () => {
  const result = await pool.query('SELECT * FROM users');
  console.log('Query result:', result.rows); // Add this
  expect(result.rows.length).toBeGreaterThan(0);
});
```

### Step 4: Check Database State
```bash
# Connect directly to test database
psql sahayakh_test

# Run queries manually
SELECT * FROM users;
SELECT COUNT(*) FROM tasks;
```

### Step 5: Check Redis State
```bash
# Connect to Redis
redis-cli

# Check keys
KEYS *
GET request:*
```

### Step 6: Review Error Message

Common errors and solutions:

| Error | Cause | Solution |
|-------|-------|----------|
| `ECONNREFUSED 5432` | PostgreSQL not running | Start PostgreSQL |
| `ECONNREFUSED 6379` | Redis not running | Start Redis |
| `relation "users" does not exist` | Table not created | Check beforeAll |
| `duplicate key value` | UUID already exists | Use unique IDs |
| `null is not valid` | Missing required value | Check test data |
| `timeout` | Test takes too long | Increase jest timeout |

---

## 📈 Coverage Reports

### Generate Coverage Report
```bash
npm test -- --coverage

# Output:
# ✓ Statements: 80.5%
# ✓ Branches: 75.3%
# ✓ Functions: 85.2%
# ✓ Lines: 80.1%
```

### View HTML Coverage Report
```bash
# Generate
npm test -- --coverage

# View
open coverage/lcov-report/index.html

# Look for uncovered lines (red)
# Click file to see which lines need tests
```

### Increase Coverage

To improve coverage:

1. Find uncovered lines: `grep -r "E" coverage/lcov.info`
2. Write tests for those branches
3. Run coverage again
4. Repeat until coverage > 80%

---

## 🔄 Continuous Integration

### GitHub Actions Setup

Create `.github/workflows/test.yml`:

```yaml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    services:
      postgres:
        image: postgres:14
        env:
          POSTGRES_PASSWORD: test
          POSTGRES_DB: sahayakh_test
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
          - 5432:5432
      
      redis:
        image: redis:7
        options: >-
          --health-cmd "redis-cli ping"
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
          - 6379:6379

    steps:
      - uses: actions/checkout@v3
      
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
      
      - run: npm ci
      
      - run: npm test -- --coverage
      
      - uses: codecov/codecov-action@v3
        with:
          files: ./coverage/lcov.info
```

### Pre-commit Hook

Create `.git/hooks/pre-commit`:

```bash
#!/bin/bash
npm test -- --onlyChanged
if [ $? -ne 0 ]; then
  echo "❌ Tests failed. Commit aborted."
  exit 1
fi
echo "✅ Tests passed. Proceeding with commit."
```

Make executable:
```bash
chmod +x .git/hooks/pre-commit
```

---

## 📋 Checklist: Ready for Production

Before deploying to production:

- [ ] All 67+ tests pass: `npm test`
- [ ] Coverage > 80%: `npm test -- --coverage`
- [ ] No warnings or errors
- [ ] CI/CD pipeline green
- [ ] Database schema matches tests
- [ ] Redis is running
- [ ] .env.test has correct values
- [ ] Code reviewed by team
- [ ] Edge cases considered
- [ ] Documentation updated

---

## 🎓 Example: Writing a Complete Test

### Scenario: Test that helpers can't accept tasks while suspended

```typescript
describe('Suspension Enforcement', () => {
  it('should prevent suspended helpers from accepting tasks', async () => {
    // ARRANGE
    // 1. Create customer
    const customerId = uuidv4();
    const taskLocation = { latitude: 17.36, longitude: 78.47 };
    await pool.query(
      'INSERT INTO users (id, phone_number, name, role, location_point) VALUES ($1, $2, $3, $4, $5)',
      [customerId, '+919999999999', 'Customer', 'customer', JSON.stringify(taskLocation)]
    );

    // 2. Create suspended helper
    const helperUserId = uuidv4();
    const helperId = uuidv4();
    await pool.query(
      'INSERT INTO users (id, phone_number, name, role, location_point) VALUES ($1, $2, $3, $4, $5)',
      [helperUserId, '+919999999001', 'Helper', 'helper', JSON.stringify(taskLocation)]
    );
    await pool.query(
      'INSERT INTO helpers (id, user_id, helper_status) VALUES ($1, $2, $3)',
      [helperId, helperUserId, 'suspended']
    );

    // 3. Create task
    const taskId = uuidv4();
    await pool.query(
      'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
      [taskId, 'SKT00001', customerId, 'personal', 'cleaning', 'Task', JSON.stringify(taskLocation), 'Warangal', 'unassigned']
    );

    // ACT
    // Check helper status
    const helperResult = await pool.query(
      'SELECT helper_status FROM helpers WHERE id = $1',
      [helperId]
    );

    // ASSERT
    // Verify helper is suspended
    expect(helperResult.rows[0].helper_status).toBe('suspended');

    // Business logic: Suspended helpers should not be selected
    // (This would be enforced in the service layer)
  });
});
```

---

## 🚀 Final Verification

Run this to ensure everything works:

```bash
# 1. Run all tests
npm test

# 2. Check coverage
npm test -- --coverage

# 3. Run specific file
npm test -- matching-engine.test.ts

# 4. Run specific test
npm test -- --testNamePattern="should score helpers"

# Expected: All passing, coverage > 80%, clear output
```

---

**Ready to test!** 🎉

Start with `npm test` and work from there.
