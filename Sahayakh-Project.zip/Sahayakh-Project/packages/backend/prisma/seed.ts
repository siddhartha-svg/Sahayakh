import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding Sahayakh database with realistic sample data...\n');

  // Clear existing data (caution: destructive!)
  await prisma.chatMessage.deleteMany({});
  await prisma.notification.deleteMany({});
  await prisma.auditLog.deleteMany({});
  await prisma.helperSuspensionLog.deleteMany({});
  await prisma.review.deleteMany({});
  await prisma.dispute.deleteMany({});
  await prisma.taskStatusHistory.deleteMany({});
  await prisma.payout.deleteMany({});
  await prisma.payment.deleteMany({});
  await prisma.task.deleteMany({});
  await prisma.helperDocument.deleteMany({});
  await prisma.helper.deleteMany({});
  await prisma.pricingConfig.deleteMany({});
  await prisma.user.deleteMany({});

  console.log('✓ Cleared existing data\n');

  // ============================================
  // 1. CREATE PRICING CONFIG (sample from PRD)
  // ============================================
  console.log('📍 Creating pricing configuration...');
  const pricingConfig = await prisma.pricingConfig.create({
    data: {
      config_key: 'current',
      base_fare_rupees: 40,
      per_km_rate: 15,
      per_minute_rate: 2.5,
      minimum_fare_rupees: 80,
      cancellation_fee_rupees: 30,
      platform_fee_percent: 15,
      business_task_multiplier: 1.25,
      peak_hour_multiplier: 1.1,
      daily_bonus_tasks_required: 5,
      daily_bonus_amount: 100,
      effective_from: new Date('2024-01-01'),
    },
  });
  console.log(`✓ Pricing config created: ${pricingConfig.config_key}\n`);

  // ============================================
  // 2. CREATE USERS (Customers, Helpers, Admin)
  // ============================================
  console.log('👥 Creating users (customers, helpers, admins)...');

  // Sample Helper: Rohit Kumar (from PRD)
  const helperRohit = await prisma.user.create({
    data: {
      phone_number: '+919876543210',
      name: 'Rohit Kumar',
      role: 'helper',
      status: 'active',
      location_name: 'Hanamkonda, Warangal',
    },
  });

  // Sample Helper: Sneha Verma (from PRD)
  const helperSneha = await prisma.user.create({
    data: {
      phone_number: '+919876543211',
      name: 'Sneha Verma',
      role: 'helper',
      status: 'active',
      location_name: 'Warangal, Telangana',
    },
  });

  // Sample Helper: Anil Reddy
  const helperAnil = await prisma.user.create({
    data: {
      phone_number: '+919876543212',
      name: 'Anil Reddy',
      role: 'helper',
      status: 'active',
      location_name: 'Kazipet, Warangal',
    },
  });

  // Sample Helpers: Additional
  const helperPriya = await prisma.user.create({
    data: {
      phone_number: '+919876543213',
      name: 'Priya Singh',
      role: 'helper',
      status: 'active',
      location_name: 'Warangal',
    },
  });

  const helperRaj = await prisma.user.create({
    data: {
      phone_number: '+919876543214',
      name: 'Raj Patel',
      role: 'helper',
      status: 'suspended',
      location_name: 'Warangal',
    },
  });

  // Sample Customers
  const customerAlice = await prisma.user.create({
    data: {
      phone_number: '+918765432100',
      name: 'Alice Johnson',
      role: 'customer',
      status: 'active',
      location_name: 'Hanamkonda, Warangal',
    },
  });

  const customerBob = await prisma.user.create({
    data: {
      phone_number: '+918765432101',
      name: 'Bob Smith',
      role: 'customer',
      status: 'active',
      location_name: 'Warangal',
    },
  });

  const customerCarol = await prisma.user.create({
    data: {
      phone_number: '+918765432102',
      name: 'Carol Davis',
      role: 'customer',
      status: 'active',
      location_name: 'Kazipet, Warangal',
    },
  });

  const customerDave = await prisma.user.create({
    data: {
      phone_number: '+918765432103',
      name: 'Dave Miller',
      role: 'customer',
      status: 'active',
      location_name: 'Warangal',
    },
  });

  // Sample Admin
  const admin = await prisma.user.create({
    data: {
      email: 'admin@sahayakh.com',
      name: 'Admin User',
      role: 'admin',
      status: 'active',
    },
  });

  console.log(`✓ Created 5 helpers, 4 customers, 1 admin\n`);

  // ============================================
  // 3. CREATE HELPER PROFILES
  // ============================================
  console.log('⭐ Creating helper profiles...');

  const helperRohitProfile = await prisma.helper.create({
    data: {
      user_id: helperRohit.id,
      rating: 4.8,
      total_tasks: 150,
      average_response_time_minutes: 5,
      helper_status: 'online',
      verification_status: 'verified',
      background_check_status: 'cleared',
      bank_account_holder_name: 'Rohit Kumar',
      bank_account_number: 'XXXXXX1234',
      bank_ifsc_code: 'SBIN0001234',
      accepts_personal_tasks: true,
      accepts_business_tasks: false,
      preferred_categories: ['pickup_delivery', 'local_visit'],
      service_radius_km: 25,
    },
  });

  const helperSnehaProfile = await prisma.helper.create({
    data: {
      user_id: helperSneha.id,
      rating: 4.5,
      total_tasks: 95,
      average_response_time_minutes: 8,
      helper_status: 'offline',
      verification_status: 'verified',
      background_check_status: 'cleared',
      bank_account_holder_name: 'Sneha Verma',
      upi_id: 'sneha.verma@upi',
      accepts_personal_tasks: false,
      accepts_business_tasks: true,
      preferred_categories: ['vendor_pickup', 'client_delivery'],
      service_radius_km: 30,
    },
  });

  const helperAnilProfile = await prisma.helper.create({
    data: {
      user_id: helperAnil.id,
      rating: 4.3,
      total_tasks: 78,
      average_response_time_minutes: 10,
      helper_status: 'online',
      verification_status: 'verified',
      background_check_status: 'cleared',
      bank_account_holder_name: 'Anil Reddy',
      bank_account_number: 'XXXXXX5678',
      bank_ifsc_code: 'ICIC0000001',
      accepts_personal_tasks: true,
      accepts_business_tasks: true,
      preferred_categories: ['pickup_delivery', 'document_work', 'site_visit'],
      service_radius_km: 20,
    },
  });

  const helperPriyaProfile = await prisma.helper.create({
    data: {
      user_id: helperPriya.id,
      rating: 4.6,
      total_tasks: 120,
      average_response_time_minutes: 6,
      helper_status: 'online',
      verification_status: 'verified',
      background_check_status: 'cleared',
      upi_id: 'priya.singh@upi',
      accepts_personal_tasks: true,
      accepts_business_tasks: true,
      preferred_categories: ['pickup_delivery', 'local_visit', 'document_work'],
      service_radius_km: 22,
    },
  });

  const helperRajProfile = await prisma.helper.create({
    data: {
      user_id: helperRaj.id,
      rating: 2.1,
      total_tasks: 45,
      average_response_time_minutes: 45,
      helper_status: 'suspended',
      verification_status: 'verified',
      background_check_status: 'red_flag',
      accepts_personal_tasks: true,
      accepts_business_tasks: false,
      service_radius_km: 15,
    },
  });

  console.log(`✓ Created 5 helper profiles\n`);

  // ============================================
  // 4. CREATE HELPER DOCUMENTS
  // ============================================
  console.log('📄 Creating helper documents...');

  await prisma.helperDocument.createMany({
    data: [
      {
        helper_id: helperRohitProfile.id,
        document_type: 'aadhaar',
        status: 'verified',
        document_number: 'XXXX1234XXXX',
        verified_by: admin.id,
        verified_at: new Date('2024-01-15'),
      },
      {
        helper_id: helperRohitProfile.id,
        document_type: 'pan',
        status: 'verified',
        document_number: 'XXXXXX1234X',
        verified_by: admin.id,
        verified_at: new Date('2024-01-15'),
      },
      {
        helper_id: helperSnehaProfile.id,
        document_type: 'dl',
        status: 'verified',
        document_number: 'DL-12345678',
        verified_by: admin.id,
        verified_at: new Date('2024-01-10'),
      },
      {
        helper_id: helperAnilProfile.id,
        document_type: 'aadhaar',
        status: 'verified',
        document_number: 'XXXX5678XXXX',
        verified_by: admin.id,
        verified_at: new Date('2024-01-12'),
      },
    ],
  });

  console.log(`✓ Created helper documents\n`);

  // ============================================
  // 5. CREATE TASKS (Various statuses)
  // ============================================
  console.log('📋 Creating tasks...');

  const tasks = [];

  // Completed tasks (with helper assigned)
  for (let i = 1; i <= 10; i++) {
    const task = await prisma.task.create({
      data: {
        task_id_display: `SKT${String(i).padStart(5, '0')}`,
        customer_id: [customerAlice.id, customerBob.id, customerCarol.id, customerDave.id][
          i % 4
        ],
        helper_id: [helperRohit.id, helperSneha.id, helperAnil.id, helperPriya.id][i % 4],
        task_type: i % 2 === 0 ? 'personal' : 'business',
        category:
          i % 3 === 0
            ? 'pickup_delivery'
            : i % 3 === 1
              ? 'local_visit'
              : 'document_work',
        status: 'completed',
        description: `Task ${i}: ${
          i % 2 === 0
            ? 'Pick up medicine from Apollo Pharmacy and deliver'
            : 'Submit documents at municipal office'
        }`,
        location_name: 'Hanamkonda, Warangal',
        budget_min: 100,
        budget_max: 300,
        final_amount: 150 + i * 10,
        created_at: new Date(Date.now() - 1000 * 60 * 60 * 24 * (10 - i)), // Past dates
        completed_at: new Date(Date.now() - 1000 * 60 * 60 * (10 - i)),
      },
    });
    tasks.push(task);
  }

  // In progress tasks
  for (let i = 11; i <= 15; i++) {
    const task = await prisma.task.create({
      data: {
        task_id_display: `SKT${String(i).padStart(5, '0')}`,
        customer_id: [customerAlice.id, customerBob.id, customerCarol.id][i % 3],
        helper_id: [helperRohit.id, helperAnil.id, helperPriya.id][i % 3],
        task_type: 'personal',
        category: 'local_visit',
        status: 'in_progress',
        description: `Task ${i}: Visit medical center and collect prescription`,
        location_name: 'Warangal, Telangana',
        budget_min: 150,
        budget_max: 250,
        created_at: new Date(Date.now() - 1000 * 60 * 60 * 2), // Recent
        started_at: new Date(Date.now() - 1000 * 60 * 30),
      },
    });
    tasks.push(task);
  }

  // Unassigned tasks
  for (let i = 16; i <= 20; i++) {
    const task = await prisma.task.create({
      data: {
        task_id_display: `SKT${String(i).padStart(5, '0')}`,
        customer_id: [customerAlice.id, customerCarol.id][i % 2],
        task_type: i % 2 === 0 ? 'business' : 'personal',
        category: i % 2 === 0 ? 'vendor_pickup' : 'pickup_delivery',
        status: 'unassigned',
        description: `Task ${i}: ${
          i % 2 === 0
            ? 'Pick up supplies from vendor'
            : 'Deliver package to city center'
        }`,
        location_name: 'Kazipet, Warangal',
        budget_min: 200,
        budget_max: 400,
        created_at: new Date(Date.now() - 1000 * 60 * 60 * 1), // Very recent
      },
    });
    tasks.push(task);
  }

  // Disputed task
  const disputedTask = await prisma.task.create({
    data: {
      task_id_display: 'SKT00021',
      customer_id: customerDave.id,
      helper_id: helperRohit.id,
      task_type: 'personal',
      category: 'document_work',
      status: 'disputed',
      description: 'Disputed task - Payment discrepancy',
      location_name: 'Hanamkonda, Warangal',
      budget_min: 100,
      budget_max: 200,
      final_amount: 150,
      created_at: new Date(Date.now() - 1000 * 60 * 60 * 48),
      completed_at: new Date(Date.now() - 1000 * 60 * 60 * 24),
    },
  });
  tasks.push(disputedTask);

  // Cancelled task
  const cancelledTask = await prisma.task.create({
    data: {
      task_id_display: 'SKT00022',
      customer_id: customerBob.id,
      task_type: 'personal',
      category: 'pickup_delivery',
      status: 'cancelled',
      description: 'Task cancelled by customer',
      location_name: 'Warangal, Telangana',
      budget_min: 150,
      budget_max: 300,
      created_at: new Date(Date.now() - 1000 * 60 * 60 * 96),
    },
  });
  tasks.push(cancelledTask);

  console.log(`✓ Created ${tasks.length} tasks\n`);

  // ============================================
  // 6. CREATE PAYMENTS
  // ============================================
  console.log('💳 Creating payments...');

  const payments = [];
  for (let i = 0; i < 10; i++) {
    const task = tasks[i]; // Use completed tasks
    const amount = Number(task.final_amount!) || 200;

    const payment = await prisma.payment.create({
      data: {
        task_id: task.id,
        customer_id: task.customer_id,
        final_amount: amount,
        task_amount: amount - 20,
        distance_surcharge: 10,
        time_surcharge: 10,
        peak_multiplier: 1.0,
        platform_fee_amount: Math.round(amount * 0.15 * 100) / 100,
        helper_payout_amount: Math.round(amount * 0.85 * 100) / 100,
        payment_method: i % 2 === 0 ? 'upi' : 'card',
        status: 'completed',
        razorpay_order_id: `order_${i}_${Date.now()}`,
        razorpay_payment_id: `pay_${i}_${Date.now()}`,
        completed_at: task.completed_at,
      },
    });
    payments.push(payment);
  }

  console.log(`✓ Created ${payments.length} payments\n`);

  // ============================================
  // 7. CREATE PAYOUTS
  // ============================================
  console.log('💰 Creating payouts...');

  const payout1 = await prisma.payout.create({
    data: {
      payout_id_display: 'P-001',
      helper_id: helperRohitProfile.id,
      total_amount: 500,
      payout_method: 'bank_transfer',
      status: 'completed',
      bank_account_number: 'XXXXXX1234',
      task_ids: [tasks[0].id, tasks[4].id, tasks[8].id],
      processed_at: new Date(Date.now() - 1000 * 60 * 60 * 24),
    },
  });

  const payout2 = await prisma.payout.create({
    data: {
      payout_id_display: 'P-002',
      helper_id: helperSnehaProfile.id,
      total_amount: 450,
      payout_method: 'upi',
      status: 'completed',
      upi_id: 'sneha.verma@upi',
      task_ids: [tasks[1].id, tasks[5].id, tasks[9].id],
      processed_at: new Date(Date.now() - 1000 * 60 * 60 * 48),
    },
  });

  const payout3 = await prisma.payout.create({
    data: {
      payout_id_display: 'P-003',
      helper_id: helperAnilProfile.id,
      total_amount: 300,
      payout_method: 'bank_transfer',
      status: 'pending',
      bank_account_number: 'XXXXXX5678',
      task_ids: [tasks[2].id, tasks[6].id],
    },
  });

  console.log(`✓ Created 3 payouts\n`);

  // ============================================
  // 8. CREATE DISPUTES
  // ============================================
  console.log('⚖️ Creating disputes...');

  const dispute1 = await prisma.dispute.create({
    data: {
      dispute_id_display: 'D-001',
      task_id: disputedTask.id,
      raised_by: customerDave.id,
      assigned_to_admin: admin.id,
      category: 'pricing',
      status: 'investigating',
      evidence_urls: [
        'https://example.com/evidence1.jpg',
        'https://example.com/evidence2.jpg',
      ],
      messages: [
        'Customer: Amount charged is higher than agreed',
        'Helper: System calculated surge pricing',
      ],
    },
  });

  const dispute2 = await prisma.dispute.create({
    data: {
      dispute_id_display: 'D-002',
      task_id: tasks[3].id,
      raised_by: [customerAlice.id, customerBob.id, customerCarol.id][Math.floor(Math.random() * 3)],
      category: 'quality',
      status: 'open',
      evidence_urls: ['https://example.com/photo.jpg'],
      messages: [
        'Customer: Task not completed properly',
      ],
    },
  });

  console.log(`✓ Created 2 disputes\n`);

  // ============================================
  // 9. CREATE REVIEWS
  // ============================================
  console.log('⭐ Creating reviews...');

  for (let i = 0; i < 8; i++) {
    const task = tasks[i]; // Use completed tasks
    const helper = await prisma.user.findUnique({
      where: { id: task.helper_id! },
      include: { helper: true },
    });

    await prisma.review.create({
      data: {
        task_id: task.id,
        helper_id: helper!.id,
        customer_to_helper_rating: ['five', 'five', 'four', 'four', 'five', 'three', 'four', 'five'][i] as any,
        customer_to_helper_text: [
          'Great service, very professional',
          'Delivered on time',
          'Good but could be faster',
          'Average experience',
          'Excellent work',
          'Not satisfied with quality',
          'Good service overall',
          'Very happy with the work',
        ][i],
        helper_to_customer_rating: ['five', 'five', 'four', 'three', 'five', 'four', 'four', 'five'][i] as any,
        helper_to_customer_text: [
          'Pleasant customer, clear instructions',
          'Easy pickup location',
          'Customer was cooperative',
          'Poor communication',
          'Great experience',
          'Customer was impatient',
          'Good cooperation',
          'Excellent customer',
        ][i],
      },
    });
  }

  console.log(`✓ Created 8 reviews\n`);

  // ============================================
  // 10. CREATE TASK STATUS HISTORY
  // ============================================
  console.log('📊 Creating task status history...');

  for (const task of tasks.slice(0, 5)) {
    await prisma.taskStatusHistory.create({
      data: {
        task_id: task.id,
        previous_status: 'unassigned',
        new_status: 'assigned',
        created_at: new Date(task.created_at!.getTime() + 1000 * 60 * 5),
      },
    });

    await prisma.taskStatusHistory.create({
      data: {
        task_id: task.id,
        previous_status: 'assigned',
        new_status: 'on_the_way',
        created_at: new Date(task.created_at!.getTime() + 1000 * 60 * 10),
      },
    });

    if (task.status === 'completed') {
      await prisma.taskStatusHistory.create({
        data: {
          task_id: task.id,
          previous_status: 'in_progress',
          new_status: 'review',
          created_at: new Date(task.completed_at!.getTime() - 1000 * 60 * 10),
        },
      });

      await prisma.taskStatusHistory.create({
        data: {
          task_id: task.id,
          previous_status: 'review',
          new_status: 'completed',
          otp_verified: true,
          distance_traveled_km: 5,
          elapsed_minutes: 45,
          created_at: task.completed_at!,
        },
      });
    }
  }

  console.log(`✓ Created task status history\n`);

  // ============================================
  // 11. CREATE NOTIFICATIONS
  // ============================================
  console.log('🔔 Creating notifications...');

  await prisma.notification.createMany({
    data: [
      {
        user_id: helperRohit.id,
        notification_type: 'task_assigned',
        title: 'New task assigned',
        body: 'You have a new task from Alice',
        related_task_id: tasks[0].id,
      },
      {
        user_id: customerAlice.id,
        notification_type: 'task_started',
        title: 'Task started',
        body: 'Rohit has started working on your task',
        related_task_id: tasks[0].id,
      },
      {
        user_id: customerAlice.id,
        notification_type: 'task_completed',
        title: 'Task completed',
        body: 'Your task has been completed',
        related_task_id: tasks[0].id,
        is_read: true,
      },
      {
        user_id: helperRohit.id,
        notification_type: 'payment_received',
        title: 'Payment received',
        body: 'You received ₹127.50 for task SKT00001',
      },
      {
        user_id: customerDave.id,
        notification_type: 'dispute_raised',
        title: 'Dispute raised',
        body: 'Dispute D-001 has been raised for your task',
        related_task_id: disputedTask.id,
      },
    ],
  });

  console.log(`✓ Created notifications\n`);

  // ============================================
  // Summary
  // ============================================
  console.log('✨ Seed completed successfully!\n');
  console.log('📊 Data Summary:');
  console.log(`   - Users: 10 (5 helpers, 4 customers, 1 admin)`);
  console.log(`   - Helper Profiles: 5`);
  console.log(`   - Helper Documents: 4`);
  console.log(`   - Tasks: ${tasks.length} (various statuses)`);
  console.log(`   - Payments: ${payments.length}`);
  console.log(`   - Payouts: 3`);
  console.log(`   - Disputes: 2`);
  console.log(`   - Reviews: 8`);
  console.log(`   - Notifications: 5`);
  console.log(`   - Pricing Config: 1`);
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error('❌ Seed failed:', e);
    await prisma.$disconnect();
    process.exit(1);
  });
