# Sahayakh Backend API

Node.js + Express REST API for the Sahayakh hyperlocal task marketplace.

## Features

- ✅ Phone + OTP authentication (customers & helpers)
- ✅ Email + password admin login
- ✅ JWT access & refresh tokens
- ✅ Rate limiting on OTP requests
- ✅ PostgreSQL database
- ✅ Redis caching
- ✅ Socket.IO real-time support (prepared)
- ✅ Type-safe TypeScript
- ✅ Comprehensive test coverage

## Setup

### 1. Environment Configuration

```bash
cp .env.example .env
```

**Required Variables:**
```env
NODE_ENV=development
PORT=3000
DATABASE_URL=postgresql://sahayakh:password@localhost:5432/sahayakh_dev
REDIS_URL=redis://localhost:6379/0
JWT_SECRET=your-secret-key
JWT_REFRESH_SECRET=your-refresh-secret
```

### 2. Database Setup

```bash
# Create database
createdb sahayakh_dev

# Run schema migration
psql sahayakh_dev < ../../001_sahayakh_initial_schema.sql

# Verify tables
psql sahayakh_dev -c "\dt"
```

### 3. Start Services

```bash
# Using Docker Compose (recommended)
docker-compose up

# Or manual startup
npm install
npm run dev
```

## API Endpoints

### Authentication

#### Register (Phone + OTP)
```
POST /api/auth/register
Content-Type: application/json

{
  "phone_number": "+919876543210",
  "name": "John Doe",
  "role": "customer" | "helper"
}

Response:
{
  "otp_sent": true,
  "expires_in": 120,
  "otp": "123456" // (dev only)
}
```

#### Verify OTP
```
POST /api/auth/verify-otp
Content-Type: application/json

{
  "phone_number": "+919876543210",
  "otp_code": "123456"
}

Response:
{
  "access_token": "eyJhbGc...",
  "refresh_token": "eyJhbGc...",
  "user_id": "uuid",
  "role": "customer",
  "user": { ... }
}
```

#### Refresh Token
```
POST /api/auth/refresh
Content-Type: application/json

{
  "refresh_token": "eyJhbGc..."
}

Response:
{
  "access_token": "eyJhbGc...",
  "refresh_token": "eyJhbGc..."
}
```

#### Get Current User
```
GET /api/auth/me
Authorization: Bearer <access_token>

Response:
{
  "id": "uuid",
  "name": "John Doe",
  "phone_number": "+919876543210",
  "role": "customer",
  "status": "active"
}
```

#### Logout
```
POST /api/auth/logout
Authorization: Bearer <access_token>

Response:
{
  "success": true,
  "message": "Logged out successfully"
}
```

### Health Check

```
GET /health

Response:
{
  "status": "ok",
  "timestamp": "2026-09-22T10:30:00.000Z"
}
```

## Architecture

### Directory Structure

```
src/
├── config/              # Configuration management
│   ├── database.ts      # PostgreSQL connection pool
│   ├── redis.ts         # Redis client
│   └── index.ts         # Environment variables & validation
├── middleware/          # Express middleware
│   ├── auth.ts          # JWT verification
│   ├── error.ts         # Error handling
│   └── cors.ts          # CORS (future)
├── utils/               # Utility functions
│   ├── jwt.ts           # Token signing/verification
│   └── otp.ts           # OTP generation/hashing
├── services/            # Business logic
│   ├── auth.ts          # Authentication flows
│   ├── otp.ts           # OTP management
│   └── user.ts          # User queries
├── routes/              # REST endpoints
│   └── auth.ts          # Auth endpoints
├── types.ts             # Backend-specific types
└── index.ts             # Express app setup
```

### Authentication Flow

#### Phone + OTP (Customers & Helpers)

1. **Register**: User provides phone + name + role
   - System checks for duplicates (PHONE_ALREADY_EXISTS)
   - Creates user in database
   - Generates 6-digit OTP
   - Stores hashed OTP in Redis (TTL: 2 hours)
   - Sends OTP via SMS (dev: console log)

2. **Verify OTP**: User submits phone + OTP
   - Retrieves OTP from Redis
   - Compares with bcrypt hash (secure against timing attacks)
   - Increments attempt counter (max 3)
   - On success: Returns JWT pair

3. **Token Usage**: Client includes JWT in Authorization header
   - `Authorization: Bearer <access_token>`
   - Valid for 1 hour
   - After expiry, use refresh token to get new pair

4. **Refresh**: Client submits refresh token
   - Verifies refresh token signature (30-day expiry)
   - Issues new access + refresh token pair

#### Email + Password (Admin)

- Future implementation
- Will use bcrypt for password hashing
- Separate from phone-based flow

### Rate Limiting

- **OTP Requests**: 10 per hour per phone number
  - Tracked in Redis: `sahayakh:otp_requests:{phone}`
  - Returns 429 when exceeded

- **Failed Logins**: 10 per 15 minutes per IP
  - Handled by express-rate-limit middleware

- **OTP Attempts**: 3 per request cycle
  - Tracked in OTP data structure
  - Locked out after max attempts

### Error Handling

All errors return standard format:

```json
{
  "error_code": "ERROR_CODE",
  "message": "Human-readable message",
  "status": 400,
  "details": {}
}
```

**Common Error Codes:**
- `INVALID_OTP` - OTP doesn't match
- `OTP_EXPIRED` - OTP not found (expired)
- `TOO_MANY_ATTEMPTS` - Max OTP attempts exceeded
- `PHONE_ALREADY_EXISTS` - Phone already registered
- `INVALID_TOKEN` - Token signature invalid or expired
- `UNAUTHORIZED` - No/invalid authorization header
- `RATE_LIMIT_EXCEEDED` - Too many requests
- `USER_NOT_FOUND` - User doesn't exist

## Testing

### Run Tests

```bash
# All tests
npm run test

# Watch mode
npm run test:watch

# Coverage report
npm run test:coverage
```

### Test Coverage

- **OTP Service**: Generation, hashing, verification, rate limiting
- **Auth Endpoints**: Register, verify-otp, refresh, me, logout
- **Error Cases**: Invalid inputs, expired tokens, rate limits
- **Database**: User creation, lookup, updates

### Test Database

Tests use separate database `sahayakh_test` with real PostgreSQL & Redis:
- Automatic table creation in setup
- Automatic cleanup after tests
- No data pollution between test runs

## Development

### Code Style

```bash
# Lint
npm run lint

# Fix linting issues
npm run lint:fix

# Type check
npm run type-check

# Format code
npx prettier --write src
```

### Environment Variables

**Development:**
```env
NODE_ENV=development
LOG_LEVEL=debug
CORS_ORIGINS=http://localhost:3000,http://localhost:5173
```

**Testing:**
```env
NODE_ENV=test
DATABASE_URL=postgresql://test:test@localhost:5432/sahayakh_test
REDIS_URL=redis://localhost:6379/1
```

**Production:**
```env
NODE_ENV=production
LOG_LEVEL=info
CORS_ORIGINS=https://yourdomain.com
JWT_SECRET=<strong-secret>
JWT_REFRESH_SECRET=<strong-secret>
```

## Dependencies

### Core
- **express** (v4.18.2) - Web framework
- **pg** (v8.11.1) - PostgreSQL driver
- **ioredis** (v5.3.2) - Redis client
- **jsonwebtoken** (v9.1.2) - JWT
- **bcryptjs** (v2.4.3) - Password/OTP hashing
- **joi** (v17.11.0) - Validation

### Middleware
- **helmet** (v7.1.0) - Security headers
- **cors** (v2.8.5) - CORS handling
- **express-rate-limit** (v7.0.0) - Rate limiting

### Utilities
- **dotenv** (v16.3.1) - Environment variables
- **uuid** (v9.0.1) - UUID generation
- **pino** (v8.17.0) - Logging

## Next Steps

1. **Additional Endpoints**: Tasks, payments, reviews, etc. (see SAHAYAKH_SYSTEM_ARCHITECTURE.md)
2. **Admin Login**: Email + password authentication
3. **Socket.IO**: Real-time location tracking, notifications
4. **Payment Gateway**: Razorpay integration
5. **Image Uploads**: AWS S3 integration
6. **SMS Delivery**: Twilio integration
7. **Logging**: Structured logging with Pino
8. **Database Migrations**: Tool for versioned schema changes

## Troubleshooting

### "Cannot connect to database"
- Check DATABASE_URL in .env
- Verify PostgreSQL is running: `psql --version`
- Check credentials: `psql -U sahayakh -d sahayakh_dev`

### "Cannot connect to Redis"
- Check REDIS_URL in .env
- Verify Redis is running: `redis-cli ping` (should return PONG)
- Check port 6379 is open

### "Port 3000 already in use"
- Change PORT in .env: `PORT=3001`
- Or kill process: `lsof -ti:3000 | xargs kill -9`

### Tests failing
- Ensure PostgreSQL and Redis are running
- Check .env.test for correct database URL
- Clear Redis: `redis-cli FLUSHALL`
- Recreate database: `dropdb sahayakh_test && createdb sahayakh_test`

## CI/CD

Tests run automatically on GitHub Actions:
1. Lint with ESLint
2. Type check with TypeScript
3. Run Jest tests with PostgreSQL + Redis services
4. Upload coverage to Codecov
5. Build Docker image

## License

MIT

## Support

See [MONOREPO_README.md](../../MONOREPO_README.md) for system overview and deployment guide.
