import { Server as SocketIOServer } from 'socket.io';
import prisma from '../config/prisma';
import * as requestService from './request';
import * as locationTracking from './location-tracking';

const REQUEST_EXPIRY_SECONDS = 45;
const REQUEST_EXPIRY_MS = REQUEST_EXPIRY_SECONDS * 1000;

// Track active expiry timers to prevent duplicates
const activeTimers: Map<string, NodeJS.Timeout> = new Map();
const getTimerKey = (taskId: string, helperId: string) => `${taskId}:${helperId}`;

export const broadcastTaskRequestToHelper = async (
  taskId: string,
  helperId: string,
  io: SocketIOServer,
  pricingConfig?: any,
): Promise<string> => {
  try {
    // Get pricing config if not provided
    let config = pricingConfig;
    if (!config) {
      config = await prisma.pricingConfig.findUnique({
        where: { config_key: 'current' },
      });
    }

    if (!config) {
      console.error('Pricing config not found');
      throw new Error('Pricing configuration not found');
    }

    // Send task request to helper via service
    const { requestId, requestPayload } = await requestService.sendTaskRequest(
      taskId,
      helperId,
      config,
    );

    // Emit Socket.IO event to specific helper
    io.of('/helpers').to(`helper:${helperId}`).emit('request:new', {
      ...requestPayload,
      action_required: true,
      countdown_starts: new Date().toISOString(),
    });

    console.log(
      `[Socket] Broadcast task ${taskId} to helper ${helperId}, expires in ${REQUEST_EXPIRY_SECONDS}s`,
    );

    // Schedule auto-expiry with 45-second timer
    scheduleRequestExpiry(taskId, helperId, io);

    return requestId;
  } catch (err) {
    console.error('[Socket] Error broadcasting task request:', err);
    throw err;
  }
};

export const scheduleRequestExpiry = (taskId: string, helperId: string, io: SocketIOServer) => {
  const timerKey = getTimerKey(taskId, helperId);

  // Clear any existing timer to prevent duplicates
  if (activeTimers.has(timerKey)) {
    clearTimeout(activeTimers.get(timerKey)!);
    activeTimers.delete(timerKey);
  }

  const timer = setTimeout(async () => {
    try {
      activeTimers.delete(timerKey);

      // Check if request is still pending
      const stillPending = await prisma.taskRequest.findFirst({
        where: {
          task_id: taskId,
          helper_id: helperId,
          status: 'pending',
        },
      });

      if (!stillPending) {
        return; // Request was already handled
      }

      console.log(`[Socket] Request expired: task ${taskId}, helper ${helperId}`);

      // Mark as expired
      await requestService.handleRequestExpiry(taskId, helperId);

      // Notify helper that request expired
      io.of('/helpers').to(`helper:${helperId}`).emit('request:expired', {
        request_id: stillPending.id,
        task_id: taskId,
      });

      // Notify customer that request expired
      io.of('/customers').to(`task:${taskId}`).emit('request:expired', {
        task_id: taskId,
        message: 'No response from helper, finding next one...',
      });

      // Auto-requeue to next available helper
      const nextHelper = await requestService.findNextAvailableHelper(taskId);
      if (nextHelper) {
        console.log(`[Socket] Auto-requeue: task ${taskId} -> helper ${nextHelper.id}`);
        await broadcastTaskRequestToHelper(taskId, nextHelper.id, io);
      } else {
        // No more helpers available
        console.log(`[Socket] No more helpers available for task ${taskId}`);

        io.of('/customers').to(`task:${taskId}`).emit('request:no_helpers', {
          task_id: taskId,
          message: 'No helpers available. Task returned to unassigned.',
        });
      }
    } catch (err) {
      console.error('[Socket] Error handling request expiry:', err);
    }
  }, REQUEST_EXPIRY_MS);

  activeTimers.set(timerKey, timer);
};

export const notifyTaskAccepted = (
  taskId: string,
  helperId: string,
  helperName: string,
  io: SocketIOServer,
) => {
  // Notify customer that helper accepted
  io.of('/customers').to(`task:${taskId}`).emit('request:accepted', {
    task_id: taskId,
    helper_id: helperId,
    helper_name: helperName,
    status: 'assigned',
  });
};

export const notifyTaskDeclined = (
  taskId: string,
  reason: string | undefined,
  io: SocketIOServer,
) => {
  // Notify customer that request was declined
  io.of('/customers').to(`task:${taskId}`).emit('request:declined', {
    task_id: taskId,
    reason: reason || 'Helper declined',
  });
};

// Clean up timer when request is handled
export const clearRequestTimer = (taskId: string, helperId: string) => {
  const timerKey = getTimerKey(taskId, helperId);
  if (activeTimers.has(timerKey)) {
    clearTimeout(activeTimers.get(timerKey)!);
    activeTimers.delete(timerKey);
  }
};

/**
 * Handle location update from helper
 * Called when helper emits 'task:request_location' event
 */
export const handleLocationUpdate = async (
  taskId: string,
  helperId: string,
  latitude: number,
  longitude: number,
  accuracy_meters: number,
  io: SocketIOServer,
): Promise<void> => {
  try {
    // Store location ping in Redis
    const newPing = await locationTracking.storeLocationPing(
      taskId,
      helperId,
      latitude,
      longitude,
      accuracy_meters,
    );

    // Check if change is significant enough to broadcast
    const shouldBroadcast = await locationTracking.hasSignificantChange(
      taskId,
      newPing,
    );

    if (shouldBroadcast) {
      // Broadcast to customer
      locationTracking.broadcastLocationToCustomer(taskId, io, newPing);

      console.log(
        `[Location] Updated task ${taskId}: ${newPing.distance_to_customer_m}m away, ETA ${newPing.eta_minutes} min`,
      );
    }
  } catch (err) {
    console.error('[Location] Error handling location update:', err);
    // Don't throw - location updates should not break the request flow
  }
};

/**
 * Handle customer reconnection
 * Send last known location immediately so map renders without waiting
 */
export const handleCustomerReconnect = async (
  socket: any,
  taskId: string,
): Promise<void> => {
  try {
    await locationTracking.reconnectLocationHandler(socket, taskId);
  } catch (err) {
    console.error('[Location] Error handling customer reconnect:', err);
  }
};

/**
 * Clean up location tracking when task completes
 * Called when task transitions to 'completed' state
 */
export const handleTaskCompletion = async (
  taskId: string,
  io: SocketIOServer,
): Promise<void> => {
  try {
    // Delete location data from Redis
    await locationTracking.cleanupTaskLocations(taskId);

    // Notify customer that location tracking ended
    io.of('/customers').to(`task:${taskId}`).emit('location:tracking_ended', {
      task_id: taskId,
    });

    console.log(`[Location] Cleaned up tracking for task ${taskId}`);
  } catch (err) {
    console.error('[Location] Error handling task completion:', err);
  }
};
