import redis from '../config/redis';
import prisma from '../config/prisma';
import { calculateDistance, estimateETA, validateLocation } from '../utils/location';
import { AppError } from '../middleware/error';

const LOCATION_TTL_SECONDS = 30 * 60; // 30 minutes
const DISTANCE_THRESHOLD_METERS = 10; // 10 meters movement threshold
const ETA_CHANGE_THRESHOLD_MINUTES = 1; // 1 minute ETA change threshold

export interface LocationPing {
  helper_lat: number;
  helper_lng: number;
  accuracy_m: number;
  timestamp: string;
  distance_to_customer_m: number;
  eta_minutes: number;
}

export interface LastLocationCache {
  lat: number;
  lng: number;
  eta_minutes: number;
}

/**
 * Store a location ping in Redis and calculate distance/ETA to task
 * Returns location data ready for broadcast
 */
export const storeLocationPing = async (
  taskId: string,
  helperId: string,
  latitude: number,
  longitude: number,
  accuracy_meters: number,
): Promise<LocationPing> => {
  // Validate location within bounds
  if (!validateLocation(latitude, longitude)) {
    throw new AppError(
      'INVALID_LOCATION',
      'Location outside Warangal service area bounds',
      400,
    );
  }

  // Get task details to calculate distance
  const task = await prisma.task.findUnique({
    where: { id: taskId },
    select: {
      location_point: true,
      helper_id: true,
    },
  });

  if (!task) {
    throw new AppError('TASK_NOT_FOUND', 'Task not found', 404);
  }

  if (task.helper_id !== helperId) {
    throw new AppError(
      'UNAUTHORIZED',
      'Helper not assigned to this task',
      403,
    );
  }

  // Parse task location
  const taskLocation = JSON.parse(task.location_point || '{}');
  if (!taskLocation.latitude || !taskLocation.longitude) {
    throw new AppError(
      'INVALID_TASK_LOCATION',
      'Task location not found',
      400,
    );
  }

  // Calculate distance in meters (Haversine returns km)
  const distanceKm = calculateDistance(
    latitude,
    longitude,
    taskLocation.latitude,
    taskLocation.longitude,
  );
  const distanceMeters = Math.round(distanceKm * 1000);

  // Calculate ETA in minutes
  const etaMinutes = Math.round(estimateETA(distanceKm));

  // Create location ping object
  const ping: LocationPing = {
    helper_lat: latitude,
    helper_lng: longitude,
    accuracy_m: accuracy_meters,
    timestamp: new Date().toISOString(),
    distance_to_customer_m: distanceMeters,
    eta_minutes: etaMinutes,
  };

  // Store in Redis with TTL
  const redisKey = `tasks:locations:${taskId}`;
  await redis.setex(
    redisKey,
    LOCATION_TTL_SECONDS,
    JSON.stringify(ping),
  );

  return ping;
};

/**
 * Check if location has changed significantly since last ping
 * Returns true if moved >10m OR ETA changed >1 min
 */
export const hasSignificantChange = async (
  taskId: string,
  newPing: LocationPing,
): Promise<boolean> => {
  const lastPing = await getLastLocationPing(taskId);
  if (!lastPing) {
    // No previous ping, always broadcast
    return true;
  }

  // Check distance change
  const previousDistanceMeters = lastPing.distance_to_customer_m || 0;
  const distanceChange = Math.abs(
    newPing.distance_to_customer_m - previousDistanceMeters,
  );

  if (distanceChange >= DISTANCE_THRESHOLD_METERS) {
    return true; // Moved >10m
  }

  // Check ETA change
  const etaChange = Math.abs(newPing.eta_minutes - (lastPing.eta_minutes || 0));
  if (etaChange >= ETA_CHANGE_THRESHOLD_MINUTES) {
    return true; // ETA changed >1 min
  }

  return false; // No significant change
};

/**
 * Retrieve the last location ping from Redis
 */
export const getLastLocationPing = async (
  taskId: string,
): Promise<LocationPing | null> => {
  const redisKey = `tasks:locations:${taskId}`;
  const cached = await redis.get(redisKey);

  if (!cached) {
    return null;
  }

  try {
    return JSON.parse(cached);
  } catch (err) {
    console.error('Failed to parse cached location:', err);
    return null;
  }
};

/**
 * Calculate dynamic ETA based on current distance
 */
export const calculateDynamicETA = (
  helperLat: number,
  helperLng: number,
  taskLat: number,
  taskLng: number,
): number => {
  const distanceKm = calculateDistance(helperLat, helperLng, taskLat, taskLng);
  return Math.round(estimateETA(distanceKm));
};

/**
 * Broadcast location update to customer (via Socket.IO)
 * Should be called from socket-handlers with io instance
 */
export const broadcastLocationToCustomer = (
  taskId: string,
  io: any,
  locationData: LocationPing,
): void => {
  if (!io) {
    console.warn('Socket.IO instance not available, location not broadcast');
    return;
  }

  try {
    io.of('/customers')
      .to(`task:${taskId}`)
      .emit('location:update', {
        helper_lat: locationData.helper_lat,
        helper_lng: locationData.helper_lng,
        accuracy_m: locationData.accuracy_m,
        timestamp: locationData.timestamp,
        distance_to_customer_m: locationData.distance_to_customer_m,
        eta_minutes: locationData.eta_minutes,
      });
  } catch (err) {
    console.error('Error broadcasting location:', err);
  }
};

/**
 * Send last location to customer on reconnect
 */
export const reconnectLocationHandler = async (
  socket: any,
  taskId: string,
): Promise<void> => {
  try {
    const lastPing = await getLastLocationPing(taskId);
    if (lastPing) {
      socket.emit('location:update', {
        helper_lat: lastPing.helper_lat,
        helper_lng: lastPing.helper_lng,
        accuracy_m: lastPing.accuracy_m,
        timestamp: lastPing.timestamp,
        distance_to_customer_m: lastPing.distance_to_customer_m,
        eta_minutes: lastPing.eta_minutes,
      });
    }
  } catch (err) {
    console.error('Error handling customer reconnect:', err);
  }
};

/**
 * Clean up location tracking data when task completes
 */
export const cleanupTaskLocations = async (taskId: string): Promise<void> => {
  const redisKey = `tasks:locations:${taskId}`;
  await redis.del(redisKey);
};

/**
 * Get location history for a task (admin query)
 * Note: Currently we only store the latest ping. Full history could be
 * implemented by storing to a different Redis structure or database.
 */
export const getTaskLocations = async (
  taskId: string,
): Promise<LocationPing | null> => {
  // For now, return the last stored location
  // In future, could implement full history storage
  return getLastLocationPing(taskId);
};
