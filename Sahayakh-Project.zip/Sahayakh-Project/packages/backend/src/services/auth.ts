import bcryptjs from 'bcryptjs';
import { config } from '../config';
import { signAccessToken, signRefreshToken, verifyRefreshToken } from '../utils/jwt';
import * as userService from './user';
import * as otpService from './otp';
import { AppError } from '../middleware/error';
import { AUTH_ERROR_CODES, AUTH_ERROR_MESSAGES, UserRole } from '@sahayakh/shared';
import { isDevelopment } from '../config';

export const registerWithPhone = async (
  phoneNumber: string,
  name: string,
  role: UserRole,
): Promise<{ otp_sent: boolean; expires_in: number; otp?: string }> => {
  const isAvailable = await otpService.isOTPAvailable(phoneNumber);
  if (!isAvailable) {
    throw new AppError(
      AUTH_ERROR_CODES.RATE_LIMIT_EXCEEDED,
      AUTH_ERROR_MESSAGES.RATE_LIMIT_EXCEEDED,
      429,
    );
  }

  const user = await userService.createUser(phoneNumber, name, role);

  const otp = await otpService.generateAndStoreOTP(phoneNumber);

  if (isDevelopment) {
    console.log(`[DEV] OTP for ${phoneNumber}: ${otp}`);
  } else {
    await sendOTPViaSMS(phoneNumber, otp);
  }

  return {
    otp_sent: true,
    expires_in: config.otp.expiryMinutes,
    ...(isDevelopment && { otp }),
  };
};

export const verifyOTP = async (phoneNumber: string, otpEntered: string) => {
  const user = await userService.findUserByPhone(phoneNumber);
  if (!user) {
    throw new AppError(
      AUTH_ERROR_CODES.USER_NOT_FOUND,
      AUTH_ERROR_MESSAGES.USER_NOT_FOUND,
      404,
    );
  }

  await otpService.verifyAndConsumeOTP(phoneNumber, otpEntered);

  const accessToken = signAccessToken(user.id, user.role);
  const refreshToken = signRefreshToken(user.id, user.role);

  return {
    access_token: accessToken,
    refresh_token: refreshToken,
    user_id: user.id,
    role: user.role,
    user: {
      id: user.id,
      name: user.name,
      phone_number: user.phone_number,
      email: user.email,
      role: user.role,
      status: user.status,
    },
  };
};

export const refreshAccessToken = async (refreshTokenStr: string) => {
  try {
    const payload = verifyRefreshToken(refreshTokenStr);

    const user = await userService.findUserById(payload.user_id);
    if (!user) {
      throw new AppError(
        AUTH_ERROR_CODES.USER_NOT_FOUND,
        AUTH_ERROR_MESSAGES.USER_NOT_FOUND,
        404,
      );
    }

    const newAccessToken = signAccessToken(user.id, user.role);
    const newRefreshToken = signRefreshToken(user.id, user.role);

    return {
      access_token: newAccessToken,
      refresh_token: newRefreshToken,
    };
  } catch (err) {
    throw new AppError(
      AUTH_ERROR_CODES.INVALID_REFRESH_TOKEN,
      AUTH_ERROR_MESSAGES.INVALID_REFRESH_TOKEN,
      401,
    );
  }
};

export const adminLogin = async (email: string, password: string) => {
  throw new AppError(
    'NOT_IMPLEMENTED',
    'Admin login requires password hash storage in database',
    501,
  );
};

export const getCurrentUser = async (userId: string) => {
  const user = await userService.findUserById(userId);
  if (!user) {
    throw new AppError(
      AUTH_ERROR_CODES.USER_NOT_FOUND,
      AUTH_ERROR_MESSAGES.USER_NOT_FOUND,
      404,
    );
  }

  return {
    id: user.id,
    name: user.name,
    phone_number: user.phone_number,
    email: user.email,
    role: user.role,
    status: user.status,
  };
};

const sendOTPViaSMS = async (phoneNumber: string, otp: string): Promise<void> => {
  if (!config.twilio.accountSid || !config.twilio.authToken || !config.twilio.phoneNumber) {
    console.log(`[SMS] Would send OTP to ${phoneNumber}: ${otp}`);
    return;
  }

  console.log(`[SMS] Sending OTP to ${phoneNumber}`);
};
