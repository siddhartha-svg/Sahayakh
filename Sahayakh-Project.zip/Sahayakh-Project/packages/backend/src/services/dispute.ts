import prisma from '../config/prisma';
import { AppError } from '../middleware/error';

/**
 * Raise a new dispute on a completed task
 * Either customer or helper can raise a dispute
 */
export const raiseDispute = async (
  taskId: string,
  raisedByUserId: string,
  category: 'quality' | 'pricing' | 'behavior' | 'otp' | 'non_completion',
  description: string,
  evidenceUrls?: string[],
): Promise<any> => {
  // Validate task exists
  const task = await prisma.task.findUnique({
    where: { id: taskId },
    include: { customer: true, helper: true },
  });

  if (!task) {
    throw new AppError('TASK_NOT_FOUND', 'Task not found', 404);
  }

  // Validate user is party to the task
  if (task.customer_id !== raisedByUserId && task.helper_id !== raisedByUserId) {
    throw new AppError(
      'UNAUTHORIZED',
      'Only customer or helper can raise dispute',
      403,
    );
  }

  // Validate task is completed
  if (task.status !== 'completed') {
    throw new AppError(
      'TASK_NOT_COMPLETED',
      'Can only raise dispute on completed tasks',
      400,
    );
  }

  // Check no active dispute already exists
  const existingDispute = await prisma.dispute.findFirst({
    where: {
      task_id: taskId,
      status: {
        in: ['open', 'investigating'],
      },
    },
  });

  if (existingDispute) {
    throw new AppError(
      'DISPUTE_EXISTS',
      'An active dispute already exists for this task',
      400,
    );
  }

  // Get last dispute ID to increment
  const lastDispute = await prisma.dispute.findFirst({
    orderBy: {
      created_at: 'desc',
    },
    select: {
      dispute_id_display: true,
    },
  });

  const lastNumber = lastDispute
    ? parseInt(lastDispute.dispute_id_display.replace('D-', ''))
    : 0;
  const disputeIdDisplay = `D-${String(lastNumber + 1).padStart(6, '0')}`;

  // Create dispute record
  const dispute = await prisma.dispute.create({
    data: {
      dispute_id_display: disputeIdDisplay,
      task_id: taskId,
      raised_by: raisedByUserId,
      category,
      status: 'open',
      evidence_urls: evidenceUrls || [],
      messages: [
        JSON.stringify({
          userId: raisedByUserId,
          text: description,
          timestamp: new Date().toISOString(),
        }),
      ],
    },
  });

  // Update task status to disputed
  await prisma.task.update({
    where: { id: taskId },
    data: { status: 'disputed' },
  });

  console.log(
    `[Dispute] Created dispute ${disputeIdDisplay} for task ${task.task_id_display}`,
  );

  // Notify other party (in production, would create notification via notification service)
  const otherPartyId =
    task.customer_id === raisedByUserId ? task.helper_id : task.customer_id;
  console.log(
    `[Dispute] Notifying ${otherPartyId} of dispute ${disputeIdDisplay}`,
  );

  return {
    id: dispute.id,
    dispute_id_display: dispute.dispute_id_display,
    task_id: dispute.task_id,
    status: dispute.status,
    category: dispute.category,
    raised_by: dispute.raised_by,
    created_at: dispute.created_at,
    message_count: dispute.messages.length,
  };
};

/**
 * Add a message to an existing dispute
 */
export const addDisputeMessage = async (
  disputeId: string,
  userId: string,
  messageText: string,
): Promise<any> => {
  // Validate dispute exists and user is party
  const dispute = await prisma.dispute.findUnique({
    where: { id: disputeId },
    include: { task: true },
  });

  if (!dispute) {
    throw new AppError('DISPUTE_NOT_FOUND', 'Dispute not found', 404);
  }

  // Validate user is party to the task
  const task = dispute.task;
  if (task.customer_id !== userId && task.helper_id !== userId) {
    throw new AppError(
      'UNAUTHORIZED',
      'Only parties to the task can add messages',
      403,
    );
  }

  // Validate dispute is not resolved
  if (dispute.status === 'resolved') {
    throw new AppError(
      'DISPUTE_RESOLVED',
      'Cannot add messages to resolved dispute',
      400,
    );
  }

  // Add message to messages array
  const newMessage = JSON.stringify({
    userId,
    text: messageText,
    timestamp: new Date().toISOString(),
  });

  const updatedMessages = [...(dispute.messages || []), newMessage];

  const updated = await prisma.dispute.update({
    where: { id: disputeId },
    data: {
      messages: updatedMessages,
    },
  });

  console.log(
    `[Dispute] Added message to dispute ${dispute.dispute_id_display}`,
  );

  // Notify other party
  const otherPartyId = task.customer_id === userId ? task.helper_id : task.customer_id;
  console.log(
    `[Dispute] Notifying ${otherPartyId} of new message in dispute ${dispute.dispute_id_display}`,
  );

  return {
    dispute_id: updated.id,
    message_count: updated.messages.length,
  };
};

/**
 * Get dispute with full message thread
 */
export const getDisputeWithMessages = async (disputeId: string): Promise<any> => {
  const dispute = await prisma.dispute.findUnique({
    where: { id: disputeId },
    include: {
      task: {
        select: {
          id: true,
          task_id_display: true,
          task_type: true,
          category: true,
          description: true,
          customer_id: true,
          helper_id: true,
          final_amount: true,
          created_at: true,
        },
      },
      raised_by_user: {
        select: {
          id: true,
          name: true,
          phone_number: true,
        },
      },
      assigned_user: {
        select: {
          id: true,
          name: true,
          email: true,
        },
      },
    },
  });

  if (!dispute) {
    throw new AppError('DISPUTE_NOT_FOUND', 'Dispute not found', 404);
  }

  // Parse messages
  const parsedMessages = (dispute.messages || []).map((msg) => {
    try {
      return JSON.parse(msg);
    } catch {
      return {
        userId: null,
        text: msg,
        timestamp: new Date().toISOString(),
      };
    }
  });

  return {
    id: dispute.id,
    dispute_id_display: dispute.dispute_id_display,
    task: dispute.task,
    category: dispute.category,
    status: dispute.status,
    resolution_type: dispute.resolution_type,
    raised_by: dispute.raised_by_user,
    assigned_to_admin: dispute.assigned_user,
    evidence_urls: dispute.evidence_urls,
    messages: parsedMessages,
    created_at: dispute.created_at,
    resolved_at: dispute.resolved_at,
  };
};

/**
 * Get disputes filtered by status
 */
export const getDisputesByStatus = async (
  status: 'open' | 'investigating' | 'resolved' | 'appealed',
  adminId?: string,
  limit: number = 20,
  offset: number = 0,
): Promise<any[]> => {
  const where: any = { status };
  if (adminId) {
    where.assigned_to_admin = adminId;
  }

  const disputes = await prisma.dispute.findMany({
    where,
    include: {
      task: {
        select: {
          task_id_display: true,
          customer_id: true,
          helper_id: true,
          final_amount: true,
        },
      },
      raised_by_user: {
        select: {
          name: true,
        },
      },
    },
    orderBy: {
      created_at: 'desc',
    },
    skip: offset,
    take: limit,
  });

  return disputes.map((d) => ({
    id: d.id,
    dispute_id_display: d.dispute_id_display,
    task_id_display: d.task.task_id_display,
    category: d.category,
    status: d.status,
    raised_by: d.raised_by_user.name,
    created_at: d.created_at,
    message_count: d.messages.length,
    assigned_to_admin: d.assigned_to_admin,
  }));
};

/**
 * Assign dispute to admin
 */
export const assignDisputeToAdmin = async (
  disputeId: string,
  adminId: string,
): Promise<any> => {
  const dispute = await prisma.dispute.findUnique({
    where: { id: disputeId },
  });

  if (!dispute) {
    throw new AppError('DISPUTE_NOT_FOUND', 'Dispute not found', 404);
  }

  // Update assignment and status
  const updated = await prisma.dispute.update({
    where: { id: disputeId },
    data: {
      assigned_to_admin: adminId,
      status: 'investigating',
    },
  });

  // Log to audit
  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'dispute_assign',
      resource_type: 'Dispute',
      resource_id: disputeId,
    },
  });

  console.log(`[Dispute] Assigned dispute ${dispute.dispute_id_display} to admin`);

  return {
    id: updated.id,
    dispute_id_display: updated.dispute_id_display,
    status: updated.status,
    assigned_to_admin: updated.assigned_to_admin,
  };
};

/**
 * Get comprehensive dispute details for admin review
 */
export const getDisputeDetails = async (disputeId: string): Promise<any> => {
  const dispute = await prisma.dispute.findUnique({
    where: { id: disputeId },
    include: {
      task: {
        include: {
          customer: {
            select: {
              id: true,
              name: true,
              phone_number: true,
              rating: true,
            },
          },
          helper: {
            select: {
              id: true,
              user: {
                select: {
                  name: true,
                  phone_number: true,
                },
              },
              rating: true,
              completion_rate: true,
              total_tasks: true,
            },
          },
        },
      },
      raised_by_user: {
        select: {
          name: true,
        },
      },
      assigned_user: {
        select: {
          name: true,
        },
      },
    },
  });

  if (!dispute) {
    throw new AppError('DISPUTE_NOT_FOUND', 'Dispute not found', 404);
  }

  // Get payment details
  const payment = await prisma.payment.findUnique({
    where: { task_id: dispute.task_id },
  });

  // Get prior disputes for both parties
  const customerPriorDisputes = await prisma.dispute.findMany({
    where: {
      task: {
        customer_id: dispute.task.customer_id,
      },
    },
    select: {
      dispute_id_display: true,
      status: true,
      resolution_type: true,
      created_at: true,
    },
  });

  const helperPriorDisputes = await prisma.dispute.findMany({
    where: {
      task: {
        helper_id: dispute.task.helper_id,
      },
    },
    select: {
      dispute_id_display: true,
      status: true,
      resolution_type: true,
      created_at: true,
    },
  });

  // Parse messages
  const parsedMessages = (dispute.messages || []).map((msg) => {
    try {
      return JSON.parse(msg);
    } catch {
      return msg;
    }
  });

  return {
    id: dispute.id,
    dispute_id_display: dispute.dispute_id_display,
    category: dispute.category,
    status: dispute.status,
    resolution_type: dispute.resolution_type,
    task: {
      id: dispute.task.id,
      task_id_display: dispute.task.task_id_display,
      type: dispute.task.task_type,
      description: dispute.task.description,
      final_amount: dispute.task.final_amount,
      created_at: dispute.task.created_at,
    },
    payment: payment
      ? {
          final_amount: payment.final_amount,
          platform_fee: payment.platform_fee_amount,
          helper_payout: payment.helper_payout_amount,
        }
      : null,
    customer: dispute.task.customer,
    helper: dispute.task.helper,
    raised_by: dispute.raised_by_user.name,
    assigned_to_admin: dispute.assigned_user?.name,
    evidence_urls: dispute.evidence_urls,
    messages: parsedMessages,
    customer_prior_disputes: customerPriorDisputes,
    helper_prior_disputes: helperPriorDisputes,
    created_at: dispute.created_at,
    resolved_at: dispute.resolved_at,
  };
};

/**
 * Count dispute losses for a helper
 */
export const countDisputeLosses = async (helperId: string): Promise<number> => {
  const losses = await prisma.dispute.findMany({
    where: {
      task: {
        helper_id: helperId,
      },
      resolution_type: 'customer_win',
    },
  });

  return losses.length;
};

/**
 * Count active disputes for a task
 */
export const hasActiveDispute = async (taskId: string): Promise<boolean> => {
  const dispute = await prisma.dispute.findFirst({
    where: {
      task_id: taskId,
      status: {
        in: ['open', 'investigating'],
      },
    },
  });

  return !!dispute;
};
