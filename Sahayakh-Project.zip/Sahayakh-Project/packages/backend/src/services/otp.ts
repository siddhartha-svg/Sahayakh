import { getRedis, getRedisKey } from '../config/redis';
import { generateOTP as generateOTPCode, hashOTP, compareOTP } from '../utils/otp';
import { config } from '../config';
import { AppError } from '../middleware/error';
import { AUTH_ERROR_CODES, AUTH_ERROR_MESSAGES } from '@sahayakh/shared';

export const generateAndStoreOTP = async (phoneNumber: string): Promise<string> => {
  const redis = getRedis();

  const requestKey = getRedisKey(`otp_requests:${phoneNumber}`);
  const currentRequests = await redis.incr(requestKey);

  if (currentRequests === 1) {
    await redis.expire(requestKey, 3600);
  }

  if (currentRequests > 10) {
    throw new AppError(
      AUTH_ERROR_CODES.RATE_LIMIT_EXCEEDED,
      AUTH_ERROR_MESSAGES.RATE_LIMIT_EXCEEDED,
      429,
    );
  }

  const otp = generateOTPCode();
  const otpHash = await hashOTP(otp);

  const otpKey = getRedisKey(`otp:${phoneNumber}`);
  const otpData = JSON.stringify({
    hash: otpHash,
    attempts: 0,
    createdAt: Date.now(),
  });

  await redis.setex(otpKey, config.otp.expiryMinutes * 60, otpData);

  return otp;
};

export const verifyAndConsumeOTP = async (phoneNumber: string, otpEntered: string): Promise<boolean> => {
  const redis = getRedis();

  const otpKey = getRedisKey(`otp:${phoneNumber}`);
  const otpDataStr = await redis.get(otpKey);

  if (!otpDataStr) {
    throw new AppError(
      AUTH_ERROR_CODES.OTP_NOT_FOUND,
      AUTH_ERROR_MESSAGES.OTP_NOT_FOUND,
      400,
    );
  }

  const otpData = JSON.parse(otpDataStr);

  if (otpData.attempts >= config.otp.maxAttempts) {
    await redis.del(otpKey);
    throw new AppError(
      AUTH_ERROR_CODES.TOO_MANY_ATTEMPTS,
      AUTH_ERROR_MESSAGES.TOO_MANY_ATTEMPTS,
      429,
    );
  }

  const isValid = await compareOTP(otpEntered, otpData.hash);

  if (!isValid) {
    otpData.attempts += 1;
    await redis.setex(otpKey, config.otp.expiryMinutes * 60, JSON.stringify(otpData));

    if (otpData.attempts >= config.otp.maxAttempts) {
      throw new AppError(
        AUTH_ERROR_CODES.TOO_MANY_ATTEMPTS,
        AUTH_ERROR_MESSAGES.TOO_MANY_ATTEMPTS,
        429,
      );
    }

    throw new AppError(
      AUTH_ERROR_CODES.INVALID_OTP,
      AUTH_ERROR_MESSAGES.INVALID_OTP,
      400,
    );
  }

  await redis.del(otpKey);
  return true;
};

export const isOTPAvailable = async (phoneNumber: string): Promise<boolean> => {
  const redis = getRedis();
  const requestKey = getRedisKey(`otp_requests:${phoneNumber}`);
  const requests = await redis.get(requestKey);
  return !requests || parseInt(requests) < 10;
};

export const getOTPCooldown = async (phoneNumber: string): Promise<number> => {
  const redis = getRedis();
  const requestKey = getRedisKey(`otp_requests:${phoneNumber}`);
  const ttl = await redis.ttl(requestKey);
  return ttl > 0 ? ttl : 0;
};
