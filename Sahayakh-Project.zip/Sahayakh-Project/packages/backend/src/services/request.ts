import prisma from '../config/prisma';
import redis from '../config/redis';
import { AppError } from '../middleware/error';
import { calculateDistance, estimatePrice, estimateETA } from '../utils/location';

const REQUEST_EXPIRY_SECONDS = 45;

const getRedisRequestKey = (taskId: string, helperId: string) => `request:${taskId}:${helperId}`;

export interface SendTaskRequestResult {
  requestId: string;
  requestPayload: {
    request_id: string;
    task_id: string;
    task_id_display: string;
    title: string;
    category: string;
    distance_km: number;
    location: {
      lat: number;
      lng: number;
      address: string;
    };
    customer: {
      name: string;
    };
    payment_estimate: {
      min: number;
      max: number;
    };
    countdown_sec: number;
    expires_at: string;
  };
}

export const sendTaskRequest = async (
  taskId: string,
  helperId: string,
  pricingConfig: any,
): Promise<SendTaskRequestResult> => {
  const task = await prisma.task.findUnique({
    where: { id: taskId },
    include: { customer: true },
  });

  if (!task) {
    throw new AppError('TASK_NOT_FOUND', 'Task not found', 404);
  }

  const helper = await prisma.helper.findUnique({
    where: { id: helperId },
    include: { user: true },
  });

  if (!helper) {
    throw new AppError('HELPER_NOT_FOUND', 'Helper not found', 404);
  }

  const expiresAt = new Date(Date.now() + REQUEST_EXPIRY_SECONDS * 1000);

  const request = await prisma.taskRequest.create({
    data: {
      task_id: taskId,
      helper_id: helperId,
      expires_at: expiresAt,
      status: 'pending',
    },
  });

  // Store in Redis with TTL
  const redisKey = getRedisRequestKey(taskId, helperId);
  await redis.setex(
    redisKey,
    REQUEST_EXPIRY_SECONDS,
    JSON.stringify({
      request_id: request.id,
      task_id: taskId,
      helper_id: helperId,
      sent_at: request.sent_at.toISOString(),
    }),
  );

  // Calculate distance and pricing
  const helperLocation = JSON.parse(helper.user.location_point || '{}');
  const taskLocation = JSON.parse(task.location_point || '{}');

  let distance = 0;
  if (helperLocation.latitude && taskLocation.latitude) {
    distance = calculateDistance(
      helperLocation.latitude,
      helperLocation.longitude,
      taskLocation.latitude,
      taskLocation.longitude,
    );
  }

  const priceEstimate = estimatePrice(
    pricingConfig?.base_fare_rupees || 40,
    pricingConfig?.per_km_rate || 15,
    distance,
    task.task_type === 'business',
    pricingConfig?.business_task_multiplier || 1.25,
    pricingConfig?.minimum_fare_rupees || 80,
  );

  const requestPayload = {
    request_id: request.id,
    task_id: task.id,
    task_id_display: task.task_id_display,
    title: task.description.substring(0, 50),
    category: task.category,
    distance_km: Math.round(distance * 10) / 10,
    location: {
      lat: taskLocation.latitude || 0,
      lng: taskLocation.longitude || 0,
      address: task.location_name,
    },
    customer: {
      name: task.customer?.name || 'Customer',
    },
    payment_estimate: {
      min: priceEstimate.min,
      max: priceEstimate.max,
    },
    countdown_sec: REQUEST_EXPIRY_SECONDS,
    expires_at: expiresAt.toISOString(),
  };

  return {
    requestId: request.id,
    requestPayload,
  };
};

export const acceptRequest = async (requestId: string, helperId: string) => {
  const request = await prisma.taskRequest.findUnique({
    where: { id: requestId },
  });

  if (!request) {
    throw new AppError('REQUEST_NOT_FOUND', 'Request not found', 404);
  }

  if (request.helper_id !== helperId) {
    throw new AppError('UNAUTHORIZED', 'Not authorized to accept this request', 403);
  }

  if (request.status !== 'pending') {
    throw new AppError('REQUEST_NOT_PENDING', 'Request is no longer pending', 400);
  }

  if (new Date() > request.expires_at) {
    throw new AppError('REQUEST_EXPIRED', 'Request has expired', 410);
  }

  const updated = await prisma.taskRequest.update({
    where: { id: requestId },
    data: {
      status: 'accepted',
      accepted_at: new Date(),
    },
  });

  // Update task status to assigned (already assigned but confirm)
  await prisma.task.update({
    where: { id: request.task_id },
    data: { status: 'assigned' },
  });

  // Remove from Redis
  await redis.del(getRedisRequestKey(request.task_id, helperId));

  return updated;
};

export const declineRequest = async (
  requestId: string,
  helperId: string,
  reason?: string,
) => {
  const request = await prisma.taskRequest.findUnique({
    where: { id: requestId },
  });

  if (!request) {
    throw new AppError('REQUEST_NOT_FOUND', 'Request not found', 404);
  }

  if (request.helper_id !== helperId) {
    throw new AppError('UNAUTHORIZED', 'Not authorized to decline this request', 403);
  }

  if (request.status !== 'pending') {
    throw new AppError('REQUEST_NOT_PENDING', 'Request is no longer pending', 400);
  }

  const updated = await prisma.taskRequest.update({
    where: { id: requestId },
    data: {
      status: 'declined',
      declined_at: new Date(),
      decline_reason: reason,
    },
  });

  // Return task to unassigned for next helper
  await prisma.task.update({
    where: { id: request.task_id },
    data: { status: 'unassigned' },
  });

  // Remove from Redis
  await redis.del(getRedisRequestKey(request.task_id, helperId));

  return updated;
};

export const handleRequestExpiry = async (taskId: string, helperId: string) => {
  const request = await prisma.taskRequest.findFirst({
    where: {
      task_id: taskId,
      helper_id: helperId,
      status: 'pending',
    },
  });

  if (!request) return null;

  const updated = await prisma.taskRequest.update({
    where: { id: request.id },
    data: { status: 'expired' },
  });

  // Return task to unassigned for requeue
  await prisma.task.update({
    where: { id: taskId },
    data: { status: 'unassigned' },
  });

  return updated;
};

export const findNextAvailableHelper = async (taskId: string) => {
  const task = await prisma.task.findUnique({
    where: { id: taskId },
  });

  if (!task) return null;

  // Get helpers who already declined or request expired
  const declinedRequests = await prisma.taskRequest.findMany({
    where: {
      task_id: taskId,
      status: { in: ['declined', 'expired'] },
    },
    select: { helper_id: true },
  });

  const declinedIds = declinedRequests.map((r) => r.helper_id);

  // Find next available helper
  const nextHelper = await prisma.helper.findFirst({
    where: {
      id: { notIn: declinedIds },
      verification_status: 'verified',
      helper_status: { in: ['online', 'active'] },
      background_check_status: 'cleared',
      accepts_personal_tasks: task.task_type === 'personal' ? true : undefined,
      accepts_business_tasks: task.task_type === 'business' ? true : undefined,
    },
    include: { user: true },
    take: 1,
  });

  return nextHelper;
};
