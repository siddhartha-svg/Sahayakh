import prisma from '../config/prisma';
import { AppError } from '../middleware/error';

/**
 * Get all helper applications with optional status filter
 */
export const getHelperApplications = async (
  status?: 'pending' | 'verified' | 'rejected' | 'expired',
  limit: number = 20,
  offset: number = 0,
): Promise<any[]> => {
  const where: any = {};
  if (status) {
    where.verification_status = status;
  }

  const helpers = await prisma.helper.findMany({
    where,
    include: {
      user: {
        select: {
          id: true,
          name: true,
          phone_number: true,
          email: true,
        },
      },
      documents: {
        select: {
          document_type: true,
          status: true,
          created_at: true,
        },
      },
    },
    orderBy: {
      created_at: 'desc',
    },
    skip: offset,
    take: limit,
  });

  return helpers.map((h) => ({
    id: h.id,
    user_id: h.user_id,
    name: h.user.name,
    phone_number: h.user.phone_number,
    email: h.user.email,
    verification_status: h.verification_status,
    background_check_status: h.background_check_status,
    documents_pending: h.documents.filter((d) => d.status === 'pending').length,
    documents_total: h.documents.length,
    created_at: h.created_at,
  }));
};

/**
 * Get comprehensive helper profile for admin review
 */
export const getHelperDetails = async (helperId: string): Promise<any> => {
  const helper = await prisma.helper.findUnique({
    where: { id: helperId },
    include: {
      user: true,
      documents: true,
    },
  });

  if (!helper) {
    throw new AppError('HELPER_NOT_FOUND', 'Helper not found', 404);
  }

  // Get task statistics
  const tasks = await prisma.task.findMany({
    where: { helper_id: helperId },
  });

  const completedTasks = tasks.filter((t) => t.status === 'completed').length;
  const totalTasks = tasks.length;
  const completionRate = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

  // Get disputes
  const disputes = await prisma.dispute.findMany({
    where: {
      task: {
        helper_id: helperId,
      },
    },
  });

  // Get earnings summary
  const payments = await prisma.payment.findMany({
    where: {
      task: {
        helper_id: helperId,
      },
      status: 'completed',
    },
  });

  const totalEarnings = payments.reduce(
    (sum, p) => sum + p.helper_payout_amount,
    0,
  );

  // Get verification history from AuditLog
  const verificationHistory = await prisma.auditLog.findMany({
    where: {
      resource_id: helperId,
      action: {
        in: ['helper_approved', 'helper_rejected', 'helper_document_verified', 'helper_document_rejected'],
      },
    },
    include: {
      admin: {
        select: {
          name: true,
        },
      },
    },
    orderBy: {
      created_at: 'desc',
    },
    take: 10,
  });

  // Get active suspension if any
  const suspension = await prisma.helperSuspensionLog.findFirst({
    where: {
      helper_id: helperId,
    },
    orderBy: {
      created_at: 'desc',
    },
  });

  return {
    id: helper.id,
    user: {
      name: helper.user.name,
      phone_number: helper.user.phone_number,
      email: helper.user.email,
      rating: helper.user.rating,
    },
    status: {
      helper_status: helper.helper_status,
      verification_status: helper.verification_status,
      background_check_status: helper.background_check_status,
    },
    documents: helper.documents.map((d) => ({
      type: d.document_type,
      status: d.status,
      url: d.document_url,
      uploaded_at: d.created_at,
    })),
    statistics: {
      total_tasks: totalTasks,
      completed_tasks: completedTasks,
      completion_rate: completionRate.toFixed(2) + '%',
      total_earnings: totalEarnings.toFixed(2),
      disputes: {
        total: disputes.length,
        losses: disputes.filter((d) => d.resolution_type === 'customer_win').length,
      },
    },
    verification_history: verificationHistory.map((h) => ({
      action: h.action,
      admin_name: h.admin?.name,
      timestamp: h.created_at,
    })),
    suspension: suspension
      ? {
          reason: suspension.reason,
          suspension_start_at: suspension.suspension_start_at,
          suspension_end_at: suspension.suspension_end_at,
          appeal_status: suspension.appeal_status,
        }
      : null,
    created_at: helper.created_at,
  };
};

/**
 * Approve helper application (verification_status: pending → verified)
 */
export const approveHelperApplication = async (
  helperId: string,
  adminId: string,
  notes?: string,
): Promise<any> => {
  const helper = await prisma.helper.findUnique({
    where: { id: helperId },
  });

  if (!helper) {
    throw new AppError('HELPER_NOT_FOUND', 'Helper not found', 404);
  }

  if (helper.verification_status !== 'pending') {
    throw new AppError(
      'INVALID_STATUS',
      'Only pending helpers can be approved',
      400,
    );
  }

  // Update helper
  const updated = await prisma.helper.update({
    where: { id: helperId },
    data: {
      verification_status: 'verified',
      helper_status: helper.helper_status === 'inactive' ? 'active' : helper.helper_status,
    },
  });

  // Log to audit trail
  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'helper_approved',
      resource_type: 'Helper',
      resource_id: helperId,
      metadata: { notes } as any,
    },
  });

  console.log(`[Helper Management] Approved helper ${helperId} by admin ${adminId}`);

  return {
    id: updated.id,
    verification_status: updated.verification_status,
    helper_status: updated.helper_status,
    approved_at: new Date(),
  };
};

/**
 * Reject helper application (verification_status: pending → rejected)
 */
export const rejectHelperApplication = async (
  helperId: string,
  adminId: string,
  reason: string,
  notes?: string,
): Promise<any> => {
  const helper = await prisma.helper.findUnique({
    where: { id: helperId },
  });

  if (!helper) {
    throw new AppError('HELPER_NOT_FOUND', 'Helper not found', 404);
  }

  if (helper.verification_status !== 'pending') {
    throw new AppError(
      'INVALID_STATUS',
      'Only pending helpers can be rejected',
      400,
    );
  }

  // Update helper
  const updated = await prisma.helper.update({
    where: { id: helperId },
    data: {
      verification_status: 'rejected',
    },
  });

  // Log to audit trail
  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'helper_rejected',
      resource_type: 'Helper',
      resource_id: helperId,
      metadata: { reason, notes } as any,
    },
  });

  console.log(`[Helper Management] Rejected helper ${helperId}: ${reason}`);

  return {
    id: updated.id,
    verification_status: updated.verification_status,
    rejection_reason: reason,
    rejected_at: new Date(),
  };
};

/**
 * Verify a single helper document
 */
export const verifyDocument = async (
  helperId: string,
  documentType: string,
  adminId: string,
  notes?: string,
): Promise<any> => {
  // Get document
  const document = await prisma.helperDocument.findFirst({
    where: {
      helper_id: helperId,
      document_type: documentType,
    },
  });

  if (!document) {
    throw new AppError('DOCUMENT_NOT_FOUND', 'Document not found', 404);
  }

  if (document.status !== 'pending') {
    throw new AppError(
      'INVALID_STATUS',
      'Only pending documents can be verified',
      400,
    );
  }

  // Update document
  const updated = await prisma.helperDocument.update({
    where: { id: document.id },
    data: {
      status: 'verified',
    },
  });

  // Log verification
  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'helper_document_verified',
      resource_type: 'HelperDocument',
      resource_id: document.id,
      metadata: { document_type: documentType, notes } as any,
    },
  });

  // Check if all documents verified + background check cleared → auto-approve
  const pendingDocuments = await prisma.helperDocument.findMany({
    where: {
      helper_id: helperId,
      status: 'pending',
    },
  });

  const helper = await prisma.helper.findUnique({
    where: { id: helperId },
  });

  if (
    pendingDocuments.length === 0 &&
    helper?.background_check_status === 'cleared' &&
    helper?.verification_status === 'pending'
  ) {
    // Auto-approve helper
    await approveHelperApplication(helperId, adminId, 'Auto-approved: all documents verified');
  }

  console.log(`[Helper Management] Verified document ${documentType} for helper ${helperId}`);

  return {
    document_type: updated.document_type,
    status: updated.status,
    verified_at: new Date(),
  };
};

/**
 * Reject a helper document
 */
export const rejectDocument = async (
  helperId: string,
  documentType: string,
  adminId: string,
  reason: string,
  notes?: string,
): Promise<any> => {
  const document = await prisma.helperDocument.findFirst({
    where: {
      helper_id: helperId,
      document_type: documentType,
    },
  });

  if (!document) {
    throw new AppError('DOCUMENT_NOT_FOUND', 'Document not found', 404);
  }

  if (document.status !== 'pending') {
    throw new AppError(
      'INVALID_STATUS',
      'Only pending documents can be rejected',
      400,
    );
  }

  // Update document
  const updated = await prisma.helperDocument.update({
    where: { id: document.id },
    data: {
      status: 'rejected',
    },
  });

  // Log rejection
  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'helper_document_rejected',
      resource_type: 'HelperDocument',
      resource_id: document.id,
      metadata: { document_type: documentType, reason, notes } as any,
    },
  });

  console.log(
    `[Helper Management] Rejected document ${documentType} for helper ${helperId}: ${reason}`,
  );

  return {
    document_type: updated.document_type,
    status: updated.status,
    rejection_reason: reason,
    rejected_at: new Date(),
  };
};

/**
 * Get document verification queue (all pending documents)
 */
export const getDocumentVerificationQueue = async (
  limit: number = 20,
  offset: number = 0,
): Promise<any[]> => {
  const documents = await prisma.helperDocument.findMany({
    where: {
      status: 'pending',
    },
    include: {
      helper: {
        include: {
          user: {
            select: {
              name: true,
            },
          },
        },
      },
    },
    orderBy: {
      created_at: 'asc',
    },
    skip: offset,
    take: limit,
  });

  return documents.map((d) => ({
    helper_id: d.helper_id,
    helper_name: d.helper.user.name,
    document_type: d.document_type,
    document_url: d.document_url,
    uploaded_at: d.created_at,
    status: d.status,
  }));
};
