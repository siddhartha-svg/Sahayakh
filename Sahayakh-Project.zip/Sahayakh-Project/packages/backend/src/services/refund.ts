import prisma from '../config/prisma';
import { AppError } from '../middleware/error';

/**
 * Issue a full refund to the customer
 */
export const issueFullRefund = async (
  paymentId: string,
  reason: string,
  adminId: string,
): Promise<any> => {
  // Get payment details
  const payment = await prisma.payment.findUnique({
    where: { id: paymentId },
    include: { task: true },
  });

  if (!payment) {
    throw new AppError('PAYMENT_NOT_FOUND', 'Payment not found', 404);
  }

  if (payment.status === 'refunded') {
    throw new AppError(
      'ALREADY_REFUNDED',
      'Payment already refunded',
      400,
    );
  }

  // Mark payment as refunded
  const refundAmount = payment.final_amount;
  const updated = await prisma.payment.update({
    where: { id: paymentId },
    data: {
      status: 'refunded',
      completed_at: new Date(),
    },
  });

  // Reverse any payouts for this task
  const payouts = await prisma.payout.findMany({
    where: {
      task_ids: {
        has: payment.task_id,
      },
      status: {
        in: ['pending', 'processing'],
      },
    },
  });

  for (const payout of payouts) {
    await prisma.payout.update({
      where: { id: payout.id },
      data: {
        status: 'failed',
      },
    });
  }

  // Log to audit trail
  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'full_refund',
      resource_type: 'Payment',
      resource_id: paymentId,
      old_values: { status: payment.status },
      new_values: { status: 'refunded', refund_amount: refundAmount },
      metadata: { reason },
    } as any,
  });

  console.log(
    `[Refund] Issued full refund of ₹${refundAmount} for payment ${paymentId}`,
  );

  return {
    id: updated.id,
    refund_amount: refundAmount,
    status: updated.status,
    completed_at: updated.completed_at,
  };
};

/**
 * Issue a partial refund to customer and partial payout to helper
 */
export const issuePartialRefund = async (
  paymentId: string,
  customerRefundAmount: number,
  helperPayoutAmount: number,
  reason: string,
  adminId: string,
): Promise<any> => {
  // Get payment details
  const payment = await prisma.payment.findUnique({
    where: { id: paymentId },
    include: { task: true },
  });

  if (!payment) {
    throw new AppError('PAYMENT_NOT_FOUND', 'Payment not found', 404);
  }

  // Validate amounts
  const totalAmount = customerRefundAmount + helperPayoutAmount;
  if (totalAmount > payment.final_amount) {
    throw new AppError(
      'INVALID_AMOUNTS',
      'Refund + payout exceeds final amount',
      400,
    );
  }

  // Mark payment as refunded
  const updated = await prisma.payment.update({
    where: { id: paymentId },
    data: {
      status: 'refunded',
      completed_at: new Date(),
    },
  });

  // Create new payout for helper (if payout amount > 0)
  let payout = null;
  if (helperPayoutAmount > 0) {
    // Get last payout ID
    const lastPayout = await prisma.payout.findFirst({
      orderBy: { created_at: 'desc' },
      select: { payout_id_display: true },
    });

    const lastNumber = lastPayout
      ? parseInt(lastPayout.payout_id_display.replace('P-', ''))
      : 0;
    const payoutIdDisplay = `P-${String(lastNumber + 1).padStart(6, '0')}`;

    payout = await prisma.payout.create({
      data: {
        payout_id_display: payoutIdDisplay,
        helper_id: payment.task.helper_id,
        total_amount: helperPayoutAmount,
        payout_method: 'bank_transfer',
        status: 'pending',
        task_ids: [payment.task_id],
      },
    });
  }

  // Log to audit trail
  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'partial_refund',
      resource_type: 'Payment',
      resource_id: paymentId,
      old_values: { status: payment.status },
      new_values: {
        status: 'refunded',
        customer_refund: customerRefundAmount,
        helper_payout: helperPayoutAmount,
      },
      metadata: { reason },
    } as any,
  });

  console.log(
    `[Refund] Issued partial refund: ₹${customerRefundAmount} to customer, ₹${helperPayoutAmount} to helper`,
  );

  return {
    payment_id: updated.id,
    customer_refund: customerRefundAmount,
    helper_payout: helperPayoutAmount,
    payout_id: payout?.id,
    platform_keeps: payment.final_amount - (customerRefundAmount + helperPayoutAmount),
  };
};

/**
 * Dismiss dispute without refund or payout change
 */
export const issueDismissal = async (
  paymentId: string,
  reason: string,
  adminId: string,
): Promise<any> => {
  const payment = await prisma.payment.findUnique({
    where: { id: paymentId },
  });

  if (!payment) {
    throw new AppError('PAYMENT_NOT_FOUND', 'Payment not found', 404);
  }

  // Log dismissal to audit trail
  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'dispute_dismissed',
      resource_type: 'Payment',
      resource_id: paymentId,
      metadata: { reason },
    } as any,
  });

  console.log(
    `[Refund] Dismissed dispute for payment ${paymentId}: ${reason}`,
  );

  return {
    payment_id: payment.id,
    status: 'dismissed',
    reason,
  };
};

/**
 * Reverse all payouts for a task (for customer_win resolution)
 */
export const reverseAllPayoutsForTask = async (
  taskId: string,
  reason: string,
  adminId: string,
): Promise<any> => {
  const payouts = await prisma.payout.findMany({
    where: {
      task_ids: {
        has: taskId,
      },
      status: {
        in: ['pending', 'processing'],
      },
    },
  });

  const reversedPayoutIds = [];

  for (const payout of payouts) {
    await prisma.payout.update({
      where: { id: payout.id },
      data: {
        status: 'failed',
      },
    });

    // Log each reversal
    await prisma.auditLog.create({
      data: {
        admin_id: adminId,
        action: 'payout_reversed',
        resource_type: 'Payout',
        resource_id: payout.id,
        metadata: { reason },
      } as any,
    });

    reversedPayoutIds.push(payout.id);
  }

  console.log(`[Refund] Reversed ${reversedPayoutIds.length} payouts for task ${taskId}`);

  return {
    task_id: taskId,
    reversed_payout_count: reversedPayoutIds.length,
    payout_ids: reversedPayoutIds,
  };
};
