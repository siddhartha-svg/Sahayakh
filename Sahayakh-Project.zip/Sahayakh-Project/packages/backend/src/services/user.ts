import prisma from '../config/prisma';
import { User, UserRole, UserStatus } from '@sahayakh/shared';
import { AppError } from '../middleware/error';
import { AUTH_ERROR_CODES, AUTH_ERROR_MESSAGES } from '@sahayakh/shared';

export const findUserByPhone = async (phoneNumber: string) => {
  return prisma.user.findFirst({
    where: {
      phone_number: phoneNumber,
      deleted_at: null,
    },
  });
};

export const findUserByEmail = async (email: string) => {
  return prisma.user.findFirst({
    where: {
      email,
      deleted_at: null,
    },
  });
};

export const findUserById = async (userId: string) => {
  return prisma.user.findFirst({
    where: {
      id: userId,
      deleted_at: null,
    },
  });
};

export const createUser = async (phoneNumber: string, name: string, role: UserRole) => {
  const existing = await findUserByPhone(phoneNumber);
  if (existing) {
    throw new AppError(
      AUTH_ERROR_CODES.PHONE_ALREADY_EXISTS,
      AUTH_ERROR_MESSAGES.PHONE_ALREADY_EXISTS,
      409,
    );
  }

  return prisma.user.create({
    data: {
      phone_number: phoneNumber,
      name,
      role: role as any,
      status: 'active' as const,
    },
  });
};

export const createAdminUser = async (email: string, name: string) => {
  const existing = await findUserByEmail(email);
  if (existing) {
    throw new AppError(
      AUTH_ERROR_CODES.USER_NOT_FOUND,
      'Email already registered',
      409,
    );
  }

  return prisma.user.create({
    data: {
      email,
      name,
      role: 'admin' as const,
      status: 'active' as const,
    },
  });
};

export const updateUserStatus = async (userId: string, status: UserStatus) => {
  const user = await prisma.user.findUnique({
    where: { id: userId },
  });

  if (!user || user.deleted_at) {
    throw new AppError(
      AUTH_ERROR_CODES.USER_NOT_FOUND,
      AUTH_ERROR_MESSAGES.USER_NOT_FOUND,
      404,
    );
  }

  return prisma.user.update({
    where: { id: userId },
    data: { status: status as any },
  });
};

export const getUserProfile = async (userId: string) => {
  return findUserById(userId);
};
