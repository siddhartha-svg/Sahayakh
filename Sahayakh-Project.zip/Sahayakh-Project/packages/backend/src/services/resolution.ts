import prisma from '../config/prisma';
import { AppError } from '../middleware/error';
import * as refundService from './refund';
import * as suspensionService from './suspension';
import * as disputeService from './dispute';

/**
 * Resolve dispute in favor of customer (full refund)
 */
export const resolveDisputeAsCustomerWin = async (
  disputeId: string,
  adminId: string,
  notes?: string,
): Promise<any> => {
  // Get dispute and payment
  const dispute = await prisma.dispute.findUnique({
    where: { id: disputeId },
    include: { task: { include: { helper: true } } },
  });

  if (!dispute) {
    throw new AppError('DISPUTE_NOT_FOUND', 'Dispute not found', 404);
  }

  if (!['open', 'investigating'].includes(dispute.status)) {
    throw new AppError(
      'INVALID_STATUS',
      'Dispute must be open or investigating',
      400,
    );
  }

  // Get payment
  const payment = await prisma.payment.findUnique({
    where: { task_id: dispute.task_id },
  });

  if (!payment) {
    throw new AppError('PAYMENT_NOT_FOUND', 'Payment not found', 404);
  }

  // Issue full refund
  await refundService.issueFullRefund(
    payment.id,
    'Customer win - dispute resolved',
    adminId,
  );

  // Reverse any pending payouts
  await refundService.reverseAllPayoutsForTask(
    dispute.task_id,
    'Customer win - dispute resolved',
    adminId,
  );

  // Check helper's dispute loss count and warn/suspend
  const lossCount = await disputeService.countDisputeLosses(dispute.task.helper_id);

  if (lossCount >= 3) {
    // Auto-suspend on 3rd loss
    const suspensionEndDate = new Date();
    suspensionEndDate.setDate(suspensionEndDate.getDate() + 30);

    await suspensionService.createSuspension(
      dispute.task.helper_id,
      'Suspended due to repeated dispute losses',
      adminId,
      suspensionEndDate,
    );
  } else {
    // Warn helper
    await suspensionService.warnHelper(
      dispute.task.helper_id,
      `Dispute loss (${lossCount}/3)`,
      adminId,
    );
  }

  // Update dispute
  const resolved = await prisma.dispute.update({
    where: { id: disputeId },
    data: {
      status: 'resolved',
      resolution_type: 'customer_win',
      resolved_at: new Date(),
    },
  });

  // Update task status back to completed
  await prisma.task.update({
    where: { id: dispute.task_id },
    data: { status: 'completed' },
  });

  // Log resolution
  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'dispute_resolution_customer_win',
      resource_type: 'Dispute',
      resource_id: disputeId,
      metadata: {
        notes,
        refund_amount: payment.final_amount,
        helper_loss_count: lossCount,
      },
    } as any,
  });

  console.log(
    `[Resolution] Dispute ${dispute.dispute_id_display} resolved as CUSTOMER WIN`,
  );

  return {
    dispute_id: resolved.id,
    dispute_id_display: resolved.dispute_id_display,
    resolution_type: 'customer_win',
    refund_amount: payment.final_amount,
    helper_action:
      lossCount >= 3 ? 'suspended' : `warned (${lossCount}/3)`,
    resolved_at: resolved.resolved_at,
  };
};

/**
 * Resolve dispute in favor of helper (full payout, no refund)
 */
export const resolveDisputeAsHelperWin = async (
  disputeId: string,
  adminId: string,
  notes?: string,
): Promise<any> => {
  // Get dispute and payment
  const dispute = await prisma.dispute.findUnique({
    where: { id: disputeId },
    include: { task: true },
  });

  if (!dispute) {
    throw new AppError('DISPUTE_NOT_FOUND', 'Dispute not found', 404);
  }

  if (!['open', 'investigating'].includes(dispute.status)) {
    throw new AppError(
      'INVALID_STATUS',
      'Dispute must be open or investigating',
      400,
    );
  }

  // Get payment
  const payment = await prisma.payment.findUnique({
    where: { task_id: dispute.task_id },
  });

  if (!payment) {
    throw new AppError('PAYMENT_NOT_FOUND', 'Payment not found', 404);
  }

  // Ensure helper gets full payout (create new payout if needed)
  let payout = await prisma.payout.findFirst({
    where: {
      task_ids: {
        has: dispute.task_id,
      },
    },
  });

  if (!payout) {
    // Create new payout
    const lastPayout = await prisma.payout.findFirst({
      orderBy: { created_at: 'desc' },
      select: { payout_id_display: true },
    });

    const lastNumber = lastPayout
      ? parseInt(lastPayout.payout_id_display.replace('P-', ''))
      : 0;
    const payoutIdDisplay = `P-${String(lastNumber + 1).padStart(6, '0')}`;

    payout = await prisma.payout.create({
      data: {
        payout_id_display: payoutIdDisplay,
        helper_id: dispute.task.helper_id,
        total_amount: payment.helper_payout_amount,
        payout_method: 'bank_transfer',
        status: 'pending',
        task_ids: [dispute.task_id],
      },
    });
  } else {
    // Restore payout if it was failed
    if (payout.status === 'failed') {
      await prisma.payout.update({
        where: { id: payout.id },
        data: { status: 'pending' },
      });
    }
  }

  // Update dispute
  const resolved = await prisma.dispute.update({
    where: { id: disputeId },
    data: {
      status: 'resolved',
      resolution_type: 'helper_win',
      resolved_at: new Date(),
    },
  });

  // Update task status back to completed
  await prisma.task.update({
    where: { id: dispute.task_id },
    data: { status: 'completed' },
  });

  // Log resolution
  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'dispute_resolution_helper_win',
      resource_type: 'Dispute',
      resource_id: disputeId,
      metadata: {
        notes,
        payout_amount: payment.helper_payout_amount,
      },
    } as any,
  });

  console.log(
    `[Resolution] Dispute ${dispute.dispute_id_display} resolved as HELPER WIN`,
  );

  return {
    dispute_id: resolved.id,
    dispute_id_display: resolved.dispute_id_display,
    resolution_type: 'helper_win',
    payout_amount: payment.helper_payout_amount,
    resolved_at: resolved.resolved_at,
  };
};

/**
 * Resolve dispute as partial (split between customer and helper)
 */
export const resolveDisputeAsPartial = async (
  disputeId: string,
  customerRefundAmount: number,
  helperPayoutAmount: number,
  adminId: string,
  notes?: string,
): Promise<any> => {
  // Get dispute and payment
  const dispute = await prisma.dispute.findUnique({
    where: { id: disputeId },
    include: { task: true },
  });

  if (!dispute) {
    throw new AppError('DISPUTE_NOT_FOUND', 'Dispute not found', 404);
  }

  if (!['open', 'investigating'].includes(dispute.status)) {
    throw new AppError(
      'INVALID_STATUS',
      'Dispute must be open or investigating',
      400,
    );
  }

  // Get payment
  const payment = await prisma.payment.findUnique({
    where: { task_id: dispute.task_id },
  });

  if (!payment) {
    throw new AppError('PAYMENT_NOT_FOUND', 'Payment not found', 404);
  }

  // Issue partial refund
  const refund = await refundService.issuePartialRefund(
    payment.id,
    customerRefundAmount,
    helperPayoutAmount,
    'Dispute resolved as partial',
    adminId,
  );

  // Update dispute
  const resolved = await prisma.dispute.update({
    where: { id: disputeId },
    data: {
      status: 'resolved',
      resolution_type: 'partial',
      resolved_at: new Date(),
    },
  });

  // Update task status back to completed
  await prisma.task.update({
    where: { id: dispute.task_id },
    data: { status: 'completed' },
  });

  // Log resolution
  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'dispute_resolution_partial',
      resource_type: 'Dispute',
      resource_id: disputeId,
      metadata: {
        notes,
        customer_refund: customerRefundAmount,
        helper_payout: helperPayoutAmount,
      },
    } as any,
  });

  console.log(
    `[Resolution] Dispute ${dispute.dispute_id_display} resolved as PARTIAL`,
  );

  return {
    dispute_id: resolved.id,
    dispute_id_display: resolved.dispute_id_display,
    resolution_type: 'partial',
    customer_refund: customerRefundAmount,
    helper_payout: helperPayoutAmount,
    platform_keeps: refund.platform_keeps,
    resolved_at: resolved.resolved_at,
  };
};

/**
 * Dismiss dispute without refund or payout change
 */
export const dismissDispute = async (
  disputeId: string,
  adminId: string,
  reason: string,
  notes?: string,
): Promise<any> => {
  // Get dispute and payment
  const dispute = await prisma.dispute.findUnique({
    where: { id: disputeId },
    include: { task: true },
  });

  if (!dispute) {
    throw new AppError('DISPUTE_NOT_FOUND', 'Dispute not found', 404);
  }

  if (!['open', 'investigating'].includes(dispute.status)) {
    throw new AppError(
      'INVALID_STATUS',
      'Dispute must be open or investigating',
      400,
    );
  }

  // Get payment
  const payment = await prisma.payment.findUnique({
    where: { task_id: dispute.task_id },
  });

  if (!payment) {
    throw new AppError('PAYMENT_NOT_FOUND', 'Payment not found', 404);
  }

  // Issue dismissal (no refund)
  await refundService.issueDismissal(
    payment.id,
    reason,
    adminId,
  );

  // Update dispute
  const resolved = await prisma.dispute.update({
    where: { id: disputeId },
    data: {
      status: 'resolved',
      resolution_type: 'dismissed',
      resolved_at: new Date(),
    },
  });

  // Update task status back to completed
  await prisma.task.update({
    where: { id: dispute.task_id },
    data: { status: 'completed' },
  });

  // Log resolution
  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'dispute_dismissed',
      resource_type: 'Dispute',
      resource_id: disputeId,
      metadata: {
        reason,
        notes,
      },
    } as any,
  });

  console.log(
    `[Resolution] Dispute ${dispute.dispute_id_display} DISMISSED: ${reason}`,
  );

  return {
    dispute_id: resolved.id,
    dispute_id_display: resolved.dispute_id_display,
    resolution_type: 'dismissed',
    reason,
    resolved_at: resolved.resolved_at,
  };
};
