import prisma from '../config/prisma';
import { AppError } from '../middleware/error';

/**
 * Create a suspension for a helper
 */
export const createSuspension = async (
  helperId: string,
  reason: string,
  triggeredByAdminId: string,
  suspensionEndAt?: Date,
): Promise<any> => {
  // Validate helper exists
  const helper = await prisma.helper.findUnique({
    where: { id: helperId },
    include: { user: true },
  });

  if (!helper) {
    throw new AppError('HELPER_NOT_FOUND', 'Helper not found', 404);
  }

  // Create suspension log
  const suspension = await prisma.helperSuspensionLog.create({
    data: {
      helper_id: helperId,
      triggered_by_admin_id: triggeredByAdminId,
      reason,
      suspension_start_at: new Date(),
      suspension_end_at: suspensionEndAt,
    },
  });

  // Update helper status
  await prisma.helper.update({
    where: { id: helperId },
    data: {
      helper_status: 'suspended',
    },
  });

  // Log to audit trail
  await prisma.auditLog.create({
    data: {
      admin_id: triggeredByAdminId,
      action: 'helper_suspended',
      resource_type: 'Helper',
      resource_id: helperId,
      metadata: { reason, suspension_end_at: suspensionEndAt },
    } as any,
  });

  console.log(
    `[Suspension] Suspended helper ${helper.user?.name} (${helperId}): ${reason}`,
  );

  return {
    id: suspension.id,
    helper_id: helperId,
    reason,
    suspension_start_at: suspension.suspension_start_at,
    suspension_end_at: suspension.suspension_end_at,
  };
};

/**
 * Warn a helper (with auto-suspension on 3rd warning)
 */
export const warnHelper = async (
  helperId: string,
  reason: string,
  adminId: string,
): Promise<any> => {
  // Count existing warnings for this helper
  const warnings = await prisma.auditLog.findMany({
    where: {
      resource_id: helperId,
      action: 'helper_warned',
    },
  });

  const warningCount = warnings.length + 1;

  // Log warning
  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'helper_warned',
      resource_type: 'Helper',
      resource_id: helperId,
      metadata: { reason, warning_count: warningCount },
    } as any,
  });

  console.log(
    `[Suspension] Warned helper ${helperId}: ${reason} (${warningCount}/3)`,
  );

  // Auto-suspend on 3rd warning
  if (warningCount >= 3) {
    const suspensionEndDate = new Date();
    suspensionEndDate.setDate(suspensionEndDate.getDate() + 30); // 30-day suspension

    await createSuspension(
      helperId,
      `Auto-suspended after ${warningCount} warnings`,
      adminId,
      suspensionEndDate,
    );

    return {
      warned: true,
      warning_count: warningCount,
      auto_suspended: true,
      suspension_days: 30,
    };
  }

  return {
    warned: true,
    warning_count: warningCount,
    auto_suspended: false,
  };
};

/**
 * Check if helper has active suspension
 */
export const checkSuspensionStatus = async (helperId: string): Promise<any> => {
  const suspension = await prisma.helperSuspensionLog.findFirst({
    where: {
      helper_id: helperId,
    },
    orderBy: {
      created_at: 'desc',
    },
  });

  if (!suspension) {
    return {
      suspended: false,
    };
  }

  const now = new Date();
  const isSuspended =
    suspension.suspension_end_at === null ||
    suspension.suspension_end_at > now;

  return {
    suspended: isSuspended,
    reason: suspension.reason,
    suspension_start_at: suspension.suspension_start_at,
    suspension_end_at: suspension.suspension_end_at,
    appeal_status: suspension.appeal_status,
  };
};

/**
 * Count dispute losses for a helper (customer_win resolutions)
 */
export const countDisputeLosses = async (helperId: string): Promise<number> => {
  const losses = await prisma.dispute.findMany({
    where: {
      task: {
        helper_id: helperId,
      },
      resolution_type: 'customer_win',
    },
  });

  return losses.length;
};

/**
 * Unlock a suspension (after appeal approval or time passed)
 */
export const unlockSuspension = async (
  suspensionId: string,
  adminId: string,
  notes?: string,
): Promise<any> => {
  const suspension = await prisma.helperSuspensionLog.findUnique({
    where: { id: suspensionId },
  });

  if (!suspension) {
    throw new AppError('SUSPENSION_NOT_FOUND', 'Suspension not found', 404);
  }

  // Check if suspension is still active
  const now = new Date();
  if (suspension.suspension_end_at && suspension.suspension_end_at <= now) {
    // Suspension time passed, auto-unlock helper
    await prisma.helper.update({
      where: { id: suspension.helper_id },
      data: {
        helper_status: 'available',
      },
    });

    // Log unlock
    await prisma.auditLog.create({
      data: {
        admin_id: adminId,
        action: 'suspension_lifted',
        resource_type: 'Helper',
        resource_id: suspension.helper_id,
        metadata: { reason: 'Time-based expiration', notes },
      } as any,
    });

    console.log(
      `[Suspension] Lifted suspension for helper ${suspension.helper_id} (time passed)`,
    );
  }

  return {
    helper_id: suspension.helper_id,
    suspension_id: suspensionId,
    unlocked: true,
  };
};

/**
 * Appeal a suspension (helper can request review)
 */
export const appealSuspension = async (
  suspensionId: string,
  appealReason: string,
): Promise<any> => {
  const suspension = await prisma.helperSuspensionLog.findUnique({
    where: { id: suspensionId },
  });

  if (!suspension) {
    throw new AppError('SUSPENSION_NOT_FOUND', 'Suspension not found', 404);
  }

  // Check appeal window (7 days)
  const now = new Date();
  const appealDeadline = new Date(suspension.suspension_start_at);
  appealDeadline.setDate(appealDeadline.getDate() + 7);

  if (now > appealDeadline) {
    throw new AppError(
      'APPEAL_WINDOW_CLOSED',
      'Appeal window has closed (7 days)',
      400,
    );
  }

  // Update suspension with appeal
  const updated = await prisma.helperSuspensionLog.update({
    where: { id: suspensionId },
    data: {
      appeal_reason: appealReason,
      appeal_status: 'pending',
    },
  });

  console.log(
    `[Suspension] Helper ${suspension.helper_id} appealed suspension`,
  );

  return {
    suspension_id: updated.id,
    appeal_status: updated.appeal_status,
    appeal_reason: updated.appeal_reason,
  };
};
