import prisma from '../config/prisma';
import { AppError } from '../middleware/error';
import * as refundService from './refund';

/**
 * Reassign task to a different helper
 */
export const reassignTask = async (
  taskId: string,
  newHelperId: string,
  adminId: string,
  reason?: string,
): Promise<any> => {
  // Get task
  const task = await prisma.task.findUnique({
    where: { id: taskId },
    include: { helper: { include: { user: true } }, customer: true },
  });

  if (!task) {
    throw new AppError('TASK_NOT_FOUND', 'Task not found', 404);
  }

  // Validate task is assignable (not in_progress, completed, etc.)
  if (!['assigned', 'on_the_way'].includes(task.status)) {
    throw new AppError(
      'INVALID_STATUS',
      'Only assigned or on_the_way tasks can be reassigned',
      400,
    );
  }

  if (!task.helper_id) {
    throw new AppError(
      'NO_HELPER_ASSIGNED',
      'Task has no helper assigned',
      400,
    );
  }

  const oldHelperId = task.helper_id;

  // Validate new helper exists
  const newHelper = await prisma.helper.findUnique({
    where: { id: newHelperId },
    include: { user: true },
  });

  if (!newHelper) {
    throw new AppError('HELPER_NOT_FOUND', 'New helper not found', 404);
  }

  // Update task
  const updated = await prisma.task.update({
    where: { id: taskId },
    data: {
      helper_id: newHelperId,
    },
  });

  // Create status history entry
  await prisma.taskStatusHistory.create({
    data: {
      task_id: taskId,
      status: task.status,
      notes: `Reassigned from ${task.helper?.user?.name} to ${newHelper.user?.name}. Reason: ${reason || 'Admin reassignment'}`,
    },
  });

  // Log reassignment
  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'task_reassigned',
      resource_type: 'Task',
      resource_id: taskId,
      old_values: { helper_id: oldHelperId },
      new_values: { helper_id: newHelperId },
      metadata: { reason } as any,
    },
  });

  console.log(
    `[Task Management] Reassigned task ${taskId} from ${oldHelperId} to ${newHelperId}`,
  );

  return {
    task_id: updated.id,
    task_id_display: updated.task_id_display,
    old_helper_id: oldHelperId,
    new_helper_id: newHelperId,
    status: updated.status,
    updated_at: new Date(),
  };
};

/**
 * Cancel a task
 */
export const cancelTask = async (
  taskId: string,
  adminId: string,
  reason: string,
  refundCustomer?: boolean,
): Promise<any> => {
  // Get task
  const task = await prisma.task.findUnique({
    where: { id: taskId },
    include: {
      helper: { include: { user: true } },
      customer: true,
    },
  });

  if (!task) {
    throw new AppError('TASK_NOT_FOUND', 'Task not found', 404);
  }

  // Validate task can be cancelled
  if (!['unassigned', 'assigned', 'on_the_way'].includes(task.status)) {
    throw new AppError(
      'INVALID_STATUS',
      'Only unassigned, assigned, or on_the_way tasks can be cancelled',
      400,
    );
  }

  // Get payment if exists
  const payment = await prisma.payment.findUnique({
    where: { task_id: taskId },
  });

  let refundIssued = false;
  let refundAmount = 0;

  // Issue refund if requested and payment exists
  if (refundCustomer && payment) {
    if (payment.status === 'completed' || payment.status === 'processing') {
      await refundService.issueFullRefund(
        payment.id,
        `Task cancelled: ${reason}`,
        adminId,
      );
      refundIssued = true;
      refundAmount = payment.final_amount;
    }
  }

  // Reverse any pending/processing payouts
  if (task.helper_id) {
    const payouts = await prisma.payout.findMany({
      where: {
        task_ids: {
          has: taskId,
        },
        status: {
          in: ['pending', 'processing'],
        },
      },
    });

    for (const payout of payouts) {
      await prisma.payout.update({
        where: { id: payout.id },
        data: {
          status: 'failed',
        },
      });
    }
  }

  // Update task
  const updated = await prisma.task.update({
    where: { id: taskId },
    data: {
      status: 'cancelled',
    },
  });

  // Create status history entry
  await prisma.taskStatusHistory.create({
    data: {
      task_id: taskId,
      status: 'cancelled',
      notes: `Cancelled by admin. Reason: ${reason}${refundIssued ? `. Refund issued: ₹${refundAmount}` : ''}`,
    },
  });

  // Log cancellation
  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'task_cancelled',
      resource_type: 'Task',
      resource_id: taskId,
      old_values: { status: task.status },
      new_values: { status: 'cancelled' },
      metadata: { reason, refund_issued: refundIssued, refund_amount: refundAmount } as any,
    },
  });

  console.log(`[Task Management] Cancelled task ${taskId}: ${reason}`);

  return {
    task_id: updated.id,
    task_id_display: updated.task_id_display,
    status: updated.status,
    reason,
    refund_issued: refundIssued,
    refund_amount: refundAmount || null,
    cancelled_at: new Date(),
  };
};

/**
 * Get comprehensive task details for admin review
 */
export const getTaskDetails = async (taskId: string): Promise<any> => {
  const task = await prisma.task.findUnique({
    where: { id: taskId },
    include: {
      customer: {
        select: {
          id: true,
          name: true,
          phone_number: true,
          rating: true,
        },
      },
      helper: {
        include: {
          user: {
            select: {
              name: true,
              phone_number: true,
              rating: true,
            },
          },
        },
      },
    },
  });

  if (!task) {
    throw new AppError('TASK_NOT_FOUND', 'Task not found', 404);
  }

  // Get payment
  const payment = await prisma.payment.findUnique({
    where: { task_id: taskId },
  });

  // Get status history
  const history = await prisma.taskStatusHistory.findMany({
    where: { task_id: taskId },
    orderBy: { created_at: 'asc' },
  });

  // Get dispute if any
  const dispute = await prisma.dispute.findFirst({
    where: { task_id: taskId },
  });

  // Get review if completed
  const review = await prisma.review.findUnique({
    where: { task_id: taskId },
  });

  return {
    id: task.id,
    task_id_display: task.task_id_display,
    task_info: {
      type: task.task_type,
      category: task.category,
      title: task.title,
      description: task.description,
      budget: task.budget,
      final_amount: task.final_amount,
    },
    location: {
      latitude: task.location_point?.coordinates[1] || null,
      longitude: task.location_point?.coordinates[0] || null,
    },
    customer: task.customer,
    helper: task.helper
      ? {
          id: task.helper.id,
          name: task.helper.user?.name,
          phone_number: task.helper.user?.phone_number,
          rating: task.helper.user?.rating,
        }
      : null,
    status: task.status,
    payment: payment
      ? {
          final_amount: payment.final_amount,
          platform_fee: payment.platform_fee_amount,
          helper_payout: payment.helper_payout_amount,
          status: payment.status,
          completed_at: payment.completed_at,
        }
      : null,
    status_history: history.map((h) => ({
      status: h.status,
      timestamp: h.created_at,
      notes: h.notes,
    })),
    dispute: dispute
      ? {
          dispute_id_display: dispute.dispute_id_display,
          status: dispute.status,
          resolution_type: dispute.resolution_type,
        }
      : null,
    review: review
      ? {
          customer_rating: review.customer_to_helper_rating,
          customer_text: review.customer_to_helper_text,
          helper_rating: review.helper_to_customer_rating,
          helper_text: review.helper_to_customer_text,
        }
      : null,
    created_at: task.created_at,
  };
};

/**
 * List tasks ready for reassignment
 */
export const listTasksForReassignment = async (
  limit: number = 20,
  offset: number = 0,
): Promise<any[]> => {
  const tasks = await prisma.task.findMany({
    where: {
      status: {
        in: ['assigned', 'on_the_way'],
      },
      helper_id: {
        not: null,
      },
    },
    include: {
      customer: {
        select: {
          name: true,
        },
      },
      helper: {
        include: {
          user: {
            select: {
              name: true,
            },
          },
        },
      },
    },
    orderBy: {
      created_at: 'desc',
    },
    skip: offset,
    take: limit,
  });

  return tasks.map((t) => ({
    task_id: t.id,
    task_id_display: t.task_id_display,
    title: t.title,
    status: t.status,
    customer_name: t.customer?.name,
    helper_name: t.helper?.user?.name,
    budget: t.budget,
    assigned_at: t.created_at,
  }));
};

/**
 * List tasks ready for cancellation
 */
export const listTasksForCancellation = async (
  limit: number = 20,
  offset: number = 0,
): Promise<any[]> => {
  const tasks = await prisma.task.findMany({
    where: {
      status: {
        in: ['unassigned', 'assigned', 'on_the_way'],
      },
    },
    include: {
      customer: {
        select: {
          name: true,
        },
      },
      helper: {
        include: {
          user: {
            select: {
              name: true,
            },
          },
        },
      },
    },
    orderBy: {
      created_at: 'desc',
    },
    skip: offset,
    take: limit,
  });

  return tasks.map((t) => ({
    task_id: t.id,
    task_id_display: t.task_id_display,
    title: t.title,
    status: t.status,
    customer_name: t.customer?.name,
    helper_name: t.helper?.user?.name || 'Unassigned',
    budget: t.budget,
    created_at: t.created_at,
  }));
};
