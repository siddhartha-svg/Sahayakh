import prisma from '../config/prisma';
import { AppError } from '../middleware/error';
import { calculateDistance, estimateETA, estimatePrice, PricingEstimate } from '../utils/location';

export interface CreateTaskInput {
  task_type: 'personal' | 'business';
  category: string;
  description: string;
  location_name: string;
  location_point: { latitude: number; longitude: number };
  preferred_date: string;
  preferred_time: string;
  budget_min: number;
  budget_max: number;
  business_name?: string;
  gst_bill_required?: boolean;
  photo_urls?: string[];
}

export const generateTaskId = async (): Promise<string> => {
  const lastTask = await prisma.task.findFirst({
    orderBy: { created_at: 'desc' },
    select: { task_id_display: true },
  });

  let nextNumber = 1;
  if (lastTask && lastTask.task_id_display) {
    const match = lastTask.task_id_display.match(/SKT(\d+)/);
    if (match) {
      nextNumber = parseInt(match[1], 10) + 1;
    }
  }

  return `SKT${String(nextNumber).padStart(5, '0')}`;
};

export const createTask = async (customerId: string, input: CreateTaskInput) => {
  const taskId = await generateTaskId();

  const task = await prisma.task.create({
    data: {
      task_id_display: taskId,
      customer_id: customerId,
      task_type: input.task_type,
      category: input.category,
      description: input.description,
      location_name: input.location_name,
      location_point: JSON.stringify(input.location_point),
      preferred_date: input.preferred_date,
      preferred_time: input.preferred_time,
      budget_min: input.budget_min,
      budget_max: input.budget_max,
      status: 'unassigned',
      business_name: input.business_name,
      gst_bill_required: input.gst_bill_required || false,
      photo_urls: input.photo_urls || [],
    },
  });

  return task;
};

export const findTaskById = async (taskId: string) => {
  return prisma.task.findUnique({
    where: { id: taskId },
    include: {
      customer: {
        select: { id: true, name: true, phone_number: true },
      },
      helper: {
        select: { id: true, user_id: true },
      },
    },
  });
};

export const getNearbyHelpers = async (
  taskId: string,
  customerId: string,
  options: {
    latitude?: number;
    longitude?: number;
    radius_km?: number;
    sort_by?: 'nearest' | 'rating' | 'price';
  },
) => {
  const task = await findTaskById(taskId);

  if (!task) {
    throw new AppError('TASK_NOT_FOUND', 'Task not found', 404);
  }

  if (task.customer_id !== customerId) {
    throw new AppError('UNAUTHORIZED', 'Not authorized to view helpers for this task', 403);
  }

  const locationPoint = JSON.parse(task.location_point);
  const latitude = options.latitude ?? locationPoint.latitude;
  const longitude = options.longitude ?? locationPoint.longitude;
  const radiusKm = options.radius_km ?? 25;
  const sortBy = options.sort_by ?? 'nearest';

  if (radiusKm < 1 || radiusKm > 50) {
    throw new AppError('INVALID_RADIUS', 'Radius must be between 1 and 50 km', 400);
  }

  const validSorts = ['nearest', 'rating', 'price'];
  if (!validSorts.includes(sortBy)) {
    throw new AppError('INVALID_SORT', 'Sort must be one of: nearest, rating, price', 400);
  }

  const pricingConfig = await prisma.pricingConfig.findUnique({
    where: { config_key: 'current' },
  });

  if (!pricingConfig) {
    throw new AppError('PRICING_CONFIG_NOT_FOUND', 'Pricing configuration not found', 500);
  }

  const helpers = await prisma.helper.findMany({
    where: {
      AND: [
        { verification_status: 'verified' },
        { helper_status: { in: ['online', 'active'] } },
        { background_check_status: 'cleared' },
        task.task_type === 'personal' ? { accepts_personal_tasks: true } : { accepts_business_tasks: true },
      ],
    },
    include: {
      user: {
        select: { id: true, name: true, phone_number: true, location_point: true },
      },
    },
    take: 50,
  });

  const helpersWithDistance = helpers
    .map((helper) => {
      if (!helper.user.location_point) {
        return null;
      }

      const helperLocation = JSON.parse(helper.user.location_point);
      const distanceKm = calculateDistance(latitude, longitude, helperLocation.latitude, helperLocation.longitude);

      if (distanceKm > radiusKm || distanceKm > helper.service_radius_km) {
        return null;
      }

      const categoryMatches =
        helper.preferred_categories.length === 0 || helper.preferred_categories.includes(task.category);

      if (!categoryMatches) {
        return null;
      }

      const etaMinutes = estimateETA(distanceKm);
      const priceEstimate = estimatePrice(
        pricingConfig.base_fare_rupees,
        pricingConfig.per_km_rate,
        distanceKm,
        task.task_type === 'business',
        pricingConfig.business_task_multiplier,
        pricingConfig.minimum_fare_rupees,
      );

      return {
        id: helper.id,
        user_id: helper.user_id,
        name: helper.user.name,
        phone_number: helper.user.phone_number,
        rating: helper.rating,
        total_tasks: helper.total_tasks,
        average_response_time_minutes: helper.average_response_time_minutes,
        helper_status: helper.helper_status,
        verification_status: helper.verification_status,
        background_check_status: helper.background_check_status,
        accepts_personal_tasks: helper.accepts_personal_tasks,
        accepts_business_tasks: helper.accepts_business_tasks,
        service_radius_km: helper.service_radius_km,
        distance_km: Math.round(distanceKm * 10) / 10,
        eta_minutes: etaMinutes,
        estimated_price_min: priceEstimate.min,
        estimated_price_max: priceEstimate.max,
        badges: ['verified', 'background_checked'],
        online_since: helper.online_since?.toISOString(),
      };
    })
    .filter(Boolean);

  let sorted = helpersWithDistance;

  if (sortBy === 'rating') {
    sorted.sort((a, b) => {
      if (b!.rating !== a!.rating) {
        return b!.rating - a!.rating;
      }
      return a!.distance_km - b!.distance_km;
    });
  } else if (sortBy === 'price') {
    sorted.sort((a, b) => a!.estimated_price_min - b!.estimated_price_min);
  } else {
    sorted.sort((a, b) => a!.distance_km - b!.distance_km);
  }

  return {
    helpers: sorted.slice(0, 10),
    count: sorted.length > 10 ? 10 : sorted.length,
    sort_by: sortBy,
    task_id: taskId,
    total_available: helpersWithDistance.length,
  };
};

export const assignHelperToTask = async (taskId: string, customerId: string, helperId: string) => {
  const task = await findTaskById(taskId);

  if (!task) {
    throw new AppError('TASK_NOT_FOUND', 'Task not found', 404);
  }

  if (task.customer_id !== customerId) {
    throw new AppError('UNAUTHORIZED', 'Not authorized to assign helpers for this task', 403);
  }

  if (task.status !== 'unassigned') {
    throw new AppError('TASK_ALREADY_ASSIGNED', 'Task is already assigned or completed', 400);
  }

  const helper = await prisma.helper.findUnique({
    where: { id: helperId },
    include: { user: true },
  });

  if (!helper) {
    throw new AppError('HELPER_NOT_FOUND', 'Helper not found', 404);
  }

  if (helper.verification_status !== 'verified') {
    throw new AppError('HELPER_NOT_VERIFIED', 'Helper is not verified', 400);
  }

  if (helper.helper_status === 'suspended') {
    throw new AppError('HELPER_SUSPENDED', 'Helper is suspended', 400);
  }

  const updatedTask = await prisma.task.update({
    where: { id: taskId },
    data: {
      helper_id: helperId,
      status: 'assigned',
    },
  });

  await prisma.taskStatusHistory.create({
    data: {
      task_id: taskId,
      previous_status: 'unassigned',
      new_status: 'assigned',
    },
  });

  await prisma.notification.create({
    data: {
      user_id: helper.user_id,
      notification_type: 'task_assigned',
      title: 'New task assigned',
      body: `Task ${task.task_id_display} has been assigned to you by ${task.customer!.name}.`,
      related_task_id: taskId,
    },
  });

  // TRIGGER: Broadcast task request to helper via Socket.IO (45-second countdown)
  try {
    const socketHandlers = await import('./socket-handlers');
    const socket = (global as any).socket;
    if (socket) {
      const pricingConfig = await prisma.pricingConfig.findUnique({
        where: { config_key: 'current' },
      });
      await socketHandlers.broadcastTaskRequestToHelper(taskId, helperId, socket, pricingConfig || undefined);
    }
  } catch (err) {
    console.error('Error broadcasting task request to helper:', err);
    // Don't fail the assignment if socket broadcast fails
  }

  return updatedTask;
};
