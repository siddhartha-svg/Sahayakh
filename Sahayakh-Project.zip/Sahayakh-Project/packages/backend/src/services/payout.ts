import prisma from '../config/prisma';
import * as paymentService from './payment';
import * as pricingService from './pricing';
import { AppError } from '../middleware/error';

const MINIMUM_PAYOUT_AMOUNT = 100; // ₹100 minimum withdrawal

/**
 * Calculate available balance for helper to withdraw
 * = sum of completed payments - sum of completed payouts
 */
export const calculateHelperBalance = async (helperId: string): Promise<number> => {
  // Sum all completed payments where helper is assigned
  const completedPayments = await prisma.payment.aggregate({
    where: {
      task: {
        helper_id: helperId,
      },
      status: 'completed',
    },
    _sum: {
      helper_payout_amount: true,
    },
  });

  const totalCompleted = completedPayments._sum.helper_payout_amount || 0;

  // Sum all completed payouts
  const completedPayouts = await prisma.payout.aggregate({
    where: {
      helper_id: helperId,
      status: 'completed',
    },
    _sum: {
      total_amount: true,
    },
  });

  const totalPaidOut = completedPayouts._sum.total_amount || 0;

  const available = totalCompleted - totalPaidOut;
  return Math.max(0, available); // Never negative
};

/**
 * Request a payout (withdrawal)
 *
 * Validates:
 * - Helper is verified and background checked
 * - Not suspended or has active disputes
 * - Amount >= minimum (₹100)
 * - Amount <= available balance
 * - Bank details are valid for the payout method
 */
export const requestPayout = async (
  helperId: string,
  amount: number,
  payoutMethod: 'bank_transfer' | 'upi',
  bankDetails?: {
    account_number?: string;
    ifsc_code?: string;
    holder_name?: string;
    upi_id?: string;
  },
): Promise<any> => {
  // Get helper to check status
  const helper = await prisma.helper.findUnique({
    where: { id: helperId },
    include: { user: true },
  });

  if (!helper) {
    throw new AppError('HELPER_NOT_FOUND', 'Helper not found', 404);
  }

  // Validate helper status
  if (helper.helper_status === 'suspended') {
    throw new AppError(
      'HELPER_SUSPENDED',
      'Suspended helpers cannot request payouts',
      403,
    );
  }

  if (helper.verification_status !== 'verified') {
    throw new AppError(
      'HELPER_NOT_VERIFIED',
      'Helper must be verified to request payout',
      400,
    );
  }

  if (helper.background_check_status !== 'cleared') {
    throw new AppError(
      'BACKGROUND_CHECK_INCOMPLETE',
      'Helper background check must be cleared',
      400,
    );
  }

  // Check for active disputes (tasks with status = 'disputed')
  const activeDispute = await prisma.task.findFirst({
    where: {
      helper_id: helperId,
      status: 'disputed',
    },
  });

  if (activeDispute) {
    throw new AppError(
      'ACTIVE_DISPUTE',
      'Cannot request payout while disputes are active',
      403,
    );
  }

  // Validate amount
  if (amount < MINIMUM_PAYOUT_AMOUNT) {
    throw new AppError(
      'AMOUNT_TOO_LOW',
      `Minimum payout amount is ₹${MINIMUM_PAYOUT_AMOUNT}`,
      400,
    );
  }

  // Check available balance
  const availableBalance = await calculateHelperBalance(helperId);
  if (amount > availableBalance) {
    throw new AppError(
      'INSUFFICIENT_BALANCE',
      `Insufficient balance. Available: ₹${availableBalance}`,
      400,
    );
  }

  // Validate bank details based on method
  if (payoutMethod === 'bank_transfer') {
    if (!bankDetails?.account_number || !bankDetails?.ifsc_code || !bankDetails?.holder_name) {
      throw new AppError(
        'INVALID_BANK_DETAILS',
        'Bank transfer requires account_number, ifsc_code, and holder_name',
        400,
      );
    }
  } else if (payoutMethod === 'upi') {
    if (!bankDetails?.upi_id) {
      throw new AppError(
        'INVALID_UPI',
        'UPI payment requires upi_id',
        400,
      );
    }
  }

  // Get last payout ID to increment
  const lastPayout = await prisma.payout.findFirst({
    orderBy: {
      created_at: 'desc',
    },
    select: {
      payout_id_display: true,
    },
  });

  const lastNumber = lastPayout
    ? parseInt(lastPayout.payout_id_display.replace('P-', ''))
    : 0;
  const payoutIdDisplay = `P-${String(lastNumber + 1).padStart(6, '0')}`;

  // Get all payment task IDs that will be covered by this payout
  const paymentsToCover = await prisma.payment.findMany({
    where: {
      task: {
        helper_id: helperId,
      },
      status: 'completed',
    },
    select: {
      task_id: true,
    },
    orderBy: {
      created_at: 'asc',
    },
  });

  let taskIdsCovered = [];
  let totalCovered = 0;

  for (const payment of paymentsToCover) {
    if (totalCovered < amount) {
      taskIdsCovered.push(payment.task_id);
      totalCovered += amount; // Simplified: in production, would track actual amounts
    }
  }

  // Create payout record
  const payout = await prisma.payout.create({
    data: {
      payout_id_display: payoutIdDisplay,
      helper_id: helperId,
      total_amount: amount,
      payout_method: payoutMethod,
      status: 'pending',
      bank_account_number: bankDetails?.account_number,
      upi_id: bankDetails?.upi_id,
      task_ids: taskIdsCovered,
    },
  });

  console.log(
    `[Payout] Created payout request ${payoutIdDisplay}: ₹${amount} (${payoutMethod})`,
  );

  return payout;
};

/**
 * Approve a pending payout (transition to processing)
 * Only admin can call this
 */
export const approvePayout = async (
  payoutId: string,
  adminId: string,
): Promise<any> => {
  const payout = await prisma.payout.findUnique({
    where: { id: payoutId },
  });

  if (!payout) {
    throw new AppError('PAYOUT_NOT_FOUND', 'Payout not found', 404);
  }

  if (payout.status !== 'pending') {
    throw new AppError(
      'PAYOUT_NOT_PENDING',
      'Only pending payouts can be approved',
      400,
    );
  }

  // Update status to processing
  const updated = await prisma.payout.update({
    where: { id: payoutId },
    data: {
      status: 'processing',
    },
  });

  // Log admin action
  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'payout_approve',
      resource_type: 'Payout',
      resource_id: payoutId,
    },
  });

  console.log(`[Payout] Approved payout ${payout.payout_id_display} by admin`);

  return updated;
};

/**
 * Mark payout as completed
 * Called when bank transfer/UPI is confirmed
 */
export const completePayout = async (
  payoutId: string,
  transferRefId?: string,
  notes?: string,
): Promise<any> => {
  const payout = await prisma.payout.findUnique({
    where: { id: payoutId },
    include: { helper: { include: { user: true } } },
  });

  if (!payout) {
    throw new AppError('PAYOUT_NOT_FOUND', 'Payout not found', 404);
  }

  if (payout.status !== 'processing') {
    throw new AppError(
      'PAYOUT_NOT_PROCESSING',
      'Only processing payouts can be completed',
      400,
    );
  }

  // Update status to completed
  const updated = await prisma.payout.update({
    where: { id: payoutId },
    data: {
      status: 'completed',
      processed_at: new Date(),
    },
  });

  // Notify helper (in production, would send push notification)
  console.log(
    `[Payout] Completed payout ${payout.payout_id_display}: ₹${payout.total_amount} to helper ${payout.helper?.user?.name}`,
  );

  return updated;
};

/**
 * Mark payout as failed
 * Called when bank transfer fails or admin manually fails it
 */
export const failPayout = async (
  payoutId: string,
  reason: string,
  adminId?: string,
): Promise<any> => {
  const payout = await prisma.payout.findUnique({
    where: { id: payoutId },
  });

  if (!payout) {
    throw new AppError('PAYOUT_NOT_FOUND', 'Payout not found', 404);
  }

  if (!['pending', 'processing'].includes(payout.status)) {
    throw new AppError(
      'INVALID_PAYOUT_STATUS',
      'Cannot fail completed or already-failed payout',
      400,
    );
  }

  // Update status to failed
  const updated = await prisma.payout.update({
    where: { id: payoutId },
    data: {
      status: 'failed',
    },
  });

  // Log failure
  if (adminId) {
    await prisma.auditLog.create({
      data: {
        admin_id: adminId,
        action: 'payout_fail',
        resource_type: 'Payout',
        resource_id: payoutId,
        new_values: { reason },
      },
    });
  }

  console.log(`[Payout] Failed payout ${payout.payout_id_display}: ${reason}`);

  // Notify helper to retry with updated bank details
  // In production: send push notification

  return updated;
};

/**
 * Get payout history for a helper
 * Returns last N payouts ordered by creation date (newest first)
 */
export const getPayoutHistory = async (
  helperId: string,
  limit: number = 10,
  offset: number = 0,
): Promise<any[]> => {
  const payouts = await prisma.payout.findMany({
    where: { helper_id: helperId },
    orderBy: { created_at: 'desc' },
    skip: offset,
    take: limit,
  });

  return payouts.map((p) => ({
    payout_id_display: p.payout_id_display,
    amount: p.total_amount,
    status: p.status,
    method: p.payout_method,
    created_at: p.created_at,
    processed_at: p.processed_at,
  }));
};

/**
 * Get detailed payout information for display to helper or admin
 */
export const getPayoutDetails = async (payoutId: string): Promise<any> => {
  const payout = await prisma.payout.findUnique({
    where: { id: payoutId },
    include: {
      helper: {
        include: { user: true },
      },
    },
  });

  if (!payout) {
    throw new AppError('PAYOUT_NOT_FOUND', 'Payout not found', 404);
  }

  return {
    id: payout.id,
    payout_id_display: payout.payout_id_display,
    amount: payout.total_amount,
    status: payout.status,
    method: payout.payout_method,
    helper_name: payout.helper?.user?.name,
    helper_phone: payout.helper?.user?.phone_number,
    bank_account: payout.bank_account_number ? '****' + payout.bank_account_number.slice(-4) : null,
    upi_id: payout.upi_id,
    created_at: payout.created_at,
    processed_at: payout.processed_at,
    task_ids: payout.task_ids,
  };
};

/**
 * Get admin payout list with filtering
 */
export const getAdminPayoutList = async (
  status?: 'pending' | 'processing' | 'completed' | 'failed',
  limit: number = 20,
  offset: number = 0,
): Promise<any[]> => {
  const payouts = await prisma.payout.findMany({
    where: status ? { status } : {},
    include: {
      helper: {
        include: { user: true },
      },
    },
    orderBy: { created_at: 'desc' },
    skip: offset,
    take: limit,
  });

  return payouts.map((p) => ({
    payout_id_display: p.payout_id_display,
    helper_name: p.helper?.user?.name,
    helper_id: p.helper_id,
    amount: p.total_amount,
    status: p.status,
    method: p.payout_method,
    created_at: p.created_at,
    processed_at: p.processed_at,
  }));
};

/**
 * Check if a helper's payouts should be withheld due to disputes or account issues
 */
export const shouldWithholdPayout = async (helperId: string): Promise<boolean> => {
  const helper = await prisma.helper.findUnique({
    where: { id: helperId },
  });

  if (!helper) {
    return true; // Withhold if helper doesn't exist
  }

  // Withhold if suspended
  if (helper.helper_status === 'suspended') {
    return true;
  }

  // Withhold if not verified
  if (helper.verification_status !== 'verified') {
    return true;
  }

  // Withhold if background check not cleared
  if (helper.background_check_status !== 'cleared') {
    return true;
  }

  // Withhold if has active disputes
  const activeDispute = await prisma.task.findFirst({
    where: {
      helper_id: helperId,
      status: 'disputed',
    },
  });

  if (activeDispute) {
    return true;
  }

  return false;
};
