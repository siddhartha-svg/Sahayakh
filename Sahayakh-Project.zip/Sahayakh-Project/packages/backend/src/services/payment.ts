import prisma from '../config/prisma';
import * as pricingService from './pricing';
import { AppError } from '../middleware/error';

/**
 * Create a payment record for a task
 * Used when task is completed to record the transaction
 */
export const createPayment = async (
  taskId: string,
  customerId: string,
  finalAmount: number,
  config: any,
): Promise<any> => {
  // Validate task exists and is completed
  const task = await prisma.task.findUnique({
    where: { id: taskId },
  });

  if (!task) {
    throw new AppError('TASK_NOT_FOUND', 'Task not found', 404);
  }

  if (task.customer_id !== customerId) {
    throw new AppError(
      'UNAUTHORIZED',
      'Only task creator can create payment',
      403,
    );
  }

  if (task.status !== 'completed') {
    throw new AppError(
      'TASK_NOT_COMPLETED',
      'Task must be completed to create payment',
      400,
    );
  }

  // Check if payment already exists
  const existingPayment = await prisma.payment.findUnique({
    where: { task_id: taskId },
  });

  if (existingPayment) {
    throw new AppError(
      'PAYMENT_EXISTS',
      'Payment already exists for this task',
      400,
    );
  }

  // Calculate payment breakdown
  const breakdown = pricingService.calculatePaymentBreakdown(
    finalAmount,
    config.platform_fee_percent,
  );

  // Create payment record
  const payment = await prisma.payment.create({
    data: {
      task_id: taskId,
      customer_id: customerId,
      final_amount: breakdown.finalAmount,
      task_amount: breakdown.finalAmount,
      distance_surcharge: 0, // Set by caller if needed
      time_surcharge: 0, // Set by caller if needed
      peak_multiplier: 1.0, // Set by caller if needed
      platform_fee_amount: breakdown.platformFeeAmount,
      helper_payout_amount: breakdown.helperPayoutAmount,
      payment_method: 'pending',
      status: 'pending',
    },
  });

  return payment;
};

/**
 * Update payment status
 * Transitions: pending → processing → completed/failed
 */
export const updatePaymentStatus = async (
  paymentId: string,
  newStatus: 'pending' | 'processing' | 'completed' | 'failed' | 'refunded',
  metadata?: any,
): Promise<any> => {
  const payment = await prisma.payment.findUnique({
    where: { id: paymentId },
  });

  if (!payment) {
    throw new AppError('PAYMENT_NOT_FOUND', 'Payment not found', 404);
  }

  // Update payment
  const updated = await prisma.payment.update({
    where: { id: paymentId },
    data: {
      status: newStatus,
      completed_at: newStatus === 'completed' ? new Date() : payment.completed_at,
    },
  });

  // Log status change
  console.log(
    `[Payment] Updated payment ${paymentId}: ${payment.status} → ${newStatus}`,
  );

  return updated;
};

/**
 * Get all completed payments for a helper
 * Used to calculate total earnings and for payout breakdown
 */
export const getHelperPaymentHistory = async (helperId: string): Promise<any[]> => {
  const payments = await prisma.payment.findMany({
    where: {
      task: {
        helper_id: helperId,
      },
      status: 'completed',
    },
    include: {
      task: {
        select: {
          id: true,
          task_id_display: true,
          task_type: true,
          category: true,
          created_at: true,
        },
      },
    },
    orderBy: {
      created_at: 'desc',
    },
  });

  return payments.map((p) => ({
    task_id_display: p.task.task_id_display,
    amount: p.helper_payout_amount,
    status: p.status,
    date: p.created_at,
    task_type: p.task.task_type,
    category: p.task.category,
  }));
};

/**
 * Get payment for a specific task
 */
export const getTaskPayment = async (taskId: string): Promise<any> => {
  const payment = await prisma.payment.findUnique({
    where: { task_id: taskId },
  });

  return payment;
};

/**
 * Process payment when task is completed
 * This is the main entry point called when a task transitions to "completed"
 *
 * Handles:
 * - Final amount calculation based on actual distance/duration
 * - Payment breakdown (platform fee + helper payout)
 * - Payment record creation
 * - Helper balance increment
 * - Dispute handling (if disputed, payment pending admin review)
 */
export const processPaymentForCompletedTask = async (
  taskId: string,
  customerId: string,
  actualDistanceKm: number = 0,
  actualDurationMinutes: number = 0,
  isDisputed: boolean = false,
): Promise<any> => {
  // Validate task exists and belongs to customer
  const task = await prisma.task.findUnique({
    where: { id: taskId },
  });

  if (!task) {
    throw new AppError('TASK_NOT_FOUND', 'Task not found', 404);
  }

  if (task.customer_id !== customerId) {
    throw new AppError(
      'UNAUTHORIZED',
      'Only task creator can process payment',
      403,
    );
  }

  if (!task.helper_id) {
    throw new AppError(
      'NO_HELPER_ASSIGNED',
      'No helper assigned to this task',
      400,
    );
  }

  // Check if payment already processed
  const existingPayment = await getTaskPayment(taskId);
  if (existingPayment) {
    throw new AppError(
      'PAYMENT_ALREADY_PROCESSED',
      'Payment already processed for this task',
      400,
    );
  }

  // Get pricing config
  const config = await pricingService.getPricingConfig();

  // Calculate final amount with actual distance/duration
  const isPeak = pricingService.isPeakHour();
  const finalAmount = pricingService.calculateFinalAmount(
    actualDistanceKm,
    actualDurationMinutes,
    task.task_type === 'business',
    isPeak,
    config,
  );

  // Create payment record
  const payment = await createPayment(taskId, customerId, finalAmount, config);

  // If disputed, mark as pending admin review
  if (isDisputed) {
    await updatePaymentStatus(payment.id, 'pending');
    console.log(
      `[Payment] Task ${taskId} is disputed, payment pending admin review`,
    );
  } else {
    // Mark as completed (auto-complete non-disputed tasks)
    await updatePaymentStatus(payment.id, 'completed');
    console.log(`[Payment] Task ${taskId} payment processed: ₹${finalAmount}`);
  }

  // Increment helper earnings in wallet (simplified: no separate wallet table yet)
  // In production, would update a HelperWallet or HelperBalance table
  // For now, we track this through Payment records in payout service

  return payment;
};

/**
 * Get earnings summary for a helper
 * Breaks down earnings by time period (today, week, month)
 */
export const getHelperEarningsSummary = async (helperId: string): Promise<any> => {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const weekStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

  // Get completed payments for this helper
  const payments = await prisma.payment.findMany({
    where: {
      task: {
        helper_id: helperId,
      },
      status: 'completed',
    },
    select: {
      helper_payout_amount: true,
      created_at: true,
    },
    orderBy: {
      created_at: 'desc',
    },
  });

  let todayEarnings = 0;
  let weekEarnings = 0;
  let monthEarnings = 0;
  let lifetimeEarnings = 0;

  for (const payment of payments) {
    const amount = payment.helper_payout_amount;
    lifetimeEarnings += amount;

    if (payment.created_at >= todayStart) {
      todayEarnings += amount;
    }
    if (payment.created_at >= weekStart) {
      weekEarnings += amount;
    }
    if (payment.created_at >= monthStart) {
      monthEarnings += amount;
    }
  }

  // Get pending earnings (in 'processing' status)
  const pendingPayments = await prisma.payment.findMany({
    where: {
      task: {
        helper_id: helperId,
      },
      status: 'processing',
    },
    select: {
      helper_payout_amount: true,
    },
  });

  const pendingEarnings = pendingPayments.reduce(
    (sum, p) => sum + p.helper_payout_amount,
    0,
  );

  return {
    today_earnings: Math.round(todayEarnings),
    week_earnings: Math.round(weekEarnings),
    month_earnings: Math.round(monthEarnings),
    pending_earnings: Math.round(pendingEarnings),
    lifetime_earnings: Math.round(lifetimeEarnings),
  };
};
