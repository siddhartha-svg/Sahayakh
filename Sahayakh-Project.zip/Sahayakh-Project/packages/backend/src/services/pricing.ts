import prisma from '../config/prisma';
import redis from '../config/redis';
import { AppError } from '../middleware/error';

const PRICING_CACHE_TTL = 300; // 5 minutes
const PRICING_CACHE_KEY = 'sahayakh:pricing:current';

export interface PricingBreakdown {
  finalAmount: number;
  platformFeeAmount: number;
  helperPayoutAmount: number;
}

/**
 * Get current pricing configuration
 * Caches for 5 minutes to avoid frequent DB queries
 */
export const getPricingConfig = async () => {
  try {
    // Check cache first
    const cached = await redis.get(PRICING_CACHE_KEY);
    if (cached) {
      return JSON.parse(cached);
    }
  } catch (err) {
    console.warn('Redis cache miss for pricing config:', err);
  }

  // Get from database
  const config = await prisma.pricingConfig.findUnique({
    where: { config_key: 'current' },
  });

  if (!config) {
    throw new AppError(
      'PRICING_CONFIG_NOT_FOUND',
      'Pricing configuration not found',
      500,
    );
  }

  // Validate effective date
  if (config.effective_from && config.effective_from > new Date()) {
    throw new AppError(
      'PRICING_NOT_EFFECTIVE',
      'Pricing configuration is not yet effective',
      400,
    );
  }

  // Cache for 5 minutes
  try {
    await redis.setex(PRICING_CACHE_KEY, PRICING_CACHE_TTL, JSON.stringify(config));
  } catch (err) {
    console.warn('Failed to cache pricing config:', err);
  }

  return config;
};

/**
 * Initialize or get default pricing configuration
 */
export const getOrCreatePricingConfig = async () => {
  let config = await prisma.pricingConfig.findUnique({
    where: { config_key: 'current' },
  });

  if (!config) {
    // Create default configuration
    config = await prisma.pricingConfig.create({
      data: {
        config_key: 'current',
        base_fare_rupees: 40,
        per_km_rate: 15,
        per_minute_rate: 2.5,
        minimum_fare_rupees: 80,
        cancellation_fee_rupees: 30,
        platform_fee_percent: 15,
        business_task_multiplier: 1.25,
        peak_hour_multiplier: 1.1,
        daily_bonus_tasks_required: 5,
        daily_bonus_amount: 100,
        effective_from: new Date(),
      },
    });
  }

  return config;
};

/**
 * Calculate final task amount including all surcharges and multipliers
 *
 * Formula:
 * 1. Base = base_fare + (distance_km * per_km_rate)
 * 2. Distance surcharge if > 2km: (distance_km - 2) * per_km_rate * 0.5
 * 3. Time surcharge if > 30min: (duration_minutes - 30) * per_minute_rate
 * 4. Peak hour multiplier (6pm-11pm): × multiplier
 * 5. Business multiplier (if task_type='business'): × multiplier
 * 6. Apply minimum fare
 */
export const calculateFinalAmount = (
  distanceKm: number,
  durationMinutes: number,
  isBusinessTask: boolean,
  isPeakHour: boolean,
  config: any,
): number => {
  // Step 1: Base amount
  let amount = config.base_fare_rupees + distanceKm * config.per_km_rate;

  // Step 2: Distance surcharge for distances > 2km
  if (distanceKm > 2) {
    const surchargeDistance = distanceKm - 2;
    const surcharge = surchargeDistance * config.per_km_rate * 0.5;
    amount += surcharge;
  }

  // Step 3: Time surcharge for durations > 30 minutes
  if (durationMinutes > 30) {
    const surchargeTime = durationMinutes - 30;
    const surcharge = surchargeTime * config.per_minute_rate;
    amount += surcharge;
  }

  // Step 4: Peak hour multiplier (6pm-11pm)
  if (isPeakHour) {
    amount *= config.peak_hour_multiplier;
  }

  // Step 5: Business task multiplier
  if (isBusinessTask) {
    amount *= config.business_task_multiplier;
  }

  // Step 6: Apply minimum fare
  amount = Math.max(amount, config.minimum_fare_rupees);

  return Math.round(amount);
};

/**
 * Check if current time is peak hour (6pm-11pm)
 */
export const isPeakHour = (): boolean => {
  const now = new Date();
  const hour = now.getHours();
  return hour >= 18 && hour < 23; // 6pm (18:00) to 11pm (23:00)
};

/**
 * Calculate payment breakdown: platform fee and helper payout
 *
 * Platform takes: finalAmount * platform_fee_percent / 100
 * Helper gets: finalAmount - platform_fee_amount
 */
export const calculatePaymentBreakdown = (
  finalAmount: number,
  platformFeePercent: number,
): PricingBreakdown => {
  const platformFeeAmount = Math.round(
    (finalAmount * platformFeePercent) / 100,
  );
  const helperPayoutAmount = finalAmount - platformFeeAmount;

  return {
    finalAmount,
    platformFeeAmount,
    helperPayoutAmount,
  };
};

/**
 * Update pricing configuration
 * Only admin users can call this
 * Logs all changes to AuditLog for audit trail
 */
export const updatePricingConfig = async (
  updates: Partial<{
    base_fare_rupees: number;
    per_km_rate: number;
    per_minute_rate: number;
    minimum_fare_rupees: number;
    cancellation_fee_rupees: number;
    platform_fee_percent: number;
    business_task_multiplier: number;
    peak_hour_multiplier: number;
    daily_bonus_tasks_required: number;
    daily_bonus_amount: number;
  }>,
  adminId: string,
): Promise<any> => {
  // Validate updates
  if (updates.platform_fee_percent !== undefined) {
    if (updates.platform_fee_percent < 0 || updates.platform_fee_percent > 100) {
      throw new AppError(
        'INVALID_FEE_PERCENT',
        'Platform fee percent must be between 0 and 100',
        400,
      );
    }
  }

  // Validate all amounts are non-negative
  const amountFields = [
    'base_fare_rupees',
    'per_km_rate',
    'per_minute_rate',
    'minimum_fare_rupees',
    'cancellation_fee_rupees',
    'daily_bonus_amount',
  ];

  for (const field of amountFields) {
    if ((updates as any)[field] !== undefined && (updates as any)[field] < 0) {
      throw new AppError(
        'INVALID_AMOUNT',
        `${field} cannot be negative`,
        400,
      );
    }
  }

  // Get current config for audit trail
  const currentConfig = await getPricingConfig();
  const oldValues = {
    base_fare_rupees: currentConfig.base_fare_rupees,
    per_km_rate: currentConfig.per_km_rate,
    per_minute_rate: currentConfig.per_minute_rate,
    minimum_fare_rupees: currentConfig.minimum_fare_rupees,
    cancellation_fee_rupees: currentConfig.cancellation_fee_rupees,
    platform_fee_percent: currentConfig.platform_fee_percent,
    business_task_multiplier: currentConfig.business_task_multiplier,
    peak_hour_multiplier: currentConfig.peak_hour_multiplier,
    daily_bonus_tasks_required: currentConfig.daily_bonus_tasks_required,
    daily_bonus_amount: currentConfig.daily_bonus_amount,
  };

  // Update config
  const updatedConfig = await prisma.pricingConfig.update({
    where: { config_key: 'current' },
    data: {
      ...updates,
      effective_from: new Date(),
    },
  });

  // Log to audit trail
  const newValues = {
    base_fare_rupees: updatedConfig.base_fare_rupees,
    per_km_rate: updatedConfig.per_km_rate,
    per_minute_rate: updatedConfig.per_minute_rate,
    minimum_fare_rupees: updatedConfig.minimum_fare_rupees,
    cancellation_fee_rupees: updatedConfig.cancellation_fee_rupees,
    platform_fee_percent: updatedConfig.platform_fee_percent,
    business_task_multiplier: updatedConfig.business_task_multiplier,
    peak_hour_multiplier: updatedConfig.peak_hour_multiplier,
    daily_bonus_tasks_required: updatedConfig.daily_bonus_tasks_required,
    daily_bonus_amount: updatedConfig.daily_bonus_amount,
  };

  await prisma.auditLog.create({
    data: {
      admin_id: adminId,
      action: 'pricing_update',
      resource_type: 'PricingConfig',
      resource_id: updatedConfig.id,
      old_values: oldValues,
      new_values: newValues,
    },
  });

  // Clear cache
  try {
    await redis.del(PRICING_CACHE_KEY);
  } catch (err) {
    console.warn('Failed to clear pricing cache:', err);
  }

  return updatedConfig;
};
