import { Server as HTTPServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';
import * as socketHandlers from '../services/socket-handlers';

export const initializeSocket = (httpServer: HTTPServer): SocketIOServer => {
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: '*',
      methods: ['GET', 'POST'],
    },
    transports: ['websocket', 'polling'],
    pingInterval: 25000,
    pingTimeout: 60000,
  });

  // Namespace: /helpers - for all helper-related events
  const helpersNamespace = io.of('/helpers');

  helpersNamespace.on('connection', (socket) => {
    console.log(`[Helpers] Helper connected: ${socket.id}`);

    // Helper subscribes to location-based rooms for task broadcasts
    socket.on('subscribe_location', (data: { zoneId?: string; helperId: string }) => {
      if (data.zoneId) {
        socket.join(`helpers:zone:${data.zoneId}`);
        console.log(`[Helpers] Helper ${data.helperId} joined zone ${data.zoneId}`);
      }
      // Also join helper-specific room
      socket.join(`helper:${data.helperId}`);
      console.log(`[Helpers] Helper ${data.helperId} joined private room`);
    });

    // Location tracking: helper sends GPS updates during task execution
    socket.on('task:request_location', async (data: any) => {
      const { taskId, helperId, latitude, longitude, accuracy } = data;
      try {
        await socketHandlers.handleLocationUpdate(
          taskId,
          helperId,
          latitude,
          longitude,
          accuracy || 0,
          io,
        );
      } catch (err) {
        console.error('[Helpers] Error handling location update:', err);
      }
    });

    socket.on('disconnect', () => {
      console.log(`[Helpers] Helper disconnected: ${socket.id}`);
    });

    socket.on('error', (error: any) => {
      console.error(`[Helpers] Socket error:`, error);
    });
  });

  // Namespace: /customers - for customer updates
  const customersNamespace = io.of('/customers');

  customersNamespace.on('connection', (socket) => {
    console.log(`[Customers] Customer connected: ${socket.id}`);

    // Customer subscribes to task-specific rooms for real-time updates
    socket.on('subscribe_task', async (data: { taskId: string; customerId: string }) => {
      socket.join(`task:${data.taskId}`);
      console.log(`[Customers] Customer ${data.customerId} joined task ${data.taskId}`);

      // Send last known location immediately on reconnect
      await socketHandlers.handleCustomerReconnect(socket, data.taskId);
    });

    socket.on('disconnect', () => {
      console.log(`[Customers] Customer disconnected: ${socket.id}`);
    });

    socket.on('error', (error: any) => {
      console.error(`[Customers] Socket error:`, error);
    });
  });

  // Health check namespace
  io.on('connection', (socket) => {
    socket.on('ping', () => {
      socket.emit('pong');
    });
  });

  console.log('✓ Socket.IO initialized with /helpers and /customers namespaces');

  return io;
};
