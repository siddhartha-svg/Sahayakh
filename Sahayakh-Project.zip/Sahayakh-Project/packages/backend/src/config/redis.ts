import Redis from 'ioredis';

let redis: Redis | null = null;

export const initializeRedis = async (): Promise<Redis> => {
  if (redis) return redis;

  const redisUrl = process.env.REDIS_URL || 'redis://localhost:6379/0';

  redis = new Redis(redisUrl, {
    maxRetriesPerRequest: null,
    enableReadyCheck: true,
  });

  redis.on('error', (err) => {
    console.error('Redis error:', err);
  });

  redis.on('connect', () => {
    console.log('✓ Redis connection established');
  });

  try {
    await redis.ping();
    return redis;
  } catch (err) {
    console.error('✗ Redis connection failed:', err);
    throw err;
  }
};

export const getRedis = (): Redis => {
  if (!redis) {
    throw new Error('Redis not initialized. Call initializeRedis first.');
  }
  return redis;
};

export const closeRedis = async (): Promise<void> => {
  if (redis) {
    await redis.quit();
    redis = null;
    console.log('✓ Redis connection closed');
  }
};

export const getRedisKey = (key: string): string => {
  const prefix = process.env.REDIS_KEY_PREFIX || 'sahayakh:';
  return `${prefix}${key}`;
};
