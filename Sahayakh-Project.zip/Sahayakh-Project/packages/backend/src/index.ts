import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import { createServer } from 'http';
import { validateConfig, config } from './config';
import { initializeDatabase } from './config/database';
import { initializeRedis } from './config/redis';
import { initializeSocket } from './config/socket';
import authRoutes from './routes/auth';
import tasksRoutes from './routes/tasks';
import requestRoutes from './routes/requests';
import disputesRoutes from './routes/disputes';
import adminRoutes from './routes/admin';
import { errorHandler, asyncHandler } from './middleware/error';

const app = express();

validateConfig();

const initializeApp = async () => {
  try {
    await initializeDatabase();
    await initializeRedis();

    app.use(helmet());
    app.use(cors({ origin: config.security.corsOrigins }));
    app.use(express.json());

    const limiter = rateLimit({
      windowMs: config.rateLimit.windowMs,
      max: config.rateLimit.maxRequests,
      message: 'Too many requests from this IP, please try again later.',
    });

    app.use('/api/', limiter);

    app.get(
      '/health',
      asyncHandler(async (req, res) => {
        res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
      }),
    );

    app.use('/api', authRoutes);
    app.use('/api/tasks', tasksRoutes);
    app.use('/api/requests', requestRoutes);
    app.use('/api', disputesRoutes);
    app.use('/api', adminRoutes);

    app.use((req, res) => {
      res.status(404).json({
        error_code: 'NOT_FOUND',
        message: 'Resource not found',
        status: 404,
      });
    });

    app.use(errorHandler);

    // Initialize HTTP server with Socket.IO
    const httpServer = createServer(app);
    const socket = initializeSocket(httpServer);

    // Store socket instance globally for access from services
    (global as any).socket = socket;

    const port = config.port;
    httpServer.listen(port, () => {
      console.log(`✓ ${config.appName} v${config.appVersion} listening on port ${port}`);
    });

    const gracefulShutdown = async (signal: string) => {
      console.log(`\n✓ Received ${signal}, shutting down gracefully...`);
      process.exit(0);
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  } catch (err) {
    console.error('✗ Failed to initialize application:', err);
    process.exit(1);
  }
};

initializeApp();

export default app;
