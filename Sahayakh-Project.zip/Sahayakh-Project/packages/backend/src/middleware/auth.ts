import { Request, Response, NextFunction } from 'express';
import { verifyAccessToken } from '../utils/jwt';
import { TokenPayload, AUTH_ERROR_CODES, AUTH_ERROR_MESSAGES } from '@sahayakh/shared';

declare global {
  namespace Express {
    interface Request {
      user?: TokenPayload;
    }
  }
}

export const authMiddleware = (req: Request, res: Response, next: NextFunction): void => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({
      error_code: AUTH_ERROR_CODES.UNAUTHORIZED,
      message: AUTH_ERROR_MESSAGES.UNAUTHORIZED,
      status: 401,
    });
    return;
  }

  const token = authHeader.substring(7);

  try {
    const payload = verifyAccessToken(token);
    req.user = payload;
    next();
  } catch (err) {
    res.status(401).json({
      error_code: AUTH_ERROR_CODES.INVALID_TOKEN,
      message: AUTH_ERROR_MESSAGES.INVALID_TOKEN,
      status: 401,
    });
  }
};

export const optionalAuthMiddleware = (req: Request, res: Response, next: NextFunction): void => {
  const authHeader = req.headers.authorization;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7);
    try {
      const payload = verifyAccessToken(token);
      req.user = payload;
    } catch {
      // Ignore auth errors, continue without user
    }
  }

  next();
};
