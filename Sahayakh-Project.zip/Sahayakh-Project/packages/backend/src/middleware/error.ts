import { Request, Response, NextFunction } from 'express';
import { ApiError, AUTH_ERROR_CODES, AUTH_ERROR_MESSAGES } from '@sahayakh/shared';

export class AppError extends Error {
  constructor(
    public errorCode: string,
    public message: string,
    public status: number = 400,
    public details?: Record<string, unknown>,
  ) {
    super(message);
    this.name = 'AppError';
  }
}

export const errorHandler = (err: Error | AppError, req: Request, res: Response, next: NextFunction): void => {
  console.error('[Error]', err);

  if (err instanceof AppError) {
    res.status(err.status).json({
      error_code: err.errorCode,
      message: err.message,
      status: err.status,
      ...(err.details && { details: err.details }),
    });
    return;
  }

  // Handle JWT errors
  if (err.message.includes('jwt')) {
    res.status(401).json({
      error_code: AUTH_ERROR_CODES.INVALID_TOKEN,
      message: AUTH_ERROR_MESSAGES.INVALID_TOKEN,
      status: 401,
    });
    return;
  }

  // Default error response
  res.status(500).json({
    error_code: 'INTERNAL_SERVER_ERROR',
    message: 'Internal server error',
    status: 500,
  });
};

export const asyncHandler = (fn: (req: Request, res: Response, next: NextFunction) => Promise<void>) => {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};
