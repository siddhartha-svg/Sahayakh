import jwt from 'jsonwebtoken';
import { config } from '../config';
import { TokenPayload } from '@sahayakh/shared';

export const signAccessToken = (userId: string, role: string): string => {
  return jwt.sign(
    {
      user_id: userId,
      role,
    },
    config.jwt.secret!,
    {
      expiresIn: config.jwt.expiry,
    },
  );
};

export const signRefreshToken = (userId: string, role: string): string => {
  return jwt.sign(
    {
      user_id: userId,
      role,
      type: 'refresh',
    },
    config.jwt.refreshSecret!,
    {
      expiresIn: config.jwt.refreshExpiry,
    },
  );
};

export const verifyAccessToken = (token: string): TokenPayload => {
  try {
    return jwt.verify(token, config.jwt.secret!) as TokenPayload;
  } catch (err) {
    throw new Error('Invalid or expired token');
  }
};

export const verifyRefreshToken = (token: string): TokenPayload => {
  try {
    return jwt.verify(token, config.jwt.refreshSecret!) as TokenPayload;
  } catch (err) {
    throw new Error('Invalid or expired refresh token');
  }
};

export const decodeToken = (token: string): TokenPayload | null => {
  try {
    return jwt.decode(token) as TokenPayload;
  } catch {
    return null;
  }
};
