const WARANGAL_BOUNDS = {
  minLat: 16.5,
  maxLat: 18.5,
  minLng: 77.5,
  maxLng: 79.5,
};

export const validateLocation = (lat: number, lng: number): boolean => {
  return (
    lat >= WARANGAL_BOUNDS.minLat &&
    lat <= WARANGAL_BOUNDS.maxLat &&
    lng >= WARANGAL_BOUNDS.minLng &&
    lng <= WARANGAL_BOUNDS.maxLng
  );
};

export const calculateDistance = (
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number,
): number => {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

export const estimateETA = (distanceKm: number): number => {
  const avgSpeedKmPerHour = 40;
  return Math.round((distanceKm / avgSpeedKmPerHour) * 60);
};

export interface PricingEstimate {
  min: number;
  max: number;
}

export const estimatePrice = (
  baseFare: number,
  perKmRate: number,
  distanceKm: number,
  isBusinessTask: boolean,
  businessMultiplier: number,
  minimumFare: number,
): PricingEstimate => {
  const basePrice = baseFare + distanceKm * perKmRate;
  let estimatedPrice = Math.max(basePrice, minimumFare);

  if (isBusinessTask) {
    estimatedPrice *= businessMultiplier;
  }

  return {
    min: Math.round(estimatedPrice),
    max: Math.round(estimatedPrice * 1.2),
  };
};
