import Joi from 'joi';
import { validateLocation } from './location';

const TASK_CATEGORIES = [
  'pickup_delivery',
  'local_visit',
  'document_work',
  'vendor_pickup',
  'client_delivery',
  'site_visit',
  'bank_gst_visit',
  'other',
];

export const createTaskSchema = Joi.object({
  task_type: Joi.string().valid('personal', 'business').required(),
  category: Joi.string()
    .valid(...TASK_CATEGORIES)
    .required(),
  description: Joi.string().min(10).max(500).required(),
  location_name: Joi.string().required(),
  location_point: Joi.object({
    latitude: Joi.number().required(),
    longitude: Joi.number().required(),
  }).required(),
  preferred_date: Joi.string().isoDate().required(),
  preferred_time: Joi.string()
    .pattern(/^\d{2}:\d{2}$/)
    .required(),
  budget_min: Joi.number().min(30).required(),
  budget_max: Joi.number().greater(Joi.ref('budget_min')).required(),
  business_name: Joi.when('task_type', {
    is: 'business',
    then: Joi.string().required(),
    otherwise: Joi.string().optional(),
  }),
  gst_bill_required: Joi.boolean().optional(),
  photo_urls: Joi.array().items(Joi.string().uri()).max(3).optional(),
});

export const validateTaskDate = (dateStr: string): { valid: boolean; error?: string } => {
  const date = new Date(dateStr);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  if (date < today) {
    return { valid: false, error: 'Date cannot be in the past' };
  }

  const thirtyDaysFromNow = new Date(today);
  thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);

  if (date > thirtyDaysFromNow) {
    return { valid: false, error: 'Date cannot be more than 30 days in the future' };
  }

  return { valid: true };
};

export const validateTaskTime = (timeStr: string): { valid: boolean; error?: string } => {
  const match = timeStr.match(/^(\d{2}):(\d{2})$/);
  if (!match) {
    return { valid: false, error: 'Time must be in HH:MM format' };
  }

  const [, hours, minutes] = match;
  const h = parseInt(hours, 10);
  const m = parseInt(minutes, 10);

  if (h < 0 || h > 23 || m < 0 || m > 59) {
    return { valid: false, error: 'Invalid time' };
  }

  return { valid: true };
};

export const validateLocationBounds = (lat: number, lng: number): { valid: boolean; error?: string } => {
  if (!validateLocation(lat, lng)) {
    return { valid: false, error: 'Location is outside service area (Warangal region)' };
  }
  return { valid: true };
};
