import crypto from 'crypto';
import bcryptjs from 'bcryptjs';
import { config } from '../config';

export const generateOTP = (): string => {
  const otp = crypto.randomInt(Math.pow(10, config.otp.length - 1), Math.pow(10, config.otp.length));
  return otp.toString();
};

export const hashOTP = async (otp: string): Promise<string> => {
  return bcryptjs.hash(otp, config.security.bcryptRounds);
};

export const compareOTP = async (otp: string, hash: string): Promise<boolean> => {
  return bcryptjs.compare(otp, hash);
};
