import express from 'express';
import { authenticate } from '../middleware/auth';
import { AppError } from '../middleware/error';
import * as disputeService from '../services/dispute';
import * as resolutionService from '../services/resolution';

const router = express.Router();

// ============== CUSTOMER/HELPER ENDPOINTS ==============

/**
 * POST /disputes
 * Raise a new dispute on a completed task
 */
router.post('/disputes', authenticate, async (req, res, next) => {
  try {
    const { task_id, category, description, evidence_urls } = req.body;

    // Validate required fields
    if (!task_id || !category || !description) {
      throw new AppError(
        'INVALID_INPUT',
        'Missing required fields: task_id, category, description',
        400,
      );
    }

    const dispute = await disputeService.raiseDispute(
      task_id,
      req.user.id,
      category,
      description,
      evidence_urls,
    );

    res.status(201).json({
      success: true,
      data: dispute,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /disputes/:dispute_id/messages
 * Add a message to a dispute
 */
router.post('/disputes/:dispute_id/messages', authenticate, async (req, res, next) => {
  try {
    const { dispute_id } = req.params;
    const { message_text } = req.body;

    if (!message_text) {
      throw new AppError(
        'INVALID_INPUT',
        'Missing required field: message_text',
        400,
      );
    }

    const result = await disputeService.addDisputeMessage(
      dispute_id,
      req.user.id,
      message_text,
    );

    res.status(200).json({
      success: true,
      data: result,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /disputes/:dispute_id
 * Get full dispute details with message thread
 */
router.get('/disputes/:dispute_id', authenticate, async (req, res, next) => {
  try {
    const { dispute_id } = req.params;
    const dispute = await disputeService.getDisputeWithMessages(dispute_id);

    // Authorization: user must be party to the task
    if (
      dispute.task.customer_id !== req.user.id &&
      dispute.task.helper_id !== req.user.id
    ) {
      throw new AppError(
        'UNAUTHORIZED',
        'You can only view disputes you are party to',
        403,
      );
    }

    res.status(200).json({
      success: true,
      data: dispute,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /disputes/me/active
 * Get active disputes for current user
 */
router.get('/disputes/me/active', authenticate, async (req, res, next) => {
  try {
    const { limit = 20, offset = 0 } = req.query;

    // Get all disputes where user is party to the task
    const disputes = await disputeService.getDisputesByStatus(
      'open',
      undefined,
      parseInt(limit as string),
      parseInt(offset as string),
    );

    // Filter to only disputes user is involved in
    const userDisputes = await Promise.all(
      disputes.map(async (d) => {
        const detail = await disputeService.getDisputeWithMessages(d.id);
        if (
          detail.task.customer_id === req.user.id ||
          detail.task.helper_id === req.user.id
        ) {
          return d;
        }
        return null;
      }),
    );

    res.status(200).json({
      success: true,
      data: userDisputes.filter(Boolean),
    });
  } catch (error) {
    next(error);
  }
});

// ============== ADMIN ENDPOINTS ==============

/**
 * GET /admin/disputes
 * List all disputes (admin only)
 */
router.get('/admin/disputes', authenticate, async (req, res, next) => {
  try {
    // Check admin role
    if (req.user.role !== 'admin') {
      throw new AppError(
        'UNAUTHORIZED',
        'Only admins can access this endpoint',
        403,
      );
    }

    const { status, assigned_to, limit = 20, offset = 0 } = req.query;

    let disputes;
    if (status) {
      disputes = await disputeService.getDisputesByStatus(
        status as any,
        assigned_to as string,
        parseInt(limit as string),
        parseInt(offset as string),
      );
    } else {
      // Get all open and investigating disputes
      const open = await disputeService.getDisputesByStatus(
        'open',
        assigned_to as string,
        parseInt(limit as string),
        parseInt(offset as string),
      );
      const investigating = await disputeService.getDisputesByStatus(
        'investigating',
        assigned_to as string,
        parseInt(limit as string),
        parseInt(offset as string),
      );
      disputes = [...open, ...investigating];
    }

    res.status(200).json({
      success: true,
      data: disputes,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /admin/disputes/:dispute_id/dossier
 * Get comprehensive dispute details for admin review
 */
router.get('/admin/disputes/:dispute_id/dossier', authenticate, async (req, res, next) => {
  try {
    // Check admin role
    if (req.user.role !== 'admin') {
      throw new AppError(
        'UNAUTHORIZED',
        'Only admins can access this endpoint',
        403,
      );
    }

    const { dispute_id } = req.params;
    const dossier = await disputeService.getDisputeDetails(dispute_id);

    res.status(200).json({
      success: true,
      data: dossier,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /admin/disputes/:dispute_id/assign
 * Assign dispute to an admin
 */
router.post('/admin/disputes/:dispute_id/assign', authenticate, async (req, res, next) => {
  try {
    // Check admin role
    if (req.user.role !== 'admin') {
      throw new AppError(
        'UNAUTHORIZED',
        'Only admins can access this endpoint',
        403,
      );
    }

    const { dispute_id } = req.params;
    const { admin_id } = req.body;

    if (!admin_id) {
      throw new AppError(
        'INVALID_INPUT',
        'Missing required field: admin_id',
        400,
      );
    }

    const result = await disputeService.assignDisputeToAdmin(
      dispute_id,
      admin_id,
    );

    res.status(200).json({
      success: true,
      data: result,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /admin/disputes/:dispute_id/resolve/customer-win
 * Resolve dispute in favor of customer
 */
router.post(
  '/admin/disputes/:dispute_id/resolve/customer-win',
  authenticate,
  async (req, res, next) => {
    try {
      // Check admin role
      if (req.user.role !== 'admin') {
        throw new AppError(
          'UNAUTHORIZED',
          'Only admins can access this endpoint',
          403,
        );
      }

      const { dispute_id } = req.params;
      const { notes } = req.body;

      const result = await resolutionService.resolveDisputeAsCustomerWin(
        dispute_id,
        req.user.id,
        notes,
      );

      res.status(200).json({
        success: true,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  },
);

/**
 * POST /admin/disputes/:dispute_id/resolve/helper-win
 * Resolve dispute in favor of helper
 */
router.post(
  '/admin/disputes/:dispute_id/resolve/helper-win',
  authenticate,
  async (req, res, next) => {
    try {
      // Check admin role
      if (req.user.role !== 'admin') {
        throw new AppError(
          'UNAUTHORIZED',
          'Only admins can access this endpoint',
          403,
        );
      }

      const { dispute_id } = req.params;
      const { notes } = req.body;

      const result = await resolutionService.resolveDisputeAsHelperWin(
        dispute_id,
        req.user.id,
        notes,
      );

      res.status(200).json({
        success: true,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  },
);

/**
 * POST /admin/disputes/:dispute_id/resolve/partial
 * Resolve dispute as partial split
 */
router.post(
  '/admin/disputes/:dispute_id/resolve/partial',
  authenticate,
  async (req, res, next) => {
    try {
      // Check admin role
      if (req.user.role !== 'admin') {
        throw new AppError(
          'UNAUTHORIZED',
          'Only admins can access this endpoint',
          403,
        );
      }

      const { dispute_id } = req.params;
      const { customer_refund_amount, helper_payout_amount, notes } = req.body;

      if (!customer_refund_amount || !helper_payout_amount) {
        throw new AppError(
          'INVALID_INPUT',
          'Missing required fields: customer_refund_amount, helper_payout_amount',
          400,
        );
      }

      const result = await resolutionService.resolveDisputeAsPartial(
        dispute_id,
        customer_refund_amount,
        helper_payout_amount,
        req.user.id,
        notes,
      );

      res.status(200).json({
        success: true,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  },
);

/**
 * POST /admin/disputes/:dispute_id/resolve/dismiss
 * Dismiss dispute without refund or payout
 */
router.post(
  '/admin/disputes/:dispute_id/resolve/dismiss',
  authenticate,
  async (req, res, next) => {
    try {
      // Check admin role
      if (req.user.role !== 'admin') {
        throw new AppError(
          'UNAUTHORIZED',
          'Only admins can access this endpoint',
          403,
        );
      }

      const { dispute_id } = req.params;
      const { reason, notes } = req.body;

      if (!reason) {
        throw new AppError(
          'INVALID_INPUT',
          'Missing required field: reason',
          400,
        );
      }

      const result = await resolutionService.dismissDispute(
        dispute_id,
        req.user.id,
        reason,
        notes,
      );

      res.status(200).json({
        success: true,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  },
);

export default router;
