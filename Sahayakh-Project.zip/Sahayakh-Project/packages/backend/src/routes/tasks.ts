import { Router, Request, Response } from 'express';
import { authMiddleware } from '../middleware/auth';
import { asyncHandler, AppError } from '../middleware/error';
import * as taskService from '../services/task';
import { createTaskSchema, validateTaskDate, validateTaskTime, validateLocationBounds } from '../utils/task-validators';
import { estimatePrice } from '../utils/location';
import prisma from '../config/prisma';

const router = Router();

router.post(
  '/',
  authMiddleware,
  asyncHandler(async (req: Request, res: Response) => {
    if (!req.user) {
      throw new AppError('UNAUTHORIZED', 'Not authenticated', 401);
    }

    const customerId = req.user.user_id;

    const validation = createTaskSchema.validate(req.body, { abortEarly: false });
    if (validation.error) {
      res.status(400).json({
        error_code: 'VALIDATION_ERROR',
        message: 'Validation failed',
        status: 400,
        details: { errors: validation.error.details.map((d) => d.message) },
      });
      return;
    }

    const input = validation.value as taskService.CreateTaskInput;

    const dateValidation = validateTaskDate(input.preferred_date);
    if (!dateValidation.valid) {
      throw new AppError('DATE_INVALID', dateValidation.error!, 400);
    }

    const timeValidation = validateTaskTime(input.preferred_time);
    if (!timeValidation.valid) {
      throw new AppError('TIME_INVALID', timeValidation.error!, 400);
    }

    const locationValidation = validateLocationBounds(input.location_point.latitude, input.location_point.longitude);
    if (!locationValidation.valid) {
      throw new AppError('INVALID_LOCATION', locationValidation.error!, 400);
    }

    if (input.budget_min < 30) {
      throw new AppError('BUDGET_TOO_LOW', 'Budget minimum must be at least ₹30', 400);
    }

    if (input.task_type === 'business' && !input.business_name) {
      throw new AppError('MISSING_BUSINESS_NAME', 'Business name is required for business tasks', 400);
    }

    const task = await taskService.createTask(customerId, input);

    const pricingConfig = await prisma.pricingConfig.findUnique({
      where: { config_key: 'current' },
    });

    const priceEstimate = estimatePrice(
      pricingConfig?.base_fare_rupees || 40,
      pricingConfig?.per_km_rate || 15,
      0,
      input.task_type === 'business',
      pricingConfig?.business_task_multiplier || 1.25,
      pricingConfig?.minimum_fare_rupees || 80,
    );

    res.status(201).json({
      task: {
        id: task.id,
        task_id_display: task.task_id_display,
        customer_id: task.customer_id,
        status: task.status,
        task_type: task.task_type,
        category: task.category,
        description: task.description,
        location_name: task.location_name,
        location_point: JSON.parse(task.location_point),
        preferred_date: task.preferred_date,
        preferred_time: task.preferred_time,
        budget_min: task.budget_min,
        budget_max: task.budget_max,
        created_at: task.created_at?.toISOString(),
        updated_at: task.updated_at?.toISOString(),
      },
      estimated_price_range: priceEstimate,
    });
  }),
);

router.get(
  '/:task_id/helpers/nearby',
  authMiddleware,
  asyncHandler(async (req: Request, res: Response) => {
    if (!req.user) {
      throw new AppError('UNAUTHORIZED', 'Not authenticated', 401);
    }

    const customerId = req.user.user_id;
    const taskId = req.params.task_id;
    const { latitude, longitude, radius_km, sort_by } = req.query;

    const options: any = {};

    if (latitude) {
      options.latitude = parseFloat(latitude as string);
      if (isNaN(options.latitude)) {
        throw new AppError('VALIDATION_ERROR', 'Invalid latitude', 400);
      }
    }

    if (longitude) {
      options.longitude = parseFloat(longitude as string);
      if (isNaN(options.longitude)) {
        throw new AppError('VALIDATION_ERROR', 'Invalid longitude', 400);
      }
    }

    if (radius_km) {
      options.radius_km = parseFloat(radius_km as string);
      if (isNaN(options.radius_km)) {
        throw new AppError('VALIDATION_ERROR', 'Invalid radius_km', 400);
      }
    }

    if (sort_by) {
      options.sort_by = sort_by;
    }

    const result = await taskService.getNearbyHelpers(taskId, customerId, options);

    res.status(200).json(result);
  }),
);

router.post(
  '/:task_id/assign',
  authMiddleware,
  asyncHandler(async (req: Request, res: Response) => {
    if (!req.user) {
      throw new AppError('UNAUTHORIZED', 'Not authenticated', 401);
    }

    const customerId = req.user.user_id;
    const taskId = req.params.task_id;
    const { helper_id } = req.body;

    if (!helper_id) {
      throw new AppError('VALIDATION_ERROR', 'helper_id is required', 400);
    }

    const task = await taskService.assignHelperToTask(taskId, customerId, helper_id);

    res.status(200).json({
      task: {
        id: task.id,
        task_id_display: task.task_id_display,
        status: task.status,
        helper_id: task.helper_id,
        customer_id: task.customer_id,
      },
      message: 'Helper assigned successfully. OTP will be sent when helper arrives.',
    });
  }),
);

export default router;
