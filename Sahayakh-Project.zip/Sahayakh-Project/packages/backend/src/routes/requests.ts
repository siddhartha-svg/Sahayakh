import { Router, Request, Response } from 'express';
import { authMiddleware } from '../middleware/auth';
import { asyncHandler, AppError } from '../middleware/error';
import * as requestService from '../services/request';
import * as socketHandlers from '../services/socket-handlers';
import prisma from '../config/prisma';

const router = Router();

// Accept task request
router.post(
  '/:request_id/accept',
  authMiddleware,
  asyncHandler(async (req: Request, res: Response) => {
    if (!req.user) {
      throw new AppError('UNAUTHORIZED', 'Not authenticated', 401);
    }

    const { request_id } = req.params;
    const helperId = req.user.user_id;

    const accepted = await requestService.acceptRequest(request_id, helperId);

    // Clear the expiry timer
    socketHandlers.clearRequestTimer(accepted.task_id, helperId);

    // Get full task and helper details for broadcast
    const task = await prisma.task.findUnique({
      where: { id: accepted.task_id },
      include: { helper: { include: { user: true } } },
    });

    // Notify customer via Socket.IO
    const socket = (global as any).socket;
    if (socket && task?.helper?.user) {
      socketHandlers.notifyTaskAccepted(
        accepted.task_id,
        helperId,
        task.helper.user.name,
        socket,
      );
    }

    res.status(200).json({
      request: {
        id: accepted.id,
        task_id: accepted.task_id,
        helper_id: accepted.helper_id,
        status: accepted.status,
        accepted_at: accepted.accepted_at?.toISOString(),
      },
      message: 'Task request accepted successfully',
    });
  }),
);

// Decline task request
router.post(
  '/:request_id/decline',
  authMiddleware,
  asyncHandler(async (req: Request, res: Response) => {
    if (!req.user) {
      throw new AppError('UNAUTHORIZED', 'Not authenticated', 401);
    }

    const { request_id } = req.params;
    const { reason } = req.body;
    const helperId = req.user.user_id;

    const declined = await requestService.declineRequest(request_id, helperId, reason);

    // Clear the expiry timer
    socketHandlers.clearRequestTimer(declined.task_id, helperId);

    // Notify customer that request was declined
    const socket = (global as any).socket;
    if (socket) {
      socketHandlers.notifyTaskDeclined(declined.task_id, reason, socket);

      // Auto-requeue: find and send to next helper
      const nextHelper = await requestService.findNextAvailableHelper(declined.task_id);
      if (nextHelper) {
        const pricingConfig = await prisma.pricingConfig.findUnique({
          where: { config_key: 'current' },
        });
        await socketHandlers.broadcastTaskRequestToHelper(
          declined.task_id,
          nextHelper.id,
          socket,
          pricingConfig || undefined,
        );
      } else {
        // No more helpers available
        socket.of('/customers').to(`task:${declined.task_id}`).emit('request:no_helpers', {
          task_id: declined.task_id,
          message: 'No helpers available. Task returned to unassigned.',
        });
      }
    }

    res.status(200).json({
      request: {
        id: declined.id,
        task_id: declined.task_id,
        helper_id: declined.helper_id,
        status: declined.status,
        decline_reason: declined.decline_reason,
        declined_at: declined.declined_at?.toISOString(),
      },
      message: 'Task request declined',
    });
  }),
);

export default router;
