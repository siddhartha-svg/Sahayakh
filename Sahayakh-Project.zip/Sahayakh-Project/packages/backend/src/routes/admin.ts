import express from 'express';
import { authenticate } from '../middleware/auth';
import { AppError } from '../middleware/error';
import * as helperManagement from '../services/helper-management';
import * as taskManagement from '../services/task-management';
import * as suspensionService from '../services/suspension';
import * as pricingService from '../services/pricing';

const router = express.Router();

// Middleware to check admin role
const requireAdmin = (req: any, res: any, next: any) => {
  if (req.user.role !== 'admin') {
    throw new AppError(
      'UNAUTHORIZED',
      'Only admins can access this endpoint',
      403,
    );
  }
  next();
};

// ============== HELPER MANAGEMENT ENDPOINTS ==============

/**
 * GET /admin/helpers
 * List helper applications with optional status filter
 */
router.get('/admin/helpers', authenticate, requireAdmin, async (req, res, next) => {
  try {
    const { status, limit = 20, offset = 0 } = req.query;

    const helpers = await helperManagement.getHelperApplications(
      status as any,
      parseInt(limit as string),
      parseInt(offset as string),
    );

    res.status(200).json({
      success: true,
      data: helpers,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /admin/helpers/:helper_id
 * Get comprehensive helper profile
 */
router.get('/admin/helpers/:helper_id', authenticate, requireAdmin, async (req, res, next) => {
  try {
    const { helper_id } = req.params;
    const details = await helperManagement.getHelperDetails(helper_id);

    res.status(200).json({
      success: true,
      data: details,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /admin/helpers/:helper_id/approve
 * Approve helper application
 */
router.post(
  '/admin/helpers/:helper_id/approve',
  authenticate,
  requireAdmin,
  async (req, res, next) => {
    try {
      const { helper_id } = req.params;
      const { notes } = req.body;

      const result = await helperManagement.approveHelperApplication(
        helper_id,
        req.user.id,
        notes,
      );

      res.status(200).json({
        success: true,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  },
);

/**
 * POST /admin/helpers/:helper_id/reject
 * Reject helper application
 */
router.post(
  '/admin/helpers/:helper_id/reject',
  authenticate,
  requireAdmin,
  async (req, res, next) => {
    try {
      const { helper_id } = req.params;
      const { reason, notes } = req.body;

      if (!reason) {
        throw new AppError(
          'INVALID_INPUT',
          'Missing required field: reason',
          400,
        );
      }

      const result = await helperManagement.rejectHelperApplication(
        helper_id,
        req.user.id,
        reason,
        notes,
      );

      res.status(200).json({
        success: true,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  },
);

/**
 * GET /admin/documents
 * Get document verification queue
 */
router.get('/admin/documents', authenticate, requireAdmin, async (req, res, next) => {
  try {
    const { limit = 20, offset = 0 } = req.query;

    const queue = await helperManagement.getDocumentVerificationQueue(
      parseInt(limit as string),
      parseInt(offset as string),
    );

    res.status(200).json({
      success: true,
      data: queue,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /admin/documents/:helper_id/:document_type/verify
 * Verify a helper document
 */
router.post(
  '/admin/documents/:helper_id/:document_type/verify',
  authenticate,
  requireAdmin,
  async (req, res, next) => {
    try {
      const { helper_id, document_type } = req.params;
      const { notes } = req.body;

      const result = await helperManagement.verifyDocument(
        helper_id,
        document_type,
        req.user.id,
        notes,
      );

      res.status(200).json({
        success: true,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  },
);

/**
 * POST /admin/documents/:helper_id/:document_type/reject
 * Reject a helper document
 */
router.post(
  '/admin/documents/:helper_id/:document_type/reject',
  authenticate,
  requireAdmin,
  async (req, res, next) => {
    try {
      const { helper_id, document_type } = req.params;
      const { reason, notes } = req.body;

      if (!reason) {
        throw new AppError(
          'INVALID_INPUT',
          'Missing required field: reason',
          400,
        );
      }

      const result = await helperManagement.rejectDocument(
        helper_id,
        document_type,
        req.user.id,
        reason,
        notes,
      );

      res.status(200).json({
        success: true,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  },
);

// ============== TASK MANAGEMENT ENDPOINTS ==============

/**
 * GET /admin/tasks/reassign-queue
 * Get tasks ready for reassignment
 */
router.get('/admin/tasks/reassign-queue', authenticate, requireAdmin, async (req, res, next) => {
  try {
    const { limit = 20, offset = 0 } = req.query;

    const tasks = await taskManagement.listTasksForReassignment(
      parseInt(limit as string),
      parseInt(offset as string),
    );

    res.status(200).json({
      success: true,
      data: tasks,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /admin/tasks/cancel-queue
 * Get tasks ready for cancellation
 */
router.get('/admin/tasks/cancel-queue', authenticate, requireAdmin, async (req, res, next) => {
  try {
    const { limit = 20, offset = 0 } = req.query;

    const tasks = await taskManagement.listTasksForCancellation(
      parseInt(limit as string),
      parseInt(offset as string),
    );

    res.status(200).json({
      success: true,
      data: tasks,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /admin/tasks/:task_id
 * Get comprehensive task details
 */
router.get('/admin/tasks/:task_id', authenticate, requireAdmin, async (req, res, next) => {
  try {
    const { task_id } = req.params;
    const details = await taskManagement.getTaskDetails(task_id);

    res.status(200).json({
      success: true,
      data: details,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /admin/tasks/:task_id/reassign
 * Reassign task to a different helper
 */
router.post(
  '/admin/tasks/:task_id/reassign',
  authenticate,
  requireAdmin,
  async (req, res, next) => {
    try {
      const { task_id } = req.params;
      const { new_helper_id, reason } = req.body;

      if (!new_helper_id) {
        throw new AppError(
          'INVALID_INPUT',
          'Missing required field: new_helper_id',
          400,
        );
      }

      const result = await taskManagement.reassignTask(
        task_id,
        new_helper_id,
        req.user.id,
        reason,
      );

      res.status(200).json({
        success: true,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  },
);

/**
 * POST /admin/tasks/:task_id/cancel
 * Cancel a task
 */
router.post(
  '/admin/tasks/:task_id/cancel',
  authenticate,
  requireAdmin,
  async (req, res, next) => {
    try {
      const { task_id } = req.params;
      const { reason, refund_customer, notes } = req.body;

      if (!reason) {
        throw new AppError(
          'INVALID_INPUT',
          'Missing required field: reason',
          400,
        );
      }

      const result = await taskManagement.cancelTask(
        task_id,
        req.user.id,
        reason,
        refund_customer,
      );

      res.status(200).json({
        success: true,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  },
);

// ============== HELPER SUSPENSION ENDPOINTS ==============

/**
 * POST /admin/helpers/:helper_id/suspend
 * Suspend a helper
 */
router.post(
  '/admin/helpers/:helper_id/suspend',
  authenticate,
  requireAdmin,
  async (req, res, next) => {
    try {
      const { helper_id } = req.params;
      const { reason, suspension_days } = req.body;

      if (!reason) {
        throw new AppError(
          'INVALID_INPUT',
          'Missing required field: reason',
          400,
        );
      }

      let suspensionEndAt: Date | undefined;
      if (suspension_days) {
        suspensionEndAt = new Date();
        suspensionEndAt.setDate(suspensionEndAt.getDate() + suspension_days);
      }

      const result = await suspensionService.createSuspension(
        helper_id,
        reason,
        req.user.id,
        suspensionEndAt,
      );

      res.status(200).json({
        success: true,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  },
);

/**
 * POST /admin/helpers/:helper_id/reactivate
 * Reactivate a suspended helper
 */
router.post(
  '/admin/helpers/:helper_id/reactivate',
  authenticate,
  requireAdmin,
  async (req, res, next) => {
    try {
      const { helper_id } = req.params;
      const { reason } = req.body;

      // Find the latest suspension
      const suspensions = await (require('../config/prisma')).default.helperSuspensionLog.findMany({
        where: { helper_id },
        orderBy: { created_at: 'desc' },
        take: 1,
      });

      if (!suspensions.length) {
        throw new AppError(
          'NOT_SUSPENDED',
          'Helper is not currently suspended',
          400,
        );
      }

      const suspension = suspensions[0];
      const result = await suspensionService.unlockSuspension(
        suspension.id,
        req.user.id,
        reason,
      );

      res.status(200).json({
        success: true,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  },
);

/**
 * POST /admin/helpers/:helper_id/warn
 * Warn a helper (with auto-suspend on 3rd warning)
 */
router.post(
  '/admin/helpers/:helper_id/warn',
  authenticate,
  requireAdmin,
  async (req, res, next) => {
    try {
      const { helper_id } = req.params;
      const { reason } = req.body;

      if (!reason) {
        throw new AppError(
          'INVALID_INPUT',
          'Missing required field: reason',
          400,
        );
      }

      const result = await suspensionService.warnHelper(
        helper_id,
        reason,
        req.user.id,
      );

      res.status(200).json({
        success: true,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  },
);

// ============== PRICING ENDPOINTS ==============

/**
 * GET /admin/pricing
 * Get current pricing configuration
 */
router.get('/admin/pricing', authenticate, requireAdmin, async (req, res, next) => {
  try {
    const config = await pricingService.getPricingConfig();

    res.status(200).json({
      success: true,
      data: {
        base_fare_rupees: config.base_fare_rupees,
        per_km_rate: config.per_km_rate,
        per_minute_rate: config.per_minute_rate,
        minimum_fare_rupees: config.minimum_fare_rupees,
        cancellation_fee_rupees: config.cancellation_fee_rupees,
        platform_fee_percent: config.platform_fee_percent,
        business_task_multiplier: config.business_task_multiplier,
        peak_hour_multiplier: config.peak_hour_multiplier,
        daily_bonus_tasks_required: config.daily_bonus_tasks_required,
        daily_bonus_amount: config.daily_bonus_amount,
        effective_from: config.effective_from,
      },
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /admin/pricing
 * Update pricing configuration
 */
router.post('/admin/pricing', authenticate, requireAdmin, async (req, res, next) => {
  try {
    const updates = req.body;

    const result = await pricingService.updatePricingConfig(updates, req.user.id);

    res.status(200).json({
      success: true,
      data: {
        config_id: result.id,
        effective_from: result.effective_from,
        base_fare_rupees: result.base_fare_rupees,
        per_km_rate: result.per_km_rate,
        per_minute_rate: result.per_minute_rate,
        minimum_fare_rupees: result.minimum_fare_rupees,
        platform_fee_percent: result.platform_fee_percent,
        business_task_multiplier: result.business_task_multiplier,
        peak_hour_multiplier: result.peak_hour_multiplier,
      },
    });
  } catch (error) {
    next(error);
  }
});

export default router;
