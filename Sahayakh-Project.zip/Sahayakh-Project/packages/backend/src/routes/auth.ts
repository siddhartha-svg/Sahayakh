import { Router, Request, Response } from 'express';
import { validate, registerSchema, verifyOTPSchema, refreshTokenSchema, validatePhoneNumber, validateEmail, validateName, validateRole } from '@sahayakh/shared';
import * as authService from '../services/auth';
import { authMiddleware, asyncHandler } from '../middleware/auth';
import { AppError } from '../middleware/error';
import { AUTH_ERROR_CODES, AUTH_ERROR_MESSAGES } from '@sahayakh/shared';

const router = Router();

router.post(
  '/auth/register',
  asyncHandler(async (req: Request, res: Response) => {
    const validation = validate(registerSchema, req.body);
    if (!validation.valid) {
      res.status(400).json({
        error_code: 'VALIDATION_ERROR',
        message: 'Validation failed',
        status: 400,
        details: { errors: validation.errors },
      });
      return;
    }

    const { phone_number, name, role } = validation.data as {
      phone_number: string;
      name: string;
      role: 'customer' | 'helper';
    };

    const phoneValidation = validatePhoneNumber(phone_number);
    if (!phoneValidation.valid) {
      throw new AppError(
        AUTH_ERROR_CODES.INVALID_PHONE_NUMBER,
        phoneValidation.error!,
        400,
      );
    }

    const nameValidation = validateName(name);
    if (!nameValidation.valid) {
      throw new AppError(
        'INVALID_NAME',
        nameValidation.error!,
        400,
      );
    }

    const roleValidation = validateRole(role);
    if (!roleValidation.valid) {
      throw new AppError(
        AUTH_ERROR_CODES.INVALID_ROLE,
        roleValidation.error!,
        400,
      );
    }

    const result = await authService.registerWithPhone(phoneValidation.value!, nameValidation.value!, role);

    res.status(200).json(result);
  }),
);

router.post(
  '/auth/verify-otp',
  asyncHandler(async (req: Request, res: Response) => {
    const validation = validate(verifyOTPSchema, req.body);
    if (!validation.valid) {
      res.status(400).json({
        error_code: 'VALIDATION_ERROR',
        message: 'Validation failed',
        status: 400,
        details: { errors: validation.errors },
      });
      return;
    }

    const { phone_number, otp_code } = validation.data as {
      phone_number: string;
      otp_code: string;
    };

    const phoneValidation = validatePhoneNumber(phone_number);
    if (!phoneValidation.valid) {
      throw new AppError(
        AUTH_ERROR_CODES.INVALID_PHONE_NUMBER,
        phoneValidation.error!,
        400,
      );
    }

    const result = await authService.verifyOTP(phoneValidation.value!, otp_code);

    res.status(200).json(result);
  }),
);

router.post(
  '/auth/refresh',
  asyncHandler(async (req: Request, res: Response) => {
    const validation = validate(refreshTokenSchema, req.body);
    if (!validation.valid) {
      res.status(400).json({
        error_code: 'VALIDATION_ERROR',
        message: 'Validation failed',
        status: 400,
        details: { errors: validation.errors },
      });
      return;
    }

    const { refresh_token } = validation.data as { refresh_token: string };

    const result = await authService.refreshAccessToken(refresh_token);

    res.status(200).json(result);
  }),
);

router.get(
  '/auth/me',
  authMiddleware,
  asyncHandler(async (req: Request, res: Response) => {
    if (!req.user) {
      throw new AppError(
        AUTH_ERROR_CODES.UNAUTHORIZED,
        AUTH_ERROR_MESSAGES.UNAUTHORIZED,
        401,
      );
    }

    const user = await authService.getCurrentUser(req.user.user_id);

    res.status(200).json(user);
  }),
);

router.post(
  '/auth/logout',
  authMiddleware,
  asyncHandler(async (req: Request, res: Response) => {
    res.status(200).json({ success: true, message: 'Logged out successfully' });
  }),
);

export default router;
