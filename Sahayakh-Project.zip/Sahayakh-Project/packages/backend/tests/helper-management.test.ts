import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import prisma from '../src/config/prisma';
import * as helperManagement from '../src/services/helper-management';

describe('Helper Management Service', () => {
  let helperId: string;
  let adminId: string;
  let documentIds: { [key: string]: string } = {};

  beforeEach(async () => {
    // Create helper user
    const helperUser = await prisma.user.create({
      data: {
        id: 'helper-' + Date.now(),
        name: 'Test Helper',
        phone_number: '9876543210',
        email: 'helper@test.com',
        role: 'helper',
      },
    });

    const helper = await prisma.helper.create({
      data: {
        user_id: helperUser.id,
        helper_status: 'inactive',
        verification_status: 'pending',
        background_check_status: 'cleared',
      },
    });
    helperId = helper.id;

    // Create documents
    const docTypes = ['aadhaar', 'pan', 'driving_license', 'selfie', 'bank_account'];
    for (const type of docTypes) {
      const doc = await prisma.helperDocument.create({
        data: {
          helper_id: helperId,
          document_type: type,
          document_url: `https://example.com/docs/${type}.pdf`,
          status: 'pending',
        },
      });
      documentIds[type] = doc.id;
    }

    // Create admin
    const admin = await prisma.user.create({
      data: {
        id: 'admin-' + Date.now(),
        name: 'Test Admin',
        phone_number: '9876543211',
        email: 'admin@test.com',
        role: 'admin',
      },
    });
    adminId = admin.id;
  });

  afterEach(async () => {
    // Cleanup
    await prisma.helperDocument.deleteMany({});
    await prisma.auditLog.deleteMany({});
    await prisma.helper.deleteMany({});
    await prisma.user.deleteMany({});
  });

  describe('getHelperApplications', () => {
    it('should list all helpers with pending status', async () => {
      const helpers = await helperManagement.getHelperApplications('pending', 10, 0);
      expect(helpers.length).toBeGreaterThan(0);
      expect(helpers[0].verification_status).toBe('pending');
    });

    it('should filter by verification status', async () => {
      // Approve the helper first
      await helperManagement.approveHelperApplication(helperId, adminId);

      const pending = await helperManagement.getHelperApplications('pending', 10, 0);
      const verified = await helperManagement.getHelperApplications('verified', 10, 0);

      expect(verified.some((h) => h.id === helperId)).toBe(true);
      expect(pending.some((h) => h.id === helperId)).toBe(false);
    });

    it('should show document count', async () => {
      const helpers = await helperManagement.getHelperApplications(undefined, 10, 0);
      const helper = helpers.find((h) => h.id === helperId);
      expect(helper?.documents_total).toBe(5);
      expect(helper?.documents_pending).toBe(5);
    });
  });

  describe('getHelperDetails', () => {
    it('should return comprehensive helper profile', async () => {
      const details = await helperManagement.getHelperDetails(helperId);

      expect(details).toBeDefined();
      expect(details.user.name).toBe('Test Helper');
      expect(details.status.verification_status).toBe('pending');
      expect(details.documents.length).toBe(5);
    });

    it('should include verification history', async () => {
      await helperManagement.approveHelperApplication(helperId, adminId);

      const details = await helperManagement.getHelperDetails(helperId);
      expect(details.verification_history.length).toBeGreaterThan(0);
      expect(details.verification_history[0].action).toBe('helper_approved');
    });
  });

  describe('approveHelperApplication', () => {
    it('should approve pending helper', async () => {
      const result = await helperManagement.approveHelperApplication(
        helperId,
        adminId,
      );

      expect(result.verification_status).toBe('verified');

      // Verify in database
      const helper = await prisma.helper.findUnique({
        where: { id: helperId },
      });
      expect(helper?.verification_status).toBe('verified');
    });

    it('should log to audit trail', async () => {
      await helperManagement.approveHelperApplication(
        helperId,
        adminId,
        'All docs verified',
      );

      const log = await prisma.auditLog.findFirst({
        where: {
          action: 'helper_approved',
          resource_id: helperId,
        },
      });

      expect(log).toBeDefined();
      expect(log?.admin_id).toBe(adminId);
    });

    it('should prevent approving non-pending helper', async () => {
      await helperManagement.approveHelperApplication(helperId, adminId);

      await expect(
        helperManagement.approveHelperApplication(helperId, adminId),
      ).rejects.toThrow('INVALID_STATUS');
    });
  });

  describe('rejectHelperApplication', () => {
    it('should reject pending helper', async () => {
      const result = await helperManagement.rejectHelperApplication(
        helperId,
        adminId,
        'Documents incomplete',
      );

      expect(result.verification_status).toBe('rejected');
      expect(result.rejection_reason).toBe('Documents incomplete');
    });

    it('should prevent rejecting non-pending helper', async () => {
      await helperManagement.approveHelperApplication(helperId, adminId);

      await expect(
        helperManagement.rejectHelperApplication(
          helperId,
          adminId,
          'Some reason',
        ),
      ).rejects.toThrow('INVALID_STATUS');
    });
  });

  describe('verifyDocument', () => {
    it('should verify pending document', async () => {
      const result = await helperManagement.verifyDocument(
        helperId,
        'aadhaar',
        adminId,
      );

      expect(result.document_type).toBe('aadhaar');
      expect(result.status).toBe('verified');

      // Verify in database
      const doc = await prisma.helperDocument.findUnique({
        where: { id: documentIds['aadhaar'] },
      });
      expect(doc?.status).toBe('verified');
    });

    it('should auto-approve helper when all docs verified', async () => {
      // Verify all documents
      for (const type of Object.keys(documentIds)) {
        await helperManagement.verifyDocument(helperId, type, adminId);
      }

      // Check if helper was auto-approved
      const helper = await prisma.helper.findUnique({
        where: { id: helperId },
      });
      expect(helper?.verification_status).toBe('verified');
    });

    it('should prevent verifying non-pending document', async () => {
      await helperManagement.verifyDocument(helperId, 'aadhaar', adminId);

      await expect(
        helperManagement.verifyDocument(helperId, 'aadhaar', adminId),
      ).rejects.toThrow('INVALID_STATUS');
    });
  });

  describe('rejectDocument', () => {
    it('should reject pending document', async () => {
      const result = await helperManagement.rejectDocument(
        helperId,
        'aadhaar',
        adminId,
        'Invalid photo quality',
      );

      expect(result.document_type).toBe('aadhaar');
      expect(result.status).toBe('rejected');
      expect(result.rejection_reason).toBe('Invalid photo quality');
    });

    it('should log rejection reason', async () => {
      await helperManagement.rejectDocument(
        helperId,
        'aadhaar',
        adminId,
        'Blurry image',
      );

      const log = await prisma.auditLog.findFirst({
        where: {
          action: 'helper_document_rejected',
        },
      });

      expect(log).toBeDefined();
    });
  });

  describe('getDocumentVerificationQueue', () => {
    it('should return pending documents in order', async () => {
      const queue = await helperManagement.getDocumentVerificationQueue(10, 0);

      expect(queue.length).toBeGreaterThan(0);
      expect(queue[0].status).toBe('pending');
    });

    it('should exclude verified documents from queue', async () => {
      await helperManagement.verifyDocument(helperId, 'aadhaar', adminId);

      const queue = await helperManagement.getDocumentVerificationQueue(10, 0);
      expect(queue.some((d) => d.document_type === 'aadhaar')).toBe(false);
    });
  });

  describe('Document verification workflow', () => {
    it('should handle complete approval workflow', async () => {
      // Verify all documents
      for (const type of ['aadhaar', 'pan', 'driving_license', 'selfie', 'bank_account']) {
        await helperManagement.verifyDocument(helperId, type, adminId);
      }

      // Check helper was auto-approved
      const helper = await prisma.helper.findUnique({
        where: { id: helperId },
      });
      expect(helper?.verification_status).toBe('verified');

      // Check history
      const details = await helperManagement.getHelperDetails(helperId);
      expect(details.verification_history.length).toBeGreaterThan(0);
      expect(details.verification_history.some((h) => h.action === 'helper_approved')).toBe(true);
    });

    it('should handle rejection workflow', async () => {
      // Reject application
      await helperManagement.rejectHelperApplication(
        helperId,
        adminId,
        'Missing documents',
      );

      // Verify status
      const helper = await prisma.helper.findUnique({
        where: { id: helperId },
      });
      expect(helper?.verification_status).toBe('rejected');
    });
  });
});
