import request from 'supertest';
import app from '../src/index';
import prisma from '../src/config/prisma';
import redis from '../src/config/redis';
import * as jwtUtils from '../src/utils/jwt';
import * as locationTracking from '../src/services/location-tracking';

describe('Location Tracking Service', () => {
  let customerId: string;
  let helperId: string;
  let customerToken: string;
  let helperToken: string;
  let taskId: string;

  beforeAll(async () => {
    // Create customer
    const customer = await prisma.user.create({
      data: {
        phone_number: '+919999999991',
        name: 'Location Test Customer',
        role: 'customer',
        status: 'active',
      },
    });
    customerId = customer.id;
    customerToken = jwtUtils.signAccessToken(customerId, 'customer');

    // Create helper
    const helperUser = await prisma.user.create({
      data: {
        phone_number: '+918888888881',
        name: 'Location Test Helper',
        role: 'helper',
        status: 'active',
        location_point: JSON.stringify({ latitude: 17.36, longitude: 78.48 }),
      },
    });
    helperId = helperUser.id;
    helperToken = jwtUtils.signAccessToken(helperId, 'helper');

    // Create helper profile
    await prisma.helper.create({
      data: {
        user_id: helperId,
        rating: 4.8,
        total_tasks: 150,
        average_response_time_minutes: 5,
        helper_status: 'online',
        verification_status: 'verified',
        background_check_status: 'cleared',
        accepts_personal_tasks: true,
        accepts_business_tasks: false,
        preferred_categories: [],
        service_radius_km: 25,
        online_since: new Date(),
      },
    });

    // Create task
    const taskRes = await request(app)
      .post('/api/tasks')
      .set('Authorization', `Bearer ${customerToken}`)
      .send({
        task_type: 'personal',
        category: 'pickup_delivery',
        description: 'Test location tracking',
        location_name: 'Test Location, Hanamkonda',
        location_point: { latitude: 17.365, longitude: 78.485 },
        preferred_date: '2026-09-25',
        preferred_time: '14:30',
        budget_min: 100,
        budget_max: 200,
      });

    taskId = taskRes.body.task.id;

    // Assign helper to task
    await request(app)
      .post(`/api/tasks/${taskId}/assign`)
      .set('Authorization', `Bearer ${customerToken}`)
      .send({ helper_id: helperId });
  });

  afterEach(async () => {
    // Clean up Redis location cache after each test
    await redis.del(`tasks:locations:${taskId}`);
  });

  afterAll(async () => {
    await redis.flushdb();
    await prisma.taskRequest.deleteMany({});
    await prisma.notification.deleteMany({});
    await prisma.taskStatusHistory.deleteMany({});
    await prisma.task.deleteMany({});
    await prisma.helper.deleteMany({});
    await prisma.user.deleteMany({});
  });

  describe('storeLocationPing', () => {
    it('should store location ping in Redis with TTL', async () => {
      const ping = await locationTracking.storeLocationPing(
        taskId,
        helperId,
        17.365,
        78.485,
        5,
      );

      expect(ping).toBeDefined();
      expect(ping.helper_lat).toBe(17.365);
      expect(ping.helper_lng).toBe(78.485);
      expect(ping.accuracy_m).toBe(5);
      expect(ping.distance_to_customer_m).toBeLessThan(1000); // Should be very close
      expect(ping.eta_minutes).toBeGreaterThan(0);

      // Verify stored in Redis
      const stored = await redis.get(`tasks:locations:${taskId}`);
      expect(stored).toBeDefined();
    });

    it('should reject location outside Warangal bounds', async () => {
      await expect(
        locationTracking.storeLocationPing(taskId, helperId, 20.0, 85.0, 5),
      ).rejects.toThrow('INVALID_LOCATION');
    });

    it('should reject if helper not assigned to task', async () => {
      const otherHelper = await prisma.user.create({
        data: {
          phone_number: '+917777777771',
          name: 'Other Helper',
          role: 'helper',
          status: 'active',
        },
      });

      await expect(
        locationTracking.storeLocationPing(taskId, otherHelper.id, 17.365, 78.485, 5),
      ).rejects.toThrow('UNAUTHORIZED');

      await prisma.user.delete({ where: { id: otherHelper.id } });
    });

    it('should calculate distance correctly', async () => {
      // Task location: 17.365, 78.485
      // Helper location: same point
      const ping1 = await locationTracking.storeLocationPing(
        taskId,
        helperId,
        17.365,
        78.485,
        5,
      );
      expect(ping1.distance_to_customer_m).toBeLessThan(10); // Should be very close

      // Helper 1km away (approx)
      const ping2 = await locationTracking.storeLocationPing(
        taskId,
        helperId,
        17.375,
        78.485,
        5,
      );
      expect(ping2.distance_to_customer_m).toBeGreaterThan(800);
      expect(ping2.distance_to_customer_m).toBeLessThan(1200);
    });
  });

  describe('getLastLocationPing', () => {
    it('should retrieve last location from Redis', async () => {
      // Store a location
      await locationTracking.storeLocationPing(taskId, helperId, 17.365, 78.485, 5);

      // Retrieve it
      const ping = await locationTracking.getLastLocationPing(taskId);
      expect(ping).toBeDefined();
      expect(ping?.helper_lat).toBe(17.365);
      expect(ping?.helper_lng).toBe(78.485);
    });

    it('should return null if no location stored', async () => {
      const ping = await locationTracking.getLastLocationPing('nonexistent-task');
      expect(ping).toBeNull();
    });
  });

  describe('hasSignificantChange', () => {
    it('should return true if no previous ping', async () => {
      const ping = await locationTracking.storeLocationPing(
        taskId,
        helperId,
        17.365,
        78.485,
        5,
      );
      const changed = await locationTracking.hasSignificantChange(taskId, ping);
      expect(changed).toBe(true);
    });

    it('should return true if moved >10m', async () => {
      // Store initial location
      await locationTracking.storeLocationPing(taskId, helperId, 17.365, 78.485, 5);

      // Move >10m (approx 0.0001 degrees = ~11m)
      const newPing = await locationTracking.storeLocationPing(
        taskId,
        helperId,
        17.3651,
        78.485,
        5,
      );
      const changed = await locationTracking.hasSignificantChange(taskId, newPing);
      expect(changed).toBe(true);
    });

    it('should return false if moved <10m AND ETA unchanged', async () => {
      // Store initial location
      const ping1 = await locationTracking.storeLocationPing(
        taskId,
        helperId,
        17.365,
        78.485,
        5,
      );

      // Move <10m (approx 0.00005 degrees = ~5m) and same ETA
      const ping2: any = {
        ...ping1,
        helper_lat: 17.36501,
        helper_lng: 78.485,
      };

      const changed = await locationTracking.hasSignificantChange(taskId, ping2);
      expect(changed).toBe(false);
    });

    it('should return true if ETA changed >1 minute', async () => {
      // Store initial location
      await locationTracking.storeLocationPing(taskId, helperId, 17.365, 78.485, 5);

      // Update with same location but different ETA
      const ping: any = await locationTracking.getLastLocationPing(taskId);
      ping.eta_minutes = (ping.eta_minutes || 0) + 2; // Change by >1 min

      const changed = await locationTracking.hasSignificantChange(taskId, ping);
      expect(changed).toBe(true);
    });
  });

  describe('calculateDynamicETA', () => {
    it('should calculate ETA based on distance', () => {
      // Task at 17.365, 78.485
      // Helper at same location: should be 0-1 min
      const eta1 = locationTracking.calculateDynamicETA(17.365, 78.485, 17.365, 78.485);
      expect(eta1).toBeLessThan(2);

      // Helper 10km away: should be ~15 min (10km / 40km/h * 60)
      const eta2 = locationTracking.calculateDynamicETA(17.265, 78.485, 17.365, 78.485);
      expect(eta2).toBeGreaterThan(12);
      expect(eta2).toBeLessThan(18);
    });
  });

  describe('cleanupTaskLocations', () => {
    it('should delete location data from Redis', async () => {
      // Store location
      await locationTracking.storeLocationPing(taskId, helperId, 17.365, 78.485, 5);
      let stored = await redis.get(`tasks:locations:${taskId}`);
      expect(stored).toBeDefined();

      // Clean up
      await locationTracking.cleanupTaskLocations(taskId);
      stored = await redis.get(`tasks:locations:${taskId}`);
      expect(stored).toBeNull();
    });
  });

  describe('broadcastLocationToCustomer', () => {
    it('should emit location:update event without errors', async () => {
      const ping = await locationTracking.storeLocationPing(
        taskId,
        helperId,
        17.365,
        78.485,
        5,
      );

      // Should not throw
      const mockIo = {
        of: () => ({
          to: () => ({
            emit: jest.fn(),
          }),
        }),
      };

      expect(() =>
        locationTracking.broadcastLocationToCustomer(taskId, mockIo, ping),
      ).not.toThrow();
    });

    it('should handle missing Socket.IO gracefully', () => {
      const ping: any = {
        helper_lat: 17.365,
        helper_lng: 78.485,
        accuracy_m: 5,
        timestamp: new Date().toISOString(),
        distance_to_customer_m: 100,
        eta_minutes: 5,
      };

      expect(() =>
        locationTracking.broadcastLocationToCustomer(taskId, null, ping),
      ).not.toThrow();
    });
  });

  describe('reconnectLocationHandler', () => {
    it('should emit last location on customer reconnect', async () => {
      // Store location
      await locationTracking.storeLocationPing(taskId, helperId, 17.365, 78.485, 5);

      // Mock socket
      const mockSocket = {
        emit: jest.fn(),
      };

      await locationTracking.reconnectLocationHandler(mockSocket, taskId);

      expect(mockSocket.emit).toHaveBeenCalledWith(
        'location:update',
        expect.objectContaining({
          helper_lat: 17.365,
          helper_lng: 78.485,
        }),
      );
    });

    it('should handle no stored location gracefully', async () => {
      const mockSocket = {
        emit: jest.fn(),
      };

      // Should not throw even if no location stored
      await locationTracking.reconnectLocationHandler(
        mockSocket,
        'nonexistent-task',
      );

      expect(mockSocket.emit).not.toHaveBeenCalled();
    });
  });

  describe('Integration scenario', () => {
    it('should handle complete location tracking flow', async () => {
      // 1. Store initial location (helper at task location)
      const ping1 = await locationTracking.storeLocationPing(
        taskId,
        helperId,
        17.365,
        78.485,
        10,
      );
      expect(ping1.distance_to_customer_m).toBeLessThan(100);

      // 2. Store updated location (helper moved)
      const ping2 = await locationTracking.storeLocationPing(
        taskId,
        helperId,
        17.366,
        78.486,
        8,
      );
      const changed = await locationTracking.hasSignificantChange(taskId, ping2);
      expect(changed).toBe(true);

      // 3. Retrieve last location
      const last = await locationTracking.getLastLocationPing(taskId);
      expect(last).toBeDefined();
      expect(last?.helper_lat).toBe(17.366);

      // 4. Clean up
      await locationTracking.cleanupTaskLocations(taskId);
      const cleaned = await locationTracking.getLastLocationPing(taskId);
      expect(cleaned).toBeNull();
    });
  });
});
