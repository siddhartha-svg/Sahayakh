import request from 'supertest';
import { initializeDatabase, getPool, closeDatabase } from '../src/config/database';
import { initializeRedis, getRedis, closeRedis } from '../src/config/redis';
import app from '../src/index';
import { v4 as uuidv4 } from 'uuid';

describe('Full Task Lifecycle Integration', () => {
  let pool: any;
  let redis: any;
  let customerId: string;
  let helperId: string;
  let helperUserId: string;
  let customerToken: string;
  let helperToken: string;

  beforeAll(async () => {
    await initializeDatabase();
    await initializeRedis();
    pool = getPool();
    redis = getRedis();

    // Create all necessary tables
    await pool.query('DROP TABLE IF EXISTS payments CASCADE');
    await pool.query('DROP TABLE IF EXISTS payouts CASCADE');
    await pool.query('DROP TABLE IF EXISTS tasks CASCADE');
    await pool.query('DROP TABLE IF EXISTS helpers CASCADE');
    await pool.query('DROP TABLE IF EXISTS users CASCADE');

    // Create complete schema
    await pool.query(`
      CREATE TABLE users (
        id UUID PRIMARY KEY,
        phone_number VARCHAR(20) UNIQUE,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE,
        role VARCHAR(20) NOT NULL DEFAULT 'customer',
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        location_point JSONB,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE helpers (
        id UUID PRIMARY KEY,
        user_id UUID NOT NULL REFERENCES users(id),
        helper_status VARCHAR(50) DEFAULT 'approved',
        rating NUMERIC(3,2) DEFAULT 5.0,
        total_tasks INT DEFAULT 0,
        service_radius_km INT DEFAULT 15,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE tasks (
        id UUID PRIMARY KEY,
        task_id_display VARCHAR(20) UNIQUE,
        customer_id UUID NOT NULL REFERENCES users(id),
        helper_id UUID REFERENCES helpers(id),
        task_type VARCHAR(20),
        category VARCHAR(100),
        description TEXT,
        location_point JSONB,
        location_name VARCHAR(255),
        preferred_date VARCHAR(20),
        preferred_time VARCHAR(20),
        budget_min NUMERIC(10,2),
        budget_max NUMERIC(10,2),
        status VARCHAR(50) DEFAULT 'unassigned',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE payments (
        id UUID PRIMARY KEY,
        task_id UUID NOT NULL REFERENCES tasks(id),
        customer_id UUID NOT NULL REFERENCES users(id),
        helper_id UUID REFERENCES helpers(id),
        final_amount NUMERIC(10,2) NOT NULL,
        platform_fee_amount NUMERIC(10,2) NOT NULL,
        helper_payout_amount NUMERIC(10,2) NOT NULL,
        status VARCHAR(50) DEFAULT 'pending',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE payouts (
        id UUID PRIMARY KEY,
        helper_id UUID NOT NULL REFERENCES helpers(id),
        total_amount NUMERIC(10,2) NOT NULL,
        payment_method VARCHAR(50),
        status VARCHAR(50) DEFAULT 'pending',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);
  });

  afterAll(async () => {
    await pool.query('DROP TABLE IF EXISTS payments CASCADE');
    await pool.query('DROP TABLE IF EXISTS payouts CASCADE');
    await pool.query('DROP TABLE IF EXISTS tasks CASCADE');
    await pool.query('DROP TABLE IF EXISTS helpers CASCADE');
    await pool.query('DROP TABLE IF EXISTS users CASCADE');
    await closeDatabase();
    await closeRedis();
  });

  afterEach(async () => {
    await redis.flushdb();
    await pool.query('DELETE FROM payments');
    await pool.query('DELETE FROM payouts');
    await pool.query('DELETE FROM tasks');
    await pool.query('DELETE FROM helpers');
    await pool.query('DELETE FROM users');
  });

  describe('Complete Task Lifecycle: Creation → Assignment → Completion → Payment', () => {
    beforeEach(async () => {
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      customerId = uuidv4();
      helperUserId = uuidv4();
      helperId = uuidv4();

      // Create customer
      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [customerId, '+919999999999', 'Test Customer', 'customer', 'active', JSON.stringify(taskLocation)]
      );

      // Create helper
      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [helperUserId, '+919999999001', 'Test Helper', 'helper', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO helpers (id, user_id, helper_status, rating) VALUES ($1, $2, $3, $4)',
        [helperId, helperUserId, 'approved', 4.8]
      );
    });

    it('should create task in unassigned state', async () => {
      const taskId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      const result = await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *',
        [taskId, 'SKT00001', customerId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'unassigned']
      );

      expect(result.rows[0].status).toBe('unassigned');
      expect(result.rows[0].helper_id).toBeNull();
      expect(result.rows[0].customer_id).toBe(customerId);
    });

    it('should transition task from unassigned → confirmed when helper accepts', async () => {
      const taskId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      // Create task
      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
        [taskId, 'SKT00001', customerId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'unassigned']
      );

      // Helper accepts
      const result = await pool.query(
        'UPDATE tasks SET status = $1, helper_id = $2, updated_at = NOW() WHERE id = $3 RETURNING *',
        ['confirmed', helperId, taskId]
      );

      expect(result.rows[0].status).toBe('confirmed');
      expect(result.rows[0].helper_id).toBe(helperId);
    });

    it('should move task through all states: confirmed → started → otp_pending → in_progress → completed', async () => {
      const taskId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      // Create task with helper assigned
      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, helper_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)',
        [taskId, 'SKT00001', customerId, helperId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'confirmed']
      );

      // confirmed → started
      let result = await pool.query('UPDATE tasks SET status = $1 WHERE id = $2 RETURNING status', ['started', taskId]);
      expect(result.rows[0].status).toBe('started');

      // started → otp_pending
      result = await pool.query('UPDATE tasks SET status = $1 WHERE id = $2 RETURNING status', ['otp_pending', taskId]);
      expect(result.rows[0].status).toBe('otp_pending');

      // otp_pending → in_progress
      result = await pool.query('UPDATE tasks SET status = $1 WHERE id = $2 RETURNING status', ['in_progress', taskId]);
      expect(result.rows[0].status).toBe('in_progress');

      // in_progress → completed
      result = await pool.query('UPDATE tasks SET status = $1 WHERE id = $2 RETURNING status', ['completed', taskId]);
      expect(result.rows[0].status).toBe('completed');
    });

    it('should create payment when task is completed', async () => {
      const taskId = uuidv4();
      const paymentId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, helper_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)',
        [taskId, 'SKT00001', customerId, helperId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'completed']
      );

      // Create payment
      const result = await pool.query(
        'INSERT INTO payments (id, task_id, customer_id, helper_id, final_amount, platform_fee_amount, helper_payout_amount, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *',
        [paymentId, taskId, customerId, helperId, 300, 45, 255, 'completed']
      );

      expect(result.rows[0].final_amount).toBe(300);
      expect(result.rows[0].platform_fee_amount).toBe(45);
      expect(result.rows[0].helper_payout_amount).toBe(255);
      expect(result.rows[0].status).toBe('completed');
    });

    it('should allow helper to request payout after task payment', async () => {
      const taskId = uuidv4();
      const paymentId = uuidv4();
      const payoutId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      // Create completed task
      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, helper_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)',
        [taskId, 'SKT00001', customerId, helperId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'completed']
      );

      // Create payment
      await pool.query(
        'INSERT INTO payments (id, task_id, customer_id, helper_id, final_amount, platform_fee_amount, helper_payout_amount, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)',
        [paymentId, taskId, customerId, helperId, 300, 45, 255, 'completed']
      );

      // Helper requests payout
      const result = await pool.query(
        'INSERT INTO payouts (id, helper_id, total_amount, payment_method, status) VALUES ($1, $2, $3, $4, $5) RETURNING *',
        [payoutId, helperId, 255, 'upi', 'pending']
      );

      expect(result.rows[0].helper_id).toBe(helperId);
      expect(result.rows[0].total_amount).toBe(255);
      expect(result.rows[0].status).toBe('pending');
    });

    it('should process payout and update helper balance', async () => {
      const taskId = uuidv4();
      const paymentId = uuidv4();
      const payoutId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      // Create completed task with payment
      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, helper_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)',
        [taskId, 'SKT00001', customerId, helperId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'completed']
      );

      await pool.query(
        'INSERT INTO payments (id, task_id, customer_id, helper_id, final_amount, platform_fee_amount, helper_payout_amount, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)',
        [paymentId, taskId, customerId, helperId, 300, 45, 255, 'completed']
      );

      // Create pending payout
      await pool.query(
        'INSERT INTO payouts (id, helper_id, total_amount, payment_method, status) VALUES ($1, $2, $3, $4, $5)',
        [payoutId, helperId, 255, 'upi', 'pending']
      );

      // Process payout
      const result = await pool.query(
        'UPDATE payouts SET status = $1 WHERE id = $2 RETURNING *',
        ['completed', payoutId]
      );

      expect(result.rows[0].status).toBe('completed');

      // Verify balance
      const payments = await pool.query(
        'SELECT helper_payout_amount FROM payments WHERE helper_id = $1 AND status = $2',
        [helperId, 'completed']
      );

      const payouts = await pool.query(
        'SELECT total_amount FROM payouts WHERE helper_id = $1 AND status = $2',
        [helperId, 'completed']
      );

      const earned = payments.rows.reduce((sum, p) => sum + parseFloat(p.helper_payout_amount), 0);
      const paid = payouts.rows.reduce((sum, p) => sum + parseFloat(p.total_amount), 0);
      const available = earned - paid;

      expect(earned).toBe(255);
      expect(paid).toBe(255);
      expect(available).toBe(0);
    });

    it('should handle multiple tasks for same helper', async () => {
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      // Create 3 completed tasks
      const taskIds = [];
      const paymentIds = [];

      for (let i = 0; i < 3; i++) {
        const taskId = uuidv4();
        const paymentId = uuidv4();

        await pool.query(
          'INSERT INTO tasks (id, task_id_display, customer_id, helper_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)',
          [taskId, `SKT${String(i + 1).padStart(5, '0')}`, customerId, helperId, 'personal', 'cleaning', 'Task', JSON.stringify(taskLocation), 'Warangal', 'completed']
        );

        await pool.query(
          'INSERT INTO payments (id, task_id, customer_id, helper_id, final_amount, platform_fee_amount, helper_payout_amount, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)',
          [paymentId, taskId, customerId, helperId, 300, 45, 255, 'completed']
        );

        taskIds.push(taskId);
        paymentIds.push(paymentId);
      }

      // Check total earnings
      const payments = await pool.query(
        'SELECT helper_payout_amount FROM payments WHERE helper_id = $1 AND status = $2',
        [helperId, 'completed']
      );

      const total = payments.rows.reduce((sum, p) => sum + parseFloat(p.helper_payout_amount), 0);

      expect(total).toBe(765); // 255 * 3
    });

    it('should track payout attempts and failures', async () => {
      const taskId = uuidv4();
      const paymentId = uuidv4();
      const payoutId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, helper_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)',
        [taskId, 'SKT00001', customerId, helperId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'completed']
      );

      await pool.query(
        'INSERT INTO payments (id, task_id, customer_id, helper_id, final_amount, platform_fee_amount, helper_payout_amount, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)',
        [paymentId, taskId, customerId, helperId, 300, 45, 255, 'completed']
      );

      // Create payout (pending)
      await pool.query(
        'INSERT INTO payouts (id, helper_id, total_amount, payment_method, status) VALUES ($1, $2, $3, $4, $5)',
        [payoutId, helperId, 255, 'upi', 'pending']
      );

      // Mark as failed
      let result = await pool.query(
        'UPDATE payouts SET status = $1 WHERE id = $2 RETURNING *',
        ['failed', payoutId]
      );

      expect(result.rows[0].status).toBe('failed');

      // Retry - should return to pending
      result = await pool.query(
        'UPDATE payouts SET status = $1 WHERE id = $2 RETURNING *',
        ['pending', payoutId]
      );

      expect(result.rows[0].status).toBe('pending');

      // Eventually completes
      result = await pool.query(
        'UPDATE payouts SET status = $1 WHERE id = $2 RETURNING *',
        ['completed', payoutId]
      );

      expect(result.rows[0].status).toBe('completed');
    });
  });
});
