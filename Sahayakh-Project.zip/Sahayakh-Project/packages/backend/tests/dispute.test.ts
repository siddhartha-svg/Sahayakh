import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import prisma from '../src/config/prisma';
import * as disputeService from '../src/services/dispute';

describe('Dispute Service', () => {
  let customerId: string;
  let helperId: string;
  let taskId: string;

  beforeEach(async () => {
    // Create test users
    const customer = await prisma.user.create({
      data: {
        id: 'customer-test-' + Date.now(),
        name: 'Test Customer',
        phone_number: '9876543210',
        email: 'customer@test.com',
        role: 'customer',
      },
    });
    customerId = customer.id;

    const helperUser = await prisma.user.create({
      data: {
        id: 'helper-user-' + Date.now(),
        name: 'Test Helper',
        phone_number: '9876543211',
        email: 'helper@test.com',
        role: 'helper',
      },
    });

    const helper = await prisma.helper.create({
      data: {
        user_id: helperUser.id,
        helper_status: 'available',
        verification_status: 'verified',
        background_check_status: 'cleared',
      },
    });
    helperId = helper.id;

    // Create test task
    const task = await prisma.task.create({
      data: {
        task_id_display: 'T-' + Date.now(),
        customer_id: customerId,
        helper_id: helper.id,
        task_type: 'household',
        category: 'cleaning',
        title: 'House Cleaning',
        description: 'Clean the house',
        location_point: {
          type: 'Point',
          coordinates: [78.1198, 17.3850],
        },
        budget: 500,
        status: 'completed',
        final_amount: 500,
      },
    });
    taskId = task.id;

    // Create payment for the task
    await prisma.payment.create({
      data: {
        task_id: taskId,
        customer_id: customerId,
        final_amount: 500,
        task_amount: 500,
        distance_surcharge: 0,
        time_surcharge: 0,
        peak_multiplier: 1.0,
        platform_fee_amount: 75,
        helper_payout_amount: 425,
        payment_method: 'card',
        status: 'completed',
        completed_at: new Date(),
      },
    });
  });

  afterEach(async () => {
    // Cleanup
    await prisma.dispute.deleteMany({});
    await prisma.payment.deleteMany({});
    await prisma.task.deleteMany({});
    await prisma.helper.deleteMany({});
    await prisma.user.deleteMany({});
  });

  describe('raiseDispute', () => {
    it('should allow customer to raise dispute', async () => {
      const dispute = await disputeService.raiseDispute(
        taskId,
        customerId,
        'quality',
        'Work was incomplete',
        [],
      );

      expect(dispute).toBeDefined();
      expect(dispute.dispute_id_display).toMatch(/^D-\d+/);
      expect(dispute.status).toBe('open');
      expect(dispute.category).toBe('quality');
    });

    it('should allow helper to raise dispute', async () => {
      const dispute = await disputeService.raiseDispute(
        taskId,
        helperId,
        'pricing',
        'Price was too low',
        [],
      );

      expect(dispute).toBeDefined();
      expect(dispute.status).toBe('open');
      expect(dispute.category).toBe('pricing');
    });

    it('should update task status to disputed', async () => {
      await disputeService.raiseDispute(
        taskId,
        customerId,
        'quality',
        'Work incomplete',
        [],
      );

      const task = await prisma.task.findUnique({ where: { id: taskId } });
      expect(task?.status).toBe('disputed');
    });

    it('should prevent raising dispute on incomplete task', async () => {
      const task = await prisma.task.create({
        data: {
          task_id_display: 'T-incomplete-' + Date.now(),
          customer_id: customerId,
          helper_id: helperId,
          task_type: 'household',
          category: 'cleaning',
          title: 'Incomplete Task',
          description: 'Not done yet',
          location_point: {
            type: 'Point',
            coordinates: [78.1198, 17.3850],
          },
          budget: 500,
          status: 'in_progress',
        },
      });

      await expect(
        disputeService.raiseDispute(
          task.id,
          customerId,
          'quality',
          'Not complete',
          [],
        ),
      ).rejects.toThrow('TASK_NOT_COMPLETED');
    });

    it('should prevent multiple active disputes on same task', async () => {
      await disputeService.raiseDispute(
        taskId,
        customerId,
        'quality',
        'First dispute',
        [],
      );

      await expect(
        disputeService.raiseDispute(
          taskId,
          helperId,
          'pricing',
          'Second dispute',
          [],
        ),
      ).rejects.toThrow('DISPUTE_EXISTS');
    });

    it('should reject unauthorized users', async () => {
      const otherUser = await prisma.user.create({
        data: {
          id: 'other-user-' + Date.now(),
          name: 'Other User',
          phone_number: '9876543212',
          email: 'other@test.com',
          role: 'customer',
        },
      });

      await expect(
        disputeService.raiseDispute(
          taskId,
          otherUser.id,
          'quality',
          'Unauthorized',
          [],
        ),
      ).rejects.toThrow('UNAUTHORIZED');
    });
  });

  describe('addDisputeMessage', () => {
    let disputeId: string;

    beforeEach(async () => {
      const dispute = await disputeService.raiseDispute(
        taskId,
        customerId,
        'quality',
        'Initial complaint',
        [],
      );
      disputeId = dispute.id;
    });

    it('should add message to dispute', async () => {
      const result = await disputeService.addDisputeMessage(
        disputeId,
        helperId,
        'I disagree with this',
      );

      expect(result.message_count).toBe(2); // Initial + new message
    });

    it('should prevent adding messages to resolved dispute', async () => {
      // Mark as resolved
      await prisma.dispute.update({
        where: { id: disputeId },
        data: { status: 'resolved' },
      });

      await expect(
        disputeService.addDisputeMessage(
          disputeId,
          helperId,
          'New message',
        ),
      ).rejects.toThrow('DISPUTE_RESOLVED');
    });

    it('should restrict messages to parties only', async () => {
      const otherUser = await prisma.user.create({
        data: {
          id: 'third-user-' + Date.now(),
          name: 'Third User',
          phone_number: '9876543213',
          email: 'third@test.com',
          role: 'customer',
        },
      });

      await expect(
        disputeService.addDisputeMessage(
          disputeId,
          otherUser.id,
          'Unauthorized message',
        ),
      ).rejects.toThrow('UNAUTHORIZED');
    });
  });

  describe('getDisputeWithMessages', () => {
    it('should retrieve dispute with parsed messages', async () => {
      const created = await disputeService.raiseDispute(
        taskId,
        customerId,
        'quality',
        'Initial message',
        [],
      );

      const dispute = await disputeService.getDisputeWithMessages(created.id);

      expect(dispute).toBeDefined();
      expect(dispute.messages).toBeDefined();
      expect(dispute.messages.length).toBeGreaterThan(0);
      expect(dispute.messages[0].text).toBe('Initial message');
    });
  });

  describe('getDisputesByStatus', () => {
    it('should return disputes by status', async () => {
      const dispute1 = await disputeService.raiseDispute(
        taskId,
        customerId,
        'quality',
        'First dispute',
        [],
      );

      // Create another completed task for second dispute
      const task2 = await prisma.task.create({
        data: {
          task_id_display: 'T-2-' + Date.now(),
          customer_id: customerId,
          helper_id: helperId,
          task_type: 'household',
          category: 'cleaning',
          title: 'Second Task',
          description: 'Another task',
          location_point: {
            type: 'Point',
            coordinates: [78.1198, 17.3850],
          },
          budget: 600,
          status: 'completed',
          final_amount: 600,
        },
      });

      await prisma.payment.create({
        data: {
          task_id: task2.id,
          customer_id: customerId,
          final_amount: 600,
          task_amount: 600,
          platform_fee_amount: 90,
          helper_payout_amount: 510,
          payment_method: 'card',
          status: 'completed',
          completed_at: new Date(),
        },
      });

      const dispute2 = await disputeService.raiseDispute(
        task2.id,
        helperId,
        'pricing',
        'Second dispute',
        [],
      );

      const openDisputes = await disputeService.getDisputesByStatus('open', undefined, 10, 0);
      expect(openDisputes.length).toBeGreaterThanOrEqual(2);
      expect(openDisputes.some(d => d.id === dispute1.id)).toBe(true);
      expect(openDisputes.some(d => d.id === dispute2.id)).toBe(true);
    });
  });

  describe('assignDisputeToAdmin', () => {
    it('should assign dispute to admin and change status', async () => {
      const adminUser = await prisma.user.create({
        data: {
          id: 'admin-user-' + Date.now(),
          name: 'Admin User',
          phone_number: '9876543214',
          email: 'admin@test.com',
          role: 'admin',
        },
      });

      const dispute = await disputeService.raiseDispute(
        taskId,
        customerId,
        'quality',
        'Test dispute',
        [],
      );

      const result = await disputeService.assignDisputeToAdmin(
        dispute.id,
        adminUser.id,
      );

      expect(result.assigned_to_admin).toBe(adminUser.id);
      expect(result.status).toBe('investigating');
    });
  });

  describe('countDisputeLosses', () => {
    it('should count customer_win disputes for helper', async () => {
      const dispute = await disputeService.raiseDispute(
        taskId,
        customerId,
        'quality',
        'Test dispute',
        [],
      );

      // Resolve as customer_win
      await prisma.dispute.update({
        where: { id: dispute.id },
        data: {
          status: 'resolved',
          resolution_type: 'customer_win',
        },
      });

      const losses = await disputeService.countDisputeLosses(helperId);
      expect(losses).toBe(1);
    });
  });
});
