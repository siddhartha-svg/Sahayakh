import request from 'supertest';
import app from '../src/index';
import prisma from '../src/config/prisma';
import * as jwtUtils from '../src/utils/jwt';

describe('Task APIs', () => {
  let customerToken: string;
  let customerId: string;
  let helperToken: string;
  let helperId: string;
  let taskId: string;

  beforeAll(async () => {
    const customer = await prisma.user.create({
      data: {
        phone_number: '+919999999999',
        name: 'Test Customer',
        role: 'customer',
        status: 'active',
      },
    });
    customerId = customer.id;
    customerToken = jwtUtils.signAccessToken(customerId, 'customer');

    const helperUser = await prisma.user.create({
      data: {
        phone_number: '+918888888888',
        name: 'Test Helper',
        role: 'helper',
        status: 'active',
        location_point: JSON.stringify({ latitude: 17.36, longitude: 78.48 }),
      },
    });
    helperId = helperUser.id;
    helperToken = jwtUtils.signAccessToken(helperId, 'helper');

    await prisma.helper.create({
      data: {
        user_id: helperId,
        rating: 4.8,
        total_tasks: 150,
        average_response_time_minutes: 5,
        helper_status: 'online',
        verification_status: 'verified',
        background_check_status: 'cleared',
        accepts_personal_tasks: true,
        accepts_business_tasks: false,
        preferred_categories: [],
        service_radius_km: 25,
        online_since: new Date(),
      },
    });

    await prisma.pricingConfig.upsert({
      where: { config_key: 'current' },
      update: {},
      create: {
        config_key: 'current',
        base_fare_rupees: 40,
        per_km_rate: 15,
        per_minute_rate: 2.5,
        minimum_fare_rupees: 80,
        cancellation_fee_rupees: 30,
        platform_fee_percent: 15,
        business_task_multiplier: 1.25,
        peak_hour_multiplier: 1.1,
        daily_bonus_tasks_required: 5,
        daily_bonus_amount: 100,
      },
    });
  });

  afterEach(async () => {
    await prisma.notification.deleteMany({});
    await prisma.taskStatusHistory.deleteMany({});
    await prisma.task.deleteMany({});
  });

  afterAll(async () => {
    await prisma.helper.deleteMany({});
    await prisma.user.deleteMany({});
    await prisma.pricingConfig.deleteMany({});
  });

  describe('POST /api/tasks', () => {
    it('should create task with valid input', async () => {
      const res = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          task_type: 'personal',
          category: 'pickup_delivery',
          description: 'Pick up medicine from Apollo Pharmacy',
          location_name: 'Apollo Pharmacy, Hanamkonda',
          location_point: { latitude: 17.36, longitude: 78.48 },
          preferred_date: '2026-09-25',
          preferred_time: '14:30',
          budget_min: 150,
          budget_max: 300,
        });

      expect(res.status).toBe(201);
      expect(res.body.task).toBeDefined();
      expect(res.body.task.task_id_display).toMatch(/^SKT\d+$/);
      expect(res.body.task.status).toBe('unassigned');
      expect(res.body.estimated_price_range).toBeDefined();
      expect(res.body.estimated_price_range.min).toBeGreaterThan(0);

      taskId = res.body.task.id;
    });

    it('should reject invalid budget', async () => {
      const res = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          task_type: 'personal',
          category: 'pickup_delivery',
          description: 'Pick up medicine from Apollo Pharmacy',
          location_name: 'Apollo Pharmacy',
          location_point: { latitude: 17.36, longitude: 78.48 },
          preferred_date: '2026-09-25',
          preferred_time: '14:30',
          budget_min: 10,
          budget_max: 20,
        });

      expect(res.status).toBe(400);
      expect(res.body.error_code).toBe('BUDGET_TOO_LOW');
    });

    it('should reject invalid location', async () => {
      const res = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          task_type: 'personal',
          category: 'pickup_delivery',
          description: 'Pick up medicine',
          location_name: 'Far away location',
          location_point: { latitude: 0, longitude: 0 },
          preferred_date: '2026-09-25',
          preferred_time: '14:30',
          budget_min: 150,
          budget_max: 300,
        });

      expect(res.status).toBe(400);
      expect(res.body.error_code).toBe('INVALID_LOCATION');
    });

    it('should require business_name for business tasks', async () => {
      const res = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          task_type: 'business',
          category: 'vendor_pickup',
          description: 'Pick up vendor materials',
          location_name: 'Hanamkonda',
          location_point: { latitude: 17.36, longitude: 78.48 },
          preferred_date: '2026-09-25',
          preferred_time: '14:30',
          budget_min: 200,
          budget_max: 400,
        });

      expect(res.status).toBe(400);
      expect(res.body.error_code).toBe('MISSING_BUSINESS_NAME');
    });

    it('should reject past date', async () => {
      const res = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          task_type: 'personal',
          category: 'pickup_delivery',
          description: 'Pick up medicine',
          location_name: 'Hanamkonda',
          location_point: { latitude: 17.36, longitude: 78.48 },
          preferred_date: '2026-09-20',
          preferred_time: '14:30',
          budget_min: 150,
          budget_max: 300,
        });

      expect(res.status).toBe(400);
      expect(res.body.error_code).toBe('DATE_INVALID');
    });

    it('should reject invalid time format', async () => {
      const res = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          task_type: 'personal',
          category: 'pickup_delivery',
          description: 'Pick up medicine',
          location_name: 'Hanamkonda',
          location_point: { latitude: 17.36, longitude: 78.48 },
          preferred_date: '2026-09-25',
          preferred_time: '25:00',
          budget_min: 150,
          budget_max: 300,
        });

      expect(res.status).toBe(400);
      expect(res.body.error_code).toBe('TIME_INVALID');
    });

    it('should require authentication', async () => {
      const res = await request(app).post('/api/tasks').send({
        task_type: 'personal',
        category: 'pickup_delivery',
        description: 'Pick up medicine',
        location_name: 'Hanamkonda',
        location_point: { latitude: 17.36, longitude: 78.48 },
        preferred_date: '2026-09-25',
        preferred_time: '14:30',
        budget_min: 150,
        budget_max: 300,
      });

      expect(res.status).toBe(401);
    });
  });

  describe('GET /api/tasks/:task_id/helpers/nearby', () => {
    beforeEach(async () => {
      const taskRes = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          task_type: 'personal',
          category: 'pickup_delivery',
          description: 'Pick up medicine from Apollo Pharmacy',
          location_name: 'Apollo Pharmacy, Hanamkonda',
          location_point: { latitude: 17.36, longitude: 78.48 },
          preferred_date: '2026-09-25',
          preferred_time: '14:30',
          budget_min: 150,
          budget_max: 300,
        });

      taskId = taskRes.body.task.id;
    });

    it('should return nearby verified helpers', async () => {
      const res = await request(app)
        .get(`/api/tasks/${taskId}/helpers/nearby`)
        .set('Authorization', `Bearer ${customerToken}`);

      expect(res.status).toBe(200);
      expect(res.body.helpers).toBeDefined();
      expect(Array.isArray(res.body.helpers)).toBe(true);
      expect(res.body.count).toBeGreaterThan(0);
      expect(res.body.sort_by).toBe('nearest');
      expect(res.body.task_id).toBe(taskId);
    });

    it('should filter by task type', async () => {
      const businessTask = await prisma.task.create({
        data: {
          task_id_display: 'SKT99999',
          customer_id: customerId,
          task_type: 'business',
          category: 'vendor_pickup',
          description: 'Business task',
          location_name: 'Hanamkonda',
          location_point: JSON.stringify({ latitude: 17.36, longitude: 78.48 }),
          preferred_date: '2026-09-25',
          preferred_time: '14:30',
          budget_min: 200,
          budget_max: 400,
          business_name: 'Test Business',
          status: 'unassigned',
        },
      });

      const res = await request(app)
        .get(`/api/tasks/${businessTask.id}/helpers/nearby`)
        .set('Authorization', `Bearer ${customerToken}`);

      expect(res.status).toBe(200);
      expect(res.body.helpers.length).toBe(0);
    });

    it('should sort by rating', async () => {
      const res = await request(app)
        .get(`/api/tasks/${taskId}/helpers/nearby?sort_by=rating`)
        .set('Authorization', `Bearer ${customerToken}`);

      expect(res.status).toBe(200);
      expect(res.body.sort_by).toBe('rating');
    });

    it('should sort by price', async () => {
      const res = await request(app)
        .get(`/api/tasks/${taskId}/helpers/nearby?sort_by=price`)
        .set('Authorization', `Bearer ${customerToken}`);

      expect(res.status).toBe(200);
      expect(res.body.sort_by).toBe('price');
    });

    it('should reject invalid radius', async () => {
      const res = await request(app)
        .get(`/api/tasks/${taskId}/helpers/nearby?radius_km=100`)
        .set('Authorization', `Bearer ${customerToken}`);

      expect(res.status).toBe(400);
      expect(res.body.error_code).toBe('INVALID_RADIUS');
    });

    it('should reject invalid sort', async () => {
      const res = await request(app)
        .get(`/api/tasks/${taskId}/helpers/nearby?sort_by=invalid`)
        .set('Authorization', `Bearer ${customerToken}`);

      expect(res.status).toBe(400);
      expect(res.body.error_code).toBe('INVALID_SORT');
    });

    it('should require authentication', async () => {
      const res = await request(app).get(`/api/tasks/${taskId}/helpers/nearby`);

      expect(res.status).toBe(401);
    });
  });

  describe('POST /api/tasks/:task_id/assign', () => {
    beforeEach(async () => {
      const taskRes = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          task_type: 'personal',
          category: 'pickup_delivery',
          description: 'Pick up medicine',
          location_name: 'Apollo Pharmacy, Hanamkonda',
          location_point: { latitude: 17.36, longitude: 78.48 },
          preferred_date: '2026-09-25',
          preferred_time: '14:30',
          budget_min: 150,
          budget_max: 300,
        });

      taskId = taskRes.body.task.id;
    });

    it('should assign helper to task', async () => {
      const res = await request(app)
        .post(`/api/tasks/${taskId}/assign`)
        .set('Authorization', `Bearer ${customerToken}`)
        .send({ helper_id: helperId });

      expect(res.status).toBe(200);
      expect(res.body.task.helper_id).toBe(helperId);
      expect(res.body.task.status).toBe('assigned');
    });

    it('should create notification for helper', async () => {
      await request(app)
        .post(`/api/tasks/${taskId}/assign`)
        .set('Authorization', `Bearer ${customerToken}`)
        .send({ helper_id: helperId });

      const notification = await prisma.notification.findFirst({
        where: {
          user_id: helperId,
          notification_type: 'task_assigned',
        },
      });

      expect(notification).toBeDefined();
      expect(notification?.related_task_id).toBe(taskId);
    });

    it('should reject assignment to already-assigned task', async () => {
      await request(app)
        .post(`/api/tasks/${taskId}/assign`)
        .set('Authorization', `Bearer ${customerToken}`)
        .send({ helper_id: helperId });

      const res = await request(app)
        .post(`/api/tasks/${taskId}/assign`)
        .set('Authorization', `Bearer ${customerToken}`)
        .send({ helper_id: helperId });

      expect(res.status).toBe(400);
      expect(res.body.error_code).toBe('TASK_ALREADY_ASSIGNED');
    });

    it('should only allow task owner to assign', async () => {
      const otherCustomer = await prisma.user.create({
        data: {
          phone_number: '+917777777777',
          name: 'Other Customer',
          role: 'customer',
          status: 'active',
        },
      });

      const otherToken = jwtUtils.signAccessToken(otherCustomer.id, 'customer');

      const res = await request(app)
        .post(`/api/tasks/${taskId}/assign`)
        .set('Authorization', `Bearer ${otherToken}`)
        .send({ helper_id: helperId });

      expect(res.status).toBe(403);
      expect(res.body.error_code).toBe('UNAUTHORIZED');

      await prisma.user.delete({ where: { id: otherCustomer.id } });
    });

    it('should require authentication', async () => {
      const res = await request(app)
        .post(`/api/tasks/${taskId}/assign`)
        .send({ helper_id: helperId });

      expect(res.status).toBe(401);
    });
  });
});
