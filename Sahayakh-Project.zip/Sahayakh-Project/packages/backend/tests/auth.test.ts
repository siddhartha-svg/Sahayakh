import request from 'supertest';
import { initializeDatabase, getPool, closeDatabase } from '../src/config/database';
import { initializeRedis, getRedis, closeRedis } from '../src/config/redis';
import app from '../src/index';
import * as authService from '../src/services/auth';

describe('Auth Routes', () => {
  let pool: ReturnType<typeof getPool>;
  let redis: ReturnType<typeof getRedis>;

  beforeAll(async () => {
    try {
      await initializeDatabase();
      await initializeRedis();
      pool = getPool();
      redis = getRedis();

      await pool.query('DROP TABLE IF EXISTS users CASCADE');
      await pool.query(`
        CREATE TABLE users (
          id UUID PRIMARY KEY,
          phone_number VARCHAR(20) UNIQUE,
          name VARCHAR(255) NOT NULL,
          email VARCHAR(255) UNIQUE,
          role VARCHAR(20) NOT NULL DEFAULT 'customer',
          status VARCHAR(20) NOT NULL DEFAULT 'active',
          location_name VARCHAR(255),
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          deleted_at TIMESTAMP WITH TIME ZONE
        )
      `);
    } catch (err) {
      console.error('Setup error:', err);
      throw err;
    }
  });

  afterAll(async () => {
    await pool.query('DROP TABLE IF EXISTS users CASCADE');
    await closeDatabase();
    await closeRedis();
  });

  afterEach(async () => {
    await redis.flushdb();
    await pool.query('DELETE FROM users');
  });

  describe('POST /api/auth/register', () => {
    it('should register a customer with phone number', async () => {
      const response = await request(app)
        .post('/api/auth/register')
        .send({
          phone_number: '+919876543210',
          name: 'Test User',
          role: 'customer',
        })
        .expect(200);

      expect(response.body.otp_sent).toBe(true);
      expect(response.body.expires_in).toBe(120);
      expect(response.body.otp).toMatch(/^\d{6}$/);
    });

    it('should reject duplicate phone number', async () => {
      await request(app)
        .post('/api/auth/register')
        .send({
          phone_number: '+919876543210',
          name: 'Test User',
          role: 'customer',
        })
        .expect(200);

      const response = await request(app)
        .post('/api/auth/register')
        .send({
          phone_number: '+919876543210',
          name: 'Another User',
          role: 'helper',
        })
        .expect(409);

      expect(response.body.error_code).toBe('PHONE_ALREADY_EXISTS');
    });

    it('should reject invalid phone number format', async () => {
      const response = await request(app)
        .post('/api/auth/register')
        .send({
          phone_number: 'invalid',
          name: 'Test User',
          role: 'customer',
        })
        .expect(400);

      expect(response.body.error_code).toBe('INVALID_PHONE_NUMBER');
    });

    it('should reject invalid role', async () => {
      const response = await request(app)
        .post('/api/auth/register')
        .send({
          phone_number: '+919876543210',
          name: 'Test User',
          role: 'invalid_role',
        })
        .expect(400);

      expect(response.body.error_code).toBe('INVALID_ROLE');
    });

    it('should enforce rate limit on OTP requests', async () => {
      for (let i = 0; i < 10; i++) {
        await request(app)
          .post('/api/auth/register')
          .send({
            phone_number: `+91987654321${i}`,
            name: 'Test User',
            role: 'customer',
          })
          .expect(200);
      }

      const response = await request(app)
        .post('/api/auth/register')
        .send({
          phone_number: '+919876543210',
          name: 'Test User',
          role: 'customer',
        })
        .expect(429);

      expect(response.body.error_code).toBe('RATE_LIMIT_EXCEEDED');
    });
  });

  describe('POST /api/auth/verify-otp', () => {
    it('should verify correct OTP and return tokens', async () => {
      const registerRes = await request(app)
        .post('/api/auth/register')
        .send({
          phone_number: '+919876543210',
          name: 'Test User',
          role: 'customer',
        })
        .expect(200);

      const otp = registerRes.body.otp;

      const verifyRes = await request(app)
        .post('/api/auth/verify-otp')
        .send({
          phone_number: '+919876543210',
          otp_code: otp,
        })
        .expect(200);

      expect(verifyRes.body.access_token).toBeDefined();
      expect(verifyRes.body.refresh_token).toBeDefined();
      expect(verifyRes.body.user_id).toBeDefined();
      expect(verifyRes.body.role).toBe('customer');
    });

    it('should reject invalid OTP', async () => {
      await request(app)
        .post('/api/auth/register')
        .send({
          phone_number: '+919876543210',
          name: 'Test User',
          role: 'customer',
        })
        .expect(200);

      const response = await request(app)
        .post('/api/auth/verify-otp')
        .send({
          phone_number: '+919876543210',
          otp_code: '000000',
        })
        .expect(400);

      expect(response.body.error_code).toBe('INVALID_OTP');
    });

    it('should reject expired OTP', async () => {
      await request(app)
        .post('/api/auth/register')
        .send({
          phone_number: '+919876543210',
          name: 'Test User',
          role: 'customer',
        })
        .expect(200);

      await redis.del('sahayakh:otp:+919876543210');

      const response = await request(app)
        .post('/api/auth/verify-otp')
        .send({
          phone_number: '+919876543210',
          otp_code: '123456',
        })
        .expect(400);

      expect(response.body.error_code).toBe('OTP_NOT_FOUND');
    });

    it('should enforce max attempts', async () => {
      await request(app)
        .post('/api/auth/register')
        .send({
          phone_number: '+919876543210',
          name: 'Test User',
          role: 'customer',
        })
        .expect(200);

      for (let i = 0; i < 3; i++) {
        await request(app)
          .post('/api/auth/verify-otp')
          .send({
            phone_number: '+919876543210',
            otp_code: '000000',
          })
          .expect(400);
      }

      const response = await request(app)
        .post('/api/auth/verify-otp')
        .send({
          phone_number: '+919876543210',
          otp_code: '000000',
        })
        .expect(429);

      expect(response.body.error_code).toBe('TOO_MANY_ATTEMPTS');
    });
  });

  describe('POST /api/auth/refresh', () => {
    it('should refresh access token with valid refresh token', async () => {
      const registerRes = await request(app)
        .post('/api/auth/register')
        .send({
          phone_number: '+919876543210',
          name: 'Test User',
          role: 'customer',
        })
        .expect(200);

      const otp = registerRes.body.otp;

      const verifyRes = await request(app)
        .post('/api/auth/verify-otp')
        .send({
          phone_number: '+919876543210',
          otp_code: otp,
        })
        .expect(200);

      const refreshRes = await request(app)
        .post('/api/auth/refresh')
        .send({
          refresh_token: verifyRes.body.refresh_token,
        })
        .expect(200);

      expect(refreshRes.body.access_token).toBeDefined();
      expect(refreshRes.body.access_token).not.toBe(verifyRes.body.access_token);
    });

    it('should reject invalid refresh token', async () => {
      const response = await request(app)
        .post('/api/auth/refresh')
        .send({
          refresh_token: 'invalid-token',
        })
        .expect(401);

      expect(response.body.error_code).toBe('INVALID_REFRESH_TOKEN');
    });
  });

  describe('GET /api/auth/me', () => {
    it('should return current user when authenticated', async () => {
      const registerRes = await request(app)
        .post('/api/auth/register')
        .send({
          phone_number: '+919876543210',
          name: 'Test User',
          role: 'customer',
        })
        .expect(200);

      const otp = registerRes.body.otp;

      const verifyRes = await request(app)
        .post('/api/auth/verify-otp')
        .send({
          phone_number: '+919876543210',
          otp_code: otp,
        })
        .expect(200);

      const response = await request(app)
        .get('/api/auth/me')
        .set('Authorization', `Bearer ${verifyRes.body.access_token}`)
        .expect(200);

      expect(response.body.id).toBe(verifyRes.body.user_id);
      expect(response.body.name).toBe('Test User');
      expect(response.body.phone_number).toBe('+919876543210');
      expect(response.body.role).toBe('customer');
    });

    it('should reject request without token', async () => {
      const response = await request(app)
        .get('/api/auth/me')
        .expect(401);

      expect(response.body.error_code).toBe('UNAUTHORIZED');
    });

    it('should reject invalid token', async () => {
      const response = await request(app)
        .get('/api/auth/me')
        .set('Authorization', 'Bearer invalid-token')
        .expect(401);

      expect(response.body.error_code).toBe('INVALID_TOKEN');
    });
  });

  describe('GET /health', () => {
    it('should return health status', async () => {
      const response = await request(app)
        .get('/health')
        .expect(200);

      expect(response.body.status).toBe('ok');
      expect(response.body.timestamp).toBeDefined();
    });
  });
});
