import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import prisma from '../src/config/prisma';
import * as taskManagement from '../src/services/task-management';

describe('Task Management Service', () => {
  let customerId: string;
  let helperId1: string;
  let helperId2: string;
  let adminId: string;
  let taskId: string;

  beforeEach(async () => {
    // Create users
    const customer = await prisma.user.create({
      data: {
        id: 'customer-' + Date.now(),
        name: 'Test Customer',
        phone_number: '9876543210',
        email: 'customer@test.com',
        role: 'customer',
      },
    });
    customerId = customer.id;

    const helperUser1 = await prisma.user.create({
      data: {
        id: 'helper-1-' + Date.now(),
        name: 'Helper One',
        phone_number: '9876543211',
        email: 'helper1@test.com',
        role: 'helper',
      },
    });

    const helper1 = await prisma.helper.create({
      data: {
        user_id: helperUser1.id,
        helper_status: 'available',
        verification_status: 'verified',
        background_check_status: 'cleared',
      },
    });
    helperId1 = helper1.id;

    const helperUser2 = await prisma.user.create({
      data: {
        id: 'helper-2-' + Date.now(),
        name: 'Helper Two',
        phone_number: '9876543212',
        email: 'helper2@test.com',
        role: 'helper',
      },
    });

    const helper2 = await prisma.helper.create({
      data: {
        user_id: helperUser2.id,
        helper_status: 'available',
        verification_status: 'verified',
        background_check_status: 'cleared',
      },
    });
    helperId2 = helper2.id;

    // Create admin
    const admin = await prisma.user.create({
      data: {
        id: 'admin-' + Date.now(),
        name: 'Test Admin',
        phone_number: '9876543213',
        email: 'admin@test.com',
        role: 'admin',
      },
    });
    adminId = admin.id;

    // Create task
    const task = await prisma.task.create({
      data: {
        task_id_display: 'T-' + Date.now(),
        customer_id: customerId,
        helper_id: helperId1,
        task_type: 'household',
        category: 'cleaning',
        title: 'House Cleaning',
        description: 'Clean the house',
        location_point: {
          type: 'Point',
          coordinates: [78.1198, 17.3850],
        },
        budget: 500,
        status: 'assigned',
        final_amount: 500,
      },
    });
    taskId = task.id;

    // Create payment
    await prisma.payment.create({
      data: {
        task_id: taskId,
        customer_id: customerId,
        final_amount: 500,
        task_amount: 500,
        platform_fee_amount: 75,
        helper_payout_amount: 425,
        payment_method: 'card',
        status: 'completed',
        completed_at: new Date(),
      },
    });
  });

  afterEach(async () => {
    // Cleanup
    await prisma.taskStatusHistory.deleteMany({});
    await prisma.payment.deleteMany({});
    await prisma.auditLog.deleteMany({});
    await prisma.task.deleteMany({});
    await prisma.helper.deleteMany({});
    await prisma.user.deleteMany({});
  });

  describe('reassignTask', () => {
    it('should reassign task to new helper', async () => {
      const result = await taskManagement.reassignTask(
        taskId,
        helperId2,
        adminId,
        'Helper unavailable',
      );

      expect(result.old_helper_id).toBe(helperId1);
      expect(result.new_helper_id).toBe(helperId2);

      // Verify in database
      const task = await prisma.task.findUnique({
        where: { id: taskId },
      });
      expect(task?.helper_id).toBe(helperId2);
    });

    it('should create status history entry', async () => {
      await taskManagement.reassignTask(
        taskId,
        helperId2,
        adminId,
        'Reassignment reason',
      );

      const history = await prisma.taskStatusHistory.findFirst({
        where: { task_id: taskId },
      });

      expect(history).toBeDefined();
      expect(history?.notes).toContain('Reassigned from');
    });

    it('should log to audit trail', async () => {
      await taskManagement.reassignTask(
        taskId,
        helperId2,
        adminId,
        'Helper sick',
      );

      const log = await prisma.auditLog.findFirst({
        where: {
          action: 'task_reassigned',
          resource_id: taskId,
        },
      });

      expect(log).toBeDefined();
      expect(log?.admin_id).toBe(adminId);
    });

    it('should prevent reassigning non-assigned tasks', async () => {
      // Set task to in_progress
      await prisma.task.update({
        where: { id: taskId },
        data: { status: 'in_progress' },
      });

      await expect(
        taskManagement.reassignTask(taskId, helperId2, adminId),
      ).rejects.toThrow('INVALID_STATUS');
    });
  });

  describe('cancelTask', () => {
    it('should cancel assigned task', async () => {
      const result = await taskManagement.cancelTask(
        taskId,
        adminId,
        'Customer request',
        false,
      );

      expect(result.status).toBe('cancelled');
      expect(result.reason).toBe('Customer request');

      // Verify in database
      const task = await prisma.task.findUnique({
        where: { id: taskId },
      });
      expect(task?.status).toBe('cancelled');
    });

    it('should issue refund if requested', async () => {
      const result = await taskManagement.cancelTask(
        taskId,
        adminId,
        'Service unavailable',
        true,
      );

      expect(result.refund_issued).toBe(true);
      expect(result.refund_amount).toBe(500);

      // Verify payment refunded
      const payment = await prisma.payment.findUnique({
        where: { task_id: taskId },
      });
      expect(payment?.status).toBe('refunded');
    });

    it('should log cancellation with reason', async () => {
      await taskManagement.cancelTask(
        taskId,
        adminId,
        'Technical issues',
        false,
      );

      const log = await prisma.auditLog.findFirst({
        where: {
          action: 'task_cancelled',
          resource_id: taskId,
        },
      });

      expect(log).toBeDefined();
      expect(log?.metadata).toHaveProperty('reason', 'Technical issues');
    });

    it('should prevent cancelling in_progress tasks', async () => {
      // Set task to in_progress
      await prisma.task.update({
        where: { id: taskId },
        data: { status: 'in_progress' },
      });

      await expect(
        taskManagement.cancelTask(taskId, adminId, 'Some reason'),
      ).rejects.toThrow('INVALID_STATUS');
    });
  });

  describe('getTaskDetails', () => {
    it('should return comprehensive task details', async () => {
      const details = await taskManagement.getTaskDetails(taskId);

      expect(details).toBeDefined();
      expect(details.task_id_display).toBe(details.task_id_display);
      expect(details.customer).toBeDefined();
      expect(details.helper).toBeDefined();
      expect(details.payment).toBeDefined();
    });

    it('should include status history', async () => {
      // Create another status change
      await prisma.task.update({
        where: { id: taskId },
        data: { status: 'on_the_way' },
      });

      await prisma.taskStatusHistory.create({
        data: {
          task_id: taskId,
          status: 'on_the_way',
          notes: 'Helper on the way',
        },
      });

      const details = await taskManagement.getTaskDetails(taskId);
      expect(details.status_history.length).toBeGreaterThan(0);
    });
  });

  describe('listTasksForReassignment', () => {
    it('should list assigned and on_the_way tasks', async () => {
      const tasks = await taskManagement.listTasksForReassignment(10, 0);

      expect(tasks.length).toBeGreaterThan(0);
      expect(tasks.some((t) => t.task_id === taskId)).toBe(true);
    });

    it('should exclude completed tasks', async () => {
      // Complete the task
      await prisma.task.update({
        where: { id: taskId },
        data: { status: 'completed' },
      });

      const tasks = await taskManagement.listTasksForReassignment(10, 0);
      expect(tasks.some((t) => t.task_id === taskId)).toBe(false);
    });
  });

  describe('listTasksForCancellation', () => {
    it('should list cancellable tasks', async () => {
      const tasks = await taskManagement.listTasksForCancellation(10, 0);

      expect(tasks.length).toBeGreaterThan(0);
      expect(tasks.some((t) => t.task_id === taskId)).toBe(true);
    });

    it('should exclude already cancelled tasks', async () => {
      await prisma.task.update({
        where: { id: taskId },
        data: { status: 'cancelled' },
      });

      const tasks = await taskManagement.listTasksForCancellation(10, 0);
      expect(tasks.some((t) => t.task_id === taskId)).toBe(false);
    });
  });

  describe('Task management workflow', () => {
    it('should handle complete reassignment workflow', async () => {
      // Get reassignment queue
      const queue = await taskManagement.listTasksForReassignment(10, 0);
      expect(queue.length).toBeGreaterThan(0);

      // Reassign task
      const result = await taskManagement.reassignTask(
        taskId,
        helperId2,
        adminId,
        'Original helper unavailable',
      );

      expect(result.new_helper_id).toBe(helperId2);

      // Verify reassignment in details
      const details = await taskManagement.getTaskDetails(taskId);
      expect(details.helper.id).toBe(helperId2);
    });

    it('should handle complete cancellation workflow', async () => {
      // Get cancellation queue
      const queue = await taskManagement.listTasksForCancellation(10, 0);
      expect(queue.length).toBeGreaterThan(0);

      // Cancel with refund
      const result = await taskManagement.cancelTask(
        taskId,
        adminId,
        'Service unavailable',
        true,
      );

      expect(result.status).toBe('cancelled');
      expect(result.refund_issued).toBe(true);

      // Verify cancellation
      const details = await taskManagement.getTaskDetails(taskId);
      expect(details.status).toBe('cancelled');
    });
  });
});
