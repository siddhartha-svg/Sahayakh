import request from 'supertest';
import app from '../src/index';
import prisma from '../src/config/prisma';
import * as jwtUtils from '../src/utils/jwt';

describe('Helper Request Flow (45-Second Countdown)', () => {
  let customerToken: string;
  let customerId: string;
  let helperToken: string;
  let helperId: string;
  let taskId: string;
  let requestId: string;

  beforeAll(async () => {
    const customer = await prisma.user.create({
      data: {
        phone_number: '+919999999999',
        name: 'Test Customer',
        role: 'customer',
        status: 'active',
      },
    });
    customerId = customer.id;
    customerToken = jwtUtils.signAccessToken(customerId, 'customer');

    const helperUser = await prisma.user.create({
      data: {
        phone_number: '+918888888888',
        name: 'Test Helper',
        role: 'helper',
        status: 'active',
        location_point: JSON.stringify({ latitude: 17.36, longitude: 78.48 }),
      },
    });
    helperId = helperUser.id;
    helperToken = jwtUtils.signAccessToken(helperId, 'helper');

    await prisma.helper.create({
      data: {
        user_id: helperId,
        rating: 4.8,
        total_tasks: 150,
        average_response_time_minutes: 5,
        helper_status: 'online',
        verification_status: 'verified',
        background_check_status: 'cleared',
        accepts_personal_tasks: true,
        accepts_business_tasks: false,
        preferred_categories: [],
        service_radius_km: 25,
        online_since: new Date(),
      },
    });

    await prisma.pricingConfig.upsert({
      where: { config_key: 'current' },
      update: {},
      create: {
        config_key: 'current',
        base_fare_rupees: 40,
        per_km_rate: 15,
        per_minute_rate: 2.5,
        minimum_fare_rupees: 80,
        cancellation_fee_rupees: 30,
        platform_fee_percent: 15,
        business_task_multiplier: 1.25,
        peak_hour_multiplier: 1.1,
        daily_bonus_tasks_required: 5,
        daily_bonus_amount: 100,
      },
    });
  });

  afterEach(async () => {
    await prisma.taskRequest.deleteMany({});
    await prisma.notification.deleteMany({});
    await prisma.taskStatusHistory.deleteMany({});
    await prisma.task.deleteMany({});
  });

  afterAll(async () => {
    await prisma.helper.deleteMany({});
    await prisma.user.deleteMany({});
    await prisma.pricingConfig.deleteMany({});
  });

  describe('Task Request Creation', () => {
    it('should create task request when customer assigns helper', async () => {
      // Create task
      const taskRes = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          task_type: 'personal',
          category: 'pickup_delivery',
          description: 'Pick up medicine from Apollo Pharmacy',
          location_name: 'Apollo Pharmacy, Hanamkonda',
          location_point: { latitude: 17.36, longitude: 78.48 },
          preferred_date: '2026-09-25',
          preferred_time: '14:30',
          budget_min: 150,
          budget_max: 300,
        });

      taskId = taskRes.body.task.id;
      expect(taskRes.status).toBe(201);

      // Assign helper (creates request)
      const assignRes = await request(app)
        .post(`/api/tasks/${taskId}/assign`)
        .set('Authorization', `Bearer ${customerToken}`)
        .send({ helper_id: helperId });

      expect(assignRes.status).toBe(200);
      expect(assignRes.body.task.status).toBe('assigned');

      // Verify request created in DB
      const taskRequest = await prisma.taskRequest.findFirst({
        where: { task_id: taskId, helper_id: helperId },
      });

      expect(taskRequest).toBeDefined();
      expect(taskRequest?.status).toBe('pending');
      expect(taskRequest?.expires_at).toBeDefined();

      requestId = taskRequest!.id;
    });
  });

  describe('Accept Request', () => {
    beforeEach(async () => {
      // Create and assign task
      const taskRes = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          task_type: 'personal',
          category: 'pickup_delivery',
          description: 'Pick up medicine',
          location_name: 'Apollo Pharmacy, Hanamkonda',
          location_point: { latitude: 17.36, longitude: 78.48 },
          preferred_date: '2026-09-25',
          preferred_time: '14:30',
          budget_min: 150,
          budget_max: 300,
        });

      taskId = taskRes.body.task.id;

      await request(app)
        .post(`/api/tasks/${taskId}/assign`)
        .set('Authorization', `Bearer ${customerToken}`)
        .send({ helper_id: helperId });

      const taskRequest = await prisma.taskRequest.findFirst({
        where: { task_id: taskId, helper_id: helperId },
      });
      requestId = taskRequest!.id;
    });

    it('should accept request and update status to accepted', async () => {
      const res = await request(app)
        .post(`/api/requests/${requestId}/accept`)
        .set('Authorization', `Bearer ${helperToken}`);

      expect(res.status).toBe(200);
      expect(res.body.request.status).toBe('accepted');
      expect(res.body.request.accepted_at).toBeDefined();
      expect(res.body.message).toBe('Task request accepted successfully');

      // Verify in database
      const updated = await prisma.taskRequest.findUnique({
        where: { id: requestId },
      });
      expect(updated?.status).toBe('accepted');
      expect(updated?.accepted_at).toBeDefined();
    });

    it('should prevent other helpers from accepting request', async () => {
      const otherHelper = await prisma.user.create({
        data: {
          phone_number: '+917777777777',
          name: 'Other Helper',
          role: 'helper',
          status: 'active',
        },
      });

      const otherToken = jwtUtils.signAccessToken(otherHelper.id, 'helper');

      const res = await request(app)
        .post(`/api/requests/${requestId}/accept`)
        .set('Authorization', `Bearer ${otherToken}`);

      expect(res.status).toBe(403);
      expect(res.body.error_code).toBe('UNAUTHORIZED');

      await prisma.user.delete({ where: { id: otherHelper.id } });
    });

    it('should prevent accepting expired request', async () => {
      // Mark request as expired manually
      await prisma.taskRequest.update({
        where: { id: requestId },
        data: { expires_at: new Date(Date.now() - 1000) },
      });

      const res = await request(app)
        .post(`/api/requests/${requestId}/accept`)
        .set('Authorization', `Bearer ${helperToken}`);

      expect(res.status).toBe(410);
      expect(res.body.error_code).toBe('REQUEST_EXPIRED');
    });

    it('should prevent accepting already declined request', async () => {
      await request(app)
        .post(`/api/requests/${requestId}/decline`)
        .set('Authorization', `Bearer ${helperToken}`)
        .send({ reason: 'too_far' });

      const res = await request(app)
        .post(`/api/requests/${requestId}/accept`)
        .set('Authorization', `Bearer ${helperToken}`);

      expect(res.status).toBe(400);
      expect(res.body.error_code).toBe('REQUEST_NOT_PENDING');
    });

    it('should require authentication', async () => {
      const res = await request(app).post(`/api/requests/${requestId}/accept`);

      expect(res.status).toBe(401);
    });
  });

  describe('Decline Request', () => {
    beforeEach(async () => {
      const taskRes = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          task_type: 'personal',
          category: 'pickup_delivery',
          description: 'Pick up medicine',
          location_name: 'Apollo Pharmacy, Hanamkonda',
          location_point: { latitude: 17.36, longitude: 78.48 },
          preferred_date: '2026-09-25',
          preferred_time: '14:30',
          budget_min: 150,
          budget_max: 300,
        });

      taskId = taskRes.body.task.id;

      await request(app)
        .post(`/api/tasks/${taskId}/assign`)
        .set('Authorization', `Bearer ${customerToken}`)
        .send({ helper_id: helperId });

      const taskRequest = await prisma.taskRequest.findFirst({
        where: { task_id: taskId, helper_id: helperId },
      });
      requestId = taskRequest!.id;
    });

    it('should decline request with reason', async () => {
      const res = await request(app)
        .post(`/api/requests/${requestId}/decline`)
        .set('Authorization', `Bearer ${helperToken}`)
        .send({ reason: 'too_far' });

      expect(res.status).toBe(200);
      expect(res.body.request.status).toBe('declined');
      expect(res.body.request.decline_reason).toBe('too_far');
      expect(res.body.message).toBe('Task request declined');

      // Verify in database
      const updated = await prisma.taskRequest.findUnique({
        where: { id: requestId },
      });
      expect(updated?.status).toBe('declined');
      expect(updated?.decline_reason).toBe('too_far');

      // Verify task returned to unassigned
      const task = await prisma.task.findUnique({
        where: { id: taskId },
      });
      expect(task?.status).toBe('unassigned');
    });

    it('should decline request without reason', async () => {
      const res = await request(app)
        .post(`/api/requests/${requestId}/decline`)
        .set('Authorization', `Bearer ${helperToken}`)
        .send({});

      expect(res.status).toBe(200);
      expect(res.body.request.status).toBe('declined');
    });

    it('should prevent other helpers from declining request', async () => {
      const otherHelper = await prisma.user.create({
        data: {
          phone_number: '+917777777777',
          name: 'Other Helper',
          role: 'helper',
          status: 'active',
        },
      });

      const otherToken = jwtUtils.signAccessToken(otherHelper.id, 'helper');

      const res = await request(app)
        .post(`/api/requests/${requestId}/decline`)
        .set('Authorization', `Bearer ${otherToken}`)
        .send({ reason: 'busy' });

      expect(res.status).toBe(403);
      expect(res.body.error_code).toBe('UNAUTHORIZED');

      await prisma.user.delete({ where: { id: otherHelper.id } });
    });

    it('should require authentication', async () => {
      const res = await request(app)
        .post(`/api/requests/${requestId}/decline`)
        .send({ reason: 'busy' });

      expect(res.status).toBe(401);
    });
  });

  describe('Request Expiry', () => {
    beforeEach(async () => {
      const taskRes = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          task_type: 'personal',
          category: 'pickup_delivery',
          description: 'Pick up medicine',
          location_name: 'Apollo Pharmacy, Hanamkonda',
          location_point: { latitude: 17.36, longitude: 78.48 },
          preferred_date: '2026-09-25',
          preferred_time: '14:30',
          budget_min: 150,
          budget_max: 300,
        });

      taskId = taskRes.body.task.id;

      await request(app)
        .post(`/api/tasks/${taskId}/assign`)
        .set('Authorization', `Bearer ${customerToken}`)
        .send({ helper_id: helperId });

      const taskRequest = await prisma.taskRequest.findFirst({
        where: { task_id: taskId, helper_id: helperId },
      });
      requestId = taskRequest!.id;
    });

    it('should mark request as expired after 45 seconds (simulated)', async () => {
      // Simulate expiry by marking request as expired
      await prisma.taskRequest.update({
        where: { id: requestId },
        data: { status: 'expired' },
      });

      // Task should be returned to unassigned
      await prisma.task.update({
        where: { id: taskId },
        data: { status: 'unassigned' },
      });

      const expiredRequest = await prisma.taskRequest.findUnique({
        where: { id: requestId },
      });

      expect(expiredRequest?.status).toBe('expired');

      const task = await prisma.task.findUnique({
        where: { id: taskId },
      });

      expect(task?.status).toBe('unassigned');
    });
  });

  describe('Auto-Requeue Logic', () => {
    it('should find next available helper after decline', async () => {
      // Create second helper
      const helper2User = await prisma.user.create({
        data: {
          phone_number: '+916666666666',
          name: 'Second Helper',
          role: 'helper',
          status: 'active',
          location_point: JSON.stringify({ latitude: 17.36, longitude: 78.48 }),
        },
      });

      const helper2Id = helper2User.id;

      await prisma.helper.create({
        data: {
          user_id: helper2Id,
          rating: 4.5,
          total_tasks: 100,
          average_response_time_minutes: 8,
          helper_status: 'online',
          verification_status: 'verified',
          background_check_status: 'cleared',
          accepts_personal_tasks: true,
          accepts_business_tasks: false,
          preferred_categories: [],
          service_radius_km: 25,
          online_since: new Date(),
        },
      });

      // Create and assign task
      const taskRes = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${customerToken}`)
        .send({
          task_type: 'personal',
          category: 'pickup_delivery',
          description: 'Pick up medicine',
          location_name: 'Apollo Pharmacy, Hanamkonda',
          location_point: { latitude: 17.36, longitude: 78.48 },
          preferred_date: '2026-09-25',
          preferred_time: '14:30',
          budget_min: 150,
          budget_max: 300,
        });

      taskId = taskRes.body.task.id;

      await request(app)
        .post(`/api/tasks/${taskId}/assign`)
        .set('Authorization', `Bearer ${customerToken}`)
        .send({ helper_id: helperId });

      // Decline first request
      const request1 = await prisma.taskRequest.findFirst({
        where: { task_id: taskId, helper_id: helperId },
      });

      await request(app)
        .post(`/api/requests/${request1!.id}/decline`)
        .set('Authorization', `Bearer ${helperToken}`)
        .send({ reason: 'busy' });

      // Verify task is unassigned after decline
      const task = await prisma.task.findUnique({
        where: { id: taskId },
      });
      expect(task?.status).toBe('unassigned');

      // Clean up
      await prisma.helper.delete({ where: { id: helper2Id } });
      await prisma.user.delete({ where: { id: helper2User.id } });
    });
  });
});
