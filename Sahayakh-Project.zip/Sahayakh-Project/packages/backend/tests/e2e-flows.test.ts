import request from 'supertest';
import { initializeDatabase, getPool, closeDatabase } from '../src/config/database';
import { initializeRedis, getRedis, closeRedis } from '../src/config/redis';
import app from '../src/index';
import { v4 as uuidv4 } from 'uuid';

describe('E2E Critical Flows', () => {
  let pool: any;
  let redis: any;

  beforeAll(async () => {
    await initializeDatabase();
    await initializeRedis();
    pool = getPool();
    redis = getRedis();

    // Create schema
    await pool.query('DROP TABLE IF EXISTS payments CASCADE');
    await pool.query('DROP TABLE IF EXISTS payouts CASCADE');
    await pool.query('DROP TABLE IF EXISTS tasks CASCADE');
    await pool.query('DROP TABLE IF EXISTS task_requests CASCADE');
    await pool.query('DROP TABLE IF EXISTS helpers CASCADE');
    await pool.query('DROP TABLE IF EXISTS users CASCADE');

    await pool.query(`
      CREATE TABLE users (
        id UUID PRIMARY KEY,
        phone_number VARCHAR(20) UNIQUE,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE,
        role VARCHAR(20) NOT NULL DEFAULT 'customer',
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        location_point JSONB,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE helpers (
        id UUID PRIMARY KEY,
        user_id UUID NOT NULL REFERENCES users(id),
        helper_status VARCHAR(50) DEFAULT 'approved',
        rating NUMERIC(3,2) DEFAULT 5.0,
        total_tasks INT DEFAULT 0,
        service_radius_km INT DEFAULT 15,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE tasks (
        id UUID PRIMARY KEY,
        task_id_display VARCHAR(20) UNIQUE,
        customer_id UUID NOT NULL REFERENCES users(id),
        helper_id UUID REFERENCES helpers(id),
        task_type VARCHAR(20),
        category VARCHAR(100),
        description TEXT,
        location_point JSONB,
        location_name VARCHAR(255),
        status VARCHAR(50) DEFAULT 'unassigned',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE task_requests (
        id UUID PRIMARY KEY,
        task_id UUID NOT NULL REFERENCES tasks(id),
        helper_id UUID NOT NULL REFERENCES helpers(id),
        status VARCHAR(50) DEFAULT 'pending',
        expires_at TIMESTAMP WITH TIME ZONE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE payments (
        id UUID PRIMARY KEY,
        task_id UUID NOT NULL REFERENCES tasks(id),
        customer_id UUID NOT NULL REFERENCES users(id),
        helper_id UUID REFERENCES helpers(id),
        final_amount NUMERIC(10,2) NOT NULL,
        platform_fee_amount NUMERIC(10,2) NOT NULL,
        helper_payout_amount NUMERIC(10,2) NOT NULL,
        status VARCHAR(50) DEFAULT 'pending',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE payouts (
        id UUID PRIMARY KEY,
        helper_id UUID NOT NULL REFERENCES helpers(id),
        total_amount NUMERIC(10,2) NOT NULL,
        payment_method VARCHAR(50),
        status VARCHAR(50) DEFAULT 'pending',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);
  });

  afterAll(async () => {
    await pool.query('DROP TABLE IF EXISTS payments CASCADE');
    await pool.query('DROP TABLE IF EXISTS payouts CASCADE');
    await pool.query('DROP TABLE IF EXISTS task_requests CASCADE');
    await pool.query('DROP TABLE IF EXISTS tasks CASCADE');
    await pool.query('DROP TABLE IF EXISTS helpers CASCADE');
    await pool.query('DROP TABLE IF EXISTS users CASCADE');
    await closeDatabase();
    await closeRedis();
  });

  afterEach(async () => {
    await redis.flushdb();
    await pool.query('DELETE FROM payments');
    await pool.query('DELETE FROM payouts');
    await pool.query('DELETE FROM task_requests');
    await pool.query('DELETE FROM tasks');
    await pool.query('DELETE FROM helpers');
    await pool.query('DELETE FROM users');
  });

  describe('Customer Flow: Create Task → View Helpers → Select Helper → Complete → Rate', () => {
    it('should allow customer to create task and see available helpers', async () => {
      const customerId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      // 1. Customer registers
      const customerResult = await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
        [customerId, '+919999999999', 'Test Customer', 'customer', 'active', JSON.stringify(taskLocation)]
      );

      expect(customerResult.rows[0].role).toBe('customer');

      // 2. Customer creates task
      const taskId = uuidv4();
      const taskResult = await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *',
        [taskId, 'SKT00001', customerId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'unassigned']
      );

      expect(taskResult.rows[0].status).toBe('unassigned');
      expect(taskResult.rows[0].customer_id).toBe(customerId);

      // 3. Create multiple helpers
      const helperConfigs = [
        { rating: 4.9, distance: 2 },
        { rating: 4.7, distance: 5 },
        { rating: 4.5, distance: 3 }
      ];

      for (let i = 0; i < helperConfigs.length; i++) {
        const helperUserId = uuidv4();
        const helperId = uuidv4();
        const helperLat = taskLocation.latitude + (helperConfigs[i].distance / 111);

        await pool.query(
          'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
          [helperUserId, `+919999999${String(i).padStart(3, '0')}`, `Helper ${i}`, 'helper', 'active', JSON.stringify({ latitude: helperLat, longitude: taskLocation.longitude })]
        );

        await pool.query(
          'INSERT INTO helpers (id, user_id, helper_status, rating) VALUES ($1, $2, $3, $4)',
          [helperId, helperUserId, 'approved', helperConfigs[i].rating]
        );
      }

      // 4. Get available helpers
      const helpersResult = await pool.query(
        'SELECT * FROM helpers WHERE helper_status = $1 ORDER BY rating DESC LIMIT 10',
        ['approved']
      );

      expect(helpersResult.rows.length).toBe(3);
      // Should be sorted by rating descending
      expect(helpersResult.rows[0].rating).toBeGreaterThanOrEqual(helpersResult.rows[1].rating);
    });

    it('should handle helper request acceptance and task confirmation', async () => {
      const customerId = uuidv4();
      const helperUserId = uuidv4();
      const helperId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      // Setup
      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [customerId, '+919999999999', 'Test Customer', 'customer', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [helperUserId, '+919999999001', 'Test Helper', 'helper', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO helpers (id, user_id, helper_status) VALUES ($1, $2, $3)',
        [helperId, helperUserId, 'approved']
      );

      const taskId = uuidv4();
      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
        [taskId, 'SKT00001', customerId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'unassigned']
      );

      // 1. System sends request to helper
      const requestId = uuidv4();
      const requestResult = await pool.query(
        'INSERT INTO task_requests (id, task_id, helper_id, status, expires_at) VALUES ($1, $2, $3, $4, $5) RETURNING *',
        [requestId, taskId, helperId, 'pending', new Date(Date.now() + 45000)]
      );

      expect(requestResult.rows[0].status).toBe('pending');

      // 2. Helper accepts request
      const acceptResult = await pool.query(
        'UPDATE task_requests SET status = $1 WHERE id = $2 RETURNING *',
        ['accepted', requestId]
      );

      expect(acceptResult.rows[0].status).toBe('accepted');

      // 3. Task moves to confirmed
      const confirmResult = await pool.query(
        'UPDATE tasks SET status = $1, helper_id = $2 WHERE id = $3 RETURNING *',
        ['confirmed', helperId, taskId]
      );

      expect(confirmResult.rows[0].status).toBe('confirmed');
      expect(confirmResult.rows[0].helper_id).toBe(helperId);
    });

    it('should allow helper to decline and try another helper', async () => {
      const customerId = uuidv4();
      const helper1UserId = uuidv4();
      const helper1Id = uuidv4();
      const helper2UserId = uuidv4();
      const helper2Id = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      // Setup
      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [customerId, '+919999999999', 'Test Customer', 'customer', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [helper1UserId, '+919999999001', 'Helper 1', 'helper', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [helper2UserId, '+919999999002', 'Helper 2', 'helper', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO helpers (id, user_id, helper_status) VALUES ($1, $2, $3)',
        [helper1Id, helper1UserId, 'approved']
      );

      await pool.query(
        'INSERT INTO helpers (id, user_id, helper_status) VALUES ($1, $2, $3)',
        [helper2Id, helper2UserId, 'approved']
      );

      const taskId = uuidv4();
      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
        [taskId, 'SKT00001', customerId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'unassigned']
      );

      // 1. Send request to helper 1
      const request1Id = uuidv4();
      await pool.query(
        'INSERT INTO task_requests (id, task_id, helper_id, status, expires_at) VALUES ($1, $2, $3, $4, $5)',
        [request1Id, taskId, helper1Id, 'pending', new Date(Date.now() + 45000)]
      );

      // 2. Helper 1 declines
      await pool.query(
        'UPDATE task_requests SET status = $1 WHERE id = $2',
        ['declined', request1Id]
      );

      // 3. Send request to helper 2
      const request2Id = uuidv4();
      const request2Result = await pool.query(
        'INSERT INTO task_requests (id, task_id, helper_id, status, expires_at) VALUES ($1, $2, $3, $4, $5) RETURNING *',
        [request2Id, taskId, helper2Id, 'pending', new Date(Date.now() + 45000)]
      );

      expect(request2Result.rows[0].helper_id).toBe(helper2Id);

      // 4. Helper 2 accepts
      await pool.query(
        'UPDATE task_requests SET status = $1 WHERE id = $2',
        ['accepted', request2Id]
      );

      // 5. Task confirmed with helper 2
      const confirmResult = await pool.query(
        'UPDATE tasks SET status = $1, helper_id = $2 WHERE id = $3 RETURNING *',
        ['confirmed', helper2Id, taskId]
      );

      expect(confirmResult.rows[0].helper_id).toBe(helper2Id);
    });
  });

  describe('Helper Flow: Receive Request → Accept → Complete Task → Earn Payment → Withdraw', () => {
    it('should handle complete helper workflow from request to payout', async () => {
      const customerId = uuidv4();
      const helperUserId = uuidv4();
      const helperId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      // 1. Setup customer and helper
      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [customerId, '+919999999999', 'Test Customer', 'customer', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [helperUserId, '+919999999001', 'Test Helper', 'helper', 'active', JSON.stringify(taskLocation)]
      );

      const helperResult = await pool.query(
        'INSERT INTO helpers (id, user_id, helper_status) VALUES ($1, $2, $3) RETURNING *',
        [helperId, helperUserId, 'approved']
      );

      expect(helperResult.rows[0].total_tasks).toBe(0); // New helper

      // 2. Task created by customer
      const taskId = uuidv4();
      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
        [taskId, 'SKT00001', customerId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'unassigned']
      );

      // 3. Helper receives request
      const requestId = uuidv4();
      const requestResult = await pool.query(
        'INSERT INTO task_requests (id, task_id, helper_id, status, expires_at) VALUES ($1, $2, $3, $4, $5) RETURNING *',
        [requestId, taskId, helperId, 'pending', new Date(Date.now() + 45000)]
      );

      expect(requestResult.rows[0].status).toBe('pending');

      // 4. Helper accepts
      await pool.query(
        'UPDATE task_requests SET status = $1 WHERE id = $2',
        ['accepted', requestId]
      );

      // 5. Task confirmed and helper starts work
      await pool.query(
        'UPDATE tasks SET status = $1, helper_id = $2 WHERE id = $3',
        ['confirmed', helperId, taskId]
      );

      // ... task goes through: started → otp_pending → in_progress → completed

      // 6. Task completed
      await pool.query(
        'UPDATE tasks SET status = $1 WHERE id = $2',
        ['completed', taskId]
      );

      // 7. Payment created: ₹300 total, ₹45 fee, ₹255 to helper
      const paymentId = uuidv4();
      const paymentResult = await pool.query(
        'INSERT INTO payments (id, task_id, customer_id, helper_id, final_amount, platform_fee_amount, helper_payout_amount, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *',
        [paymentId, taskId, customerId, helperId, 300, 45, 255, 'completed']
      );

      expect(paymentResult.rows[0].helper_payout_amount).toBe(255);

      // 8. Helper requests payout
      const payoutId = uuidv4();
      const payoutResult = await pool.query(
        'INSERT INTO payouts (id, helper_id, total_amount, payment_method, status) VALUES ($1, $2, $3, $4, $5) RETURNING *',
        [payoutId, helperId, 255, 'upi', 'pending']
      );

      expect(payoutResult.rows[0].status).toBe('pending');

      // 9. Admin processes payout
      const processedResult = await pool.query(
        'UPDATE payouts SET status = $1 WHERE id = $2 RETURNING *',
        ['completed', payoutId]
      );

      expect(processedResult.rows[0].status).toBe('completed');

      // 10. Helper's balance is now 0 (earned 255, paid out 255)
      const payments = await pool.query(
        'SELECT helper_payout_amount FROM payments WHERE helper_id = $1 AND status = $2',
        [helperId, 'completed']
      );

      const payouts = await pool.query(
        'SELECT total_amount FROM payouts WHERE helper_id = $1 AND status = $2',
        [helperId, 'completed']
      );

      const earned = payments.rows.reduce((sum, p) => sum + parseFloat(p.helper_payout_amount), 0);
      const paid = payouts.rows.reduce((sum, p) => sum + parseFloat(p.total_amount), 0);

      expect(earned).toBe(255);
      expect(paid).toBe(255);
      expect(earned - paid).toBe(0);
    });

    it('should prevent suspended helper from accepting tasks', async () => {
      const customerId = uuidv4();
      const helperUserId = uuidv4();
      const helperId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      // Setup
      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [customerId, '+919999999999', 'Test Customer', 'customer', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [helperUserId, '+919999999001', 'Test Helper', 'helper', 'active', JSON.stringify(taskLocation)]
      );

      // Create suspended helper
      await pool.query(
        'INSERT INTO helpers (id, user_id, helper_status) VALUES ($1, $2, $3)',
        [helperId, helperUserId, 'suspended']
      );

      const taskId = uuidv4();
      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
        [taskId, 'SKT00001', customerId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'unassigned']
      );

      // Get helper status
      const helperCheckResult = await pool.query(
        'SELECT helper_status FROM helpers WHERE id = $1',
        [helperId]
      );

      expect(helperCheckResult.rows[0].helper_status).toBe('suspended');

      // Suspended helper should not be able to accept requests
      // (Business logic would prevent this in service layer)
    });
  });

  describe('Concurrent Task Handling', () => {
    it('should handle multiple helpers accepting different tasks', async () => {
      const customerId1 = uuidv4();
      const customerId2 = uuidv4();
      const helper1UserId = uuidv4();
      const helper1Id = uuidv4();
      const helper2UserId = uuidv4();
      const helper2Id = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      // Setup
      for (const [cId, cName] of [[customerId1, 'Customer 1'], [customerId2, 'Customer 2']]) {
        await pool.query(
          'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
          [cId, `+91999999999${uuidv4().substring(0, 1)}`, cName, 'customer', 'active', JSON.stringify(taskLocation)]
        );
      }

      for (const [hUserId, hId, hName] of [[helper1UserId, helper1Id, 'Helper 1'], [helper2UserId, helper2Id, 'Helper 2']]) {
        await pool.query(
          'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
          [hUserId, `+91999999999${uuidv4().substring(0, 1)}`, hName, 'helper', 'active', JSON.stringify(taskLocation)]
        );

        await pool.query(
          'INSERT INTO helpers (id, user_id, helper_status) VALUES ($1, $2, $3)',
          [hId, hUserId, 'approved']
        );
      }

      // Create 2 tasks
      const task1Id = uuidv4();
      const task2Id = uuidv4();

      for (const [tId, cId, tName] of [[task1Id, customerId1, 'Task 1'], [task2Id, customerId2, 'Task 2']]) {
        await pool.query(
          'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
          [tId, tName, cId, 'personal', 'cleaning', tName, JSON.stringify(taskLocation), 'Warangal', 'unassigned']
        );
      }

      // Helper 1 accepts task 1
      const request1Id = uuidv4();
      await pool.query(
        'INSERT INTO task_requests (id, task_id, helper_id, status, expires_at) VALUES ($1, $2, $3, $4, $5)',
        [request1Id, task1Id, helper1Id, 'accepted', new Date(Date.now() + 45000)]
      );

      await pool.query(
        'UPDATE tasks SET status = $1, helper_id = $2 WHERE id = $3',
        ['confirmed', helper1Id, task1Id]
      );

      // Helper 2 accepts task 2
      const request2Id = uuidv4();
      await pool.query(
        'INSERT INTO task_requests (id, task_id, helper_id, status, expires_at) VALUES ($1, $2, $3, $4, $5)',
        [request2Id, task2Id, helper2Id, 'accepted', new Date(Date.now() + 45000)]
      );

      await pool.query(
        'UPDATE tasks SET status = $1, helper_id = $2 WHERE id = $3',
        ['confirmed', helper2Id, task2Id]
      );

      // Verify both tasks are confirmed with different helpers
      const task1 = await pool.query('SELECT * FROM tasks WHERE id = $1', [task1Id]);
      const task2 = await pool.query('SELECT * FROM tasks WHERE id = $1', [task2Id]);

      expect(task1.rows[0].helper_id).toBe(helper1Id);
      expect(task2.rows[0].helper_id).toBe(helper2Id);
      expect(task1.rows[0].status).toBe('confirmed');
      expect(task2.rows[0].status).toBe('confirmed');
    });
  });
});
