import { v4 as uuidv4 } from 'uuid';
import { initializeDatabase, getPool, closeDatabase } from '../src/config/database';
import { initializeRedis, getRedis, closeRedis } from '../src/config/redis';
import * as pricingService from '../src/services/pricing';
import * as payoutService from '../src/services/payout';
import prisma from '../src/config/prisma';

describe('Fee and Payout Calculations', () => {
  let pool: any;
  let redis: any;

  beforeAll(async () => {
    await initializeDatabase();
    await initializeRedis();
    pool = getPool();
    redis = getRedis();

    // Create necessary tables
    await pool.query('DROP TABLE IF EXISTS payments CASCADE');
    await pool.query('DROP TABLE IF EXISTS pricing_configs CASCADE');
    await pool.query('DROP TABLE IF EXISTS payouts CASCADE');
    await pool.query('DROP TABLE IF EXISTS tasks CASCADE');
    await pool.query('DROP TABLE IF EXISTS helpers CASCADE');
    await pool.query('DROP TABLE IF EXISTS users CASCADE');

    await pool.query(`
      CREATE TABLE users (
        id UUID PRIMARY KEY,
        phone_number VARCHAR(20) UNIQUE,
        name VARCHAR(255) NOT NULL,
        role VARCHAR(20) DEFAULT 'customer',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE helpers (
        id UUID PRIMARY KEY,
        user_id UUID NOT NULL REFERENCES users(id),
        helper_status VARCHAR(50) DEFAULT 'approved',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE tasks (
        id UUID PRIMARY KEY,
        customer_id UUID NOT NULL REFERENCES users(id),
        helper_id UUID REFERENCES helpers(id),
        status VARCHAR(50) DEFAULT 'unassigned',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE pricing_configs (
        id UUID PRIMARY KEY,
        config_key VARCHAR(50) UNIQUE,
        base_fare_rupees NUMERIC(10,2),
        per_km_rate NUMERIC(10,2),
        per_minute_rate NUMERIC(10,2),
        minimum_fare_rupees NUMERIC(10,2),
        cancellation_fee_rupees NUMERIC(10,2),
        platform_fee_percent NUMERIC(5,2),
        business_task_multiplier NUMERIC(4,2),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE payments (
        id UUID PRIMARY KEY,
        task_id UUID NOT NULL REFERENCES tasks(id),
        customer_id UUID NOT NULL REFERENCES users(id),
        helper_id UUID REFERENCES helpers(id),
        final_amount NUMERIC(10,2) NOT NULL,
        platform_fee_amount NUMERIC(10,2) NOT NULL,
        helper_payout_amount NUMERIC(10,2) NOT NULL,
        status VARCHAR(50) DEFAULT 'processing',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE payouts (
        id UUID PRIMARY KEY,
        helper_id UUID NOT NULL REFERENCES helpers(id),
        total_amount NUMERIC(10,2) NOT NULL,
        status VARCHAR(50) DEFAULT 'pending',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create default pricing config
    await pool.query(`
      INSERT INTO pricing_configs (id, config_key, base_fare_rupees, per_km_rate, per_minute_rate, minimum_fare_rupees, cancellation_fee_rupees, platform_fee_percent, business_task_multiplier)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
    `, [uuidv4(), 'current', 40, 15, 2.5, 80, 30, 15, 1.25]);
  });

  afterAll(async () => {
    await pool.query('DROP TABLE IF EXISTS payments CASCADE');
    await pool.query('DROP TABLE IF EXISTS pricing_configs CASCADE');
    await pool.query('DROP TABLE IF EXISTS payouts CASCADE');
    await pool.query('DROP TABLE IF EXISTS tasks CASCADE');
    await pool.query('DROP TABLE IF EXISTS helpers CASCADE');
    await pool.query('DROP TABLE IF EXISTS users CASCADE');
    await closeDatabase();
    await closeRedis();
  });

  afterEach(async () => {
    await redis.flushdb();
    await pool.query('DELETE FROM payments');
    await pool.query('DELETE FROM payouts');
    await pool.query('DELETE FROM tasks');
    await pool.query('DELETE FROM helpers');
    await pool.query('DELETE FROM users');
  });

  describe('Base Fare Calculation', () => {
    it('should calculate fare with base + distance + time', async () => {
      // Get pricing config
      const config = await pool.query('SELECT * FROM pricing_configs WHERE config_key = $1', ['current']);
      const pricing = config.rows[0];

      // Calculate: base (40) + distance (5km * 15) + time (10min * 2.5)
      // = 40 + 75 + 25 = 140
      const distance = 5;
      const time = 10;

      const fare = pricing.base_fare_rupees + (distance * pricing.per_km_rate) + (time * pricing.per_minute_rate);

      expect(fare).toBe(140);
    });

    it('should apply minimum fare if calculated fare is lower', async () => {
      const config = await pool.query('SELECT * FROM pricing_configs WHERE config_key = $1', ['current']);
      const pricing = config.rows[0];

      // Small distance: base (40) + distance (0.5km * 15) + time (2min * 2.5)
      // = 40 + 7.5 + 5 = 52.5 < 80 (minimum)
      const distance = 0.5;
      const time = 2;

      let fare = pricing.base_fare_rupees + (distance * pricing.per_km_rate) + (time * pricing.per_minute_rate);

      // Apply minimum
      if (fare < pricing.minimum_fare_rupees) {
        fare = pricing.minimum_fare_rupees;
      }

      expect(fare).toBe(80);
    });

    it('should apply business multiplier for business tasks', async () => {
      const config = await pool.query('SELECT * FROM pricing_configs WHERE config_key = $1', ['current']);
      const pricing = config.rows[0];

      // Personal: base (40) + distance (10km * 15) + time (20min * 2.5) = 40 + 150 + 50 = 240
      // Business: 240 * 1.25 = 300
      const distance = 10;
      const time = 20;

      const personalFare = pricing.base_fare_rupees + (distance * pricing.per_km_rate) + (time * pricing.per_minute_rate);
      const businessFare = personalFare * pricing.business_task_multiplier;

      expect(personalFare).toBe(240);
      expect(businessFare).toBe(300);
    });

    it('should handle zero distance correctly', async () => {
      const config = await pool.query('SELECT * FROM pricing_configs WHERE config_key = $1', ['current']);
      const pricing = config.rows[0];

      // Base (40) + zero distance + time (5min * 2.5) = 40 + 0 + 12.5 = 52.5 < 80
      const distance = 0;
      const time = 5;

      let fare = pricing.base_fare_rupees + (distance * pricing.per_km_rate) + (time * pricing.per_minute_rate);

      if (fare < pricing.minimum_fare_rupees) {
        fare = pricing.minimum_fare_rupees;
      }

      expect(fare).toBe(80);
    });
  });

  describe('Platform Fee Calculation', () => {
    it('should deduct 15% platform fee from final amount', async () => {
      const config = await pool.query('SELECT * FROM pricing_configs WHERE config_key = $1', ['current']);
      const pricing = config.rows[0];

      // Final amount: 300
      // Fee: 300 * 15% = 45
      // Helper gets: 300 - 45 = 255
      const finalAmount = 300;
      const fee = finalAmount * (pricing.platform_fee_percent / 100);
      const helperEarns = finalAmount - fee;

      expect(fee).toBe(45);
      expect(helperEarns).toBe(255);
    });

    it('should calculate fee for minimum fare', async () => {
      const config = await pool.query('SELECT * FROM pricing_configs WHERE config_key = $1', ['current']);
      const pricing = config.rows[0];

      // Final amount: 80 (minimum)
      // Fee: 80 * 15% = 12
      // Helper gets: 80 - 12 = 68
      const finalAmount = pricing.minimum_fare_rupees;
      const fee = finalAmount * (pricing.platform_fee_percent / 100);
      const helperEarns = finalAmount - fee;

      expect(fee).toBe(12);
      expect(helperEarns).toBe(68);
    });

    it('should round fees to nearest rupee', async () => {
      const config = await pool.query('SELECT * FROM pricing_configs WHERE config_key = $1', ['current']);
      const pricing = config.rows[0];

      // Final: 333
      // Fee: 333 * 15% = 49.95 ≈ 50
      // Helper: 333 - 50 = 283
      const finalAmount = 333;
      const feeDecimal = finalAmount * (pricing.platform_fee_percent / 100);
      const fee = Math.round(feeDecimal);
      const helperEarns = finalAmount - fee;

      expect(fee).toBe(50);
      expect(helperEarns).toBe(283);
    });

    it('should apply fee to business multiplied amount', async () => {
      const config = await pool.query('SELECT * FROM pricing_configs WHERE config_key = $1', ['current']);
      const pricing = config.rows[0];

      // Personal: 240, Business: 240 * 1.25 = 300
      // Fee: 300 * 15% = 45
      // Helper: 300 - 45 = 255
      const personalAmount = 240;
      const businessAmount = personalAmount * pricing.business_task_multiplier;
      const fee = businessAmount * (pricing.platform_fee_percent / 100);
      const helperEarns = businessAmount - fee;

      expect(businessAmount).toBe(300);
      expect(fee).toBe(45);
      expect(helperEarns).toBe(255);
    });
  });

  describe('Payout Processing', () => {
    it('should calculate available balance correctly', async () => {
      const userId = uuidv4();
      const helperId = uuidv4();
      const taskId = uuidv4();
      const customerId = uuidv4();

      // Create users and helpers
      await pool.query(
        'INSERT INTO users (id, phone_number, name, role) VALUES ($1, $2, $3, $4)',
        [userId, '+919999999999', 'Helper', 'helper']
      );

      await pool.query(
        'INSERT INTO helpers (id, user_id) VALUES ($1, $2)',
        [helperId, userId]
      );

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role) VALUES ($1, $2, $3, $4)',
        [customerId, '+919999999998', 'Customer', 'customer']
      );

      await pool.query(
        'INSERT INTO tasks (id, customer_id, helper_id, status) VALUES ($1, $2, $3, $4)',
        [taskId, customerId, helperId, 'completed']
      );

      // Create payment: final=300, fee=45, helper_payout=255
      await pool.query(
        'INSERT INTO payments (id, task_id, customer_id, helper_id, final_amount, platform_fee_amount, helper_payout_amount, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)',
        [uuidv4(), taskId, customerId, helperId, 300, 45, 255, 'completed']
      );

      // Calculate available balance
      const payments = await pool.query(
        'SELECT helper_payout_amount FROM payments WHERE helper_id = $1 AND status = $2',
        [helperId, 'completed']
      );

      const totalEarned = payments.rows.reduce((sum, p) => sum + parseFloat(p.helper_payout_amount), 0);

      // No payouts yet
      const totalPaidOut = 0;

      const availableBalance = totalEarned - totalPaidOut;

      expect(availableBalance).toBe(255);
    });

    it('should deduct paid payouts from available balance', async () => {
      const userId = uuidv4();
      const helperId = uuidv4();
      const customerId = uuidv4();

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role) VALUES ($1, $2, $3, $4)',
        [userId, '+919999999999', 'Helper', 'helper']
      );

      await pool.query(
        'INSERT INTO helpers (id, user_id) VALUES ($1, $2)',
        [helperId, userId]
      );

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role) VALUES ($1, $2, $3, $4)',
        [customerId, '+919999999998', 'Customer', 'customer']
      );

      // Create 3 completed payments
      for (let i = 0; i < 3; i++) {
        const taskId = uuidv4();
        await pool.query(
          'INSERT INTO tasks (id, customer_id, helper_id, status) VALUES ($1, $2, $3, $4)',
          [taskId, customerId, helperId, 'completed']
        );

        await pool.query(
          'INSERT INTO payments (id, task_id, customer_id, helper_id, final_amount, platform_fee_amount, helper_payout_amount, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)',
          [uuidv4(), taskId, customerId, helperId, 300, 45, 255, 'completed']
        );
      }

      // Total earned: 255 * 3 = 765

      // Create payout for 100
      await pool.query(
        'INSERT INTO payouts (id, helper_id, total_amount, status) VALUES ($1, $2, $3, $4)',
        [uuidv4(), helperId, 100, 'completed']
      );

      // Available: 765 - 100 = 665
      const payments = await pool.query(
        'SELECT helper_payout_amount FROM payments WHERE helper_id = $1 AND status = $2',
        [helperId, 'completed']
      );

      const totalEarned = payments.rows.reduce((sum, p) => sum + parseFloat(p.helper_payout_amount), 0);

      const payouts = await pool.query(
        'SELECT total_amount FROM payouts WHERE helper_id = $1 AND status = $2',
        [helperId, 'completed']
      );

      const totalPaidOut = payouts.rows.reduce((sum, p) => sum + parseFloat(p.total_amount), 0);

      const available = totalEarned - totalPaidOut;

      expect(totalEarned).toBe(765);
      expect(totalPaidOut).toBe(100);
      expect(available).toBe(665);
    });

    it('should enforce minimum payout amount (₹100)', async () => {
      const minimumPayout = 100;
      const requestedAmount = 50;

      expect(requestedAmount < minimumPayout).toBe(true);
    });

    it('should prevent payout exceeding available balance', async () => {
      const available = 200;
      const requestedAmount = 250;

      expect(requestedAmount > available).toBe(true);
    });

    it('should handle multiple payments for same helper', async () => {
      const userId = uuidv4();
      const helperId = uuidv4();
      const customerId = uuidv4();

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role) VALUES ($1, $2, $3, $4)',
        [userId, '+919999999999', 'Helper', 'helper']
      );

      await pool.query(
        'INSERT INTO helpers (id, user_id) VALUES ($1, $2)',
        [helperId, userId]
      );

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role) VALUES ($1, $2, $3, $4)',
        [customerId, '+919999999998', 'Customer', 'customer']
      );

      // Create payments with different amounts
      const paymentAmounts = [255, 340, 215]; // After fees

      for (let i = 0; i < paymentAmounts.length; i++) {
        const taskId = uuidv4();
        await pool.query(
          'INSERT INTO tasks (id, customer_id, helper_id, status) VALUES ($1, $2, $3, $4)',
          [taskId, customerId, helperId, 'completed']
        );

        await pool.query(
          'INSERT INTO payments (id, task_id, customer_id, helper_id, final_amount, platform_fee_amount, helper_payout_amount, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)',
          [uuidv4(), taskId, customerId, helperId, paymentAmounts[i] * 1.176, // Reverse fee calc
          (paymentAmounts[i] * 1.176) * 0.15, paymentAmounts[i], 'completed']
        );
      }

      const payments = await pool.query(
        'SELECT helper_payout_amount FROM payments WHERE helper_id = $1 AND status = $2',
        [helperId, 'completed']
      );

      const totalEarned = payments.rows.reduce((sum, p) => sum + parseFloat(p.helper_payout_amount), 0);

      expect(totalEarned).toBe(810); // 255 + 340 + 215
    });
  });

  describe('Fee Breakdown Accuracy', () => {
    it('should ensure final_amount = fee + helper_payout', async () => {
      const config = await pool.query('SELECT * FROM pricing_configs WHERE config_key = $1', ['current']);
      const pricing = config.rows[0];

      // Calculate: base + distance + time
      const distance = 5;
      const time = 10;

      let fare = pricing.base_fare_rupees + (distance * pricing.per_km_rate) + (time * pricing.per_minute_rate);

      if (fare < pricing.minimum_fare_rupees) {
        fare = pricing.minimum_fare_rupees;
      }

      const finalAmount = fare;
      const feeAmount = Math.round(finalAmount * (pricing.platform_fee_percent / 100));
      const helperPayout = finalAmount - feeAmount;

      // Verify breakdown
      expect(finalAmount).toBe(feeAmount + helperPayout);
    });

    it('should maintain accuracy with business multiplier', async () => {
      const config = await pool.query('SELECT * FROM pricing_configs WHERE config_key = $1', ['current']);
      const pricing = config.rows[0];

      // Business task
      const distance = 8;
      const time = 15;

      let fare = pricing.base_fare_rupees + (distance * pricing.per_km_rate) + (time * pricing.per_minute_rate);
      fare = fare * pricing.business_task_multiplier;

      if (fare < pricing.minimum_fare_rupees) {
        fare = pricing.minimum_fare_rupees;
      }

      const finalAmount = fare;
      const feeAmount = Math.round(finalAmount * (pricing.platform_fee_percent / 100));
      const helperPayout = finalAmount - feeAmount;

      expect(finalAmount).toBe(feeAmount + helperPayout);
    });
  });
});
