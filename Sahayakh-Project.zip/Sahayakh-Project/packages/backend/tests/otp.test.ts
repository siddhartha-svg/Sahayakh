import { generateOTP as generateOTPCode, hashOTP, compareOTP } from '../src/utils/otp';
import { generateAndStoreOTP, verifyAndConsumeOTP } from '../src/services/otp';
import { initializeRedis, getRedis, getRedisKey } from '../src/config/redis';
import { AppError } from '../src/middleware/error';

describe('OTP Utility Functions', () => {
  it('should generate a 6-digit OTP', () => {
    const otp = generateOTPCode();
    expect(otp).toMatch(/^\d{6}$/);
  });

  it('should generate different OTPs', () => {
    const otp1 = generateOTPCode();
    const otp2 = generateOTPCode();
    expect(otp1).not.toBe(otp2);
  });

  it('should hash OTP', async () => {
    const otp = '123456';
    const hash = await hashOTP(otp);
    expect(hash).toBeDefined();
    expect(hash).not.toBe(otp);
  });

  it('should compare OTP correctly', async () => {
    const otp = '123456';
    const hash = await hashOTP(otp);
    const isMatch = await compareOTP(otp, hash);
    expect(isMatch).toBe(true);
  });

  it('should not match incorrect OTP', async () => {
    const otp = '123456';
    const wrongOtp = '654321';
    const hash = await hashOTP(otp);
    const isMatch = await compareOTP(wrongOtp, hash);
    expect(isMatch).toBe(false);
  });
});

describe('OTP Service', () => {
  let redis: ReturnType<typeof getRedis>;

  beforeAll(async () => {
    await initializeRedis();
    redis = getRedis();
  });

  afterEach(async () => {
    await redis.flushdb();
  });

  it('should generate and store OTP', async () => {
    const phoneNumber = '+919876543210';
    const otp = await generateAndStoreOTP(phoneNumber);

    expect(otp).toMatch(/^\d{6}$/);

    const otpKey = getRedisKey(`otp:${phoneNumber}`);
    const stored = await redis.get(otpKey);
    expect(stored).toBeDefined();
  });

  it('should enforce rate limit on OTP generation', async () => {
    const phoneNumber = '+919876543210';

    for (let i = 0; i < 10; i++) {
      await generateAndStoreOTP(phoneNumber);
    }

    await expect(generateAndStoreOTP(phoneNumber)).rejects.toThrow(AppError);
  });

  it('should verify correct OTP', async () => {
    const phoneNumber = '+919876543210';
    const otp = await generateAndStoreOTP(phoneNumber);

    const isValid = await verifyAndConsumeOTP(phoneNumber, otp);
    expect(isValid).toBe(true);
  });

  it('should reject incorrect OTP', async () => {
    const phoneNumber = '+919876543210';
    await generateAndStoreOTP(phoneNumber);

    await expect(verifyAndConsumeOTP(phoneNumber, '000000')).rejects.toThrow(AppError);
  });

  it('should enforce max attempts', async () => {
    const phoneNumber = '+919876543210';
    await generateAndStoreOTP(phoneNumber);

    for (let i = 0; i < 3; i++) {
      try {
        await verifyAndConsumeOTP(phoneNumber, '000000');
      } catch {
        // Expected to fail
      }
    }

    await expect(verifyAndConsumeOTP(phoneNumber, '000000')).rejects.toThrow(AppError);
  });

  it('should clear OTP after successful verification', async () => {
    const phoneNumber = '+919876543210';
    const otp = await generateAndStoreOTP(phoneNumber);

    await verifyAndConsumeOTP(phoneNumber, otp);

    const otpKey = getRedisKey(`otp:${phoneNumber}`);
    const stored = await redis.get(otpKey);
    expect(stored).toBeNull();
  });
});
