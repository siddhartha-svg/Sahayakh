import request from 'supertest';
import { initializeDatabase, getPool, closeDatabase } from '../src/config/database';
import { initializeRedis, getRedis, closeRedis } from '../src/config/redis';
import app from '../src/index';
import * as taskService from '../src/services/task';
import prisma from '../src/config/prisma';
import { v4 as uuidv4 } from 'uuid';

describe('Task State Machine', () => {
  let pool: any;
  let redis: any;

  beforeAll(async () => {
    await initializeDatabase();
    await initializeRedis();
    pool = getPool();
    redis = getRedis();

    await pool.query('DROP TABLE IF EXISTS tasks CASCADE');
    await pool.query('DROP TABLE IF EXISTS users CASCADE');

    await pool.query(`
      CREATE TABLE users (
        id UUID PRIMARY KEY,
        phone_number VARCHAR(20) UNIQUE,
        name VARCHAR(255) NOT NULL,
        role VARCHAR(20) NOT NULL DEFAULT 'customer',
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        location_point JSONB,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE tasks (
        id UUID PRIMARY KEY,
        task_id_display VARCHAR(20) UNIQUE,
        customer_id UUID NOT NULL REFERENCES users(id),
        helper_id UUID,
        task_type VARCHAR(20),
        category VARCHAR(100),
        description TEXT,
        location_point JSONB,
        location_name VARCHAR(255),
        preferred_date VARCHAR(20),
        preferred_time VARCHAR(20),
        budget_min NUMERIC(10,2),
        budget_max NUMERIC(10,2),
        status VARCHAR(50) DEFAULT 'unassigned',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE helpers (
        id UUID PRIMARY KEY,
        user_id UUID NOT NULL REFERENCES users(id),
        helper_status VARCHAR(50) DEFAULT 'approved',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);
  });

  afterAll(async () => {
    await pool.query('DROP TABLE IF EXISTS tasks CASCADE');
    await pool.query('DROP TABLE IF EXISTS helpers CASCADE');
    await pool.query('DROP TABLE IF EXISTS users CASCADE');
    await closeDatabase();
    await closeRedis();
  });

  afterEach(async () => {
    await redis.flushdb();
    await pool.query('DELETE FROM tasks');
    await pool.query('DELETE FROM helpers');
    await pool.query('DELETE FROM users');
  });

  describe('Task Status Transitions', () => {
    let customerId: string;
    let helperId: string;
    let taskId: string;

    beforeEach(async () => {
      customerId = uuidv4();
      const helperId_user = uuidv4();
      helperId = uuidv4();
      taskId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [customerId, '+919999999999', 'Test Customer', 'customer', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [helperId_user, '+919999999001', 'Test Helper', 'helper', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO helpers (id, user_id, helper_status) VALUES ($1, $2, $3)',
        [helperId, helperId_user, 'approved']
      );

      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
        [taskId, 'SKT00001', customerId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'unassigned']
      );
    });

    it('should transition from unassigned to confirmed', async () => {
      const result = await pool.query('UPDATE tasks SET status = $1, helper_id = $2, updated_at = NOW() WHERE id = $3 RETURNING *', ['confirmed', helperId, taskId]);

      expect(result.rows[0].status).toBe('confirmed');
      expect(result.rows[0].helper_id).toBe(helperId);
    });

    it('should transition from confirmed to started', async () => {
      await pool.query('UPDATE tasks SET status = $1, helper_id = $2 WHERE id = $3', ['confirmed', helperId, taskId]);

      const result = await pool.query('UPDATE tasks SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *', ['started', taskId]);

      expect(result.rows[0].status).toBe('started');
    });

    it('should transition from started to otp_pending', async () => {
      await pool.query('UPDATE tasks SET status = $1, helper_id = $2 WHERE id = $3', ['started', helperId, taskId]);

      const result = await pool.query('UPDATE tasks SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *', ['otp_pending', taskId]);

      expect(result.rows[0].status).toBe('otp_pending');
    });

    it('should transition from otp_pending to in_progress', async () => {
      await pool.query('UPDATE tasks SET status = $1, helper_id = $2 WHERE id = $3', ['otp_pending', helperId, taskId]);

      const result = await pool.query('UPDATE tasks SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *', ['in_progress', taskId]);

      expect(result.rows[0].status).toBe('in_progress');
    });

    it('should transition from in_progress to completed', async () => {
      await pool.query('UPDATE tasks SET status = $1, helper_id = $2 WHERE id = $3', ['in_progress', helperId, taskId]);

      const result = await pool.query('UPDATE tasks SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *', ['completed', taskId]);

      expect(result.rows[0].status).toBe('completed');
    });

    it('should transition from in_progress to review (for customer rating)', async () => {
      await pool.query('UPDATE tasks SET status = $1, helper_id = $2 WHERE id = $3', ['in_progress', helperId, taskId]);

      const result = await pool.query('UPDATE tasks SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *', ['review', taskId]);

      expect(result.rows[0].status).toBe('review');
    });

    it('should transition from completed to disputed', async () => {
      await pool.query('UPDATE tasks SET status = $1, helper_id = $2 WHERE id = $3', ['completed', helperId, taskId]);

      const result = await pool.query('UPDATE tasks SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *', ['disputed', taskId]);

      expect(result.rows[0].status).toBe('disputed');
    });

    it('should allow cancellation from unassigned', async () => {
      const result = await pool.query('UPDATE tasks SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *', ['cancelled', taskId]);

      expect(result.rows[0].status).toBe('cancelled');
    });

    it('should allow cancellation from confirmed', async () => {
      await pool.query('UPDATE tasks SET status = $1, helper_id = $2 WHERE id = $3', ['confirmed', helperId, taskId]);

      const result = await pool.query('UPDATE tasks SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *', ['cancelled', taskId]);

      expect(result.rows[0].status).toBe('cancelled');
    });

    it('should prevent invalid state transitions', async () => {
      // Try to go from unassigned to completed (invalid)
      // This test validates business logic, not DB - so check via service
      const task = await taskService.findTaskById(taskId);
      expect(task.status).toBe('unassigned');

      // In real implementation, would validate in service/route
      // Cannot go directly from unassigned to completed
    });
  });

  describe('Task Lifecycle Validation', () => {
    it('should require helper assignment before task can start', async () => {
      const customerId = uuidv4();
      const taskId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [customerId, '+919999999999', 'Test Customer', 'customer', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
        [taskId, 'SKT00001', customerId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'unassigned']
      );

      const task = await pool.query('SELECT * FROM tasks WHERE id = $1', [taskId]);

      // Task without helper assignment should stay unassigned
      expect(task.rows[0].status).toBe('unassigned');
      expect(task.rows[0].helper_id).toBeNull();
    });

    it('should maintain helper_id throughout task lifecycle', async () => {
      const customerId = uuidv4();
      const helperId_user = uuidv4();
      const helperId = uuidv4();
      const taskId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [customerId, '+919999999999', 'Test Customer', 'customer', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [helperId_user, '+919999999001', 'Test Helper', 'helper', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO helpers (id, user_id, helper_status) VALUES ($1, $2, $3)',
        [helperId, helperId_user, 'approved']
      );

      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
        [taskId, 'SKT00001', customerId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'unassigned']
      );

      // Move through states and verify helper_id persists
      await pool.query('UPDATE tasks SET status = $1, helper_id = $2 WHERE id = $3', ['confirmed', helperId, taskId]);
      let task = await pool.query('SELECT * FROM tasks WHERE id = $1', [taskId]);
      expect(task.rows[0].helper_id).toBe(helperId);

      await pool.query('UPDATE tasks SET status = $1 WHERE id = $2', ['started', taskId]);
      task = await pool.query('SELECT * FROM tasks WHERE id = $1', [taskId]);
      expect(task.rows[0].helper_id).toBe(helperId);

      await pool.query('UPDATE tasks SET status = $1 WHERE id = $2', ['completed', taskId]);
      task = await pool.query('SELECT * FROM tasks WHERE id = $1', [taskId]);
      expect(task.rows[0].helper_id).toBe(helperId);
    });
  });

  describe('Task Status Queries', () => {
    it('should return only unassigned tasks in search', async () => {
      const customerId = uuidv4();
      const helperId_user = uuidv4();
      const helperId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [customerId, '+919999999999', 'Test Customer', 'customer', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [helperId_user, '+919999999001', 'Test Helper', 'helper', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO helpers (id, user_id, helper_status) VALUES ($1, $2, $3)',
        [helperId, helperId_user, 'approved']
      );

      // Create multiple tasks with different statuses
      for (let i = 0; i < 3; i++) {
        const taskId = uuidv4();
        const status = i === 0 ? 'unassigned' : i === 1 ? 'confirmed' : 'completed';
        const assignedHelper = status !== 'unassigned' ? helperId : null;

        await pool.query(
          'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status, helper_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)',
          [taskId, `SKT${String(i + 1).padStart(5, '0')}`, customerId, 'personal', 'cleaning', 'Task', JSON.stringify(taskLocation), 'Warangal', status, assignedHelper]
        );
      }

      const result = await pool.query('SELECT * FROM tasks WHERE status = $1', ['unassigned']);

      expect(result.rows.length).toBe(1);
      expect(result.rows[0].status).toBe('unassigned');
    });

    it('should return completed tasks for payment processing', async () => {
      const customerId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [customerId, '+919999999999', 'Test Customer', 'customer', 'active', JSON.stringify(taskLocation)]
      );

      // Create completed and non-completed tasks
      for (let i = 0; i < 3; i++) {
        const taskId = uuidv4();
        const status = i === 0 ? 'completed' : 'in_progress';

        await pool.query(
          'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
          [taskId, `SKT${String(i + 1).padStart(5, '0')}`, customerId, 'personal', 'cleaning', 'Task', JSON.stringify(taskLocation), 'Warangal', status]
        );
      }

      const result = await pool.query('SELECT * FROM tasks WHERE status = $1', ['completed']);

      expect(result.rows.length).toBe(1);
      expect(result.rows[0].status).toBe('completed');
    });
  });
});
