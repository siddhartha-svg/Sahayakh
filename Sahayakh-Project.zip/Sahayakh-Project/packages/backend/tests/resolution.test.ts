import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import prisma from '../src/config/prisma';
import * as disputeService from '../src/services/dispute';
import * as resolutionService from '../src/services/resolution';

describe('Dispute Resolution Service', () => {
  let customerId: string;
  let helperId: string;
  let adminId: string;
  let taskId: string;
  let disputeId: string;
  let paymentId: string;

  const createTestSetup = async () => {
    // Create users
    const customer = await prisma.user.create({
      data: {
        id: 'customer-' + Date.now(),
        name: 'Test Customer',
        phone_number: '9876543210',
        email: 'customer@test.com',
        role: 'customer',
      },
    });
    customerId = customer.id;

    const helperUser = await prisma.user.create({
      data: {
        id: 'helper-user-' + Date.now(),
        name: 'Test Helper',
        phone_number: '9876543211',
        email: 'helper@test.com',
        role: 'helper',
      },
    });

    const helper = await prisma.helper.create({
      data: {
        user_id: helperUser.id,
        helper_status: 'available',
        verification_status: 'verified',
        background_check_status: 'cleared',
      },
    });
    helperId = helper.id;

    const admin = await prisma.user.create({
      data: {
        id: 'admin-' + Date.now(),
        name: 'Test Admin',
        phone_number: '9876543212',
        email: 'admin@test.com',
        role: 'admin',
      },
    });
    adminId = admin.id;

    // Create task
    const task = await prisma.task.create({
      data: {
        task_id_display: 'T-' + Date.now(),
        customer_id: customerId,
        helper_id: helper.id,
        task_type: 'household',
        category: 'cleaning',
        title: 'House Cleaning',
        description: 'Clean the house',
        location_point: {
          type: 'Point',
          coordinates: [78.1198, 17.3850],
        },
        budget: 1000,
        status: 'completed',
        final_amount: 1000,
      },
    });
    taskId = task.id;

    // Create payment
    const payment = await prisma.payment.create({
      data: {
        task_id: taskId,
        customer_id: customerId,
        final_amount: 1000,
        task_amount: 1000,
        distance_surcharge: 0,
        time_surcharge: 0,
        peak_multiplier: 1.0,
        platform_fee_amount: 150,
        helper_payout_amount: 850,
        payment_method: 'card',
        status: 'completed',
        completed_at: new Date(),
      },
    });
    paymentId = payment.id;

    // Create dispute
    const dispute = await disputeService.raiseDispute(
      taskId,
      customerId,
      'quality',
      'Work incomplete',
      [],
    );
    disputeId = dispute.id;
  };

  beforeEach(async () => {
    await createTestSetup();
  });

  afterEach(async () => {
    // Cleanup
    await prisma.dispute.deleteMany({});
    await prisma.payment.deleteMany({});
    await prisma.payout.deleteMany({});
    await prisma.auditLog.deleteMany({});
    await prisma.task.deleteMany({});
    await prisma.helper.deleteMany({});
    await prisma.user.deleteMany({});
  });

  describe('resolveDisputeAsCustomerWin', () => {
    it('should refund customer on customer_win', async () => {
      const result = await resolutionService.resolveDisputeAsCustomerWin(
        disputeId,
        adminId,
        'Work quality verified customer claim',
      );

      expect(result.resolution_type).toBe('customer_win');
      expect(result.refund_amount).toBe(1000);

      // Verify payment is refunded
      const payment = await prisma.payment.findUnique({
        where: { id: paymentId },
      });
      expect(payment?.status).toBe('refunded');
    });

    it('should warn helper on first loss', async () => {
      const result = await resolutionService.resolveDisputeAsCustomerWin(
        disputeId,
        adminId,
      );

      expect(result.helper_action).toContain('warned');
      expect(result.helper_action).toContain('1/3');
    });

    it('should update dispute status to resolved', async () => {
      await resolutionService.resolveDisputeAsCustomerWin(
        disputeId,
        adminId,
      );

      const dispute = await prisma.dispute.findUnique({
        where: { id: disputeId },
      });
      expect(dispute?.status).toBe('resolved');
      expect(dispute?.resolution_type).toBe('customer_win');
    });

    it('should auto-suspend helper on 3rd loss', async () => {
      // Create 2 more disputes and resolve as customer_win
      for (let i = 0; i < 2; i++) {
        const task = await prisma.task.create({
          data: {
            task_id_display: `T-${Date.now()}-${i}`,
            customer_id: customerId,
            helper_id: helperId,
            task_type: 'household',
            category: 'cleaning',
            title: `Task ${i}`,
            description: `Task description ${i}`,
            location_point: {
              type: 'Point',
              coordinates: [78.1198, 17.3850],
            },
            budget: 1000,
            status: 'completed',
            final_amount: 1000,
          },
        });

        await prisma.payment.create({
          data: {
            task_id: task.id,
            customer_id: customerId,
            final_amount: 1000,
            task_amount: 1000,
            platform_fee_amount: 150,
            helper_payout_amount: 850,
            payment_method: 'card',
            status: 'completed',
            completed_at: new Date(),
          },
        });

        const dispute = await disputeService.raiseDispute(
          task.id,
          customerId,
          'quality',
          'Quality issue',
          [],
        );

        await resolutionService.resolveDisputeAsCustomerWin(
          dispute.id,
          adminId,
        );
      }

      // Resolve the main dispute (3rd loss)
      const result = await resolutionService.resolveDisputeAsCustomerWin(
        disputeId,
        adminId,
      );

      expect(result.helper_action).toContain('suspended');

      // Verify helper is suspended
      const helper = await prisma.helper.findUnique({
        where: { id: helperId },
      });
      expect(helper?.helper_status).toBe('suspended');
    });
  });

  describe('resolveDisputeAsHelperWin', () => {
    it('should ensure helper gets full payout', async () => {
      const result = await resolutionService.resolveDisputeAsHelperWin(
        disputeId,
        adminId,
      );

      expect(result.resolution_type).toBe('helper_win');
      expect(result.payout_amount).toBe(850);

      // Verify payout exists
      const payout = await prisma.payout.findFirst({
        where: {
          task_ids: {
            has: taskId,
          },
        },
      });
      expect(payout).toBeDefined();
      expect(payout?.total_amount).toBe(850);
    });

    it('should update dispute and task status', async () => {
      await resolutionService.resolveDisputeAsHelperWin(
        disputeId,
        adminId,
      );

      const dispute = await prisma.dispute.findUnique({
        where: { id: disputeId },
      });
      expect(dispute?.status).toBe('resolved');
      expect(dispute?.resolution_type).toBe('helper_win');

      const task = await prisma.task.findUnique({
        where: { id: taskId },
      });
      expect(task?.status).toBe('completed');
    });
  });

  describe('resolveDisputeAsPartial', () => {
    it('should split refund between customer and helper', async () => {
      const result = await resolutionService.resolveDisputeAsPartial(
        disputeId,
        600, // customer refund
        300, // helper payout
        adminId,
        '50-30 split',
      );

      expect(result.resolution_type).toBe('partial');
      expect(result.customer_refund).toBe(600);
      expect(result.helper_payout).toBe(300);
      expect(result.platform_keeps).toBe(100);

      // Verify payment marked as refunded
      const payment = await prisma.payment.findUnique({
        where: { id: paymentId },
      });
      expect(payment?.status).toBe('refunded');

      // Verify payout created
      const payout = await prisma.payout.findFirst({
        where: {
          task_ids: {
            has: taskId,
          },
        },
      });
      expect(payout?.total_amount).toBe(300);
    });

    it('should reject invalid amounts', async () => {
      await expect(
        resolutionService.resolveDisputeAsPartial(
          disputeId,
          600,
          500, // total exceeds final_amount
          adminId,
        ),
      ).rejects.toThrow('INVALID_AMOUNTS');
    });
  });

  describe('dismissDispute', () => {
    it('should dismiss without refund', async () => {
      const result = await resolutionService.dismissDispute(
        disputeId,
        adminId,
        'Frivolous complaint',
        'No merit to claim',
      );

      expect(result.resolution_type).toBe('dismissed');
      expect(result.reason).toBe('Frivolous complaint');

      // Verify payment NOT refunded
      const payment = await prisma.payment.findUnique({
        where: { id: paymentId },
      });
      expect(payment?.status).toBe('completed'); // Unchanged
    });

    it('should update dispute status', async () => {
      await resolutionService.dismissDispute(
        disputeId,
        adminId,
        'No evidence',
      );

      const dispute = await prisma.dispute.findUnique({
        where: { id: disputeId },
      });
      expect(dispute?.status).toBe('resolved');
      expect(dispute?.resolution_type).toBe('dismissed');
    });
  });

  describe('Resolution workflow', () => {
    it('should handle complete customer_win workflow', async () => {
      // Assign to admin
      await disputeService.assignDisputeToAdmin(disputeId, adminId);

      // Add messages
      await disputeService.addDisputeMessage(
        disputeId,
        helperId,
        'I disagree',
      );

      // Resolve
      const result = await resolutionService.resolveDisputeAsCustomerWin(
        disputeId,
        adminId,
        'Evidence supports customer',
      );

      // Verify final state
      expect(result.resolution_type).toBe('customer_win');
      expect(result.refund_amount).toBe(1000);

      const dispute = await disputeService.getDisputeWithMessages(disputeId);
      expect(dispute.status).toBe('resolved');
      expect(dispute.messages.length).toBeGreaterThan(1);
    });
  });
});
