import { describe, it, expect, beforeEach, afterEach } from '@jest/globals';
import prisma from '../src/config/prisma';
import * as suspensionService from '../src/services/suspension';

describe('Suspension Service', () => {
  let helperId: string;
  let adminId: string;

  beforeEach(async () => {
    // Create helper user
    const helperUser = await prisma.user.create({
      data: {
        id: 'helper-user-' + Date.now(),
        name: 'Test Helper',
        phone_number: '9876543210',
        email: 'helper@test.com',
        role: 'helper',
      },
    });

    const helper = await prisma.helper.create({
      data: {
        user_id: helperUser.id,
        helper_status: 'available',
        verification_status: 'verified',
        background_check_status: 'cleared',
      },
    });
    helperId = helper.id;

    // Create admin user
    const admin = await prisma.user.create({
      data: {
        id: 'admin-' + Date.now(),
        name: 'Test Admin',
        phone_number: '9876543211',
        email: 'admin@test.com',
        role: 'admin',
      },
    });
    adminId = admin.id;
  });

  afterEach(async () => {
    // Cleanup
    await prisma.helperSuspensionLog.deleteMany({});
    await prisma.auditLog.deleteMany({});
    await prisma.helper.deleteMany({});
    await prisma.user.deleteMany({});
  });

  describe('createSuspension', () => {
    it('should create suspension record', async () => {
      const endDate = new Date();
      endDate.setDate(endDate.getDate() + 30);

      const result = await suspensionService.createSuspension(
        helperId,
        'Repeated disputes',
        adminId,
        endDate,
      );

      expect(result).toBeDefined();
      expect(result.helper_id).toBe(helperId);
      expect(result.reason).toBe('Repeated disputes');
      expect(result.suspension_end_at).toEqual(endDate);
    });

    it('should update helper status to suspended', async () => {
      const endDate = new Date();
      endDate.setDate(endDate.getDate() + 30);

      await suspensionService.createSuspension(
        helperId,
        'Behavior complaint',
        adminId,
        endDate,
      );

      const helper = await prisma.helper.findUnique({
        where: { id: helperId },
      });
      expect(helper?.helper_status).toBe('suspended');
    });

    it('should create indefinite suspension if no end date', async () => {
      const result = await suspensionService.createSuspension(
        helperId,
        'Severe violation',
        adminId,
      );

      expect(result.suspension_end_at).toBeUndefined();
    });
  });

  describe('warnHelper', () => {
    it('should warn helper without suspension', async () => {
      const result = await suspensionService.warnHelper(
        helperId,
        'Poor quality work',
        adminId,
      );

      expect(result.warned).toBe(true);
      expect(result.warning_count).toBe(1);
      expect(result.auto_suspended).toBe(false);
    });

    it('should track multiple warnings', async () => {
      await suspensionService.warnHelper(helperId, 'Issue 1', adminId);
      const result = await suspensionService.warnHelper(
        helperId,
        'Issue 2',
        adminId,
      );

      expect(result.warning_count).toBe(2);
      expect(result.auto_suspended).toBe(false);
    });

    it('should auto-suspend on 3rd warning', async () => {
      await suspensionService.warnHelper(helperId, 'Issue 1', adminId);
      await suspensionService.warnHelper(helperId, 'Issue 2', adminId);
      const result = await suspensionService.warnHelper(
        helperId,
        'Issue 3',
        adminId,
      );

      expect(result.warning_count).toBe(3);
      expect(result.auto_suspended).toBe(true);
      expect(result.suspension_days).toBe(30);

      // Verify helper is suspended
      const helper = await prisma.helper.findUnique({
        where: { id: helperId },
      });
      expect(helper?.helper_status).toBe('suspended');
    });
  });

  describe('checkSuspensionStatus', () => {
    it('should return no suspension if none exists', async () => {
      const result = await suspensionService.checkSuspensionStatus(helperId);

      expect(result.suspended).toBe(false);
    });

    it('should detect active suspension', async () => {
      const endDate = new Date();
      endDate.setDate(endDate.getDate() + 30);

      await suspensionService.createSuspension(
        helperId,
        'Test suspension',
        adminId,
        endDate,
      );

      const result = await suspensionService.checkSuspensionStatus(helperId);

      expect(result.suspended).toBe(true);
      expect(result.reason).toBe('Test suspension');
    });

    it('should detect expired suspension', async () => {
      const endDate = new Date();
      endDate.setDate(endDate.getDate() - 1); // Past date

      await suspensionService.createSuspension(
        helperId,
        'Expired suspension',
        adminId,
        endDate,
      );

      const result = await suspensionService.checkSuspensionStatus(helperId);

      expect(result.suspended).toBe(false);
    });
  });

  describe('countDisputeLosses', () => {
    it('should count customer_win resolutions', async () => {
      // Create multiple disputes with different resolutions
      for (let i = 0; i < 2; i++) {
        await prisma.dispute.create({
          data: {
            dispute_id_display: `D-${Date.now()}-${i}`,
            task_id: `task-${Date.now()}-${i}`,
            raised_by: adminId,
            category: 'quality',
            status: 'resolved',
            resolution_type: 'customer_win',
          },
        });
      }

      // Add task-helper relationship (we need to create actual tasks)
      const helperUser = await prisma.user.findUnique({
        where: { role: 'helper' },
      });

      if (helperUser) {
        // This is a simplified check - in real tests we'd create actual tasks
        const count = await suspensionService.countDisputeLosses(helperId);
        expect(count).toBeGreaterThanOrEqual(0);
      }
    });
  });

  describe('appealSuspension', () => {
    it('should allow suspension appeal within 7 days', async () => {
      const endDate = new Date();
      endDate.setDate(endDate.getDate() + 30);

      const suspension = await suspensionService.createSuspension(
        helperId,
        'Test suspension',
        adminId,
        endDate,
      );

      const result = await suspensionService.appealSuspension(
        suspension.id,
        'I have improved my work quality',
      );

      expect(result.appeal_status).toBe('pending');
      expect(result.appeal_reason).toBe('I have improved my work quality');
    });

    it('should reject appeal after 7 days', async () => {
      // Create suspension with start date 8 days ago
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - 8);
      const endDate = new Date();
      endDate.setDate(endDate.getDate() + 22);

      const suspension = await prisma.helperSuspensionLog.create({
        data: {
          helper_id: helperId,
          triggered_by_admin_id: adminId,
          reason: 'Old suspension',
          suspension_start_at: startDate,
          suspension_end_at: endDate,
        },
      });

      await expect(
        suspensionService.appealSuspension(
          suspension.id,
          'Appeal after deadline',
        ),
      ).rejects.toThrow('APPEAL_WINDOW_CLOSED');
    });
  });

  describe('unlockSuspension', () => {
    it('should unlock expired suspension', async () => {
      const endDate = new Date();
      endDate.setDate(endDate.getDate() - 1); // Already expired

      const suspension = await suspensionService.createSuspension(
        helperId,
        'Expired suspension',
        adminId,
        endDate,
      );

      const result = await suspensionService.unlockSuspension(
        suspension.id,
        adminId,
        'Time-based expiration',
      );

      expect(result.unlocked).toBe(true);

      // Verify helper status reset
      const helper = await prisma.helper.findUnique({
        where: { id: helperId },
      });
      expect(helper?.helper_status).toBe('available');
    });
  });
});
