import request from 'supertest';
import { initializeDatabase, getPool, closeDatabase } from '../src/config/database';
import { initializeRedis, getRedis, closeRedis } from '../src/config/redis';
import app from '../src/index';
import * as taskService from '../src/services/task';
import prisma from '../src/config/prisma';
import { v4 as uuidv4 } from 'uuid';

describe('Matching Engine', () => {
  let pool: any;
  let redis: any;

  beforeAll(async () => {
    await initializeDatabase();
    await initializeRedis();
    pool = getPool();
    redis = getRedis();

    // Drop and recreate tables
    await pool.query('DROP TABLE IF EXISTS tasks CASCADE');
    await pool.query('DROP TABLE IF EXISTS helpers CASCADE');
    await pool.query('DROP TABLE IF EXISTS users CASCADE');

    // Create users table
    await pool.query(`
      CREATE TABLE users (
        id UUID PRIMARY KEY,
        phone_number VARCHAR(20) UNIQUE,
        name VARCHAR(255) NOT NULL,
        role VARCHAR(20) NOT NULL DEFAULT 'customer',
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        location_point JSONB,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create tasks table
    await pool.query(`
      CREATE TABLE tasks (
        id UUID PRIMARY KEY,
        task_id_display VARCHAR(20) UNIQUE,
        customer_id UUID NOT NULL REFERENCES users(id),
        helper_id UUID,
        task_type VARCHAR(20),
        category VARCHAR(100),
        description TEXT,
        location_point JSONB,
        location_name VARCHAR(255),
        preferred_date VARCHAR(20),
        preferred_time VARCHAR(20),
        budget_min NUMERIC(10,2),
        budget_max NUMERIC(10,2),
        status VARCHAR(50) DEFAULT 'unassigned',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create helpers table
    await pool.query(`
      CREATE TABLE helpers (
        id UUID PRIMARY KEY,
        user_id UUID NOT NULL REFERENCES users(id),
        helper_status VARCHAR(50) DEFAULT 'approved',
        rating NUMERIC(3,2) DEFAULT 5.0,
        total_tasks INT DEFAULT 0,
        service_radius_km INT DEFAULT 15,
        preferred_task_type VARCHAR(50),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);
  });

  afterAll(async () => {
    await pool.query('DROP TABLE IF EXISTS tasks CASCADE');
    await pool.query('DROP TABLE IF EXISTS helpers CASCADE');
    await pool.query('DROP TABLE IF EXISTS users CASCADE');
    await closeDatabase();
    await closeRedis();
  });

  afterEach(async () => {
    await redis.flushdb();
    await pool.query('DELETE FROM tasks');
    await pool.query('DELETE FROM helpers');
    await pool.query('DELETE FROM users');
  });

  describe('Helper Scoring', () => {
    it('should score helpers by distance (nearest)', async () => {
      // Create customer
      const customerId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 }; // Warangal

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [customerId, '+919999999999', 'Test Customer', 'customer', 'active', JSON.stringify(taskLocation)]
      );

      // Create helpers at different distances
      const helpers = [];
      const distances = [2, 5, 10, 15, 20]; // km from task

      for (let i = 0; i < distances.length; i++) {
        const userId = uuidv4();
        const helperId = uuidv4();
        const distance = distances[i];

        // Calculate offset position
        const lat = taskLocation.latitude + (distance / 111); // 1 degree ≈ 111 km
        const lng = taskLocation.longitude;

        await pool.query(
          'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
          [userId, `+919999999${String(i).padStart(3, '0')}`, `Helper ${i}`, 'helper', 'active', JSON.stringify({ latitude: lat, longitude: lng })]
        );

        await pool.query(
          'INSERT INTO helpers (id, user_id, helper_status, rating, total_tasks) VALUES ($1, $2, $3, $4, $5)',
          [helperId, userId, 'approved', 5.0, 10 + i]
        );

        helpers.push({ id: helperId, userId, expectedDistance: distance });
      }

      // Create task
      const taskId = uuidv4();
      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
        [taskId, 'SKT00001', customerId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'unassigned']
      );

      // Get nearby helpers (should be sorted by distance)
      const result = await taskService.getNearbyHelpers(taskId, customerId, { sort_by: 'nearest' });

      // Verify helpers are sorted by distance
      expect(result).toBeDefined();
      expect(result.length).toBeGreaterThan(0);

      // First helper should be closest
      const distances1 = result.map((h: any) => h.distance_km);
      for (let i = 0; i < distances1.length - 1; i++) {
        expect(distances1[i]).toBeLessThanOrEqual(distances1[i + 1]);
      }
    });

    it('should score helpers by rating', async () => {
      const customerId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [customerId, '+919999999999', 'Test Customer', 'customer', 'active', JSON.stringify(taskLocation)]
      );

      // Create helpers with different ratings
      const helpers = [];
      const ratings = [5.0, 4.5, 4.0, 3.5, 3.0];

      for (let i = 0; i < ratings.length; i++) {
        const userId = uuidv4();
        const helperId = uuidv4();

        await pool.query(
          'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
          [userId, `+919999999${String(i).padStart(3, '0')}`, `Helper ${i}`, 'helper', 'active', JSON.stringify(taskLocation)]
        );

        await pool.query(
          'INSERT INTO helpers (id, user_id, helper_status, rating, total_tasks) VALUES ($1, $2, $3, $4, $5)',
          [helperId, userId, 'approved', ratings[i], 10 + i]
        );

        helpers.push({ id: helperId, expectedRating: ratings[i] });
      }

      const taskId = uuidv4();
      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
        [taskId, 'SKT00001', customerId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'unassigned']
      );

      // Get helpers sorted by rating
      const result = await taskService.getNearbyHelpers(taskId, customerId, { sort_by: 'rating' });

      expect(result).toBeDefined();
      expect(result.length).toBeGreaterThan(0);

      // First helper should have highest rating
      const helperRatings = result.map((h: any) => h.rating);
      for (let i = 0; i < helperRatings.length - 1; i++) {
        expect(helperRatings[i]).toBeGreaterThanOrEqual(helperRatings[i + 1]);
      }
    });

    it('should exclude suspended helpers', async () => {
      const customerId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [customerId, '+919999999999', 'Test Customer', 'customer', 'active', JSON.stringify(taskLocation)]
      );

      // Create one suspended and one active helper
      const activeUserId = uuidv4();
      const activeHelperId = uuidv4();
      const suspendedUserId = uuidv4();
      const suspendedHelperId = uuidv4();

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [activeUserId, '+919999999001', 'Active Helper', 'helper', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [suspendedUserId, '+919999999002', 'Suspended Helper', 'helper', 'active', JSON.stringify(taskLocation)]
      );

      await pool.query(
        'INSERT INTO helpers (id, user_id, helper_status, rating, total_tasks) VALUES ($1, $2, $3, $4, $5)',
        [activeHelperId, activeUserId, 'approved', 4.5, 20]
      );

      await pool.query(
        'INSERT INTO helpers (id, user_id, helper_status, rating, total_tasks) VALUES ($1, $2, $3, $4, $5)',
        [suspendedHelperId, suspendedUserId, 'suspended', 4.0, 15]
      );

      const taskId = uuidv4();
      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
        [taskId, 'SKT00001', customerId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'unassigned']
      );

      const result = await taskService.getNearbyHelpers(taskId, customerId);

      // Suspended helper should not be in results
      const suspendedInResults = result.some((h: any) => h.id === suspendedHelperId);
      expect(suspendedInResults).toBe(false);

      // Active helper should be in results
      const activeInResults = result.some((h: any) => h.id === activeHelperId);
      expect(activeInResults).toBe(true);
    });

    it('should filter helpers outside service radius', async () => {
      const customerId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [customerId, '+919999999999', 'Test Customer', 'customer', 'active', JSON.stringify(taskLocation)]
      );

      // Create helpers with different service radius
      const helperConfigs = [
        { serviceRadius: 5, distance: 3 }, // Inside
        { serviceRadius: 5, distance: 8 }, // Outside
        { serviceRadius: 15, distance: 10 }, // Inside
        { serviceRadius: 10, distance: 12 }, // Outside
      ];

      for (let i = 0; i < helperConfigs.length; i++) {
        const { serviceRadius, distance } = helperConfigs[i];
        const userId = uuidv4();
        const helperId = uuidv4();

        const lat = taskLocation.latitude + (distance / 111);

        await pool.query(
          'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
          [userId, `+919999999${String(i).padStart(3, '0')}`, `Helper ${i}`, 'helper', 'active', JSON.stringify({ latitude: lat, longitude: taskLocation.longitude })]
        );

        await pool.query(
          'INSERT INTO helpers (id, user_id, helper_status, rating, total_tasks, service_radius_km) VALUES ($1, $2, $3, $4, $5, $6)',
          [helperId, userId, 'approved', 4.5, 10, serviceRadius]
        );
      }

      const taskId = uuidv4();
      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
        [taskId, 'SKT00001', customerId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'unassigned']
      );

      const result = await taskService.getNearbyHelpers(taskId, customerId);

      // Only 2 helpers should be within their service radius
      // Helper 0: 5km radius, 3km distance = inside
      // Helper 1: 5km radius, 8km distance = outside
      // Helper 2: 15km radius, 10km distance = inside
      // Helper 3: 10km radius, 12km distance = outside
      expect(result.length).toBe(2);
    });
  });

  describe('Task Type Matching', () => {
    it('should prioritize helpers with matching task type preferences', async () => {
      const customerId = uuidv4();
      const taskLocation = { latitude: 17.360589, longitude: 78.474845 };

      await pool.query(
        'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
        [customerId, '+919999999999', 'Test Customer', 'customer', 'active', JSON.stringify(taskLocation)]
      );

      // Create helpers with different task type preferences
      const helpers = [
        { userId: uuidv4(), helperId: uuidv4(), preference: 'personal' },
        { userId: uuidv4(), helperId: uuidv4(), preference: 'business' },
        { userId: uuidv4(), helperId: uuidv4(), preference: null }, // No preference
      ];

      for (const helper of helpers) {
        await pool.query(
          'INSERT INTO users (id, phone_number, name, role, status, location_point) VALUES ($1, $2, $3, $4, $5, $6)',
          [helper.userId, `+91999999999${helper.helperId.substring(0, 3)}`, 'Helper', 'helper', 'active', JSON.stringify(taskLocation)]
        );

        await pool.query(
          'INSERT INTO helpers (id, user_id, helper_status, rating, total_tasks, preferred_task_type) VALUES ($1, $2, $3, $4, $5, $6)',
          [helper.helperId, helper.userId, 'approved', 4.5, 10, helper.preference]
        );
      }

      const taskId = uuidv4();
      await pool.query(
        'INSERT INTO tasks (id, task_id_display, customer_id, task_type, category, description, location_point, location_name, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
        [taskId, 'SKT00001', customerId, 'personal', 'cleaning', 'Clean my home', JSON.stringify(taskLocation), 'Warangal', 'unassigned']
      );

      const result = await taskService.getNearbyHelpers(taskId, customerId);

      // Personal task should prioritize helpers with personal preference
      expect(result.length).toBeGreaterThan(0);
      // If sorting by preference implemented, personal-preference helper should rank higher
    });
  });
});
