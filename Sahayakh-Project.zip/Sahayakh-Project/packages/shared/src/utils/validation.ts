import Joi from 'joi';

const phoneRegex = /^\+?[1-9]\d{1,14}$/;
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const otpRegex = /^\d{6}$/;
const upiRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z]{3,}$/;

export const validatePhoneNumber = (phone: string): { valid: boolean; value?: string; error?: string } => {
  const trimmed = phone.trim();
  if (phoneRegex.test(trimmed)) {
    return { valid: true, value: trimmed };
  }
  return { valid: false, error: 'Invalid phone number format' };
};

export const validateEmail = (email: string): { valid: boolean; value?: string; error?: string } => {
  const trimmed = email.trim().toLowerCase();
  if (emailRegex.test(trimmed)) {
    return { valid: true, value: trimmed };
  }
  return { valid: false, error: 'Invalid email format' };
};

export const validateOTP = (otp: string): { valid: boolean; value?: string; error?: string } => {
  const trimmed = otp.trim();
  if (otpRegex.test(trimmed)) {
    return { valid: true, value: trimmed };
  }
  return { valid: false, error: 'OTP must be 6 digits' };
};

export const validatePassword = (password: string): { valid: boolean; error?: string } => {
  if (password.length < 8) {
    return { valid: false, error: 'Password must be at least 8 characters' };
  }
  return { valid: true };
};

export const validateName = (name: string): { valid: boolean; value?: string; error?: string } => {
  const trimmed = name.trim();
  if (trimmed.length >= 2 && trimmed.length <= 255) {
    return { valid: true, value: trimmed };
  }
  return { valid: false, error: 'Name must be between 2 and 255 characters' };
};

export const validateRole = (role: string): { valid: boolean; error?: string } => {
  if (['customer', 'helper', 'admin'].includes(role)) {
    return { valid: true };
  }
  return { valid: false, error: 'Invalid user role' };
};

export const validateUPI = (upi: string): { valid: boolean; value?: string; error?: string } => {
  const trimmed = upi.trim().toLowerCase();
  if (upiRegex.test(trimmed)) {
    return { valid: true, value: trimmed };
  }
  return { valid: false, error: 'Invalid UPI ID format' };
};

export const registerSchema = Joi.object({
  phone_number: Joi.string().required().messages({
    'string.empty': 'Phone number is required',
    'any.required': 'Phone number is required',
  }),
  name: Joi.string().min(2).max(255).required().messages({
    'string.min': 'Name must be at least 2 characters',
    'string.max': 'Name must not exceed 255 characters',
    'any.required': 'Name is required',
  }),
  role: Joi.string().valid('customer', 'helper').required().messages({
    'any.only': 'Role must be customer or helper',
    'any.required': 'Role is required',
  }),
});

export const verifyOTPSchema = Joi.object({
  phone_number: Joi.string().required().messages({
    'string.empty': 'Phone number is required',
    'any.required': 'Phone number is required',
  }),
  otp_code: Joi.string().length(6).pattern(/^\d+$/).required().messages({
    'string.length': 'OTP must be 6 digits',
    'string.pattern.base': 'OTP must contain only digits',
    'any.required': 'OTP code is required',
  }),
});

export const refreshTokenSchema = Joi.object({
  refresh_token: Joi.string().required().messages({
    'string.empty': 'Refresh token is required',
    'any.required': 'Refresh token is required',
  }),
});

export const adminLoginSchema = Joi.object({
  email: Joi.string().email().required().messages({
    'string.email': 'Invalid email format',
    'any.required': 'Email is required',
  }),
  password: Joi.string().min(8).required().messages({
    'string.min': 'Password must be at least 8 characters',
    'any.required': 'Password is required',
  }),
});

export const validate = (schema: Joi.ObjectSchema, data: unknown) => {
  const { error, value } = schema.validate(data, { abortEarly: false, stripUnknown: true });
  if (error) {
    return {
      valid: false,
      errors: error.details.map((e) => ({
        field: e.path.join('.'),
        message: e.message,
      })),
    };
  }
  return { valid: true, data: value };
};
