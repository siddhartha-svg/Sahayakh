export const AUTH_ERROR_CODES = {
  PHONE_ALREADY_EXISTS: 'PHONE_ALREADY_EXISTS',
  INVALID_OTP: 'INVALID_OTP',
  OTP_EXPIRED: 'OTP_EXPIRED',
  TOO_MANY_ATTEMPTS: 'TOO_MANY_ATTEMPTS',
  INVALID_TOKEN: 'INVALID_TOKEN',
  UNAUTHORIZED: 'UNAUTHORIZED',
  RATE_LIMIT_EXCEEDED: 'RATE_LIMIT_EXCEEDED',
  INVALID_CREDENTIALS: 'INVALID_CREDENTIALS',
  USER_NOT_FOUND: 'USER_NOT_FOUND',
  INVALID_PHONE_NUMBER: 'INVALID_PHONE_NUMBER',
  INVALID_EMAIL: 'INVALID_EMAIL',
  INVALID_ROLE: 'INVALID_ROLE',
  OTP_NOT_FOUND: 'OTP_NOT_FOUND',
  TOKEN_EXPIRED: 'TOKEN_EXPIRED',
  INVALID_REFRESH_TOKEN: 'INVALID_REFRESH_TOKEN',
} as const;

export const AUTH_ERROR_MESSAGES = {
  PHONE_ALREADY_EXISTS: 'Phone number already registered',
  INVALID_OTP: 'Invalid OTP code',
  OTP_EXPIRED: 'OTP has expired',
  TOO_MANY_ATTEMPTS: 'Too many OTP attempts. Please try again later.',
  INVALID_TOKEN: 'Invalid or malformed token',
  UNAUTHORIZED: 'Unauthorized access',
  RATE_LIMIT_EXCEEDED: 'Too many requests. Please try again later.',
  INVALID_CREDENTIALS: 'Invalid email or password',
  USER_NOT_FOUND: 'User not found',
  INVALID_PHONE_NUMBER: 'Invalid phone number format',
  INVALID_EMAIL: 'Invalid email format',
  INVALID_ROLE: 'Invalid user role',
  OTP_NOT_FOUND: 'OTP not found or expired',
  TOKEN_EXPIRED: 'Token has expired',
  INVALID_REFRESH_TOKEN: 'Invalid or expired refresh token',
} as const;

export const OTP_CONFIG = {
  LENGTH: parseInt(process.env.OTP_LENGTH || '6', 10),
  EXPIRY_MINUTES: parseInt(process.env.OTP_EXPIRY_MINUTES || '120', 10),
  MAX_ATTEMPTS: parseInt(process.env.OTP_MAX_ATTEMPTS || '3', 10),
  COOLDOWN_SECONDS: parseInt(process.env.OTP_COOLDOWN_SECONDS || '30', 10),
};

export const JWT_CONFIG = {
  EXPIRY: process.env.JWT_EXPIRY || '1h',
  REFRESH_EXPIRY: process.env.JWT_REFRESH_EXPIRY || '30d',
};

export const RATE_LIMIT_CONFIG = {
  WINDOW_MS: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000', 10),
  MAX_REQUESTS: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100', 10),
  OTP_REQUESTS_PER_HOUR: 10,
  LOGIN_ATTEMPTS_PER_15MIN: 10,
};

export const BCRYPT_ROUNDS = parseInt(process.env.BCRYPT_ROUNDS || '10', 10);

export const USER_ROLES = {
  CUSTOMER: 'customer' as const,
  HELPER: 'helper' as const,
  ADMIN: 'admin' as const,
};

export const USER_STATUSES = {
  ACTIVE: 'active' as const,
  SUSPENDED: 'suspended' as const,
  DELETED: 'deleted' as const,
};
