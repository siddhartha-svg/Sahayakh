import { UUID } from 'crypto';

export type UserRole = 'customer' | 'helper' | 'admin';
export type UserStatus = 'active' | 'suspended' | 'deleted';

export interface User {
  id: UUID;
  phone_number?: string;
  name: string;
  email?: string;
  role: UserRole;
  status: UserStatus;
  location_name?: string;
  created_at: Date;
  updated_at: Date;
  deleted_at?: Date | null;
}

export interface AuthRequest {
  phone_number: string;
  name?: string;
  role?: UserRole;
}

export interface OTPVerifyRequest {
  phone_number: string;
  otp_code: string;
}

export interface RefreshTokenRequest {
  refresh_token: string;
}

export interface AuthResponse {
  access_token: string;
  refresh_token: string;
  user_id: string;
  role: UserRole;
  user: {
    id: string;
    name: string;
    phone_number?: string;
    email?: string;
    role: UserRole;
    status: UserStatus;
  };
}

export interface AdminLoginRequest {
  email: string;
  password: string;
}

export interface TokenPayload {
  user_id: string;
  role: UserRole;
  iat: number;
  exp: number;
}

export interface OTPSentResponse {
  otp_sent: boolean;
  expires_in: number;
  message?: string;
}

export interface RefreshTokenResponse {
  access_token: string;
  refresh_token: string;
}

export interface MeResponse {
  id: string;
  name: string;
  phone_number?: string;
  email?: string;
  role: UserRole;
  status: UserStatus;
}

export interface ApiError {
  error_code: string;
  message: string;
  status: number;
  details?: Record<string, unknown>;
}
