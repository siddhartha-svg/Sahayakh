import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  ScrollView,
} from 'react-native';
import { useTheme, colors } from '../theme';
import { taskApi } from '../api/client';

interface Task {
  id: string;
  title: string;
  customerName: string;
  type: 'personal' | 'business';
  location: string;
  status: 'assigned' | 'on_the_way' | 'in_progress' | 'completed';
  duration?: number;
  distance?: number;
  amount: number;
  startedAt?: string;
  completedAt?: string;
}

export const MyTasksScreen: React.FC = () => {
  const { colorMode } = useTheme();
  const palette = colors[colorMode];
  const [activeTab, setActiveTab] = useState<'active' | 'completed'>('active');
  const [activeTasks, setActiveTasks] = useState<Task[]>([]);
  const [completedTasks, setCompletedTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const mockActiveTasks: Task[] = [
    {
      id: 't1',
      title: 'Pick up medicine from Apollo Pharmacy',
      customerName: 'Anil Reddy',
      type: 'personal',
      location: 'Hanamkonda, Warangal',
      status: 'on_the_way',
      distance: 0.8,
      amount: 280,
      startedAt: new Date(Date.now() - 5 * 60000).toISOString(),
    },
  ];

  const mockCompletedTasks: Task[] = [
    {
      id: 'c1',
      title: 'Collect lab report from clinic',
      customerName: 'Sneha V.',
      type: 'personal',
      location: 'Warangal',
      status: 'completed',
      duration: 31,
      distance: 3.9,
      amount: 179,
      completedAt: '21 Sep 2026, 9:12 AM',
    },
    {
      id: 'c2',
      title: 'Deliver signed invoices to client',
      customerName: 'Deccan Prints',
      type: 'business',
      location: 'Warangal',
      status: 'completed',
      duration: 44,
      distance: 5.1,
      amount: 289,
      completedAt: '21 Sep 2026, 8:20 AM',
    },
  ];

  useEffect(() => {
    loadTasks();
  }, []);

  const loadTasks = async () => {
    setLoading(true);
    try {
      // In production:
      // const active = await taskApi.getActiveTasks();
      // const completed = await taskApi.getCompletedTasks();
      await new Promise((r) => setTimeout(r, 600));
      setActiveTasks(mockActiveTasks);
      setCompletedTasks(mockCompletedTasks);
    } catch (error) {
      console.error('Failed to load tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadTasks();
    setRefreshing(false);
  };

  const renderTask = (item: Task) => (
    <TouchableOpacity
      style={[styles.taskCard, { backgroundColor: palette.surface }]}
      onPress={() => {}}
    >
      <View style={styles.taskHeader}>
        <View style={{ flex: 1 }}>
          <View style={styles.taskBadge}>
            <Text
              style={[
                styles.taskBadgeText,
                {
                  color:
                    item.type === 'business'
                      ? palette.bizText
                      : palette.accentText,
                  backgroundColor:
                    item.type === 'business'
                      ? palette.bizSoft
                      : palette.accentSoft,
                },
              ]}
            >
              {item.type === 'business' ? '💼 Business' : '👤 Personal'}
            </Text>
          </View>
          <Text style={[styles.taskTitle, { color: palette.ink }]}>
            {item.title}
          </Text>
        </View>
        <Text
          style={[
            styles.taskAmount,
            { color: palette.accentText },
          ]}
        >
          ₹{item.amount}
        </Text>
      </View>

      <View style={styles.taskMeta}>
        <Text style={[styles.taskMetaText, { color: palette.muted }]}>
          {item.customerName}
        </Text>
        <Text style={[styles.taskMetaText, { color: palette.muted }]}>
          📍 {item.location}
        </Text>
      </View>

      {activeTab === 'active' ? (
        <View style={styles.taskStatus}>
          <View
            style={[
              styles.statusDot,
              { backgroundColor: palette.accent.personal },
            ]}
          />
          <Text style={[styles.statusText, { color: palette.accentText }]}>
            {item.status === 'on_the_way'
              ? `On the way • ${item.distance}km`
              : item.status === 'assigned'
              ? 'Assigned • Ready to start'
              : 'In progress'}
          </Text>
        </View>
      ) : (
        <View style={styles.taskStats}>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: palette.ink }]}>
              {item.duration}
            </Text>
            <Text style={[styles.statLabel, { color: palette.muted }]}>
              mins
            </Text>
          </View>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: palette.ink }]}>
              {item.distance}km
            </Text>
            <Text style={[styles.statLabel, { color: palette.muted }]}>
              distance
            </Text>
          </View>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: palette.accentText }]}>
              ₹{item.amount}
            </Text>
            <Text style={[styles.statLabel, { color: palette.muted }]}>
              earned
            </Text>
          </View>
        </View>
      )}
    </TouchableOpacity>
  );

  const displayTasks = activeTab === 'active' ? activeTasks : completedTasks;

  return (
    <View style={[styles.container, { backgroundColor: palette.page }]}>
      <View style={[styles.header, { backgroundColor: palette.surface }]}>
        <Text style={[styles.title, { color: palette.ink }]}>My Tasks</Text>
      </View>

      {/* Tab Switcher */}
      <View style={[styles.tabs, { backgroundColor: palette.surface }]}>
        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'active' && [
              styles.activeTab,
              { borderBottomColor: palette.accent.personal },
            ],
          ]}
          onPress={() => setActiveTab('active')}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === 'active' && { color: palette.accentText },
              activeTab !== 'active' && { color: palette.muted },
            ]}
          >
            Active
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.tab,
            activeTab === 'completed' && [
              styles.activeTab,
              { borderBottomColor: palette.accent.personal },
            ],
          ]}
          onPress={() => setActiveTab('completed')}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === 'completed' && { color: palette.accentText },
              activeTab !== 'completed' && { color: palette.muted },
            ]}
          >
            Completed
          </Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={displayTasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => renderTask(item)}
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        ListEmptyComponent={
          !loading ? (
            <View style={[styles.empty, { marginTop: 40 }]}>
              <Text style={[styles.emptyTitle, { color: palette.ink }]}>
                No {activeTab} tasks
              </Text>
              <Text style={[styles.emptyText, { color: palette.muted }]}>
                {activeTab === 'active'
                  ? 'Go online to accept new tasks'
                  : 'Your completed tasks will appear here'}
              </Text>
            </View>
          ) : (
            <ActivityIndicator
              size="large"
              color={palette.accent.personal}
              style={{ marginTop: 40 }}
            />
          )
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 18,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  title: {
    fontSize: 20,
    fontWeight: '800',
  },
  tabs: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  tab: {
    flex: 1,
    paddingVertical: 14,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  activeTab: {
    borderBottomWidth: 2,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '700',
  },
  list: {
    paddingHorizontal: 18,
    paddingVertical: 12,
  },
  taskCard: {
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 14,
    padding: 12,
    marginBottom: 10,
  },
  taskHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 8,
  },
  taskBadge: {
    marginBottom: 6,
  },
  taskBadgeText: {
    fontSize: 12.5,
    fontWeight: '700',
    paddingHorizontal: 9,
    paddingVertical: 3,
    borderRadius: 999,
    overflow: 'hidden',
  },
  taskTitle: {
    fontSize: 14,
    fontWeight: '700',
    marginTop: 4,
  },
  taskAmount: {
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.02,
  },
  taskMeta: {
    gap: 4,
    marginBottom: 10,
  },
  taskMetaText: {
    fontSize: 12.5,
  },
  taskStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusText: {
    fontSize: 13,
    fontWeight: '600',
  },
  taskStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 14,
    fontWeight: '800',
  },
  statLabel: {
    fontSize: 11,
    marginTop: 2,
  },
  empty: {
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  emptyTitle: {
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 4,
  },
  emptyText: {
    fontSize: 14,
    textAlign: 'center',
  },
});
