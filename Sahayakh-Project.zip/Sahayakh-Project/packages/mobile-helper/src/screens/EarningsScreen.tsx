import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  TextInput,
  FlatList,
  RefreshControl,
  Modal,
  Animated,
} from 'react-native';
import { useTheme, colors } from '../theme';
import { earningsApi } from '../api/client';
import { Button } from '../components/Button';

interface Payout {
  id: string;
  amount: number;
  to: string;
  date: string;
  status: 'pending' | 'completed' | 'failed';
}

interface Earning {
  id: string;
  title: string;
  amount: number;
  date: string;
  type: 'personal' | 'business';
}

interface PaymentMethod {
  id: string;
  type: 'upi' | 'bank';
  label: string;
  details: string;
  isDefault: boolean;
}

export const EarningsScreen: React.FC = () => {
  const { colorMode } = useTheme();
  const palette = colors[colorMode];
  const [balance, setBalance] = useState(3480);
  const [totalEarnings, setTotalEarnings] = useState(5847);
  const [earnings, setEarnings] = useState<Earning[]>([]);
  const [payouts, setPayouts] = useState<Payout[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [withdrawalTab, setWithdrawalTab] = useState<'history' | 'withdraw'>('history');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null);
  const [showMethodSheet, setShowMethodSheet] = useState(false);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [weeklyData] = useState([980, 1120, 760, 1340, 1050, 890, 1320]);

  const mockEarnings: Earning[] = [
    { id: 'e1', title: 'Pick up medicine from Apollo Pharmacy', amount: 275, date: '22 Sep 2026', type: 'personal' },
    { id: 'e2', title: 'Collect lab report from clinic', amount: 179, date: '21 Sep 2026', type: 'personal' },
    { id: 'e3', title: 'Deliver signed invoices to client', amount: 289, date: '21 Sep 2026', type: 'business' },
    { id: 'e4', title: 'Pick up parcel from courier office', amount: 153, date: '20 Sep 2026', type: 'personal' },
    { id: 'e5', title: 'Collect cheques from bank', amount: 247, date: '20 Sep 2026', type: 'business' },
  ];

  const mockPayouts: Payout[] = [
    { id: 'p1', amount: 1500, to: 'UPI rohit@upi', date: '19 Sep 2026', status: 'completed' },
    { id: 'p2', amount: 2200, to: 'HDFC Bank ****4821', date: '14 Sep 2026', status: 'completed' },
    { id: 'p3', amount: 890, to: 'UPI rohit@upi', date: '12 Sep 2026', status: 'completed' },
  ];

  const mockPaymentMethods: PaymentMethod[] = [
    { id: 'm1', type: 'upi', label: 'UPI', details: 'rohit@upi', isDefault: true },
    { id: 'm2', type: 'bank', label: 'Bank Account', details: 'HDFC Bank ****4821', isDefault: false },
  ];

  useEffect(() => {
    loadEarnings();
  }, []);

  const loadEarnings = async () => {
    setLoading(true);
    try {
      // In production:
      // const balanceData = await earningsApi.getBalance();
      // const earningsData = await earningsApi.getEarningsHistory();
      // const payoutsData = await earningsApi.getPayoutHistory();
      // const methodsData = await earningsApi.getWithdrawalMethods();
      await new Promise((r) => setTimeout(r, 600));
      setEarnings(mockEarnings);
      setPayouts(mockPayouts);
      setPaymentMethods(mockPaymentMethods);
      setSelectedMethod(mockPaymentMethods[0]);
    } catch (error) {
      console.error('Failed to load earnings:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadEarnings();
    setRefreshing(false);
  };

  const handleWithdrawal = async () => {
    if (!withdrawAmount || parseFloat(withdrawAmount) < 100) {
      alert('Minimum withdrawal amount is ₹100');
      return;
    }

    if (parseFloat(withdrawAmount) > balance) {
      alert('Insufficient balance');
      return;
    }

    if (!selectedMethod) {
      alert('Please select a payment method');
      return;
    }

    setLoading(true);
    try {
      // await earningsApi.initiateWithdrawal(
      //   parseFloat(withdrawAmount),
      //   selectedMethod.type,
      //   { methodId: selectedMethod.id }
      // );
      await new Promise((r) => setTimeout(r, 800));
      alert('Withdrawal request submitted successfully!');
      setWithdrawAmount('');
      setWithdrawalTab('history');
      setBalance((prev) => prev - parseFloat(withdrawAmount));
      await loadEarnings();
    } catch (error) {
      console.error('Withdrawal failed:', error);
      alert('Withdrawal failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getMaxAmount = () => {
    return Math.min(balance, 50000); // Max withdrawal per request
  };

  return (
    <View style={[styles.container, { backgroundColor: palette.page }]}>
      <View style={[styles.header, { backgroundColor: palette.surface }]}>
        <Text style={[styles.title, { color: palette.ink }]}>Earnings</Text>
      </View>

      <ScrollView
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {/* Balance Card */}
        <View style={[styles.balanceCard, { backgroundColor: palette.accentDeep }]}>
          <View style={styles.balanceTop}>
            <View>
              <Text style={styles.balanceLabel}>Available Balance</Text>
              <Text style={styles.balanceAmount}>₹{balance.toLocaleString('en-IN')}</Text>
            </View>
            <Button
              label="Withdraw"
              onPress={() => setWithdrawalTab('withdraw')}
              variant="primary"
              size="small"
              style={{ backgroundColor: '#fff', height: 40 }}
            />
          </View>
        </View>

        {/* Total Earnings Card */}
        <View
          style={[
            styles.totalCard,
            { backgroundColor: palette.surface, borderColor: palette.line },
          ]}
        >
          <View style={styles.totalItem}>
            <Text style={[styles.totalLabel, { color: palette.muted }]}>
              Total Earnings
            </Text>
            <Text style={[styles.totalValue, { color: palette.accentText }]}>
              ₹{totalEarnings.toLocaleString('en-IN')}
            </Text>
          </View>
          <View style={[styles.totalDivider, { backgroundColor: palette.line }]} />
          <View style={styles.totalItem}>
            <Text style={[styles.totalLabel, { color: palette.muted }]}>
              Tasks Completed
            </Text>
            <Text style={[styles.totalValue, { color: palette.ink }]}>
              {earnings.length + 3}
            </Text>
          </View>
        </View>

        {/* Weekly Earnings Chart */}
        <View style={[styles.chartSection, { paddingHorizontal: 18, paddingTop: 16 }]}>
          <Text style={[styles.chartTitle, { color: palette.ink }]}>This Week</Text>
          <View style={styles.chart}>
            {weeklyData.map((value, i) => {
              const maxValue = Math.max(...weeklyData);
              const isToday = i === 6;
              return (
                <View key={i} style={styles.chartBar}>
                  <View
                    style={[
                      styles.chartBarFill,
                      {
                        height: (value / maxValue) * 100 + '%',
                        backgroundColor: isToday
                          ? palette.accent.personal
                          : palette.accentSoft,
                      },
                    ]}
                  />
                  <View style={styles.chartBarLabel}>
                    <Text
                      style={[
                        styles.chartBarLabelText,
                        {
                          color: isToday ? palette.ink : palette.muted,
                        },
                      ]}
                    >
                      {i === 0
                        ? 'M'
                        : i === 1
                        ? 'T'
                        : i === 2
                        ? 'W'
                        : i === 3
                        ? 'T'
                        : i === 4
                        ? 'F'
                        : i === 5
                        ? 'S'
                        : 'T'}
                    </Text>
                    {isToday && (
                      <Text style={[styles.todayLabel, { color: palette.muted }]}>
                        Today
                      </Text>
                    )}
                  </View>
                </View>
              );
            })}
          </View>
        </View>

        {/* Tab Switcher */}
        <View style={[styles.tabs, { borderTopColor: palette.line }]}>
          <TouchableOpacity
            style={[
              styles.tab,
              withdrawalTab === 'history' && {
                borderBottomColor: palette.accent.personal,
              },
            ]}
            onPress={() => setWithdrawalTab('history')}
          >
            <Text
              style={[
                styles.tabText,
                withdrawalTab === 'history' && { color: palette.accentText },
                withdrawalTab !== 'history' && { color: palette.muted },
              ]}
            >
              History
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.tab,
              withdrawalTab === 'withdraw' && {
                borderBottomColor: palette.accent.personal,
              },
            ]}
            onPress={() => setWithdrawalTab('withdraw')}
          >
            <Text
              style={[
                styles.tabText,
                withdrawalTab === 'withdraw' && { color: palette.accentText },
                withdrawalTab !== 'withdraw' && { color: palette.muted },
              ]}
            >
              Withdraw
            </Text>
          </TouchableOpacity>
        </View>

        {/* Content */}
        {withdrawalTab === 'history' ? (
          <View style={styles.historySection}>
            <Text style={[styles.sectionTitle, { color: palette.ink }]}>
              Recent Payouts
            </Text>
            <FlatList
              data={payouts}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
              renderItem={({ item }) => (
                <View style={[styles.payoutItem, { backgroundColor: palette.surface }]}>
                  <View style={[styles.payoutIcon, { backgroundColor: palette.amberBg }]}>
                    <Text style={styles.payoutIconText}>💰</Text>
                  </View>
                  <View style={styles.payoutInfo}>
                    <Text style={[styles.payoutTo, { color: palette.ink }]}>
                      {item.to}
                    </Text>
                    <Text style={[styles.payoutDate, { color: palette.muted }]}>
                      {item.date}
                    </Text>
                  </View>
                  <View style={styles.payoutAmount}>
                    <Text
                      style={[
                        styles.payoutAmountText,
                        {
                          color:
                            item.status === 'completed'
                              ? palette.success
                              : palette.muted,
                        },
                      ]}
                    >
                      +₹{item.amount}
                    </Text>
                    <Text style={[styles.payoutStatus, { color: palette.muted }]}>
                      {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                    </Text>
                  </View>
                </View>
              )}
            />

            <Text style={[styles.sectionTitle, { color: palette.ink, marginTop: 20 }]}>
              Recent Earnings
            </Text>
            <FlatList
              data={earnings}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
              renderItem={({ item }) => (
                <View style={[styles.earningItem, { backgroundColor: palette.surface }]}>
                  <View
                    style={[
                      styles.earningIcon,
                      {
                        backgroundColor:
                          item.type === 'business' ? palette.bizSoft : palette.accentSoft,
                      },
                    ]}
                  >
                    <Text style={[styles.earningIconText, { color: item.type === 'business' ? palette.bizText : palette.accentText }]}>
                      {item.type === 'business' ? '💼' : '✓'}
                    </Text>
                  </View>
                  <View style={styles.earningInfo}>
                    <Text style={[styles.earningTitle, { color: palette.ink }]}>
                      {item.title}
                    </Text>
                    <Text style={[styles.earningDate, { color: palette.muted }]}>
                      {item.date}
                    </Text>
                  </View>
                  <Text style={[styles.earningAmount, { color: palette.accentText }]}>
                    ₹{item.amount}
                  </Text>
                </View>
              )}
            />
          </View>
        ) : (
          <View style={styles.withdrawSection}>
            <Text style={[styles.sectionTitle, { color: palette.ink }]}>
              Request Withdrawal
            </Text>

            {/* Amount Input */}
            <View style={styles.formGroup}>
              <Text style={[styles.label, { color: palette.ink }]}>Amount (₹)</Text>
              <View
                style={[
                  styles.input,
                  { borderColor: palette.line, backgroundColor: palette.surface },
                ]}
              >
                <Text style={{ color: palette.muted, fontSize: 16, marginRight: 4 }}>
                  ₹
                </Text>
                <TextInput
                  style={{ flex: 1, fontSize: 16, color: palette.ink }}
                  placeholder="Enter amount"
                  keyboardType="number-pad"
                  value={withdrawAmount}
                  onChangeText={setWithdrawAmount}
                  placeholderTextColor={palette.muted}
                />
              </View>
              <View style={styles.hintRow}>
                <Text style={[styles.hint, { color: palette.muted, flex: 1 }]}>
                  Min: ₹100 • Max: ₹{getMaxAmount().toLocaleString('en-IN')}
                </Text>
                <TouchableOpacity
                  onPress={() =>
                    setWithdrawAmount(Math.min(balance, 50000).toString())
                  }
                >
                  <Text style={[styles.maxLink, { color: palette.accentText }]}>
                    Max
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* Payment Method Selection */}
            <View style={styles.formGroup}>
              <Text style={[styles.label, { color: palette.ink }]}>Payment Method</Text>

              {paymentMethods.map((method) => (
                <TouchableOpacity
                  key={method.id}
                  style={[
                    styles.methodOption,
                    {
                      borderColor:
                        selectedMethod?.id === method.id
                          ? palette.accent.personal
                          : palette.line,
                      backgroundColor:
                        selectedMethod?.id === method.id
                          ? palette.accentSoft
                          : palette.surface,
                    },
                  ]}
                  onPress={() => setSelectedMethod(method)}
                >
                  <View
                    style={[
                      styles.radioButton,
                      {
                        borderColor:
                          selectedMethod?.id === method.id
                            ? palette.accent.personal
                            : palette.muted,
                        backgroundColor:
                          selectedMethod?.id === method.id
                            ? palette.accent.personal
                            : 'transparent',
                      },
                    ]}
                  >
                    {selectedMethod?.id === method.id && (
                      <Text style={styles.radioCheck}>✓</Text>
                    )}
                  </View>
                  <View style={{ flex: 1 }}>
                    <View style={styles.methodHeader}>
                      <Text style={[styles.methodTitle, { color: palette.ink }]}>
                        {method.label}
                      </Text>
                      {method.isDefault && (
                        <Text style={[styles.defaultBadge, { color: palette.accentText }]}>
                          Default
                        </Text>
                      )}
                    </View>
                    <Text style={[styles.methodSubtitle, { color: palette.muted }]}>
                      {method.details}
                    </Text>
                    <Text style={[styles.methodSpeed, { color: palette.muted }]}>
                      {method.type === 'upi' ? 'Instant' : '1-2 business days'}
                    </Text>
                  </View>
                </TouchableOpacity>
              ))}

              <TouchableOpacity
                style={[styles.addMethodButton, { borderColor: palette.line }]}
                onPress={() => {
                  // Navigate to add payment method screen
                }}
              >
                <Text style={[styles.addMethodText, { color: palette.accentText }]}>
                  + Add Payment Method
                </Text>
              </TouchableOpacity>
            </View>

            {/* Amount Summary */}
            {withdrawAmount && (
              <View
                style={[
                  styles.summaryBox,
                  {
                    backgroundColor: palette.accentSoft,
                    borderColor: palette.accentText,
                  },
                ]}
              >
                <View style={styles.summaryRow}>
                  <Text style={[styles.summaryLabel, { color: palette.ink }]}>
                    Withdrawal Amount
                  </Text>
                  <Text style={[styles.summaryValue, { color: palette.accentText }]}>
                    ₹{parseInt(withdrawAmount || '0').toLocaleString('en-IN')}
                  </Text>
                </View>
                <View style={[styles.summaryDivider, { backgroundColor: palette.line }]} />
                <View style={styles.summaryRow}>
                  <Text style={[styles.summaryLabel, { color: palette.muted }]}>
                    Processing Fee
                  </Text>
                  <Text style={[styles.summaryValue, { color: palette.muted }]}>
                    Free
                  </Text>
                </View>
                <View style={[styles.summaryDivider, { backgroundColor: palette.line }]} />
                <View style={styles.summaryRow}>
                  <Text style={[styles.summaryLabel, { color: palette.ink, fontWeight: '700' }]}>
                    You Receive
                  </Text>
                  <Text style={[styles.summaryValue, { color: palette.accentText, fontWeight: '800' }]}>
                    ₹{parseInt(withdrawAmount || '0').toLocaleString('en-IN')}
                  </Text>
                </View>
              </View>
            )}

            {/* Submit Button */}
            <Button
              label="Request Withdrawal"
              onPress={handleWithdrawal}
              variant="primary"
              loading={loading}
              disabled={!withdrawAmount || !selectedMethod}
              style={{ marginTop: 20, marginBottom: 30 }}
            />
          </View>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 18,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  title: {
    fontSize: 20,
    fontWeight: '800',
  },
  balanceCard: {
    borderRadius: 22,
    padding: 16,
    marginHorizontal: 18,
    marginTop: 20,
  },
  balanceTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  balanceLabel: {
    fontSize: 13,
    color: '#fff',
    opacity: 0.9,
    fontWeight: '700',
    marginBottom: 6,
  },
  balanceAmount: {
    fontSize: 36,
    fontWeight: '800',
    letterSpacing: -0.03,
    color: '#fff',
  },
  totalCard: {
    borderWidth: 1,
    borderRadius: 16,
    padding: 14,
    marginHorizontal: 18,
    marginTop: 14,
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  totalItem: {
    flex: 1,
    alignItems: 'center',
  },
  totalLabel: {
    fontSize: 11.5,
    marginBottom: 6,
  },
  totalValue: {
    fontSize: 18,
    fontWeight: '800',
  },
  totalDivider: {
    width: 1,
    height: 40,
  },
  chartSection: {
    marginTop: 16,
  },
  chartTitle: {
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 12,
  },
  chart: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    height: 180,
    gap: 8,
    paddingVertical: 12,
  },
  chartBar: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end',
    height: '100%',
  },
  chartBarFill: {
    width: '100%',
    maxWidth: 28,
    borderRadius: 8,
    borderBottomLeftRadius: 4,
    borderBottomRightRadius: 4,
  },
  chartBarLabel: {
    alignItems: 'center',
    marginTop: 8,
  },
  chartBarLabelText: {
    fontSize: 11,
    fontWeight: '600',
  },
  todayLabel: {
    fontSize: 9,
    marginTop: 2,
  },
  tabs: {
    flexDirection: 'row',
    borderTopWidth: 1,
    marginTop: 20,
  },
  tab: {
    flex: 1,
    paddingVertical: 14,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '700',
  },
  historySection: {
    paddingHorizontal: 18,
    paddingVertical: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 12,
  },
  payoutItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 12,
    paddingHorizontal: 12,
    marginBottom: 10,
    borderRadius: 14,
  },
  payoutIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  payoutIconText: {
    fontSize: 20,
  },
  payoutInfo: {
    flex: 1,
  },
  payoutTo: {
    fontSize: 14,
    fontWeight: '700',
  },
  payoutDate: {
    fontSize: 12,
    marginTop: 2,
  },
  payoutAmount: {
    alignItems: 'flex-end',
  },
  payoutAmountText: {
    fontSize: 14,
    fontWeight: '800',
  },
  payoutStatus: {
    fontSize: 11,
    marginTop: 2,
  },
  earningItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 12,
    paddingHorizontal: 12,
    marginBottom: 10,
    borderRadius: 14,
  },
  earningIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  earningIconText: {
    fontSize: 16,
  },
  earningInfo: {
    flex: 1,
  },
  earningTitle: {
    fontSize: 14,
    fontWeight: '700',
    overflow: 'hidden',
  },
  earningDate: {
    fontSize: 12,
    marginTop: 2,
  },
  earningAmount: {
    fontSize: 16,
    fontWeight: '800',
  },
  withdrawSection: {
    paddingHorizontal: 18,
    paddingVertical: 16,
  },
  formGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 8,
  },
  input: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1.5,
    borderRadius: 12,
    paddingHorizontal: 12,
    minHeight: 48,
  },
  hint: {
    fontSize: 12,
    marginTop: 6,
  },
  methodOption: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    borderWidth: 1.5,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 12,
    marginBottom: 10,
  },
  radioButton: {
    width: 20,
    height: 20,
    borderRadius: 50,
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 2,
    flexShrink: 0,
  },
  radioCheck: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
  },
  methodHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  methodTitle: {
    fontSize: 14,
    fontWeight: '700',
    flex: 1,
  },
  defaultBadge: {
    fontSize: 11,
    fontWeight: '700',
  },
  methodSubtitle: {
    fontSize: 12.5,
    marginTop: 4,
  },
  methodSpeed: {
    fontSize: 11.5,
    marginTop: 2,
  },
  addMethodButton: {
    borderWidth: 1.5,
    borderStyle: 'dashed',
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 12,
    marginBottom: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addMethodText: {
    fontSize: 13.5,
    fontWeight: '700',
  },
  summaryBox: {
    borderWidth: 1,
    borderRadius: 14,
    padding: 14,
    marginBottom: 18,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  summaryLabel: {
    fontSize: 13.5,
  },
  summaryValue: {
    fontSize: 15,
    fontWeight: '800',
  },
  summaryDivider: {
    height: 1,
  },
  hintRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 6,
  },
  maxLink: {
    fontSize: 13,
    fontWeight: '700',
  },
});
