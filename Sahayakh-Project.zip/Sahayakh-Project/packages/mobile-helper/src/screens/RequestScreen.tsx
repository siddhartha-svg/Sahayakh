import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Image,
} from 'react-native';
import { useTheme, colors } from '../theme';
import { useNavigation } from '@react-navigation/native';
import { Button } from '../components/Button';
import { taskApi } from '../api/client';

interface RequestData {
  id: string;
  title: string;
  description: string;
  type: 'personal' | 'business';
  location: string;
  customerName: string;
  customerRating: number;
  customerReviews: number;
  amount: number;
  estimatedDuration: number;
  distance: number;
  eta: number;
  instructions: string;
}

export const RequestScreen: React.FC<{ route: any }> = ({ route }) => {
  const { colorMode } = useTheme();
  const palette = colors[colorMode];
  const navigation = useNavigation<any>();
  const [loading, setLoading] = useState(false);

  const request: RequestData = route?.params?.request || {
    id: 'r1',
    title: 'Pick up medicine from Apollo Pharmacy and deliver it to my home.',
    description: 'Need to pick up prescribed medicine from Apollo Pharmacy Hanamkonda branch',
    type: 'personal',
    location: 'Hanamkonda, Warangal',
    customerName: 'Anil Reddy',
    customerRating: 4.9,
    customerReviews: 128,
    amount: 280,
    estimatedDuration: 18,
    distance: 1.2,
    eta: 6,
    instructions: 'Show medicine bill to customer. Deliver between 10-11 AM',
  };

  const handleAccept = async () => {
    setLoading(true);
    try {
      // await taskApi.acceptTask(request.id);
      await new Promise((r) => setTimeout(r, 800));
      navigation.navigate('Navigate', { taskId: request.id, request });
    } catch (error) {
      console.error('Failed to accept request:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDecline = async () => {
    setLoading(true);
    try {
      // await taskApi.declineTask(request.id);
      await new Promise((r) => setTimeout(r, 600));
      navigation.goBack();
    } catch (error) {
      console.error('Failed to decline request:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={[styles.container, { backgroundColor: palette.page }]}>
      <View style={[styles.header, { backgroundColor: palette.surface }]}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}
        >
          <Text style={[styles.backIcon, { color: palette.ink }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: palette.ink }]}>
          New Request
        </Text>
      </View>

      <View style={styles.body}>
        {/* Task Title */}
        <Text style={[styles.taskTitle, { color: palette.ink }]}>
          {request.title}
        </Text>

        {/* Type Badge & Amount */}
        <View style={styles.badgeRow}>
          <View
            style={[
              styles.typeBadge,
              {
                backgroundColor:
                  request.type === 'business'
                    ? palette.bizSoft
                    : palette.accentSoft,
              },
            ]}
          >
            <Text style={styles.typeEmoji}>
              {request.type === 'business' ? '💼' : '👤'}
            </Text>
            <Text
              style={[
                styles.typeLabel,
                {
                  color:
                    request.type === 'business'
                      ? palette.bizText
                      : palette.accentText,
                },
              ]}
            >
              {request.type === 'business' ? 'Business' : 'Personal'}
            </Text>
          </View>
          <Text style={[styles.amount, { color: palette.accentText }]}>
            ₹{request.amount}
          </Text>
        </View>

        {/* Location & Distance */}
        <View style={styles.detailSection}>
          <Text style={[styles.detailLabel, { color: palette.muted }]}>
            📍 LOCATION
          </Text>
          <Text style={[styles.detailValue, { color: palette.ink }]}>
            {request.location}
          </Text>
          <View style={styles.distanceRow}>
            <Text style={[styles.distanceText, { color: palette.muted }]}>
              {request.distance}km away • {request.eta} mins
            </Text>
          </View>
        </View>

        {/* Duration */}
        <View style={styles.detailSection}>
          <Text style={[styles.detailLabel, { color: palette.muted }]}>
            ⏱️ ESTIMATED TIME
          </Text>
          <Text style={[styles.detailValue, { color: palette.ink }]}>
            {request.estimatedDuration} minutes
          </Text>
        </View>

        {/* Description */}
        <View style={styles.detailSection}>
          <Text style={[styles.detailLabel, { color: palette.muted }]}>
            📝 DETAILS
          </Text>
          <Text style={[styles.detailValue, { color: palette.ink }]}>
            {request.description}
          </Text>
        </View>

        {/* Instructions */}
        <View
          style={[
            styles.instructionBox,
            { backgroundColor: palette.accentSoft, borderColor: palette.accentText },
          ]}
        >
          <Text style={[styles.instructionTitle, { color: palette.accentText }]}>
            📋 Special Instructions
          </Text>
          <Text style={[styles.instructionText, { color: palette.ink }]}>
            {request.instructions}
          </Text>
        </View>

        {/* Customer Section */}
        <View style={styles.detailSection}>
          <Text style={[styles.detailLabel, { color: palette.muted }]}>
            CUSTOMER
          </Text>
          <View style={styles.customerCard}>
            <View
              style={[
                styles.customerAvatar,
                { backgroundColor: palette.accentSoft },
              ]}
            >
              <Text style={[styles.customerInitial, { color: palette.accentText }]}>
                {request.customerName[0]}
              </Text>
            </View>
            <View style={styles.customerInfo}>
              <Text style={[styles.customerName, { color: palette.ink }]}>
                {request.customerName}
              </Text>
              <View style={styles.customerRating}>
                <Text style={styles.stars}>
                  {'⭐'.repeat(Math.floor(request.customerRating))}
                </Text>
                <Text style={[styles.ratingText, { color: palette.muted }]}>
                  {request.customerRating} • {request.customerReviews} reviews
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* Contact Customer */}
        <View style={styles.contactSection}>
          <Button
            label="Call Customer"
            onPress={() => {}}
            variant="secondary"
            style={{ marginBottom: 10 }}
          />
          <Button
            label="Message Customer"
            onPress={() => {}}
            variant="ghost"
          />
        </View>

        {/* Action Buttons */}
        <View style={styles.actions}>
          <Button
            label="Accept Request"
            onPress={handleAccept}
            variant="primary"
            loading={loading}
            style={{ marginBottom: 10 }}
          />
          <Button
            label="Decline"
            onPress={handleDecline}
            variant="secondary"
            loading={loading}
          />
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    fontSize: 22,
    fontWeight: '700',
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: '700',
    flex: 1,
    textAlign: 'center',
  },
  body: {
    paddingHorizontal: 18,
    paddingVertical: 16,
  },
  taskTitle: {
    fontSize: 18,
    fontWeight: '700',
    lineHeight: 1.3,
    marginBottom: 12,
  },
  badgeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  typeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
  },
  typeEmoji: {
    fontSize: 14,
  },
  typeLabel: {
    fontSize: 12,
    fontWeight: '700',
  },
  amount: {
    fontSize: 20,
    fontWeight: '800',
  },
  detailSection: {
    marginBottom: 18,
  },
  detailLabel: {
    fontSize: 11.5,
    fontWeight: '700',
    marginBottom: 6,
    letterSpacing: 0.5,
  },
  detailValue: {
    fontSize: 15,
    fontWeight: '600',
    lineHeight: 1.4,
  },
  distanceRow: {
    marginTop: 6,
  },
  distanceText: {
    fontSize: 12.5,
  },
  instructionBox: {
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 12,
    marginBottom: 20,
  },
  instructionTitle: {
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 6,
  },
  instructionText: {
    fontSize: 13.5,
    lineHeight: 1.4,
  },
  customerCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
  },
  customerAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  customerInitial: {
    fontSize: 18,
    fontWeight: '800',
  },
  customerInfo: {
    flex: 1,
  },
  customerName: {
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 4,
  },
  customerRating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  stars: {
    fontSize: 12,
  },
  ratingText: {
    fontSize: 12.5,
  },
  contactSection: {
    marginTop: 16,
    marginBottom: 20,
  },
  actions: {
    gap: 10,
    paddingBottom: 20,
  },
});
