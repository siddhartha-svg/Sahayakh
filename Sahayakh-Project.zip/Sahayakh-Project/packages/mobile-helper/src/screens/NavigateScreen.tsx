import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { useTheme, colors } from '../theme';
import { useNavigation } from '@react-navigation/native';
import { Button } from '../components/Button';

interface StepStatus {
  label: string;
  icon: string;
  completed: boolean;
  current: boolean;
}

export const NavigateScreen: React.FC<{ route: any }> = ({ route }) => {
  const { colorMode } = useTheme();
  const palette = colors[colorMode];
  const navigation = useNavigation<any>();
  const [elapsed, setElapsed] = useState(0);
  const [eta, setEta] = useState(8); // 8 minutes
  const [loading, setLoading] = useState(false);
  const [steps, setSteps] = useState<StepStatus[]>([
    { label: 'Accepted', icon: '✓', completed: true, current: false },
    { label: 'On the way', icon: '📍', completed: false, current: true },
    { label: 'Reached', icon: '✓', completed: false, current: false },
    { label: 'In progress', icon: '◉', completed: false, current: false },
    { label: 'Completed', icon: '✓', completed: false, current: false },
  ]);

  const taskId = route?.params?.taskId;
  const request = route?.params?.request;

  // Simulate ETA countdown and auto-transition
  useEffect(() => {
    const interval = setInterval(() => {
      setEta((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          // Auto-transition to OTP screen
          setTimeout(() => {
            navigation.navigate('OTP', { taskId, request });
          }, 500);
          return 0;
        }
        return prev - 1;
      });
      setElapsed((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const handleSkip = async () => {
    setLoading(true);
    await new Promise((r) => setTimeout(r, 500));
    navigation.navigate('OTP', { taskId, request });
  };

  return (
    <ScrollView style={[styles.container, { backgroundColor: palette.page }]}>
      <View style={[styles.header, { backgroundColor: palette.surface }]}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}
        >
          <Text style={[styles.backIcon, { color: palette.ink }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: palette.ink }]}>
          Task in Progress
        </Text>
        <TouchableOpacity style={styles.helpButton}>
          <Text style={[styles.helpIcon, { color: palette.accentText }]}>?</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.body}>
        {/* Progress Steps */}
        <View style={styles.stepsContainer}>
          {steps.map((step, index) => (
            <View key={index} style={styles.stepWrapper}>
              <View style={styles.stepRow}>
                <View
                  style={[
                    styles.stepIcon,
                    {
                      backgroundColor: step.completed
                        ? palette.accent.personal
                        : step.current
                        ? 'transparent'
                        : palette.surface2,
                      borderColor: step.current
                        ? palette.accent.personal
                        : palette.line,
                      borderWidth: step.current ? 2 : 0,
                    },
                  ]}
                >
                  <Text
                    style={[
                      styles.stepIconText,
                      {
                        color: step.completed
                          ? '#fff'
                          : step.current
                          ? palette.accentText
                          : palette.muted,
                      },
                    ]}
                  >
                    {step.icon}
                  </Text>
                </View>
                <Text
                  style={[
                    styles.stepLabel,
                    {
                      color: step.completed || step.current
                        ? palette.ink
                        : palette.muted,
                    },
                  ]}
                >
                  {step.label}
                </Text>
              </View>
              {index < steps.length - 1 && (
                <View
                  style={[
                    styles.stepLine,
                    {
                      backgroundColor:
                        step.completed || step.current
                          ? palette.accent.personal
                          : palette.line,
                    },
                  ]}
                />
              )}
            </View>
          ))}
        </View>

        {/* Status Card */}
        <View
          style={[
            styles.statusCard,
            { backgroundColor: palette.accentSoft },
          ]}
        >
          <View
            style={[
              styles.statusIcon,
              { backgroundColor: palette.accent.personal },
            ]}
          >
            <Text style={styles.statusIconText}>🚗</Text>
          </View>
          <View>
            <Text style={[styles.statusTitle, { color: palette.ink }]}>
              You are on the way
            </Text>
            <Text
              style={[
                styles.statusSubtitle,
                { color: palette.accentText },
              ]}
            >
              Arriving in {eta} min
            </Text>
          </View>
        </View>

        {/* Map Placeholder */}
        <View
          style={[
            styles.mapContainer,
            { backgroundColor: palette.surface2, borderColor: palette.line },
          ]}
        >
          <Text style={{ fontSize: 24, marginBottom: 8 }}>🗺️</Text>
          <Text style={[styles.mapPlaceholder, { color: palette.ink }]}>
            Live Map View
          </Text>
          <Text style={[styles.mapHint, { color: palette.muted }]}>
            GPS tracking enabled • Customer location shared
          </Text>
        </View>

        {/* Helper Info */}
        <View style={styles.helperSection}>
          <View style={styles.helperRow}>
            <View
              style={[
                styles.helperAvatar,
                { backgroundColor: palette.accentSoft },
              ]}
            >
              <Text style={styles.helperInitial}>A</Text>
            </View>
            <View style={styles.helperInfo}>
              <Text style={[styles.helperName, { color: palette.ink }]}>
                {request?.customerName || 'Anil Reddy'}
              </Text>
              <Text style={[styles.helperStatus, { color: palette.accentText }]}>
                On the way to your location
              </Text>
            </View>
          </View>

          {/* Contact Buttons */}
          <View style={styles.contactButtons}>
            <TouchableOpacity
              style={[
                styles.contactBtn,
                { borderColor: palette.line },
              ]}
            >
              <Text style={styles.contactBtnIcon}>📞</Text>
              <Text style={[styles.contactBtnText, { color: palette.accentText }]}>
                Call
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.contactBtn,
                { borderColor: palette.line },
              ]}
            >
              <Text style={styles.contactBtnIcon}>💬</Text>
              <Text style={[styles.contactBtnText, { color: palette.accentText }]}>
                Chat
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Live Note */}
        <View
          style={[
            styles.liveNote,
            { backgroundColor: palette.accentSoft },
          ]}
        >
          <Text style={[styles.liveNoteText, { color: palette.ink }]}>
            📍 Live location enabled. OTP will be shared on arrival.
          </Text>
        </View>

        {/* Demo Button */}
        <Button
          label="Skip to OTP Verification"
          onPress={handleSkip}
          variant="secondary"
          loading={loading}
          style={{ marginTop: 16, marginBottom: 20 }}
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 18,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    fontSize: 22,
    fontWeight: '700',
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: '700',
    flex: 1,
    textAlign: 'center',
  },
  helpButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  helpIcon: {
    fontSize: 16,
    fontWeight: '700',
  },
  body: {
    paddingHorizontal: 18,
    paddingVertical: 16,
  },
  stepsContainer: {
    marginBottom: 16,
  },
  stepWrapper: {
    marginBottom: 8,
  },
  stepRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  stepIcon: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    flexShrink: 0,
  },
  stepIconText: {
    fontSize: 14,
    fontWeight: '700',
  },
  stepLabel: {
    fontSize: 13,
    fontWeight: '600',
  },
  stepLine: {
    width: 2,
    height: 20,
    marginLeft: 13,
    marginVertical: 4,
  },
  statusCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    borderRadius: 16,
    paddingHorizontal: 14,
    paddingVertical: 12,
    marginBottom: 16,
  },
  statusIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  statusIconText: {
    fontSize: 20,
  },
  statusTitle: {
    fontSize: 16,
    fontWeight: '800',
  },
  statusSubtitle: {
    fontSize: 13.5,
    fontWeight: '600',
  },
  mapContainer: {
    height: 150,
    borderRadius: 16,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  mapPlaceholder: {
    fontSize: 16,
    fontWeight: '700',
  },
  mapHint: {
    fontSize: 12,
    marginTop: 4,
  },
  helperSection: {
    marginBottom: 16,
  },
  helperRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  helperAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  helperInitial: {
    fontSize: 18,
    fontWeight: '800',
    color: '#1B7A3E',
  },
  helperInfo: {
    flex: 1,
  },
  helperName: {
    fontSize: 15,
    fontWeight: '700',
  },
  helperStatus: {
    fontSize: 12.5,
    marginTop: 2,
  },
  contactButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  contactBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    borderWidth: 1.5,
    borderRadius: 12,
    paddingVertical: 10,
  },
  contactBtnIcon: {
    fontSize: 16,
  },
  contactBtnText: {
    fontSize: 13,
    fontWeight: '700',
  },
  liveNote: {
    flexDirection: 'row',
    gap: 8,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginBottom: 16,
  },
  liveNoteText: {
    fontSize: 12.5,
    fontWeight: '600',
    flex: 1,
  },
});
