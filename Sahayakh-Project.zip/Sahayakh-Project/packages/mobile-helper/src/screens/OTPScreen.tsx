import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { useTheme, colors } from '../theme';
import { useNavigation } from '@react-navigation/native';
import { Button } from '../components/Button';

export const OTPScreen: React.FC<{ route: any }> = ({ route }) => {
  const { colorMode } = useTheme();
  const palette = colors[colorMode];
  const navigation = useNavigation<any>();
  const [otp, setOtp] = useState(['', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const inputRefs = useRef<any[]>([]);

  const taskId = route?.params?.taskId;
  const request = route?.params?.request;
  const displayOtp = '2847'; // Mock OTP to enter

  const handleDigitPress = (digit: string) => {
    const newOtp = [...otp];
    const emptyIndex = newOtp.findIndex((val) => val === '');

    if (emptyIndex !== -1) {
      newOtp[emptyIndex] = digit;
      setOtp(newOtp);
      setError('');

      // Auto-focus next input
      if (emptyIndex < 3) {
        inputRefs.current[emptyIndex + 1]?.focus();
      }

      // Auto-verify if all digits entered
      if (emptyIndex === 3) {
        setTimeout(() => {
          handleVerify(newOtp);
        }, 300);
      }
    }
  };

  const handleBackspace = () => {
    const newOtp = [...otp];
    const lastFilledIndex = newOtp.findIndex((val, idx) => {
      if (val === '') return false;
      if (idx === newOtp.length - 1) return true;
      return newOtp.slice(idx + 1).every((v) => v === '');
    });

    if (lastFilledIndex !== -1) {
      newOtp[lastFilledIndex] = '';
      setOtp(newOtp);
    }
  };

  const handleVerify = async (otpArray: string[]) => {
    const otpString = otpArray.join('');

    if (otpString.length !== 4) {
      setError('Please enter 4-digit OTP');
      return;
    }

    if (otpString !== displayOtp) {
      setError('Incorrect OTP. Try again.');
      setOtp(['', '', '', '']);
      return;
    }

    setLoading(true);
    try {
      // await taskApi.verifyOTP(taskId, otpString);
      await new Promise((r) => setTimeout(r, 800));
      navigation.navigate('Work', { taskId, request });
    } catch (error) {
      console.error('OTP verification failed:', error);
      setError('Verification failed. Please try again.');
      setOtp(['', '', '', '']);
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    setLoading(true);
    try {
      // await taskApi.resendOTP(taskId);
      await new Promise((r) => setTimeout(r, 600));
      alert('OTP resent to customer');
    } catch (error) {
      console.error('Resend OTP failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleManualVerify = async () => {
    await handleVerify(otp);
  };

  return (
    <ScrollView style={[styles.container, { backgroundColor: palette.page }]}>
      <View style={[styles.header, { backgroundColor: palette.surface }]}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}
        >
          <Text style={[styles.backIcon, { color: palette.ink }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: palette.ink }]}>
          Verify OTP
        </Text>
      </View>

      <View style={styles.body}>
        {/* Icon & Title */}
        <View
          style={[
            styles.otpIcon,
            { backgroundColor: palette.accentSoft },
          ]}
        >
          <Text style={styles.otpIconText}>🔐</Text>
        </View>

        <Text style={[styles.title, { color: palette.ink }]}>
          Verify OTP from Customer
        </Text>

        <Text style={[styles.subtitle, { color: palette.muted }]}>
          Customer has shared a 4-digit code. Enter it below to confirm arrival.
        </Text>

        {/* OTP Input Display */}
        <View style={styles.otpDisplay}>
          {otp.map((digit, index) => (
            <View
              key={index}
              ref={(ref) => (inputRefs.current[index] = ref)}
              style={[
                styles.otpBox,
                {
                  borderColor:
                    error && digit === ''
                      ? palette.error
                      : digit !== ''
                      ? palette.accent.personal
                      : palette.line,
                  backgroundColor:
                    digit !== '' ? palette.accentSoft : palette.surface,
                },
              ]}
            >
              <Text
                style={[
                  styles.otpBoxText,
                  {
                    color:
                      error && digit === ''
                        ? palette.error
                        : palette.ink,
                  },
                ]}
              >
                {digit}
              </Text>
            </View>
          ))}
        </View>

        {/* Error Message */}
        {error && (
          <Text style={[styles.errorText, { color: palette.error }]}>
            {error}
          </Text>
        )}

        {/* Helper Message */}
        <View style={[styles.helperBox, { backgroundColor: palette.accentSoft }]}>
          <Text style={[styles.helperTitle, { color: palette.accentText }]}>
            💡 Tip
          </Text>
          <Text style={[styles.helperText, { color: palette.ink }]}>
            You can also manually enter the OTP or ask the customer to share it again.
          </Text>
        </View>

        {/* Number Pad */}
        <View style={styles.numPad}>
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
            <TouchableOpacity
              key={num}
              style={[
                styles.numButton,
                { backgroundColor: palette.surface2 },
              ]}
              onPress={() => handleDigitPress(num.toString())}
            >
              <Text style={[styles.numText, { color: palette.ink }]}>
                {num}
              </Text>
            </TouchableOpacity>
          ))}

          {/* Backspace */}
          <TouchableOpacity
            style={[styles.numButtonWide, { backgroundColor: palette.surface2 }]}
            onPress={handleBackspace}
          >
            <Text style={[styles.numText, { color: palette.ink }]}>
              ⌫ Backspace
            </Text>
          </TouchableOpacity>

          {/* 0 */}
          <TouchableOpacity
            style={[styles.numButton, { backgroundColor: palette.surface2 }]}
            onPress={() => handleDigitPress('0')}
          >
            <Text style={[styles.numText, { color: palette.ink }]}>0</Text>
          </TouchableOpacity>
        </View>

        {/* Resend Link */}
        <View style={styles.resendSection}>
          <Text style={[styles.resendLabel, { color: palette.muted }]}>
            Didn't receive OTP?
          </Text>
          <TouchableOpacity onPress={handleResend} disabled={loading}>
            <Text style={[styles.resendLink, { color: palette.accentText }]}>
              Request again
            </Text>
          </TouchableOpacity>
        </View>

        {/* Manual Verify Button */}
        <Button
          label="Verify OTP"
          onPress={handleManualVerify}
          variant="primary"
          loading={loading}
          disabled={otp.some((d) => d === '')}
          style={{ marginBottom: 20 }}
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    fontSize: 22,
    fontWeight: '700',
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: '700',
    flex: 1,
    textAlign: 'center',
  },
  body: {
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 20,
  },
  otpIcon: {
    width: 64,
    height: 64,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 14,
  },
  otpIconText: {
    fontSize: 32,
  },
  title: {
    fontSize: 20,
    fontWeight: '800',
    lineHeight: 1.2,
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 14,
    lineHeight: 1.35,
    textAlign: 'center',
    maxWidth: 280,
    marginBottom: 20,
  },
  otpDisplay: {
    flexDirection: 'row',
    gap: 8,
    justifyContent: 'center',
    marginBottom: 12,
  },
  otpBox: {
    width: 44,
    height: 56,
    borderWidth: 1.5,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  otpBoxText: {
    fontSize: 26,
    fontWeight: '800',
  },
  errorText: {
    fontSize: 13,
    fontWeight: '600',
    minHeight: 19,
    marginBottom: 12,
  },
  helperBox: {
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    marginBottom: 16,
    width: '100%',
  },
  helperTitle: {
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 4,
  },
  helperText: {
    fontSize: 12.5,
    lineHeight: 1.35,
  },
  numPad: {
    width: '100%',
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    paddingHorizontal: 18,
    paddingVertical: 8,
    justifyContent: 'center',
  },
  numButton: {
    width: '30%',
    height: 54,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  numButtonWide: {
    width: '100%',
    height: 54,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  numText: {
    fontSize: 22,
    fontWeight: '700',
  },
  resendSection: {
    alignItems: 'center',
    marginVertical: 12,
    marginBottom: 20,
  },
  resendLabel: {
    fontSize: 12.5,
    marginBottom: 4,
  },
  resendLink: {
    fontSize: 13.5,
    fontWeight: '700',
  },
});
