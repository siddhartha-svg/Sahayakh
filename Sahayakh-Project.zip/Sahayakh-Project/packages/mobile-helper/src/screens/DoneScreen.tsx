import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { useTheme, colors } from '../theme';
import { useNavigation } from '@react-navigation/native';
import { Button } from '../components/Button';

interface Summary {
  duration: number;
  distance: number;
  amount: number;
  finalEarnings: number;
  platformFee: number;
  timestamp: string;
}

export const DoneScreen: React.FC<{ route: any }> = ({ route }) => {
  const { colorMode } = useTheme();
  const palette = colors[colorMode];
  const navigation = useNavigation<any>();
  const [loading, setLoading] = useState(false);

  const summary: Summary = route?.params?.summary || {
    duration: 35,
    distance: 4.8,
    amount: 280,
    finalEarnings: 238,
    platformFee: 42,
    timestamp: new Date().toLocaleString(),
  };

  const handleBackToHome = async () => {
    setLoading(true);
    await new Promise((r) => setTimeout(r, 400));
    navigation.reset({
      index: 0,
      routes: [{ name: 'MainTabs' }],
    });
  };

  const handleViewDetails = async () => {
    setLoading(true);
    await new Promise((r) => setTimeout(r, 300));
    navigation.navigate('MainTabs');
  };

  return (
    <ScrollView style={[styles.container, { backgroundColor: palette.page }]}>
      <View style={[styles.header, { backgroundColor: palette.surface }]}>
        <Text style={[styles.headerTitle, { color: palette.ink }]}>
          Task Completed
        </Text>
      </View>

      <View style={styles.body}>
        {/* Success Animation - Burst Effect */}
        <View style={styles.burstContainer}>
          <View
            style={[
              styles.burstCircle,
              { backgroundColor: palette.accent.personal },
            ]}
          >
            <Text style={styles.burstEmoji}>🎉</Text>
          </View>
        </View>

        {/* Title & Message */}
        <Text style={[styles.title, { color: palette.ink }]}>
          Great Job!
        </Text>

        <Text style={[styles.subtitle, { color: palette.muted }]}>
          Task completed successfully. Your earnings have been added to your wallet.
        </Text>

        {/* Earnings Highlight */}
        <View
          style={[
            styles.earningsBox,
            { backgroundColor: palette.accentSoft },
          ]}
        >
          <Text style={[styles.earningsLabel, { color: palette.accentText }]}>
            You Earned
          </Text>
          <Text style={[styles.earningsAmount, { color: palette.accentText }]}>
            ₹{summary.finalEarnings}
          </Text>
          <Text style={[styles.earningsSubtext, { color: palette.muted }]}>
            Added to wallet • Available for withdrawal
          </Text>
        </View>

        {/* Summary Details */}
        <View
          style={[
            styles.summaryCard,
            { backgroundColor: palette.surface, borderColor: palette.line },
          ]}
        >
          <View style={styles.summaryRow}>
            <View style={styles.summaryItem}>
              <Text style={[styles.summaryLabel, { color: palette.muted }]}>
                ⏱️ Duration
              </Text>
              <Text style={[styles.summaryValue, { color: palette.ink }]}>
                {summary.duration} min
              </Text>
            </View>
            <View style={styles.summaryDivider} />
            <View style={styles.summaryItem}>
              <Text style={[styles.summaryLabel, { color: palette.muted }]}>
                📍 Distance
              </Text>
              <Text style={[styles.summaryValue, { color: palette.ink }]}>
                {summary.distance} km
              </Text>
            </View>
            <View style={styles.summaryDivider} />
            <View style={styles.summaryItem}>
              <Text style={[styles.summaryLabel, { color: palette.muted }]}>
                💵 Amount
              </Text>
              <Text style={[styles.summaryValue, { color: palette.ink }]}>
                ₹{summary.amount}
              </Text>
            </View>
          </View>
        </View>

        {/* Bonus Section */}
        <View
          style={[
            styles.bonusSection,
            { backgroundColor: palette.amberBg },
          ]}
        >
          <Text style={[styles.bonusTitle, { color: palette.amberText }]}>
            🎁 Bonus Eligible
          </Text>
          <Text style={[styles.bonusText, { color: palette.amberText }]}>
            Complete 3 more tasks to earn ₹100 bonus!
          </Text>
          <View
            style={[
              styles.bonusProgress,
              { backgroundColor: 'rgba(0,0,0,0.1)' },
            ]}
          >
            <View
              style={[
                styles.bonusBar,
                {
                  width: '33%',
                  backgroundColor: palette.accent.personal,
                },
              ]}
            />
          </View>
          <Text style={[styles.bonusCount, { color: palette.amberText }]}>
            1/3 completed
          </Text>
        </View>

        {/* Details Breakdown */}
        <View style={styles.detailsSection}>
          <Text style={[styles.detailsTitle, { color: palette.ink }]}>
            Earnings Breakdown
          </Text>

          <View style={[styles.detailItem, { backgroundColor: palette.surface }]}>
            <Text style={[styles.detailLabel, { color: palette.ink }]}>
              Task Amount
            </Text>
            <Text style={[styles.detailValue, { color: palette.ink }]}>
              ₹{summary.amount}
            </Text>
          </View>

          <View style={[styles.detailItem, { backgroundColor: palette.surface }]}>
            <Text style={[styles.detailLabel, { color: palette.error }]}>
              Sahayakh Fee (15%)
            </Text>
            <Text style={[styles.detailValue, { color: palette.error }]}>
              -₹{summary.platformFee}
            </Text>
          </View>

          <View style={[styles.detailItem, { backgroundColor: palette.success }]}>
            <Text style={[styles.detailLabel, { color: '#fff', fontWeight: '700' }]}>
              Your Earnings
            </Text>
            <Text style={[styles.detailValue, { color: '#fff', fontWeight: '800' }]}>
              ₹{summary.finalEarnings}
            </Text>
          </View>
        </View>

        {/* Share & Rating Prompt */}
        <View
          style={[
            styles.feedbackSection,
            { backgroundColor: palette.surface2, borderColor: palette.line },
          ]}
        >
          <Text style={[styles.feedbackTitle, { color: palette.ink }]}>
            How was your experience?
          </Text>
          <Text style={[styles.feedbackText, { color: palette.muted }]}>
            Your feedback helps us improve the app
          </Text>
          <View style={styles.ratingStars}>
            {[1, 2, 3, 4, 5].map((star) => (
              <TouchableOpacity key={star} style={styles.starButton}>
                <Text style={styles.star}>⭐</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Action Buttons */}
        <Button
          label="Back to Home"
          onPress={handleBackToHome}
          variant="primary"
          loading={loading}
          style={{ marginTop: 20, marginBottom: 10 }}
        />

        <Button
          label="View Earnings"
          onPress={handleViewDetails}
          variant="secondary"
          loading={loading}
          style={{ marginBottom: 20 }}
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 18,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
  },
  body: {
    paddingHorizontal: 18,
    paddingVertical: 20,
  },
  burstContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  burstCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  burstEmoji: {
    fontSize: 50,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    lineHeight: 1.4,
    textAlign: 'center',
    marginBottom: 20,
  },
  earningsBox: {
    borderRadius: 18,
    paddingVertical: 18,
    paddingHorizontal: 16,
    marginBottom: 18,
    alignItems: 'center',
  },
  earningsLabel: {
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 6,
  },
  earningsAmount: {
    fontSize: 38,
    fontWeight: '800',
    letterSpacing: -0.02,
    marginBottom: 4,
  },
  earningsSubtext: {
    fontSize: 12,
  },
  summaryCard: {
    borderWidth: 1,
    borderRadius: 16,
    paddingVertical: 14,
    marginBottom: 18,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  summaryItem: {
    alignItems: 'center',
    flex: 1,
  },
  summaryLabel: {
    fontSize: 11.5,
    marginBottom: 6,
  },
  summaryValue: {
    fontSize: 17,
    fontWeight: '800',
  },
  summaryDivider: {
    width: 1,
    height: 40,
    backgroundColor: '#E5E7EB',
  },
  bonusSection: {
    borderRadius: 14,
    padding: 14,
    marginBottom: 18,
  },
  bonusTitle: {
    fontSize: 14,
    fontWeight: '800',
    marginBottom: 6,
  },
  bonusText: {
    fontSize: 13,
    marginBottom: 10,
    lineHeight: 1.35,
  },
  bonusProgress: {
    height: 6,
    borderRadius: 99,
    overflow: 'hidden',
    marginBottom: 8,
  },
  bonusBar: {
    height: '100%',
    borderRadius: 99,
  },
  bonusCount: {
    fontSize: 12,
    fontWeight: '700',
  },
  detailsSection: {
    marginBottom: 18,
  },
  detailsTitle: {
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 10,
  },
  detailItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 14,
    marginBottom: 8,
    borderRadius: 10,
  },
  detailLabel: {
    fontSize: 13.5,
  },
  detailValue: {
    fontSize: 13.5,
    fontWeight: '800',
  },
  feedbackSection: {
    borderWidth: 1,
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 14,
    marginBottom: 20,
  },
  feedbackTitle: {
    fontSize: 14,
    fontWeight: '800',
    marginBottom: 6,
  },
  feedbackText: {
    fontSize: 12.5,
    marginBottom: 12,
  },
  ratingStars: {
    flexDirection: 'row',
    gap: 12,
    justifyContent: 'center',
  },
  starButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  star: {
    fontSize: 28,
    opacity: 0.5,
  },
});
