import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  FlatList,
  Image,
} from 'react-native';
import { useTheme, colors } from '../theme';
import { useNavigation } from '@react-navigation/native';
import { Button } from '../components/Button';

interface CheckItem {
  id: string;
  label: string;
  completed: boolean;
}

export const WorkScreen: React.FC<{ route: any }> = ({ route }) => {
  const { colorMode } = useTheme();
  const palette = colors[colorMode];
  const navigation = useNavigation<any>();
  const [checks, setChecks] = useState<CheckItem[]>([
    { id: '1', label: 'Reach the task location', completed: true },
    { id: '2', label: 'Complete the errand', completed: false },
    { id: '3', label: 'Take proof photos', completed: false },
    { id: '4', label: 'Confirm with the customer', completed: false },
  ]);
  const [photos, setPhotos] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [elapsed, setElapsed] = useState(0);

  const taskId = route?.params?.taskId;
  const request = route?.params?.request;

  // Simulate elapsed time
  useEffect(() => {
    const interval = setInterval(() => {
      setElapsed((prev) => {
        if (prev >= 37) {
          clearInterval(interval);
          // Auto-transition to summary
          setTimeout(() => {
            navigation.navigate('Summary', { taskId, request, checks, photos });
          }, 500);
          return 37;
        }
        return prev + 1;
      });
    }, 900); // 900ms = 3 minutes in demo

    return () => clearInterval(interval);
  }, []);

  const toggleCheck = (id: string) => {
    setChecks((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, completed: !item.completed } : item
      )
    );
  };

  const handleAddPhoto = async () => {
    setLoading(true);
    try {
      // In production: use ImagePicker from expo-image-picker
      // For demo: add mock photo
      await new Promise((r) => setTimeout(r, 600));
      setPhotos((prev) => [
        ...prev,
        `photo_${prev.length + 1}`,
      ]);
    } catch (error) {
      console.error('Failed to add photo:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotos((prev) => prev.filter((_, i) => i !== index));
  };

  const handleComplete = async () => {
    setLoading(true);
    try {
      // Check if all items are completed
      const allCompleted = checks.every((c) => c.completed);
      if (!allCompleted) {
        alert('Please complete all checklist items');
        setLoading(false);
        return;
      }

      if (photos.length === 0) {
        alert('Please add at least one proof photo');
        setLoading(false);
        return;
      }

      // await taskApi.completeTask(taskId, { checks, photos });
      await new Promise((r) => setTimeout(r, 800));
      navigation.navigate('Summary', { taskId, request, checks, photos });
    } catch (error) {
      console.error('Failed to complete task:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSkip = async () => {
    setLoading(true);
    await new Promise((r) => setTimeout(r, 500));
    navigation.navigate('Summary', { taskId, request, checks, photos });
  };

  // Status message based on elapsed time
  const getStatus = () => {
    if (elapsed < 10) return 'Just started...';
    if (elapsed < 20) return 'In progress...';
    if (elapsed < 30) return 'Almost done...';
    return 'Wrapping up...';
  };

  return (
    <ScrollView style={[styles.container, { backgroundColor: palette.page }]}>
      <View style={[styles.header, { backgroundColor: palette.surface }]}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}
        >
          <Text style={[styles.backIcon, { color: palette.ink }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: palette.ink }]}>
          Task in Progress
        </Text>
        <TouchableOpacity style={styles.helpButton}>
          <Text style={[styles.helpIcon, { color: palette.accentText }]}>?</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.body}>
        {/* Progress Steps */}
        <View style={styles.stepsContainer}>
          <View style={styles.stepRow}>
            <Text style={[styles.stepIcon, { color: palette.accent.personal }]}>
              ✓
            </Text>
            <Text style={[styles.stepLabel, { color: palette.ink }]}>
              Assigned
            </Text>
          </View>
          <View style={styles.stepRow}>
            <Text style={[styles.stepIcon, { color: palette.accent.personal }]}>
              ✓
            </Text>
            <Text style={[styles.stepLabel, { color: palette.ink }]}>
              On the way
            </Text>
          </View>
          <View style={styles.stepRow}>
            <Text style={[styles.stepIcon, { color: palette.accent.personal }]}>
              ✓
            </Text>
            <Text style={[styles.stepLabel, { color: palette.ink }]}>
              Reached
            </Text>
          </View>
          <View style={styles.stepRow}>
            <View
              style={[
                styles.currentStepIcon,
                { borderColor: palette.accent.personal },
              ]}
            >
              <Text style={[styles.currentStepDot, { color: palette.accentText }]}>
                ◉
              </Text>
            </View>
            <Text style={[styles.stepLabel, { color: palette.ink }]}>
              In progress
            </Text>
          </View>
          <View style={styles.stepRow}>
            <Text style={[styles.stepIcon, { color: palette.muted }]}>•</Text>
            <Text style={[styles.stepLabel, { color: palette.muted }]}>
              Completed
            </Text>
          </View>
        </View>

        {/* Status Card */}
        <View
          style={[
            styles.statusCard,
            { backgroundColor: palette.accentSoft },
          ]}
        >
          <View
            style={[
              styles.statusIcon,
              { backgroundColor: palette.accent.personal },
            ]}
          >
            <Text style={styles.statusIconText}>⏱️</Text>
          </View>
          <View>
            <Text style={[styles.statusTitle, { color: palette.ink }]}>
              Task is in progress
            </Text>
            <Text
              style={[
                styles.statusSubtitle,
                { color: palette.accentText },
              ]}
            >
              {new Date(elapsed * 3 * 60000).toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit',
              })}
            </Text>
          </View>
        </View>

        {/* Metrics */}
        <View style={styles.metricsGrid}>
          <View style={[styles.metricBox, { backgroundColor: palette.surface }]}>
            <Text style={[styles.metricLabel, { color: palette.muted }]}>
              ⏱️ Time Elapsed
            </Text>
            <Text style={[styles.metricValue, { color: palette.ink }]}>
              {Math.floor(elapsed / 60)}h {elapsed % 60}m
            </Text>
          </View>
          <View style={[styles.metricBox, { backgroundColor: palette.surface }]}>
            <Text style={[styles.metricLabel, { color: palette.muted }]}>
              📍 Distance
            </Text>
            <Text style={[styles.metricValue, { color: palette.ink }]}>
              {(elapsed / 10).toFixed(1)}km
            </Text>
          </View>
        </View>

        {/* Checklist */}
        <Text style={[styles.sectionTitle, { color: palette.ink }]}>
          Checklist
        </Text>

        {checks.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={[
              styles.checkItem,
              {
                backgroundColor: palette.surface,
                borderBottomColor: palette.line,
              },
            ]}
            onPress={() => toggleCheck(item.id)}
          >
            <View
              style={[
                styles.checkbox,
                {
                  backgroundColor: item.completed
                    ? palette.accent.personal
                    : 'transparent',
                  borderColor: item.completed
                    ? palette.accent.personal
                    : palette.muted,
                },
              ]}
            >
              {item.completed && (
                <Text style={styles.checkmark}>✓</Text>
              )}
            </View>
            <Text
              style={[
                styles.checkLabel,
                {
                  color: item.completed ? palette.muted : palette.ink,
                  textDecorationLine: item.completed ? 'line-through' : 'none',
                },
              ]}
            >
              {item.label}
            </Text>
          </TouchableOpacity>
        ))}

        {/* Photos Section */}
        <Text style={[styles.sectionTitle, { color: palette.ink, marginTop: 20 }]}>
          Proof Photos
        </Text>

        <View style={styles.photosContainer}>
          {photos.map((_, index) => (
            <View
              key={index}
              style={[
                styles.photoBox,
                { backgroundColor: palette.surface2 },
              ]}
            >
              <Text style={styles.photoPlaceholder}>📷</Text>
              <TouchableOpacity
                style={styles.removeButton}
                onPress={() => handleRemovePhoto(index)}
              >
                <Text style={styles.removeIcon}>✕</Text>
              </TouchableOpacity>
            </View>
          ))}

          {photos.length < 3 && (
            <TouchableOpacity
              style={[
                styles.addPhotoBox,
                {
                  borderColor: palette.muted,
                  backgroundColor: palette.surface,
                },
              ]}
              onPress={handleAddPhoto}
              disabled={loading}
            >
              <Text style={styles.addPhotoIcon}>+</Text>
              <Text style={[styles.addPhotoText, { color: palette.muted }]}>
                Add Photo
              </Text>
            </TouchableOpacity>
          )}
        </View>

        <Text style={[styles.photoHint, { color: palette.muted }]}>
          Add photos as proof of task completion
        </Text>

        {/* Complete Button */}
        <Button
          label="Mark Task Complete"
          onPress={handleComplete}
          variant="primary"
          loading={loading}
          style={{ marginTop: 20, marginBottom: 10 }}
        />

        {/* Skip Button */}
        <Button
          label="Skip to Summary"
          onPress={handleSkip}
          variant="secondary"
          loading={loading}
          style={{ marginBottom: 20 }}
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 18,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    fontSize: 22,
    fontWeight: '700',
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: '700',
    flex: 1,
    textAlign: 'center',
  },
  helpButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  helpIcon: {
    fontSize: 16,
    fontWeight: '700',
  },
  body: {
    paddingHorizontal: 18,
    paddingVertical: 16,
  },
  stepsContainer: {
    marginBottom: 12,
  },
  stepRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 8,
  },
  stepIcon: {
    fontSize: 14,
    fontWeight: '700',
    width: 28,
    textAlign: 'center',
  },
  currentStepIcon: {
    width: 28,
    height: 28,
    borderRadius: 14,
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  currentStepDot: {
    fontSize: 16,
    fontWeight: '700',
  },
  stepLabel: {
    fontSize: 13,
    fontWeight: '600',
  },
  statusCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    borderRadius: 16,
    paddingHorizontal: 14,
    paddingVertical: 12,
    marginBottom: 16,
  },
  statusIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  statusIconText: {
    fontSize: 20,
  },
  statusTitle: {
    fontSize: 16,
    fontWeight: '800',
  },
  statusSubtitle: {
    fontSize: 13.5,
    fontWeight: '600',
    marginTop: 2,
  },
  metricsGrid: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 20,
  },
  metricBox: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 14,
    paddingVertical: 10,
    paddingHorizontal: 12,
  },
  metricLabel: {
    fontSize: 12,
    marginBottom: 6,
  },
  metricValue: {
    fontSize: 18,
    fontWeight: '800',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 12,
  },
  checkItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 12,
    paddingHorizontal: 0,
    borderBottomWidth: 1,
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 8,
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    flexShrink: 0,
  },
  checkmark: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '700',
  },
  checkLabel: {
    fontSize: 15,
    fontWeight: '600',
    flex: 1,
  },
  photosContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 8,
  },
  photoBox: {
    width: '48%',
    aspectRatio: 1,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  photoPlaceholder: {
    fontSize: 32,
  },
  removeButton: {
    position: 'absolute',
    top: -8,
    right: -8,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#C0392B',
    justifyContent: 'center',
    alignItems: 'center',
  },
  removeIcon: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  addPhotoBox: {
    width: '48%',
    aspectRatio: 1,
    borderWidth: 1.5,
    borderStyle: 'dashed',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addPhotoIcon: {
    fontSize: 28,
    marginBottom: 4,
  },
  addPhotoText: {
    fontSize: 12.5,
    fontWeight: '600',
  },
  photoHint: {
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 16,
  },
});
