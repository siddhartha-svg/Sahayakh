import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Switch,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useTheme, colors } from '../theme';
import { useAuthStore, useAvailabilityStore } from '../store';
import { Button } from '../components/Button';
import { taskApi, statusApi } from '../api/client';

interface IncomingRequest {
  id: string;
  title: string;
  location: string;
  amount: number;
  type: 'personal' | 'business';
  customerName: string;
  customerRating: number;
  distance?: number;
  eta?: number;
}

export const HomeScreen: React.FC = () => {
  const { colorMode } = useTheme();
  const palette = colors[colorMode];
  const navigation = useNavigation<any>();
  const { user } = useAuthStore();
  const { isOnline, toggleOnline } = useAvailabilityStore();
  const [requests, setRequests] = useState<IncomingRequest[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const mockRequests: IncomingRequest[] = [
    {
      id: 'r1',
      title: 'Pick up medicine from Apollo Pharmacy',
      location: 'Hanamkonda, Warangal',
      amount: 280,
      type: 'personal',
      customerName: 'Anil Reddy',
      customerRating: 4.9,
      distance: 1.2,
      eta: 6,
    },
    {
      id: 'r2',
      title: 'Collect signed invoices from vendor',
      location: 'Subedari, Warangal',
      amount: 480,
      type: 'business',
      customerName: 'Sri Lakshmi Traders',
      customerRating: 4.8,
      distance: 1.8,
      eta: 9,
    },
  ];

  useEffect(() => {
    loadRequests();
  }, [isOnline]);

  const loadRequests = async () => {
    setLoading(true);
    try {
      if (isOnline) {
        // In production: const data = await taskApi.getIncomingRequests();
        await new Promise((r) => setTimeout(r, 800));
        setRequests(mockRequests);
      } else {
        setRequests([]);
      }
    } catch (error) {
      console.error('Failed to load requests:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadRequests();
    setRefreshing(false);
  };

  const handleToggleOnline = async () => {
    toggleOnline();
    try {
      if (!isOnline) {
        // await statusApi.setOnline();
      } else {
        // await statusApi.setOffline();
      }
    } catch (error) {
      console.error('Failed to update status:', error);
    }
  };

  const handleAccept = async (requestId: string) => {
    try {
      setLoading(true);
      await new Promise((r) => setTimeout(r, 600));
      const request = requests.find((r) => r.id === requestId);
      navigation.navigate('Request', { request });
    } catch (error) {
      console.error('Failed to accept task:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDecline = (requestId: string) => {
    setRequests((prev) => prev.filter((r) => r.id !== requestId));
  };

  return (
    <View style={[styles.container, { backgroundColor: palette.page }]}>
      <View style={[styles.header, { backgroundColor: palette.surface }]}>
        <View style={styles.who}>
          <View
            style={[
              styles.avatar,
              { backgroundColor: palette.accentSoft },
            ]}
          >
            <Text style={[styles.initials, { color: palette.accentText }]}>
              {user?.name?.split(' ').map((n) => n[0]).join('')}
            </Text>
          </View>
          <View style={styles.info}>
            <Text style={[styles.name, { color: palette.ink }]}>
              {user?.name || 'Helper'}
            </Text>
            <Text style={[styles.rating, { color: palette.muted }]}>
              ⭐ {user?.rating || 4.8} • {user?.tasksCompleted || 128} tasks
            </Text>
          </View>
        </View>
      </View>

      <ScrollView
        style={styles.body}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        scrollEnabled={true}
      >
        {/* Online Toggle */}
        <View style={[styles.onlineCard, { backgroundColor: palette.surface, borderColor: isOnline ? palette.accent.personal : palette.line }]}>
          <View>
            <Text style={[styles.onlineTitle, { color: palette.ink }]}>
              {isOnline ? '🟢 Online' : '⚫ Offline'}
            </Text>
            <Text style={[styles.onlineSubtitle, { color: palette.muted }]}>
              {isOnline ? 'You are accepting requests' : 'You are not accepting requests'}
            </Text>
          </View>
          <Switch
            value={isOnline}
            onValueChange={handleToggleOnline}
            trackColor={{ false: palette.line, true: palette.accentSoft }}
            thumbColor={isOnline ? palette.accent.personal : palette.muted}
          />
        </View>

        {/* Earnings Card */}
        <View style={[styles.earnCard, { backgroundColor: palette.accentDeep }]}>
          <View style={styles.earnTop}>
            <Text style={styles.earnLabel}>Today's Earnings</Text>
            <TouchableOpacity>
              <Text style={styles.earnLink}>View →</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.earnAmount}>₹1,260</Text>
          <View style={styles.earnStats}>
            <View>
              <Text style={styles.earnStatVal}>4</Text>
              <Text style={styles.earnStatLabel}>Tasks Done</Text>
            </View>
            <View>
              <Text style={styles.earnStatVal}>₹3,480</Text>
              <Text style={styles.earnStatLabel}>Wallet Balance</Text>
            </View>
          </View>
        </View>

        {/* Incoming Requests */}
        {isOnline ? (
          <>
            <View style={styles.sectionHeader}>
              <Text style={[styles.sectionTitle, { color: palette.ink }]}>
                Incoming Requests
              </Text>
              <View
                style={[styles.badge, { backgroundColor: palette.accent.personal }]}
              >
                <Text style={styles.badgeText}>{requests.length}</Text>
              </View>
            </View>

            {loading && !refreshing ? (
              <ActivityIndicator size="large" color={palette.accent.personal} />
            ) : requests.length > 0 ? (
              <FlatList
                data={requests}
                keyExtractor={(item) => item.id}
                scrollEnabled={false}
                renderItem={({ item }) => (
                  <View
                    style={[
                      styles.requestCard,
                      {
                        backgroundColor: palette.surface,
                        borderColor: palette.accent.personal,
                      },
                    ]}
                  >
                    <View style={styles.requestHeader}>
                      <View style={styles.typeTag}>
                        <Text style={styles.typeTagText}>
                          {item.type === 'business' ? '💼' : '👤'}
                        </Text>
                        <Text style={[styles.typeTagLabel, { color: palette.error }]}>
                          {item.type === 'business' ? 'Business' : 'Personal'}
                        </Text>
                      </View>
                    </View>

                    <Text style={[styles.requestTitle, { color: palette.ink }]}>
                      {item.title}
                    </Text>

                    <View style={styles.requestMeta}>
                      <Text style={[styles.requestMetaText, { color: palette.muted }]}>
                        📍 {item.location}
                      </Text>
                    </View>

                    <View style={styles.customerRow}>
                      <View>
                        <Text style={[styles.customerName, { color: palette.ink }]}>
                          {item.customerName}
                        </Text>
                        <Text style={[styles.customerRating, { color: palette.muted }]}>
                          ⭐ {item.customerRating}
                        </Text>
                      </View>
                    </View>

                    <View style={styles.amountBox}>
                      <Text style={[styles.amountLabel, { color: palette.muted }]}>
                        Amount
                      </Text>
                      <Text style={[styles.amountValue, { color: palette.accentText }]}>
                        ₹{item.amount}
                      </Text>
                    </View>

                    <View style={styles.actions}>
                      <Button
                        label="Accept"
                        onPress={() => handleAccept(item.id)}
                        variant="primary"
                        size="medium"
                        loading={loading}
                        style={{ flex: 1 }}
                      />
                      <Button
                        label="Decline"
                        onPress={() => handleDecline(item.id)}
                        variant="secondary"
                        size="medium"
                        style={{ flex: 1, marginLeft: 10 }}
                      />
                    </View>
                  </View>
                )}
              />
            ) : (
              <View style={[styles.empty, { borderColor: palette.line }]}>
                <View style={[styles.emptyPulse, { color: palette.accentText }]}>
                  <Text style={styles.emptyIcon}>📍</Text>
                </View>
                <Text style={[styles.emptyTitle, { color: palette.ink }]}>
                  No Requests Right Now
                </Text>
                <Text style={[styles.emptyText, { color: palette.muted }]}>
                  Stay online to receive task requests from customers
                </Text>
              </View>
            )}
          </>
        ) : (
          <View style={[styles.empty, { borderColor: palette.line }]}>
            <Text style={[styles.emptyTitle, { color: palette.ink }]}>
              Go Online to Accept Requests
            </Text>
            <Text style={[styles.emptyText, { color: palette.muted }]}>
              Toggle the switch above to start receiving task requests
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 18,
    paddingTop: 12,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  who: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  initials: {
    fontSize: 16,
    fontWeight: '800',
  },
  info: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 2,
  },
  rating: {
    fontSize: 12.5,
  },
  body: {
    flex: 1,
    padding: 18,
  },
  onlineCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 14,
    borderRadius: 16,
    borderWidth: 1.5,
    marginBottom: 14,
  },
  onlineTitle: {
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 2,
  },
  onlineSubtitle: {
    fontSize: 12.5,
  },
  earnCard: {
    borderRadius: 22,
    padding: 16,
    marginBottom: 20,
    color: '#fff',
  },
  earnTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    fontSize: 13,
    opacity: 0.9,
    marginBottom: 12,
  },
  earnLabel: {
    fontSize: 13,
    color: '#fff',
    opacity: 0.9,
    fontWeight: '700',
  },
  earnLink: {
    fontWeight: '700',
    color: '#fff',
    fontSize: 13,
  },
  earnAmount: {
    fontSize: 38,
    fontWeight: '800',
    letterSpacing: -0.03,
    color: '#fff',
    marginBottom: 12,
  },
  earnStats: {
    flexDirection: 'row',
    gap: 8,
  },
  earnStatVal: {
    fontSize: 17,
    fontWeight: '800',
    color: '#fff',
  },
  earnStatLabel: {
    fontSize: 11.5,
    opacity: 0.85,
    color: '#fff',
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginVertical: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.01,
  },
  badge: {
    borderRadius: 99,
    paddingHorizontal: 9,
    paddingVertical: 2,
  },
  badgeText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#fff',
  },
  requestCard: {
    flexDirection: 'column',
    gap: 6,
    paddingVertical: 14,
    paddingHorizontal: 14,
    marginBottom: 12,
    borderWidth: 1.5,
    borderRadius: 18,
    boxShadow: '0 1px 2px rgba(14,34,23,.06), 0 4px 14px rgba(14,34,23,.06)',
  },
  requestHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  typeTag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    fontWeight: '800',
  },
  typeTagText: {
    fontSize: 16,
  },
  typeTagLabel: {
    fontSize: 13,
    fontWeight: '800',
  },
  requestTitle: {
    fontSize: 14.5,
    fontWeight: '700',
    lineHeight: 1.35,
  },
  requestMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  requestMetaText: {
    fontSize: 12.5,
  },
  customerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  customerName: {
    fontSize: 15,
    fontWeight: '700',
  },
  customerRating: {
    fontSize: 12.5,
  },
  amountBox: {
    flexDirection: 'column',
    backgroundColor: '#E3F3E8',
    borderRadius: 16,
    paddingVertical: 14,
    paddingHorizontal: 14,
    marginTop: 12,
  },
  amountLabel: {
    fontSize: 12.5,
  },
  amountValue: {
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: -0.02,
  },
  actions: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 12,
  },
  empty: {
    textAlign: 'center',
    padding: 26,
    borderWidth: 1.5,
    borderStyle: 'dashed',
    borderRadius: 18,
    alignItems: 'center',
  },
  emptyPulse: {
    width: 54,
    height: 54,
    margin: '0 auto 12px',
    display: 'flex',
    placeItems: 'center',
  },
  emptyIcon: {
    fontSize: 24,
  },
  emptyTitle: {
    fontWeight: '700',
    fontSize: 15,
    marginBottom: 2,
  },
  emptyText: {
    fontSize: 14,
  },
});
