import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  FlatList,
} from 'react-native';
import { useTheme, colors } from '../theme';
import { useNavigation } from '@react-navigation/native';
import { Button } from '../components/Button';

interface CheckItem {
  id: string;
  label: string;
  completed: boolean;
}

export const SummaryScreen: React.FC<{ route: any }> = ({ route }) => {
  const { colorMode } = useTheme();
  const palette = colors[colorMode];
  const navigation = useNavigation<any>();
  const [loading, setLoading] = useState(false);

  const taskId = route?.params?.taskId;
  const request = route?.params?.request;
  const checks = route?.params?.checks || [];
  const photos = route?.params?.photos || [];

  const mockSummary = {
    duration: 35,
    distance: 4.8,
    amount: 280,
    finalEarnings: 238, // 280 * (1 - 0.15 fee)
    platformFee: 42,
    timestamp: new Date().toLocaleString('en-IN'),
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      // await taskApi.submitTaskCompletion(taskId, {
      //   duration: mockSummary.duration,
      //   distance: mockSummary.distance,
      //   photos: photos,
      //   checks: checks,
      // });
      await new Promise((r) => setTimeout(r, 800));
      navigation.navigate('Done', { taskId, request, summary: mockSummary });
    } catch (error) {
      console.error('Failed to submit task:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={[styles.container, { backgroundColor: palette.page }]}>
      <View style={[styles.header, { backgroundColor: palette.surface }]}>
        <Text style={[styles.headerTitle, { color: palette.ink }]}>
          Task Summary
        </Text>
      </View>

      <View style={styles.body}>
        {/* Checkmark */}
        <View style={styles.successIcon}>
          <View
            style={[
              styles.checkCircle,
              { backgroundColor: palette.accent.personal },
            ]}
          >
            <Text style={styles.checkmarkText}>✓</Text>
          </View>
        </View>

        <Text style={[styles.successTitle, { color: palette.ink }]}>
          Task Completed!
        </Text>

        {/* Metrics Grid */}
        <View style={styles.metricsGrid}>
          <View style={[styles.metricCell, { borderRightColor: palette.line }]}>
            <Text style={[styles.metricLabel, { color: palette.muted }]}>
              Duration
            </Text>
            <Text style={[styles.metricValue, { color: palette.ink }]}>
              {mockSummary.duration}
            </Text>
            <Text style={[styles.metricUnit, { color: palette.muted }]}>
              minutes
            </Text>
          </View>
          <View style={[styles.metricCell, { borderRightColor: palette.line }]}>
            <Text style={[styles.metricLabel, { color: palette.muted }]}>
              Distance
            </Text>
            <Text style={[styles.metricValue, { color: palette.ink }]}>
              {mockSummary.distance}
            </Text>
            <Text style={[styles.metricUnit, { color: palette.muted }]}>
              km
            </Text>
          </View>
          <View style={styles.metricCell}>
            <Text style={[styles.metricLabel, { color: palette.muted }]}>
              Photos
            </Text>
            <Text style={[styles.metricValue, { color: palette.ink }]}>
              {photos.length}
            </Text>
            <Text style={[styles.metricUnit, { color: palette.muted }]}>
              uploaded
            </Text>
          </View>
        </View>

        {/* Earnings Breakdown */}
        <Text style={[styles.sectionTitle, { color: palette.ink }]}>
          Earnings Breakdown
        </Text>

        <View style={[styles.breakdownItem, { backgroundColor: palette.surface }]}>
          <Text style={[styles.breakdownLabel, { color: palette.ink }]}>
            Task Amount
          </Text>
          <Text style={[styles.breakdownValue, { color: palette.ink }]}>
            ₹{mockSummary.amount}
          </Text>
        </View>

        <View style={[styles.breakdownItem, { backgroundColor: palette.surface }]}>
          <Text style={[styles.breakdownLabel, { color: palette.error }]}>
            Sahayakh Fee (15%)
          </Text>
          <Text style={[styles.breakdownValue, { color: palette.error }]}>
            -₹{mockSummary.platformFee}
          </Text>
        </View>

        <View
          style={[
            styles.totalBreakdown,
            {
              backgroundColor: palette.accentSoft,
              borderColor: palette.accentText,
            },
          ]}
        >
          <Text style={[styles.totalLabel, { color: palette.accentText }]}>
            You Earn
          </Text>
          <Text style={[styles.totalAmount, { color: palette.accentText }]}>
            ₹{mockSummary.finalEarnings}
          </Text>
        </View>

        {/* Details */}
        <View
          style={[
            styles.detailsSection,
            {
              backgroundColor: palette.surface,
              borderColor: palette.line,
            },
          ]}
        >
          <View style={styles.detailRow}>
            <Text style={[styles.detailLabel, { color: palette.muted }]}>
              Task ID
            </Text>
            <Text style={[styles.detailValue, { color: palette.ink }]}>
              {taskId}
            </Text>
          </View>
          <View style={styles.detailDivider} />
          <View style={styles.detailRow}>
            <Text style={[styles.detailLabel, { color: palette.muted }]}>
              Completed At
            </Text>
            <Text style={[styles.detailValue, { color: palette.ink }]}>
              {new Date().toLocaleString('en-US', {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              })}
            </Text>
          </View>
          <View style={styles.detailDivider} />
          <View style={styles.detailRow}>
            <Text style={[styles.detailLabel, { color: palette.muted }]}>
              Status
            </Text>
            <Text style={[styles.detailValue, { color: palette.success }]}>
              Completed
            </Text>
          </View>
        </View>

        {/* Checklist Review */}
        {checks.length > 0 && (
          <>
            <Text style={[styles.sectionTitle, { color: palette.ink }]}>
              Completed Checklist
            </Text>
            <FlatList
              data={checks}
              scrollEnabled={false}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <View style={[styles.checkReview, { backgroundColor: palette.surface }]}>
                  <Text style={styles.checkIcon}>✓</Text>
                  <Text style={[styles.checkText, { color: palette.ink }]}>
                    {item.label}
                  </Text>
                </View>
              )}
            />
          </>
        )}

        {/* Action Buttons */}
        <Button
          label="Complete & Review"
          onPress={handleSubmit}
          variant="primary"
          loading={loading}
          style={{ marginTop: 24, marginBottom: 10 }}
        />

        <Button
          label="Back"
          onPress={() => navigation.goBack()}
          variant="secondary"
          loading={loading}
          style={{ marginBottom: 20 }}
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 18,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
  },
  body: {
    paddingHorizontal: 18,
    paddingVertical: 20,
  },
  successIcon: {
    alignItems: 'center',
    marginBottom: 12,
  },
  checkCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkmarkText: {
    color: '#fff',
    fontSize: 40,
    fontWeight: '800',
  },
  successTitle: {
    fontSize: 24,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 20,
  },
  metricsGrid: {
    flexDirection: 'row',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 14,
    overflow: 'hidden',
  },
  metricCell: {
    flex: 1,
    paddingVertical: 14,
    paddingHorizontal: 12,
    alignItems: 'center',
    borderRightWidth: 1,
  },
  metricLabel: {
    fontSize: 11,
    marginBottom: 6,
  },
  metricValue: {
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 2,
  },
  metricUnit: {
    fontSize: 10.5,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 12,
  },
  breakdownItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 11,
    paddingHorizontal: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  breakdownLabel: {
    fontSize: 13.5,
  },
  breakdownValue: {
    fontSize: 13.5,
    fontWeight: '800',
  },
  totalBreakdown: {
    borderWidth: 1,
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 14,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 18,
  },
  totalLabel: {
    fontSize: 14,
    fontWeight: '700',
  },
  totalAmount: {
    fontSize: 28,
    fontWeight: '800',
  },
  detailsSection: {
    borderWidth: 1,
    borderRadius: 14,
    padding: 14,
    marginBottom: 18,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
  },
  detailLabel: {
    fontSize: 13,
  },
  detailValue: {
    fontSize: 13,
    fontWeight: '700',
  },
  detailDivider: {
    height: 1,
    backgroundColor: '#E5E7EB',
  },
  checkReview: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 12,
    paddingHorizontal: 14,
    marginBottom: 8,
    borderRadius: 10,
  },
  checkIcon: {
    fontSize: 16,
    color: '#22C55E',
    fontWeight: '700',
  },
  checkText: {
    fontSize: 13.5,
    flex: 1,
  },
});
