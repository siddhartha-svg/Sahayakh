import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Switch,
  FlatList,
  Slider,
  Modal,
} from 'react-native';
import { useTheme, colors } from '../theme';
import { useAuthStore } from '../store';
import { Button } from '../components/Button';
import { helperApi } from '../api/client';

interface Review {
  id: string;
  customerName: string;
  rating: number;
  text: string;
  date: string;
}

interface HelperSettings {
  acceptPersonal: boolean;
  acceptBusiness: boolean;
  serviceRadius: number; // in km
  autoAcceptOnline: boolean;
}

export const ProfileScreen: React.FC = () => {
  const { colorMode } = useTheme();
  const palette = colors[colorMode];
  const { user, logout } = useAuthStore();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [settings, setSettings] = useState<HelperSettings>({
    acceptPersonal: true,
    acceptBusiness: true,
    serviceRadius: 5,
    autoAcceptOnline: false,
  });
  const [showRadiusModal, setShowRadiusModal] = useState(false);
  const [tempRadius, setTempRadius] = useState(5);

  const mockReviews: Review[] = [
    {
      id: 'r1',
      customerName: 'Anil Reddy',
      rating: 5,
      text: 'Excellent service, very professional and on time.',
      date: '21 Sep 2026',
    },
    {
      id: 'r2',
      customerName: 'Sneha V.',
      rating: 4.8,
      text: 'Great helper, would recommend to anyone.',
      date: '20 Sep 2026',
    },
  ];

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    setLoading(true);
    try {
      // In production: const profile = await helperApi.getProfile();
      // const reviews = await helperApi.getReviews();
      await new Promise((r) => setTimeout(r, 600));
      setReviews(mockReviews);
    } catch (error) {
      console.error('Failed to load profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    logout();
  };

  const toggleTaskType = async (type: 'personal' | 'business') => {
    const newSettings = {
      ...settings,
      [type === 'personal' ? 'acceptPersonal' : 'acceptBusiness']:
        type === 'personal' ? !settings.acceptPersonal : !settings.acceptBusiness,
    };
    setSettings(newSettings);
    try {
      // await helperApi.updateProfile({ taskTypePreferences: newSettings });
    } catch (error) {
      console.error('Failed to update task type preference:', error);
    }
  };

  const handleRadiusChange = async () => {
    setSettings((prev) => ({ ...prev, serviceRadius: tempRadius }));
    setShowRadiusModal(false);
    try {
      // await helperApi.updateProfile({ serviceRadius: tempRadius });
    } catch (error) {
      console.error('Failed to update service radius:', error);
    }
  };

  const renderVerificationBadge = (label: string, verified: boolean) => (
    <View
      style={[
        styles.verificationRow,
        {
          backgroundColor: verified ? palette.accentSoft : palette.surface2,
        },
      ]}
    >
      <View
        style={[
          styles.verificationIcon,
          {
            backgroundColor: verified
              ? palette.accent.personal
              : palette.muted,
          },
        ]}
      >
        <Text style={styles.verificationCheckmark}>
          {verified ? '✓' : '!'}
        </Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[styles.verificationLabel, { color: palette.ink }]}>
          {label}
        </Text>
        <Text style={[styles.verificationStatus, { color: palette.muted }]}>
          {verified ? 'Verified' : 'Pending'}
        </Text>
      </View>
      {verified && (
        <Text style={[styles.verificationOk, { color: palette.accentText }]}>
          ✓
        </Text>
      )}
    </View>
  );

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: palette.page }]}
    >
      <View style={[styles.header, { backgroundColor: palette.surface }]}>
        <Text style={[styles.title, { color: palette.ink }]}>Profile</Text>
      </View>

      {/* Profile Section */}
      <View style={[styles.section, { backgroundColor: palette.surface }]}>
        <View style={styles.profileTop}>
          <View style={[styles.largeAvatar, { backgroundColor: palette.accentSoft }]}>
            <Text style={[styles.largeInitials, { color: palette.accentText }]}>
              {user?.name?.split(' ').map((n) => n[0]).join('')}
            </Text>
          </View>
          <View style={styles.profileInfo}>
            <Text style={[styles.profileName, { color: palette.ink }]}>
              {user?.name || 'Helper Name'}
            </Text>
            <Text style={[styles.profileEmail, { color: palette.muted }]}>
              {user?.email || 'email@example.com'}
            </Text>
          </View>
        </View>

        {/* Stats Grid */}
        <View style={styles.statsGrid}>
          <View style={styles.statBox}>
            <Text style={[styles.statValue, { color: palette.ink }]}>
              {user?.rating || 4.8}
            </Text>
            <Text style={[styles.statLabel, { color: palette.muted }]}>
              Rating
            </Text>
          </View>
          <View
            style={[
              styles.statDivider,
              { backgroundColor: palette.line },
            ]}
          />
          <View style={styles.statBox}>
            <Text style={[styles.statValue, { color: palette.ink }]}>
              {user?.tasksCompleted || 128}
            </Text>
            <Text style={[styles.statLabel, { color: palette.muted }]}>
              Tasks
            </Text>
          </View>
          <View
            style={[
              styles.statDivider,
              { backgroundColor: palette.line },
            ]}
          />
          <View style={styles.statBox}>
            <Text style={[styles.statValue, { color: palette.ink }]}>
              98%
            </Text>
            <Text style={[styles.statLabel, { color: palette.muted }]}>
              Complete
            </Text>
          </View>
        </View>
      </View>

      {/* Verification Section */}
      <View style={styles.sectionContainer}>
        <Text style={[styles.sectionTitle, { color: palette.ink }]}>
          Verification
        </Text>
        <View style={[styles.section, { backgroundColor: palette.surface }]}>
          {renderVerificationBadge('Identity Verified', true)}
          {renderVerificationBadge('Background Check Cleared', true)}
          {renderVerificationBadge('Bank Account Verified', true)}
        </View>
      </View>

      {/* Task Preferences Section */}
      <View style={styles.sectionContainer}>
        <Text style={[styles.sectionTitle, { color: palette.ink }]}>
          Task Preferences
        </Text>

        <View style={[styles.section, { backgroundColor: palette.surface }]}>
          <Text style={[styles.preferenceTitle, { color: palette.ink }]}>
            Accept Task Types
          </Text>

          <TouchableOpacity
            style={[
              styles.taskTypeToggle,
              {
                backgroundColor: settings.acceptPersonal
                  ? palette.accentSoft
                  : palette.surface2,
                borderColor: settings.acceptPersonal
                  ? palette.accent.personal
                  : palette.line,
              },
            ]}
            onPress={() => toggleTaskType('personal')}
          >
            <View style={styles.taskTypeIcon}>
              <Text style={styles.taskTypeEmoji}>👤</Text>
            </View>
            <View style={styles.taskTypeInfo}>
              <Text style={[styles.taskTypeLabel, { color: palette.ink }]}>
                Personal Tasks
              </Text>
              <Text style={[styles.taskTypeDesc, { color: palette.muted }]}>
                Individual errands & pickups
              </Text>
            </View>
            <Switch
              value={settings.acceptPersonal}
              onValueChange={() => toggleTaskType('personal')}
              trackColor={{ false: palette.line, true: palette.accentSoft }}
              thumbColor={settings.acceptPersonal ? palette.accent.personal : palette.muted}
            />
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.taskTypeToggle,
              {
                backgroundColor: settings.acceptBusiness
                  ? palette.bizSoft
                  : palette.surface2,
                borderColor: settings.acceptBusiness
                  ? palette.bizText
                  : palette.line,
              },
            ]}
            onPress={() => toggleTaskType('business')}
          >
            <View style={styles.taskTypeIcon}>
              <Text style={styles.taskTypeEmoji}>💼</Text>
            </View>
            <View style={styles.taskTypeInfo}>
              <Text style={[styles.taskTypeLabel, { color: palette.ink }]}>
                Business Tasks
              </Text>
              <Text style={[styles.taskTypeDesc, { color: palette.muted }]}>
                Commercial deliveries & services
              </Text>
            </View>
            <Switch
              value={settings.acceptBusiness}
              onValueChange={() => toggleTaskType('business')}
              trackColor={{ false: palette.line, true: palette.bizSoft }}
              thumbColor={settings.acceptBusiness ? palette.bizText : palette.muted}
            />
          </TouchableOpacity>
        </View>
      </View>

      {/* Service Radius Section */}
      <View style={styles.sectionContainer}>
        <Text style={[styles.sectionTitle, { color: palette.ink }]}>
          Service Area
        </Text>

        <View style={[styles.section, { backgroundColor: palette.surface }]}>
          <TouchableOpacity
            style={styles.radiusRow}
            onPress={() => {
              setTempRadius(settings.serviceRadius);
              setShowRadiusModal(true);
            }}
          >
            <View>
              <Text style={[styles.radiusLabel, { color: palette.muted }]}>
                📍 Service Radius
              </Text>
              <Text style={[styles.radiusValue, { color: palette.ink }]}>
                {settings.serviceRadius} km
              </Text>
              <Text style={[styles.radiusDesc, { color: palette.muted }]}>
                Tap to adjust your preferred service area
              </Text>
            </View>
            <Text style={[styles.radiusArrow, { color: palette.muted }]}>→</Text>
          </TouchableOpacity>

          <View style={[styles.radiusDivider, { backgroundColor: palette.line }]} />

          <TouchableOpacity
            style={styles.radiusRow}
          >
            <View>
              <Text style={[styles.radiusLabel, { color: palette.muted }]}>
                🗺️ Show on Map
              </Text>
              <Text style={[styles.radiusDesc, { color: palette.muted }]}>
                Customers can see your service area
              </Text>
            </View>
            <Switch
              value={true}
              disabled
              trackColor={{ false: palette.line, true: palette.accentSoft }}
              thumbColor={palette.accent.personal}
            />
          </TouchableOpacity>
        </View>
      </View>

      {/* Recent Reviews Section */}
      <View style={styles.sectionContainer}>
        <View style={styles.reviewsHeader}>
          <Text style={[styles.sectionTitle, { color: palette.ink }]}>
            Recent Reviews
          </Text>
          <TouchableOpacity>
            <Text style={[styles.seeAll, { color: palette.accentText }]}>
              See all →
            </Text>
          </TouchableOpacity>
        </View>

        <FlatList
          data={reviews.slice(0, 2)}
          keyExtractor={(item) => item.id}
          scrollEnabled={false}
          renderItem={({ item }) => (
            <View style={[styles.reviewCard, { backgroundColor: palette.surface }]}>
              <View style={styles.reviewHeader}>
                <View style={[styles.reviewAvatar, { backgroundColor: palette.accentSoft }]}>
                  <Text style={[styles.reviewInitial, { color: palette.accentText }]}>
                    {item.customerName[0]}
                  </Text>
                </View>
                <View style={styles.reviewInfo}>
                  <Text style={[styles.reviewName, { color: palette.ink }]}>
                    {item.customerName}
                  </Text>
                  <View style={styles.reviewRating}>
                    <Text style={styles.reviewStars}>
                      {'⭐'.repeat(Math.floor(item.rating))}
                    </Text>
                    <Text style={[styles.reviewDate, { color: palette.muted }]}>
                      {item.date}
                    </Text>
                  </View>
                </View>
              </View>
              <Text style={[styles.reviewText, { color: palette.ink }]}>
                {item.text}
              </Text>
            </View>
          )}
        />
      </View>

      {/* Settings Section */}
      <View style={styles.sectionContainer}>
        <Text style={[styles.sectionTitle, { color: palette.ink }]}>
          Settings
        </Text>

        <View style={[styles.section, { backgroundColor: palette.surface }]}>
          {/* Notifications */}
          <View
            style={[
              styles.settingRow,
              { borderBottomColor: palette.line },
            ]}
          >
            <View>
              <Text style={[styles.settingLabel, { color: palette.ink }]}>
                Notifications
              </Text>
              <Text style={[styles.settingHint, { color: palette.muted }]}>
                Receive push notifications
              </Text>
            </View>
            <Switch
              value={notificationsEnabled}
              onValueChange={setNotificationsEnabled}
              trackColor={{ false: palette.line, true: palette.accentSoft }}
              thumbColor={
                notificationsEnabled
                  ? palette.accent.personal
                  : palette.muted
              }
            />
          </View>

          {/* Edit Profile */}
          <TouchableOpacity
            style={[
              styles.settingRow,
              { borderBottomColor: palette.line },
            ]}
          >
            <View>
              <Text style={[styles.settingLabel, { color: palette.ink }]}>
                Edit Profile
              </Text>
              <Text style={[styles.settingHint, { color: palette.muted }]}>
                Update your information
              </Text>
            </View>
            <Text style={[styles.settingArrow, { color: palette.muted }]}>
              →
            </Text>
          </TouchableOpacity>

          {/* Payment Methods */}
          <TouchableOpacity
            style={[
              styles.settingRow,
              { borderBottomColor: palette.line },
            ]}
          >
            <View>
              <Text style={[styles.settingLabel, { color: palette.ink }]}>
                Payment Methods
              </Text>
              <Text style={[styles.settingHint, { color: palette.muted }]}>
                Manage your bank & UPI accounts
              </Text>
            </View>
            <Text style={[styles.settingArrow, { color: palette.muted }]}>
              →
            </Text>
          </TouchableOpacity>

          {/* Support */}
          <TouchableOpacity
            style={[
              styles.settingRow,
              { borderBottomColor: palette.line },
            ]}
          >
            <View>
              <Text style={[styles.settingLabel, { color: palette.ink }]}>
                Support
              </Text>
              <Text style={[styles.settingHint, { color: palette.muted }]}>
                Contact our support team
              </Text>
            </View>
            <Text style={[styles.settingArrow, { color: palette.muted }]}>
              →
            </Text>
          </TouchableOpacity>

          {/* About */}
          <TouchableOpacity
            style={styles.settingRow}
          >
            <View>
              <Text style={[styles.settingLabel, { color: palette.ink }]}>
                About Sahayakh
              </Text>
              <Text style={[styles.settingHint, { color: palette.muted }]}>
                Version 1.0.0
              </Text>
            </View>
            <Text style={[styles.settingArrow, { color: palette.muted }]}>
              →
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Logout Button */}
      <View style={styles.logoutSection}>
        <Button
          label="Logout"
          onPress={handleLogout}
          variant="danger"
          loading={loading}
        />
      </View>

      {/* Service Radius Modal */}
      <Modal
        visible={showRadiusModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowRadiusModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View
            style={[
              styles.modalContent,
              { backgroundColor: palette.surface },
            ]}
          >
            <View style={styles.modalHeader}>
              <Text style={[styles.modalTitle, { color: palette.ink }]}>
                Service Radius
              </Text>
              <TouchableOpacity
                onPress={() => setShowRadiusModal(false)}
                style={styles.modalClose}
              >
                <Text style={[styles.modalCloseText, { color: palette.muted }]}>
                  ✕
                </Text>
              </TouchableOpacity>
            </View>

            <Text style={[styles.modalDesc, { color: palette.muted }]}>
              Adjust how far you're willing to travel for tasks
            </Text>

            <View style={styles.radiusDisplay}>
              <Text style={[styles.radiusDisplayValue, { color: palette.accentText }]}>
                {Math.round(tempRadius)}
              </Text>
              <Text style={[styles.radiusDisplayUnit, { color: palette.muted }]}>
                kilometers
              </Text>
            </View>

            <View style={styles.sliderContainer}>
              <Text style={[styles.sliderLabel, { color: palette.muted }]}>
                1 km
              </Text>
              <Slider
                style={styles.slider}
                minimumValue={1}
                maximumValue={25}
                step={0.5}
                value={tempRadius}
                onValueChange={setTempRadius}
                minimumTrackTintColor={palette.accent.personal}
                maximumTrackTintColor={palette.line}
                thumbTintColor={palette.accent.personal}
              />
              <Text style={[styles.sliderLabel, { color: palette.muted }]}>
                25 km
              </Text>
            </View>

            <View style={[styles.radiusNote, { backgroundColor: palette.accentSoft }]}>
              <Text style={[styles.radiusNoteText, { color: palette.ink }]}>
                📍 Setting a larger radius increases your earning opportunities
              </Text>
            </View>

            <View style={styles.modalActions}>
              <Button
                label="Cancel"
                onPress={() => setShowRadiusModal(false)}
                variant="secondary"
                style={{ flex: 1, marginRight: 10 }}
              />
              <Button
                label="Apply"
                onPress={handleRadiusChange}
                variant="primary"
                style={{ flex: 1 }}
              />
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 18,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  title: {
    fontSize: 20,
    fontWeight: '800',
  },
  section: {
    borderRadius: 16,
    paddingHorizontal: 14,
    paddingVertical: 16,
    marginBottom: 12,
  },
  sectionContainer: {
    paddingHorizontal: 18,
    marginTop: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 12,
  },
  profileTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  largeAvatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  largeInitials: {
    fontSize: 28,
    fontWeight: '800',
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
  },
  profileEmail: {
    fontSize: 13.5,
  },
  statsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 16,
  },
  statBox: {
    flex: 1,
    alignItems: 'center',
  },
  statDivider: {
    width: 1,
    height: 40,
  },
  statValue: {
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 11,
  },
  verificationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 12,
    marginBottom: 10,
  },
  verificationIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  verificationCheckmark: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
  },
  verificationLabel: {
    fontSize: 14,
    fontWeight: '700',
  },
  verificationStatus: {
    fontSize: 12,
    marginTop: 2,
  },
  verificationOk: {
    fontSize: 12.5,
    fontWeight: '700',
  },
  reviewsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  seeAll: {
    fontSize: 13,
    fontWeight: '700',
  },
  reviewCard: {
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
  },
  reviewHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    marginBottom: 10,
  },
  reviewAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  reviewInitial: {
    fontSize: 16,
    fontWeight: '800',
  },
  reviewInfo: {
    flex: 1,
  },
  reviewName: {
    fontSize: 14,
    fontWeight: '700',
  },
  reviewRating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
  },
  reviewStars: {
    fontSize: 12,
  },
  reviewDate: {
    fontSize: 11.5,
  },
  reviewText: {
    fontSize: 13,
    lineHeight: 1.4,
    fontStyle: 'italic',
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    borderBottomWidth: 1,
  },
  settingLabel: {
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 2,
  },
  settingHint: {
    fontSize: 12.5,
  },
  settingArrow: {
    fontSize: 16,
  },
  logoutSection: {
    paddingHorizontal: 18,
    paddingVertical: 30,
  },
  preferenceTitle: {
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 12,
  },
  taskTypeToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderWidth: 1.5,
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 12,
    marginBottom: 10,
  },
  taskTypeIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.05)',
  },
  taskTypeEmoji: {
    fontSize: 20,
  },
  taskTypeInfo: {
    flex: 1,
  },
  taskTypeLabel: {
    fontSize: 14,
    fontWeight: '700',
  },
  taskTypeDesc: {
    fontSize: 12,
    marginTop: 2,
  },
  radiusRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  radiusLabel: {
    fontSize: 13,
    marginBottom: 4,
  },
  radiusValue: {
    fontSize: 18,
    fontWeight: '800',
  },
  radiusDesc: {
    fontSize: 12,
    marginTop: 4,
  },
  radiusArrow: {
    fontSize: 16,
  },
  radiusDivider: {
    height: 1,
    marginVertical: 12,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 18,
    paddingVertical: 20,
    paddingBottom: 30,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '800',
  },
  modalClose: {
    width: 36,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalCloseText: {
    fontSize: 18,
    fontWeight: '700',
  },
  modalDesc: {
    fontSize: 13,
    marginBottom: 20,
  },
  radiusDisplay: {
    alignItems: 'center',
    marginVertical: 20,
  },
  radiusDisplayValue: {
    fontSize: 48,
    fontWeight: '800',
  },
  radiusDisplayUnit: {
    fontSize: 14,
    marginTop: 4,
  },
  sliderContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginVertical: 20,
  },
  sliderLabel: {
    fontSize: 12,
    minWidth: 30,
  },
  slider: {
    flex: 1,
    height: 40,
  },
  radiusNote: {
    borderRadius: 12,
    padding: 12,
    marginBottom: 20,
  },
  radiusNoteText: {
    fontSize: 12.5,
    lineHeight: 1.4,
  },
  modalActions: {
    flexDirection: 'row',
    gap: 10,
  },
});
