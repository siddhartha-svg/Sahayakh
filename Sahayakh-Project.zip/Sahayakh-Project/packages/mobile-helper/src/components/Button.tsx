import React from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  ActivityIndicator,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { useTheme, colors } from '../theme';

interface ButtonProps {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'large' | 'medium' | 'small';
  disabled?: boolean;
  loading?: boolean;
  style?: ViewStyle;
}

export const Button: React.FC<ButtonProps> = ({
  label,
  onPress,
  variant = 'primary',
  size = 'large',
  disabled = false,
  loading = false,
  style,
}) => {
  const { colorMode } = useTheme();
  const palette = colors[colorMode];

  const buttonStyles: Record<string, ViewStyle> = {
    primary: {
      backgroundColor: palette.accent.personal,
      borderColor: palette.accent.personal,
    },
    secondary: {
      backgroundColor: 'transparent',
      borderColor: palette.accent.personal,
      borderWidth: 1.5,
    },
    ghost: {
      backgroundColor: palette.surface2,
      borderColor: palette.line,
      borderWidth: 1,
    },
    danger: {
      backgroundColor: 'transparent',
      borderColor: palette.error,
      borderWidth: 1.5,
    },
  };

  const textStyles: Record<string, TextStyle> = {
    primary: { color: '#fff' },
    secondary: { color: palette.accentText },
    ghost: { color: palette.muted },
    danger: { color: palette.error },
  };

  const sizeStyles: Record<string, ViewStyle> = {
    large: { height: 48, paddingHorizontal: 16 },
    medium: { height: 40, paddingHorizontal: 12 },
    small: { height: 32, paddingHorizontal: 10 },
  };

  const textSizes: Record<string, number> = {
    large: 15,
    medium: 14,
    small: 13,
  };

  return (
    <TouchableOpacity
      style={[
        styles.button,
        buttonStyles[variant],
        sizeStyles[size],
        disabled && styles.disabled,
        style,
      ]}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.7}
    >
      {loading ? (
        <ActivityIndicator
          color={variant === 'primary' ? '#fff' : palette.accentText}
          size="small"
        />
      ) : (
        <Text
          style={[
            styles.text,
            textStyles[variant],
            { fontSize: textSizes[size] },
          ]}
        >
          {label}
        </Text>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  text: {
    fontWeight: '700',
    textAlign: 'center',
  },
  disabled: {
    opacity: 0.5,
  },
});
