import axios from 'axios';
import { useAuthStore } from '../store';

const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:3000/api';

export const apiClient = axios.create({
  baseURL: API_URL,
  timeout: 10000,
});

apiClient.interceptors.request.use((config) => {
  const { token } = useAuthStore.getState();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      useAuthStore.getState().logout();
    }
    return Promise.reject(error);
  }
);

// Task Management
export const taskApi = {
  getIncomingRequests: () => apiClient.get('/tasks/incoming'),
  acceptTask: (taskId: string) => apiClient.post(`/tasks/${taskId}/accept`),
  declineTask: (taskId: string) => apiClient.post(`/tasks/${taskId}/decline`),
  getActiveTasks: () => apiClient.get('/tasks/active'),
  getCompletedTasks: (limit = 10, offset = 0) =>
    apiClient.get('/tasks/completed', { params: { limit, offset } }),
  getTaskDetails: (taskId: string) => apiClient.get(`/tasks/${taskId}`),
  updateTaskStatus: (taskId: string, status: string) =>
    apiClient.patch(`/tasks/${taskId}/status`, { status }),
  completeTask: (taskId: string, data: any) =>
    apiClient.post(`/tasks/${taskId}/complete`, data),
};

// Earnings & Payouts
export const earningsApi = {
  getBalance: () => apiClient.get('/helpers/me/balance'),
  getEarningsHistory: (limit = 10, offset = 0) =>
    apiClient.get('/helpers/me/earnings', { params: { limit, offset } }),
  getPayoutHistory: (limit = 10, offset = 0) =>
    apiClient.get('/helpers/me/payouts', { params: { limit, offset } }),
  initiateWithdrawal: (amount: number, paymentMethod: string, details: any) =>
    apiClient.post('/helpers/me/withdrawal', { amount, paymentMethod, details }),
  getWithdrawalMethods: () => apiClient.get('/helpers/me/withdrawal-methods'),
};

// Helper Profile
export const helperApi = {
  getProfile: () => apiClient.get('/helpers/me'),
  updateProfile: (data: any) => apiClient.patch('/helpers/me', data),
  getReviews: (limit = 10, offset = 0) =>
    apiClient.get('/helpers/me/reviews', { params: { limit, offset } }),
  getStatistics: () => apiClient.get('/helpers/me/statistics'),
};

// Availability & Status
export const statusApi = {
  setOnline: () => apiClient.post('/helpers/me/online'),
  setOffline: () => apiClient.post('/helpers/me/offline'),
  getStatus: () => apiClient.get('/helpers/me/status'),
  updateLocation: (latitude: number, longitude: number) =>
    apiClient.post('/helpers/me/location', { latitude, longitude }),
};

// Notifications
export const notificationApi = {
  registerDevice: (token: string) => apiClient.post('/notifications/register', { token }),
  getNotifications: (limit = 10, offset = 0) =>
    apiClient.get('/notifications', { params: { limit, offset } }),
  markAsRead: (notificationId: string) =>
    apiClient.patch(`/notifications/${notificationId}/read`),
};

// Chat & Support
export const chatApi = {
  getMessages: (taskId: string) => apiClient.get(`/tasks/${taskId}/messages`),
  sendMessage: (taskId: string, message: string, attachments?: any[]) =>
    apiClient.post(`/tasks/${taskId}/messages`, { message, attachments }),
};

// Disputes
export const disputeApi = {
  raiseDispute: (taskId: string, category: string, description: string) =>
    apiClient.post('/disputes', { taskId, category, description }),
  getMyDisputes: () => apiClient.get('/disputes/me'),
  addDisputeMessage: (disputeId: string, message: string) =>
    apiClient.post(`/disputes/${disputeId}/messages`, { message }),
};

export default apiClient;
