import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar?: string;
  rating?: number;
  tasksCompleted?: number;
}

interface AuthStore {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  setUser: (user: User) => void;
  setToken: (token: string) => void;
  logout: () => void;
}

interface AvailabilityStore {
  isOnline: boolean;
  toggleOnline: () => void;
  setOnline: (online: boolean) => void;
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      setUser: (user) => set({ user, isAuthenticated: true }),
      setToken: (token) => set({ token }),
      logout: () => set({ user: null, token: null, isAuthenticated: false }),
    }),
    {
      name: 'sahayakh-helper-auth',
      storage: AsyncStorage,
    }
  )
);

export const useAvailabilityStore = create<AvailabilityStore>()(
  persist(
    (set) => ({
      isOnline: false,
      toggleOnline: () => set((state) => ({ isOnline: !state.isOnline })),
      setOnline: (online) => set({ isOnline: online }),
    }),
    {
      name: 'sahayakh-helper-availability',
      storage: AsyncStorage,
    }
  )
);
