import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Text } from 'react-native';
import { useAuthStore } from '../store';
import {
  HomeScreen,
  MyTasksScreen,
  EarningsScreen,
  ProfileScreen,
  RequestScreen,
  NavigateScreen,
  OTPScreen,
  WorkScreen,
  SummaryScreen,
  DoneScreen,
} from '../screens';
import { colors } from '../theme';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const AuthScreen = () => <View><Text>Auth Screen</Text></View>;

const palette = colors.light;

const MainTabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: palette.surface,
          borderTopColor: palette.line,
          borderTopWidth: 1,
          paddingBottom: 8,
          paddingTop: 8,
          height: 60,
        },
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '600',
        },
        tabBarActiveTintColor: palette.accent.personal,
        tabBarInactiveTintColor: palette.muted,
      }}
    >
      <Tab.Screen
        name="HomeTab"
        component={HomeScreen}
        options={{
          title: 'Home',
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20 }}>🏠</Text>,
        }}
      />
      <Tab.Screen
        name="TasksTab"
        component={MyTasksScreen}
        options={{
          title: 'My Tasks',
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20 }}>📋</Text>,
        }}
      />
      <Tab.Screen
        name="EarningsTab"
        component={EarningsScreen}
        options={{
          title: 'Earnings',
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20 }}>💰</Text>,
        }}
      />
      <Tab.Screen
        name="ProfileTab"
        component={ProfileScreen}
        options={{
          title: 'Profile',
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20 }}>👤</Text>,
        }}
      />
    </Tab.Navigator>
  );
};

export const RootNavigator = () => {
  const { isAuthenticated } = useAuthStore();

  return (
    <NavigationContainer>
      {!isAuthenticated ? (
        <Stack.Navigator
          screenOptions={{
            headerShown: false,
            animationEnabled: true,
          }}
        >
          <Stack.Screen name="Auth" component={AuthScreen} />
        </Stack.Navigator>
      ) : (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          <Stack.Group>
            <Stack.Screen
              name="MainTabs"
              component={MainTabNavigator}
              options={{ animationEnabled: false }}
            />
          </Stack.Group>

          {/* Task Flow - Modal Stack */}
          <Stack.Group screenOptions={{ presentation: 'card' }}>
            <Stack.Screen
              name="Request"
              component={RequestScreen}
              options={{ animationEnabled: true }}
            />
            <Stack.Screen
              name="Navigate"
              component={NavigateScreen}
              options={{ animationEnabled: true }}
            />
            <Stack.Screen
              name="OTP"
              component={OTPScreen}
              options={{ animationEnabled: true }}
            />
            <Stack.Screen
              name="Work"
              component={WorkScreen}
              options={{ animationEnabled: true }}
            />
            <Stack.Screen
              name="Summary"
              component={SummaryScreen}
              options={{ animationEnabled: true }}
            />
            <Stack.Screen
              name="Done"
              component={DoneScreen}
              options={{ animationEnabled: true }}
            />
          </Stack.Group>
        </Stack.Navigator>
      )}
    </NavigationContainer>
  );
};
