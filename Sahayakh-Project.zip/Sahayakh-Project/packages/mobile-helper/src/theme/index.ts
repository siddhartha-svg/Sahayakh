import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { colors } from './colors';

type ColorMode = 'light' | 'dark';

interface ThemeStore {
  colorMode: ColorMode;
  setColorMode: (mode: ColorMode) => void;
  toggleColorMode: () => void;
}

export const useTheme = create<ThemeStore>()(
  persist(
    (set) => ({
      colorMode: 'light',
      setColorMode: (mode) => set({ colorMode: mode }),
      toggleColorMode: () => set((state) => ({
        colorMode: state.colorMode === 'light' ? 'dark' : 'light',
      })),
    }),
    {
      name: 'sahayakh-theme',
      storage: AsyncStorage,
    }
  )
);

export const getColors = () => {
  const { colorMode } = useTheme.getState();
  return colors[colorMode];
};

export { colors };
