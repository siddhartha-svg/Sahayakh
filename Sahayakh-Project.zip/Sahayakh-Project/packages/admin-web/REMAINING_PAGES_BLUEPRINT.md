# Remaining Pages - Implementation Blueprint

This document provides the structure and code templates for the 3 remaining pages.

---

## 5. Disputes Page

**File**: `src/pages/Disputes.tsx`

### Features
- Dispute listing with status filter (Open, Resolved, All)
- Priority indicator (High/Medium/Low)
- Dispute detail drawer with message thread
- Admin resolution options

### Page Layout
```
┌─ Header ──────────────────────────┐
│ Disputes                           │
│ Complaints from customers/helpers  │
└────────────────────────────────────┘
┌─ Filters ─────────────────────────┐
│ [Open] [Resolved] [All]           │
│ Dispute count                      │
└────────────────────────────────────┘
┌─ Table ───────────────────────────┐
│ ID | Issue | Raised By | Prio | St│
│----|-------|-----------|------|---│
│    | ...   | ...       | High | ✓ │
└────────────────────────────────────┘
```

### Data Structure
```typescript
interface Dispute {
  id: string
  taskId: string
  issue: string
  raisedBy: string
  against: string
  role: 'Customer' | 'Helper'
  priority: 'high' | 'medium' | 'low'
  status: 'open' | 'resolved'
  refundMax: number
  messages: Array<{
    userId: string
    userName: string
    text: string
    timestamp: string
  }>
  resolution?: {
    type: 'customer_win' | 'helper_win' | 'partial' | 'dismiss'
    notes: string
    resolvedAt: string
  }
}
```

### Key Components
1. **Status filter** - Open/Resolved/All chips
2. **Priority badge** - High (red), Medium (yellow), Low (gray)
3. **Dispute drawer** with:
   - Issue title
   - Task reference (clickable)
   - Both parties' info
   - Message thread
   - Evidence links
4. **Resolution modal** - Choose action & enter details

### API Calls
```typescript
// Load disputes
const res = await disputeApi.getDisputes({ 
  status: filter === 'all' ? undefined : filter 
})

// Get full details
const res = await disputeApi.getDisputeDetails(disputeId)

// Resolve dispute
await disputeApi.resolveDispute(disputeId, {
  type: 'customer_win' | 'helper_win' | 'partial' | 'dismiss',
  refundAmount?: number,
  helperPayoutAmount?: number,
  notes?: string
})
```

### Column Definitions
```typescript
const columns = [
  {
    key: 'id',
    label: 'ID',
    width: '0.8fr',
    render: (val, row) => (
      <div>
        <div style={{ fontWeight: '700' }}>{val}</div>
        <div style={{ fontSize: '12.5px', color: colors.muted }}>
          {row.taskId}
        </div>
      </div>
    )
  },
  {
    key: 'issue',
    label: 'Issue',
    width: '2.6fr',
    hideOnMobile: true,
    render: (val, row) => (
      <div>
        <div style={{ fontWeight: '700' }}>{val}</div>
        <div style={{ fontSize: '12.5px', color: colors.muted }}>
          {row.raisedBy} vs {row.against}
        </div>
      </div>
    )
  },
  {
    key: 'raisedBy',
    label: 'Raised by',
    width: '1.5fr',
    hideOnMobile: true
  },
  {
    key: 'priority',
    label: 'Priority',
    width: '0.9fr',
    render: (val) => (
      <Pill
        label={val.charAt(0).toUpperCase() + val.slice(1)}
        tone={val === 'high' ? 'bad' : val === 'medium' ? 'warn' : 'mute'}
      />
    )
  },
  {
    key: 'status',
    label: 'Status',
    width: '1fr',
    render: (val) => (
      <Pill label={val === 'open' ? 'Open' : 'Resolved'} tone={val === 'open' ? 'warn' : 'ok'} />
    )
  }
]
```

### Resolution Options
```typescript
const resolutionOptions = [
  {
    label: 'Refund the customer in full',
    type: 'customer_win',
    subtext: 'Return ₹X to customer'
  },
  {
    label: 'Partial refund',
    type: 'partial',
    subtext: 'Choose amounts for customer & helper'
  },
  {
    label: 'Pay helper, no refund',
    type: 'helper_win',
    subtext: 'Complaint not upheld'
  },
  {
    label: 'Warn the person complained about',
    type: 'warn',
    subtext: 'Log warning and close'
  },
  {
    label: 'Dismiss',
    type: 'dismiss',
    subtext: 'No action needed'
  }
]
```

---

## 6. Payouts Page

**File**: `src/pages/Payouts.tsx`

### Features
- Summary cards (Waiting, Paid, Failed)
- Payout table with status and actions
- Bulk "Pay all pending" action
- Individual payout processing

### Page Layout
```
┌─ Header ──────────────────────────┐
│ Payouts                            │
│ Helper withdrawal requests         │
└────────────────────────────────────┘
┌─ Summary Cards ───────────────────┐
│ Waiting: ₹X (N req) │ Paid: ₹Y (N) │ Failed: N │
└────────────────────────────────────┘
┌─ Table ───────────────────────────┐
│ Helper | Method | Amount | Status │
│--------|--------|--------|--------|
│ Name   | UPI    | ₹X     | Pending│
└────────────────────────────────────┘
```

### Data Structure
```typescript
interface Payout {
  id: string
  helperId: string
  helperName: string
  amount: number
  method: string // "UPI rohit@upi" or "HDFC Bank ****4821"
  requestedAt: string
  status: 'pending' | 'paid' | 'failed'
  failureReason?: string
}

interface PayoutSummary {
  waiting: number // amount
  waitingCount: number
  paidThisWeek: number // amount
  paidCount: number
  failedCount: number
}
```

### Key Components
1. **Summary cards** - 3 cards with amounts and counts
2. **Payout table** with columns:
   - Helper (avatar + name)
   - Method (UPI/Bank with details)
   - Amount (₹X)
   - Status (Pending/Paid/Failed)
   - Actions (Pay now, Hold, Retry)
3. **Bulk action** - "Pay all pending" button
4. **Action modals** - Confirm before paying/holding

### API Calls
```typescript
// Get summary
const summary = await payoutApi.payoutSummary()

// List payouts
const res = await payoutApi.getPayouts({
  status: filter,
  limit: 50
})

// Process individual payout
await payoutApi.processPayout(payoutId)

// Hold for review
await payoutApi.holdPayout(payoutId, reason)

// Retry failed payout
await payoutApi.retryPayout(payoutId)
```

### Column Definitions
```typescript
const columns = [
  {
    key: 'helperName',
    label: 'Helper',
    width: '2.2fr',
    render: (val, row) => (
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <div style={{
          width: '40px',
          height: '40px',
          borderRadius: '8px',
          backgroundColor: colors.brandSoft,
          display: 'grid',
          placeItems: 'center',
          color: colors.brandText
        }}>
          {val.charAt(0)}
        </div>
        <div>
          <div style={{ fontWeight: '700' }}>{val}</div>
          <div style={{ fontSize: '12.5px', color: colors.muted }}>
            {row.id}
          </div>
        </div>
      </div>
    )
  },
  {
    key: 'method',
    label: 'Payment Method',
    width: '1.6fr',
    hideOnMobile: true,
    render: (val) => val // "UPI rohit@upi" or "HDFC Bank ****4821"
  },
  {
    key: 'amount',
    label: 'Amount',
    width: '1fr',
    hideOnMobile: true,
    render: (val) => `₹${val.toLocaleString('en-IN')}`
  },
  {
    key: 'status',
    label: 'Status',
    width: '0.9fr',
    render: (val, row) => {
      const tone = val === 'pending' ? 'warn' : val === 'paid' ? 'ok' : 'bad'
      const label = val === 'pending' ? 'Pending' : val === 'paid' ? 'Paid' : 'Failed'
      return <Pill label={label} tone={tone} size="small" />
    }
  },
  {
    key: 'id',
    label: 'Actions',
    width: '1.5fr',
    render: (val, row) => {
      if (row.status === 'pending') {
        return (
          <div style={{ display: 'flex', gap: '8px' }}>
            <Button label="Pay now" onClick={() => processPayout(val)} variant="primary" size="small" />
            <Button label="Hold" onClick={() => holdPayout(val)} variant="soft" size="small" />
          </div>
        )
      }
      if (row.status === 'failed') {
        return <Button label="Retry" onClick={() => retryPayout(val)} variant="outline" size="small" />
      }
      return null
    }
  }
]
```

### Summary Card Component
```typescript
<div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px', marginBottom: '16px' }}>
  <div style={{ padding: '16px', backgroundColor: colors.surface, border: `1px solid ${colors.line}`, borderRadius: '18px' }}>
    <span style={{ color: colors.muted, fontSize: '13px', fontWeight: '600' }}>Waiting to be paid</span>
    <div style={{ fontSize: '26px', fontWeight: '800', marginTop: '2px', marginBottom: '8px' }}>
      ₹{summary.waiting.toLocaleString('en-IN')}
    </div>
    <span style={{ fontSize: '12.5px', color: colors.muted }}>
      {summary.waitingCount} request{summary.waitingCount !== 1 ? 's' : ''}
    </span>
  </div>
  {/* Paid & Failed cards similarly */}
</div>
```

---

## 7. Pricing Page

**File**: `src/pages/Pricing.tsx`

### Features
- Pricing configuration form
- Live fare calculator
- Save/Reset buttons
- Unsaved changes indicator

### Page Layout
```
┌─ Header ──────────────────────────┐
│ Pricing & rules                    │
│ Set how tasks are priced           │
└────────────────────────────────────┘
┌─ Two Column Layout ───────────────┐
│ Rates Config  │  Fare Calculator  │
│               │                   │
│ [Form]        │ [Calculator]      │
└───────────────┴───────────────────┘
```

### Data Structure
```typescript
interface PricingConfig {
  base: number        // ₹ per task
  km: number          // ₹ per km
  min: number         // ₹ per minute
  minFare: number     // ₹ minimum
  bizMult: number     // x multiplier
  fee: number         // % commission
  cancel: number      // ₹ cancellation fee
  bonusTasks: number  // tasks to complete
  bonusAmt: number    // ₹ bonus amount
}

interface FareCalculation {
  km: number
  min: number
  isBusiness: boolean
  raw: number
  fare: number
  fee: number
  helperEarns: number
}
```

### Form Fields
```typescript
const fields = [
  { key: 'base', label: 'Base fare', unit: '₹', help: 'Charged on every task' },
  { key: 'km', label: 'Per kilometre', unit: '₹', step: '0.5', help: 'Actual distance travelled' },
  { key: 'min', label: 'Per minute', unit: '₹', step: '0.5', help: 'Actual task time' },
  { key: 'minFare', label: 'Minimum fare', unit: '₹', help: 'Lowest a task can cost' },
  { key: 'bizMult', label: 'Business multiplier', unit: 'x', step: '0.05', help: 'Applied to business tasks' },
  { key: 'fee', label: 'Sahayakh fee', unit: '%', help: 'Taken from each task total' },
  { key: 'cancel', label: 'Cancellation fee', unit: '₹', help: 'After a helper is assigned' },
  { key: 'bonusTasks', label: 'Daily bonus tasks', unit: '', help: 'Tasks a helper must finish' },
  { key: 'bonusAmt', label: 'Daily bonus amount', unit: '₹', help: 'Paid on reaching the target' }
]
```

### Calculator UI
```
Task Type: [Personal ▪] [Business ▪]
Distance:  [4.8] km
Time:      [37] minutes

─────────────────────────
Base fare:      ₹40
Distance (4.8km): ₹72
Time (37min):   ₹92.5
Minimum applied: —
Business rate:  —
─────────────────────────
Customer pays:  ₹280
Fee (15%):      ₹42
Helper earns:   ₹238
```

### API Calls
```typescript
// Get current pricing
const res = await pricingApi.getPricing()
setPricing(res.data)

// Save changes
await pricingApi.updatePricing(updatedConfig)
setSaved(true)

// Calculate fare (live as user types)
const result = await pricingApi.calculateFare(
  distance,
  duration,
  isBusinessTask
)
```

### Component Code Example
```typescript
import React, { useState, useEffect } from 'react'
import { useTheme } from '../theme'
import { Button } from '../components/Button'
import { pricingApi } from '../api/client'

export const Pricing: React.FC = () => {
  const { getColors } = useTheme()
  const colors = getColors()

  const [config, setConfig] = useState<PricingConfig>({
    base: 40,
    km: 15,
    min: 2.5,
    minFare: 80,
    bizMult: 1.25,
    fee: 15,
    cancel: 30,
    bonusTasks: 5,
    bonusAmt: 100
  })
  const [saved, setSaved] = useState<PricingConfig>(config)
  const [calc, setCalc] = useState({ km: 4.8, min: 37, biz: false })

  useEffect(() => {
    loadPricing()
  }, [])

  const loadPricing = async () => {
    try {
      const res = await pricingApi.getPricing()
      setConfig(res.data)
      setSaved(res.data)
    } catch (error) {
      console.error('Failed to load pricing:', error)
    }
  }

  const isDirty = JSON.stringify(config) !== JSON.stringify(saved)

  const handleSave = async () => {
    try {
      await pricingApi.updatePricing(config)
      setSaved(config)
      // showToast success
    } catch (error) {
      // showToast error
    }
  }

  return (
    <div style={{ padding: '24px' }}>
      <h1>Pricing & rules</h1>

      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '14px' }}>
        {/* Left: Form */}
        <div>
          <h2>Rates</h2>
          {/* Form fields here */}
          <div style={{ display: 'flex', gap: '10px', marginTop: '18px' }}>
            <Button label="Save changes" onClick={handleSave} variant="primary" disabled={!isDirty} />
            <Button label="Reset" onClick={() => setConfig(saved)} variant="soft" disabled={!isDirty} />
          </div>
        </div>

        {/* Right: Calculator */}
        <div>
          <h2>Fare calculator</h2>
          {/* Calculator here */}
        </div>
      </div>
    </div>
  )
}
```

---

## Implementation Order

1. **Disputes** - Most complex, message thread UI
2. **Payouts** - Table with actions, summary cards
3. **Pricing** - Form with calculator, real-time updates

---

## Common Patterns to Reuse

### Filter & Search
```typescript
const filteredItems = items.filter((item) => {
  const q = searchQuery.toLowerCase()
  return item.name.toLowerCase().includes(q)
})
```

### Drawer Opener
```typescript
const handleSelect = async (item) => {
  const res = await api.getDetails(item.id)
  setSelected(res.data)
}
```

### Modal Confirmation
```typescript
const handleAction = async () => {
  try {
    await api.action(id, data)
    setItems(items.filter(i => i.id !== id))
    showToast('Success', 'success')
  } catch (error) {
    showToast('Error', 'error')
  }
}
```

---

**Ready to implement!** Follow these blueprints and patterns to complete the remaining pages.
