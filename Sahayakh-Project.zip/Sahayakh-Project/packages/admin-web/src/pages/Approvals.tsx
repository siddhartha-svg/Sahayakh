import React, { useState, useEffect } from 'react'
import { useTheme } from '../theme'
import { Icon } from '../components/Icon'
import { Badge, Tag } from '../components/Badge'
import { Modal, Drawer } from '../components/Modal'
import { Table } from '../components/Table'
import { Button } from '../components/Button'
import { Pill } from '../components/Pill'
import { approvalApi } from '../api/client'
import { useUIStore } from '../store'

interface Application {
  id: string
  name: string
  area: string
  appliedAt: string
  type: 'Personal' | 'Business' | 'Both'
  skills: string[]
  avatar?: string
  docs: {
    aadhaar: 'ok' | 'review' | 'missing' | 'mismatch'
    pan: 'ok' | 'review' | 'missing' | 'mismatch'
    selfie: 'ok' | 'review' | 'missing' | 'mismatch'
    bank: 'ok' | 'review' | 'missing' | 'mismatch'
    police: 'ok' | 'review' | 'missing' | 'mismatch'
  }
}

const DOCS = [
  { key: 'aadhaar', label: 'Aadhaar card', icon: 'id' },
  { key: 'pan', label: 'PAN card', icon: 'id' },
  { key: 'selfie', label: 'Selfie match', icon: 'camera' },
  { key: 'bank', label: 'Bank account', icon: 'bank' },
  { key: 'police', label: 'Police verification', icon: 'shield' }
]

const DSTAT = {
  ok: { tone: 'ok' as const, label: 'Verified' },
  review: { tone: 'warn' as const, label: 'Needs review' },
  missing: { tone: 'mute' as const, label: 'Not uploaded' },
  mismatch: { tone: 'bad' as const, label: 'Photo mismatch' }
}

export const Approvals: React.FC = () => {
  const { getColors } = useTheme()
  const colors = getColors()
  const { showToast } = useUIStore()
  const [applications, setApplications] = useState<Application[]>([])
  const [loading, setLoading] = useState(false)
  const [selectedApp, setSelectedApp] = useState<Application | null>(null)
  const [showRejectModal, setShowRejectModal] = useState(false)
  const [rejectReason, setRejectReason] = useState('')

  useEffect(() => {
    loadApplications()
  }, [])

  const loadApplications = async () => {
    setLoading(true)
    try {
      const res = await approvalApi.getApplications(50)
      setApplications(res.data || [])
    } catch (error) {
      console.error('Failed to load applications:', error)
      showToast('Failed to load applications', 'error')
    } finally {
      setLoading(false)
    }
  }

  const docsOk = (app: Application) => {
    return Object.values(app.docs).filter((d) => d === 'ok').length
  }

  const isReady = (app: Application) => docsOk(app) === DOCS.length

  const handleApprove = async () => {
    if (!selectedApp) return
    try {
      await approvalApi.approveApplication(selectedApp.id)
      setApplications(applications.filter((a) => a.id !== selectedApp.id))
      setSelectedApp(null)
      showToast(`${selectedApp.name} approved as helper`, 'success')
    } catch (error) {
      console.error('Failed to approve:', error)
      showToast('Failed to approve application', 'error')
    }
  }

  const handleReject = async () => {
    if (!selectedApp || !rejectReason) return
    try {
      await approvalApi.rejectApplication(selectedApp.id, rejectReason)
      setApplications(applications.filter((a) => a.id !== selectedApp.id))
      setSelectedApp(null)
      setShowRejectModal(false)
      setRejectReason('')
      showToast(`${selectedApp.name}'s application rejected`, 'success')
    } catch (error) {
      console.error('Failed to reject:', error)
      showToast('Failed to reject application', 'error')
    }
  }

  const handleVerifyDoc = async (docKey: string) => {
    if (!selectedApp) return
    try {
      await approvalApi.verifyDocument(selectedApp.id, docKey)
      const updated = { ...selectedApp }
      updated.docs[docKey as keyof typeof updated.docs] = 'ok'
      setSelectedApp(updated)
      setApplications(
        applications.map((a) => (a.id === selectedApp.id ? updated : a))
      )
      showToast(`${docKey} marked verified`, 'success')
    } catch (error) {
      console.error('Failed to verify:', error)
      showToast('Failed to verify document', 'error')
    }
  }

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
      <div style={{ padding: '24px' }}>
        <div style={{ marginBottom: '18px' }}>
          <h1 style={{ fontSize: '26px', fontWeight: '800', letterSpacing: '-0.03em', margin: 0 }}>
            Helper approvals
          </h1>
          <p style={{ color: colors.muted, marginTop: '2px', margin: 0 }}>
            Check documents and approve new helpers before they can take tasks
          </p>
        </div>

        {applications.length === 0 && !loading ? (
          <div
            style={{
              backgroundColor: colors.surface,
              border: `1px solid ${colors.line}`,
              borderRadius: '18px',
              padding: '36px 16px',
              textAlign: 'center'
            }}
          >
            <div style={{ color: colors.ink, fontSize: '15px', fontWeight: '700', marginBottom: '2px' }}>
              All caught up
            </div>
            <div style={{ color: colors.muted }}>
              New applications will show up here.
            </div>
          </div>
        ) : (
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
              gap: '14px'
            }}
          >
            {applications.map((app) => {
              const ok = docsOk(app)
              const ready = isReady(app)

              return (
                <div
                  key={app.id}
                  onClick={() => setSelectedApp(app)}
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '12px',
                    textAlign: 'left',
                    width: '100%',
                    backgroundColor: colors.surface,
                    border: `1px solid ${colors.line}`,
                    borderRadius: '18px',
                    padding: '16px',
                    boxShadow: colors.shadow,
                    cursor: 'pointer',
                    transition: 'border-color 0.2s ease',
                    userSelect: 'none'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = colors.brand
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = colors.line
                  }}
                >
                  <span style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div
                      style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '12px',
                        backgroundColor: colors.brandSoft,
                        display: 'grid',
                        placeItems: 'center',
                        fontSize: '18px',
                        fontWeight: '800',
                        color: colors.brandText,
                        flex: 0
                      }}
                    >
                      {app.name.charAt(0)}
                    </div>
                    <span style={{ flex: 1 }}>
                      <span style={{ display: 'block', fontSize: '15px', fontWeight: '700' }}>
                        {app.name}
                      </span>
                      <span style={{ display: 'block', fontSize: '12.5px', color: colors.muted }}>
                        {app.area}, {app.appliedAt}
                      </span>
                    </span>
                    <Pill
                      label={ready ? 'Ready' : 'In review'}
                      tone={ready ? 'ok' : 'warn'}
                      size="small"
                    />
                  </span>

                  <span style={{ fontSize: '12.5px', color: colors.muted }}>
                    Documents verified
                  </span>
                  <div
                    style={{
                      display: 'block',
                      height: '4px',
                      backgroundColor: colors.line,
                      borderRadius: '99px',
                      overflow: 'hidden'
                    }}
                  >
                    <div
                      style={{
                        height: '100%',
                        width: `${(ok / DOCS.length) * 100}%`,
                        backgroundColor: colors.brand,
                        borderRadius: '99px',
                        transition: 'width 0.3s ease'
                      }}
                    />
                  </div>
                  <span style={{ fontSize: '11px', color: colors.muted, marginTop: '2px' }}>
                    {ok} of {DOCS.length}
                  </span>

                  <span style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                    {app.skills.map((skill) => (
                      <Tag key={skill} label={skill} />
                    ))}
                  </span>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Drawer */}
      <Drawer
        isOpen={!!selectedApp}
        onClose={() => setSelectedApp(null)}
        title={selectedApp ? `Application ${selectedApp.id}` : ''}
        footer={
          selectedApp && (
            <>
              <Button
                label="Reject"
                onClick={() => setShowRejectModal(true)}
                variant="danger"
                fullWidth
              />
              <Button
                label={isReady(selectedApp) ? 'Approve helper' : 'Approve'}
                onClick={handleApprove}
                variant="primary"
                disabled={!isReady(selectedApp)}
                fullWidth
              />
            </>
          )
        }
      >
        {selectedApp && (
          <>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '14px',
                marginBottom: '14px'
              }}
            >
              <div
                style={{
                  width: '64px',
                  height: '64px',
                  borderRadius: '16px',
                  backgroundColor: colors.brandSoft,
                  display: 'grid',
                  placeItems: 'center',
                  fontSize: '24px',
                  fontWeight: '800',
                  color: colors.brandText'
                }}
              >
                {selectedApp.name.charAt(0)}
              </div>
              <div>
                <div style={{ fontSize: '19px', fontWeight: '800', letterSpacing: '-0.02em' }}>
                  {selectedApp.name}
                </div>
                <div style={{ fontSize: '12.5px', color: colors.muted }}>
                  {selectedApp.area}, {selectedApp.appliedAt}
                </div>
              </div>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px', color: colors.muted }}>
                Phone
              </div>
              <div style={{ fontSize: '13.5px' }}>+91 90000 21501</div>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px', color: colors.muted }}>
                Wants to do
              </div>
              <div style={{ fontSize: '13.5px' }}>{selectedApp.type} tasks</div>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px' }}>Skills</div>
              <span style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                {selectedApp.skills.map((skill) => (
                  <Tag key={skill} label={skill} />
                ))}
              </span>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px' }}>Documents</div>
              <div
                style={{
                  backgroundColor: colors.surface2,
                  borderRadius: '12px',
                  padding: '2px 14px'
                }}
              >
                {DOCS.map((doc) => {
                  const status = selectedApp.docs[doc.key as keyof typeof selectedApp.docs]
                  const dstat = DSTAT[status]
                  const btn =
                    status === 'review' || status === 'mismatch'
                      ? 'Mark verified'
                      : status === 'missing'
                        ? 'Ask to upload'
                        : null

                  return (
                    <div
                      key={doc.key}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px',
                        padding: '11px 0',
                        borderBottom: `1px solid ${colors.line}`
                      }}
                    >
                      <span
                        style={{
                          display: 'grid',
                          placeItems: 'center',
                          color: colors.muted
                        }}
                      >
                        <Icon name={doc.icon as any} size={18} />
                      </span>
                      <div>
                        <div style={{ fontSize: '14px', fontWeight: '700' }}>{doc.label}</div>
                      </div>
                      <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <Pill label={dstat.label} tone={dstat.tone} size="small" />
                        {btn && (
                          <Button
                            label={btn}
                            onClick={() => handleVerifyDoc(doc.key)}
                            variant="soft"
                            size="small"
                          />
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            {selectedApp.docs.selfie === 'mismatch' && (
              <div
                style={{
                  marginTop: '10px',
                  fontSize: '13px',
                  color: colors.muted,
                  padding: '10px 12px',
                  backgroundColor: colors.surface2,
                  borderRadius: '8px'
                }}
              >
                The selfie does not match the photo on the ID. Check both before you verify it.
              </div>
            )}
          </>
        )}
      </Drawer>

      {/* Reject Modal */}
      <Modal
        isOpen={showRejectModal}
        onClose={() => {
          setShowRejectModal(false)
          setRejectReason('')
        }}
        title="Reject application"
        size="small"
        footer={
          <>
            <Button
              label="Cancel"
              onClick={() => {
                setShowRejectModal(false)
                setRejectReason('')
              }}
              variant="soft"
              fullWidth
            />
            <Button
              label="Reject"
              onClick={handleReject}
              variant="danger"
              disabled={!rejectReason}
              fullWidth
            />
          </>
        }
      >
        <p style={{ color: colors.muted, marginBottom: '12px' }}>
          Choose a reason. The applicant will be told what to fix.
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {['Documents unclear', 'Verification failed', 'Outside service area', 'Photo does not match ID'].map(
            (reason) => (
              <button
                key={reason}
                onClick={() => setRejectReason(reason)}
                style={{
                  padding: '12px 14px',
                  border: `1.5px solid ${rejectReason === reason ? colors.brand : colors.line}`,
                  borderRadius: '14px',
                  backgroundColor: rejectReason === reason ? colors.brandSoft : colors.surface2,
                  color: rejectReason === reason ? colors.brandText : colors.ink,
                  cursor: 'pointer',
                  fontWeight: '700',
                  fontSize: '14px',
                  textAlign: 'left'
                }}
              >
                {reason}
              </button>
            )
          )}
        </div>
      </Modal>
    </div>
  )
}
