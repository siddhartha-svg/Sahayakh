import React, { useState, useEffect } from 'react'
import { useTheme } from '../theme'
import { Icon } from '../components/Icon'
import { Drawer, Modal } from '../components/Modal'
import { Table } from '../components/Table'
import { Button } from '../components/Button'
import { Pill } from '../components/Pill'
import { taskApi, helperApi } from '../api/client'
import { useUIStore } from '../store'

interface Task {
  id: string
  title: string
  type: 'personal' | 'business'
  status: 'unassigned' | 'assigned' | 'on_the_way' | 'in_progress' | 'completed' | 'cancelled' | 'disputed'
  customer: string
  helper: string | null
  amount: number
  area: string
  createdAt: string
}

interface TaskDetail extends Task {
  description: string
  location: string
  estimatedDuration: number
  paymentBreakdown: {
    total: number
    fee: number
    helperEarns: number
  }
}

const STATUS_MAP: Record<string, { tone: 'ok' | 'warn' | 'bad' | 'info' | 'mute', label: string }> = {
  unassigned: { tone: 'warn', label: 'Unassigned' },
  assigned: { tone: 'info', label: 'Assigned' },
  on_the_way: { tone: 'info', label: 'On the way' },
  in_progress: { tone: 'info', label: 'In progress' },
  completed: { tone: 'ok', label: 'Completed' },
  cancelled: { tone: 'mute', label: 'Cancelled' },
  disputed: { tone: 'bad', label: 'Disputed' }
}

export const Tasks: React.FC = () => {
  const { getColors } = useTheme()
  const colors = getColors()
  const { showToast } = useUIStore()

  const [tasks, setTasks] = useState<Task[]>([])
  const [selectedTask, setSelectedTask] = useState<TaskDetail | null>(null)
  const [helpers, setHelpers] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [statusFilter, setStatusFilter] = useState<'all' | string>('all')
  const [typeFilter, setTypeFilter] = useState<'all' | string>('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [assignModal, setAssignModal] = useState(false)
  const [assignTo, setAssignTo] = useState<string | null>(null)
  const [cancelModal, setCancelModal] = useState(false)

  useEffect(() => {
    loadTasks()
  }, [statusFilter, typeFilter])

  const loadTasks = async () => {
    setLoading(true)
    try {
      const res = await taskApi.getTasks({
        status: statusFilter === 'all' ? undefined : statusFilter,
        type: typeFilter === 'all' ? undefined : typeFilter,
        limit: 50
      })
      setTasks(res.data || [])
    } catch (error) {
      console.error('Failed to load tasks:', error)
      showToast('Failed to load tasks', 'error')
    } finally {
      setLoading(false)
    }
  }

  const filteredTasks = tasks.filter((t) => {
    const q = searchQuery.toLowerCase()
    return (
      t.id.includes(q) || t.title.toLowerCase().includes(q) || t.customer.toLowerCase().includes(q)
    )
  })

  const handleSelectTask = async (task: Task) => {
    try {
      const res = await taskApi.getTaskDetails(task.id)
      setSelectedTask(res.data)
    } catch (error) {
      console.error('Failed to load task details:', error)
      showToast('Failed to load task details', 'error')
    }
  }

  const handleOpenAssign = async () => {
    try {
      const res = await helperApi.getHelpers({
        status: 'active',
        limit: 50
      })
      setHelpers(res.data || [])
      setAssignModal(true)
    } catch (error) {
      console.error('Failed to load helpers:', error)
      showToast('Failed to load helpers', 'error')
    }
  }

  const handleAssign = async () => {
    if (!selectedTask || !assignTo) return
    try {
      await taskApi.assignTask(selectedTask.id, assignTo)
      const helper = helpers.find((h) => h.id === assignTo)
      setSelectedTask({ ...selectedTask, helper: helper?.name || assignTo })
      setTasks(
        tasks.map((t) =>
          t.id === selectedTask.id ? { ...t, helper: helper?.name || assignTo } : t
        )
      )
      setAssignModal(false)
      setAssignTo(null)
      showToast(`Task assigned to ${helper?.name}`, 'success')
    } catch (error) {
      console.error('Failed to assign:', error)
      showToast('Failed to assign task', 'error')
    }
  }

  const handleCancel = async () => {
    if (!selectedTask) return
    try {
      await taskApi.cancelTask(selectedTask.id, 'Admin cancelled')
      setSelectedTask({ ...selectedTask, status: 'cancelled' })
      setTasks(
        tasks.map((t) =>
          t.id === selectedTask.id ? { ...t, status: 'cancelled' } : t
        )
      )
      setCancelModal(false)
      showToast(`${selectedTask.id} was cancelled`, 'success')
    } catch (error) {
      console.error('Failed to cancel:', error)
      showToast('Failed to cancel task', 'error')
    }
  }

  const columns = [
    {
      key: 'id',
      label: 'Task ID',
      width: '1.1fr',
      render: (val: string, row: Task) => (
        <div>
          <div style={{ fontWeight: '700' }}>{val}</div>
          <div style={{ fontSize: '12.5px', color: colors.muted }}>
            {row.type === 'business' ? '💼' : '👤'} {row.type === 'business' ? 'Business' : 'Personal'}
          </div>
        </div>
      )
    },
    {
      key: 'title',
      label: 'Task',
      width: '3fr',
      hideOnMobile: true,
      render: (val: string, row: Task) => (
        <div>
          <div style={{ fontWeight: '700' }}>{val}</div>
          <div style={{ fontSize: '12.5px', color: colors.muted }}>
            {row.customer}, {row.area}
          </div>
        </div>
      )
    },
    {
      key: 'helper',
      label: 'Helper',
      width: '1.4fr',
      hideOnMobile: true,
      render: (val: string | null) => (
        <span style={{ color: val ? colors.ink : colors.muted }}>
          {val || 'Not assigned'}
        </span>
      )
    },
    {
      key: 'status',
      label: 'Status',
      width: '0.9fr',
      render: (val: string) => {
        const s = STATUS_MAP[val]
        return <Pill label={s?.label || val} tone={s?.tone || 'mute'} size="small" />
      }
    },
    {
      key: 'amount',
      label: 'Amount',
      width: '0.9fr',
      hideOnMobile: true,
      render: (val: number) => (
        <span style={{ fontWeight: '800' }}>
          {val ? `₹${val}` : '—'}
        </span>
      )
    }
  ]

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
      <div style={{ padding: '24px' }}>
        <div style={{ marginBottom: '18px' }}>
          <h1 style={{ fontSize: '26px', fontWeight: '800', letterSpacing: '-0.03em', margin: 0 }}>
            Tasks
          </h1>
          <p style={{ color: colors.muted, marginTop: '2px', margin: 0 }}>
            Every task booked on Sahayakh, live and past
          </p>
        </div>

        {/* Filters */}
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginBottom: '14px', flexWrap: 'wrap' }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              border: `1.5px solid ${colors.line}`,
              borderRadius: '12px',
              padding: '0 12px',
              backgroundColor: colors.surface,
              minHeight: '42px',
              flex: 1,
              minWidth: '220px'
            }}
          >
            <Icon name="search" size={18} style={{ color: colors.muted }} />
            <input
              type="text"
              placeholder="Search ID, task, customer or helper"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{
                flex: 1,
                border: 'none',
                outline: 'none',
                backgroundColor: 'transparent',
                fontFamily: 'inherit',
                fontSize: '14px',
                color: colors.ink
              }}
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            style={{
              padding: '0 12px',
              minHeight: '42px',
              borderRadius: '12px',
              border: `1.5px solid ${colors.line}`,
              backgroundColor: colors.surface,
              color: colors.ink,
              fontFamily: 'inherit',
              fontSize: '14px',
              fontWeight: '700',
              cursor: 'pointer'
            }}
          >
            <option value="all">All statuses</option>
            {Object.entries(STATUS_MAP).map(([key, val]) => (
              <option key={key} value={key}>
                {val.label}
              </option>
            ))}
          </select>

          <div style={{ display: 'flex', gap: '8px' }}>
            {[
              { value: 'all', label: 'All types' },
              { value: 'personal', label: 'Personal' },
              { value: 'business', label: 'Business' }
            ].map((opt) => (
              <button
                key={opt.value}
                onClick={() => setTypeFilter(opt.value)}
                style={{
                  padding: '7px 13px',
                  borderRadius: '99px',
                  border: `1px solid ${typeFilter === opt.value ? colors.brand : colors.line}`,
                  backgroundColor: typeFilter === opt.value ? colors.brandSoft : colors.surface,
                  color: typeFilter === opt.value ? colors.brandText : colors.muted,
                  fontWeight: '700',
                  fontSize: '13px',
                  cursor: 'pointer'
                }}
              >
                {opt.label}
              </button>
            ))}
          </div>

          <div style={{ color: colors.muted, fontSize: '13px', fontWeight: '700' }}>
            {filteredTasks.length} task{filteredTasks.length !== 1 ? 's' : ''}
          </div>
        </div>

        {/* Table */}
        <Table
          columns={columns}
          data={filteredTasks}
          onRowClick={handleSelectTask}
          loading={loading}
          empty="No tasks found\nTry a different search or filter."
        />
      </div>

      {/* Drawer */}
      <Drawer
        isOpen={!!selectedTask}
        onClose={() => setSelectedTask(null)}
        title={selectedTask?.id || ''}
        footer={
          selectedTask && (
            <>
              {(selectedTask.status === 'unassigned' || selectedTask.status === 'assigned' || selectedTask.status === 'on_the_way') && (
                <Button
                  label={selectedTask.helper ? 'Reassign helper' : 'Assign helper'}
                  onClick={handleOpenAssign}
                  variant="primary"
                  fullWidth
                />
              )}
              {selectedTask.status !== 'completed' && selectedTask.status !== 'cancelled' && (
                <Button
                  label="Cancel task"
                  onClick={() => setCancelModal(true)}
                  variant="danger"
                  fullWidth
                />
              )}
              {selectedTask.status === 'completed' && (
                <Button
                  label="Download invoice"
                  icon={<Icon name="dl" size={16} />}
                  variant="soft"
                  fullWidth
                />
              )}
            </>
          )
        }
      >
        {selectedTask && (
          <>
            {/* Type & Status */}
            <div style={{ display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap', marginBottom: '10px' }}>
              <Pill
                label={selectedTask.type === 'business' ? 'Business' : 'Personal'}
                tone={selectedTask.type === 'business' ? 'info' : 'ok'}
              />
              <Pill
                label={STATUS_MAP[selectedTask.status]?.label || selectedTask.status}
                tone={STATUS_MAP[selectedTask.status]?.tone || 'mute'}
              />
            </div>

            {/* Title */}
            <h3 style={{ fontSize: '18px', fontWeight: '800', lineHeight: 1.3, marginTop: '10px' }}>
              {selectedTask.title}
            </h3>

            {/* Info */}
            <div style={{ marginTop: '10px' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px', color: colors.muted }}>
                Customer
              </div>
              <div style={{ fontSize: '13.5px' }}>{selectedTask.customer}</div>
            </div>

            <div style={{ marginTop: '12px' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px', color: colors.muted }}>
                Helper
              </div>
              <div style={{ fontSize: '13.5px' }}>
                {selectedTask.helper || 'Not assigned'}
              </div>
            </div>

            <div style={{ marginTop: '12px' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px', color: colors.muted }}>
                Area
              </div>
              <div style={{ fontSize: '13.5px' }}>{selectedTask.area}</div>
            </div>

            <div style={{ marginTop: '12px' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px', color: colors.muted }}>
                Created
              </div>
              <div style={{ fontSize: '13.5px' }}>Today, {selectedTask.createdAt}</div>
            </div>

            {/* Payment Breakdown */}
            {selectedTask.paymentBreakdown && (
              <div style={{ marginTop: '12px' }}>
                <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px' }}>Payment</div>
                <div
                  style={{
                    backgroundColor: colors.surface2,
                    borderRadius: '12px',
                    padding: '0 16px'
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      padding: '9px 0',
                      borderBottom: `1px solid ${colors.line}`,
                      fontSize: '14px'
                    }}
                  >
                    <span style={{ color: colors.muted }}>Customer pays</span>
                    <span style={{ fontWeight: '800' }}>
                      ₹{selectedTask.paymentBreakdown.total}
                    </span>
                  </div>
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      padding: '9px 0',
                      borderBottom: `1px solid ${colors.line}`,
                      fontSize: '14px'
                    }}
                  >
                    <span style={{ color: colors.muted }}>Sahayakh fee (15%)</span>
                    <span style={{ fontWeight: '800' }}>
                      ₹{selectedTask.paymentBreakdown.fee}
                    </span>
                  </div>
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      padding: '9px 0',
                      fontSize: '14px'
                    }}
                  >
                    <span>Helper earns</span>
                    <span style={{ fontWeight: '800' }}>
                      ₹{selectedTask.paymentBreakdown.helperEarns}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </Drawer>

      {/* Assign Modal */}
      <Modal
        isOpen={assignModal}
        onClose={() => {
          setAssignModal(false)
          setAssignTo(null)
        }}
        title={selectedTask?.helper ? 'Reassign helper' : 'Assign helper'}
        size="medium"
        footer={
          <>
            <Button
              label="Cancel"
              onClick={() => {
                setAssignModal(false)
                setAssignTo(null)
              }}
              variant="soft"
              fullWidth
            />
            <Button
              label="Assign"
              onClick={handleAssign}
              variant="primary"
              disabled={!assignTo}
              fullWidth
            />
          </>
        }
      >
        <p style={{ color: colors.muted, marginBottom: '12px' }}>
          Online helpers who accept{' '}
          {selectedTask?.type === 'business' ? 'business' : 'personal'} tasks.
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {helpers.map((helper) => (
            <button
              key={helper.id}
              onClick={() => setAssignTo(helper.id)}
              style={{
                padding: '12px 14px',
                border: `1.5px solid ${assignTo === helper.id ? colors.brand : colors.line}`,
                borderRadius: '14px',
                backgroundColor: assignTo === helper.id ? colors.brandSoft : colors.surface2,
                color: assignTo === helper.id ? colors.brandText : colors.ink,
                cursor: 'pointer',
                fontWeight: '700',
                fontSize: '14px',
                textAlign: 'left',
                display: 'flex',
                alignItems: 'center',
                gap: '12px'
              }}
            >
              <div
                style={{
                  width: '34px',
                  height: '34px',
                  borderRadius: '8px',
                  backgroundColor: colors.brandSoft,
                  display: 'grid',
                  placeItems: 'center',
                  color: colors.brandText,
                  fontWeight: '800',
                  flex: 0
                }}
              >
                {helper.name.charAt(0)}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div>{helper.name}</div>
                <div style={{ fontSize: '12.5px', color: colors.muted, fontWeight: '500' }}>
                  {helper.area}, {helper.rating || 4.8} rating
                </div>
              </div>
            </button>
          ))}
        </div>
      </Modal>

      {/* Cancel Modal */}
      <Modal
        isOpen={cancelModal}
        onClose={() => setCancelModal(false)}
        title="Cancel this task?"
        size="small"
        footer={
          <>
            <Button
              label="Keep task"
              onClick={() => setCancelModal(false)}
              variant="soft"
              fullWidth
            />
            <Button
              label="Cancel task"
              onClick={handleCancel}
              variant="danger"
              fullWidth
            />
          </>
        }
      >
        <p style={{ color: colors.muted }}>
          The customer will be told and any advance payment will be refunded. This cannot be undone.
        </p>
      </Modal>
    </div>
  )
}
