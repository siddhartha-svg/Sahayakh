import React, { useState, useEffect } from 'react'
import { useTheme } from '../theme'
import { Icon } from '../components/Icon'
import { Badge } from '../components/Badge'
import { Drawer, Modal } from '../components/Modal'
import { Table } from '../components/Table'
import { Button } from '../components/Button'
import { Pill } from '../components/Pill'
import { helperApi } from '../api/client'
import { useUIStore } from '../store'

interface Helper {
  id: string
  name: string
  area: string
  status: 'active' | 'suspended'
  online: boolean
  rating: number
  tasks: number
  earn: number
  type: 'Personal' | 'Business' | 'Both'
  skills: string[]
  joined: string
}

interface HelperDetail extends Helper {
  phone: string
  recentTasks: Array<{ id: string; title: string; status: string; amount: number }>
}

export const Helpers: React.FC = () => {
  const { getColors } = useTheme()
  const colors = getColors()
  const { showToast } = useUIStore()

  const [helpers, setHelpers] = useState<Helper[]>([])
  const [selectedHelper, setSelectedHelper] = useState<HelperDetail | null>(null)
  const [loading, setLoading] = useState(false)
  const [filter, setFilter] = useState<'all' | 'active' | 'online' | 'suspended'>('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [suspendModal, setSuspendModal] = useState(false)
  const [suspendReason, setSuspendReason] = useState('')

  useEffect(() => {
    loadHelpers()
  }, [filter])

  const loadHelpers = async () => {
    setLoading(true)
    try {
      const filterMap = { all: undefined, active: 'active', online: 'online', suspended: 'suspended' }
      const res = await helperApi.getHelpers({
        status: filterMap[filter],
        limit: 50
      })
      setHelpers(res.data || [])
    } catch (error) {
      console.error('Failed to load helpers:', error)
      showToast('Failed to load helpers', 'error')
    } finally {
      setLoading(false)
    }
  }

  const filteredHelpers = helpers.filter((h) => {
    const q = searchQuery.toLowerCase()
    return h.name.toLowerCase().includes(q) || h.id.includes(q) || h.area.toLowerCase().includes(q)
  })

  const handleSelectHelper = async (helper: Helper) => {
    try {
      const res = await helperApi.getHelperDetails(helper.id)
      setSelectedHelper(res.data)
    } catch (error) {
      console.error('Failed to load helper details:', error)
      showToast('Failed to load helper details', 'error')
    }
  }

  const handleSuspend = async () => {
    if (!selectedHelper || !suspendReason) return
    try {
      await helperApi.suspendHelper(selectedHelper.id, suspendReason)
      setHelpers(
        helpers.map((h) =>
          h.id === selectedHelper.id ? { ...h, status: 'suspended' as const } : h
        )
      )
      setSelectedHelper({ ...selectedHelper, status: 'suspended' })
      setSuspendModal(false)
      setSuspendReason('')
      showToast(`${selectedHelper.name} was suspended`, 'success')
    } catch (error) {
      console.error('Failed to suspend:', error)
      showToast('Failed to suspend helper', 'error')
    }
  }

  const handleReactivate = async () => {
    if (!selectedHelper) return
    try {
      await helperApi.reactivateHelper(selectedHelper.id)
      setHelpers(
        helpers.map((h) =>
          h.id === selectedHelper.id ? { ...h, status: 'active' as const } : h
        )
      )
      setSelectedHelper({ ...selectedHelper, status: 'active' })
      showToast(`${selectedHelper.name} is active again`, 'success')
    } catch (error) {
      console.error('Failed to reactivate:', error)
      showToast('Failed to reactivate helper', 'error')
    }
  }

  const columns = [
    {
      key: 'name',
      label: 'Helper',
      width: '2.4fr',
      render: (val: string, row: Helper) => (
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', minWidth: 0 }}>
          <div
            style={{
              width: '40px',
              height: '40px',
              borderRadius: '8px',
              backgroundColor: colors.brandSoft,
              display: 'grid',
              placeItems: 'center',
              color: colors.brandText,
              fontWeight: '800',
              flex: 0
            }}
          >
            {row.name.charAt(0)}
          </div>
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: '14px', fontWeight: '700', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {val}
            </div>
            <div style={{ fontSize: '12.5px', color: colors.muted, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {row.id}, {row.type}
            </div>
          </div>
        </div>
      )
    },
    {
      key: 'area',
      label: 'Area',
      width: '1.1fr',
      hideOnMobile: true
    },
    {
      key: 'status',
      label: 'Status',
      width: '0.8fr',
      render: (val: string, row: Helper) => {
        const isSuspended = row.status === 'suspended'
        const isOnline = !isSuspended && row.online

        return (
          <Pill
            label={isSuspended ? 'Suspended' : isOnline ? '🟢 Online' : '⚫ Offline'}
            tone={isSuspended ? 'bad' : isOnline ? 'ok' : 'mute'}
            size="small"
          />
        )
      }
    },
    {
      key: 'rating',
      label: 'Rating',
      width: '0.8fr',
      hideOnMobile: true,
      render: (val: number) => (
        <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          ⭐ <span style={{ fontWeight: '700' }}>{val}</span>
        </span>
      )
    },
    {
      key: 'tasks',
      label: 'Tasks',
      width: '0.8fr',
      hideOnMobile: true,
      render: (val: number) => <span style={{ fontWeight: '700' }}>{val}</span>
    },
    {
      key: 'earn',
      label: '30-day earnings',
      width: '1.1fr',
      hideOnMobile: true,
      render: (val: number) => <span style={{ fontWeight: '800' }}>₹{val.toLocaleString('en-IN')}</span>
    }
  ]

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
      <div style={{ padding: '24px' }}>
        <div style={{ marginBottom: '18px' }}>
          <h1 style={{ fontSize: '26px', fontWeight: '800', letterSpacing: '-0.03em', margin: 0 }}>
            Helpers
          </h1>
          <p style={{ color: colors.muted, marginTop: '2px', margin: 0 }}>
            Everyone who can take tasks on Sahayakh
          </p>
        </div>

        {/* Filters */}
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginBottom: '14px', flexWrap: 'wrap' }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              border: `1.5px solid ${colors.line}`,
              borderRadius: '12px',
              padding: '0 12px',
              backgroundColor: colors.surface,
              minHeight: '42px',
              flex: 1,
              minWidth: '220px'
            }}
          >
            <Icon name="search" size={18} style={{ color: colors.muted }} />
            <input
              type="text"
              placeholder="Search name, ID or area"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{
                flex: 1,
                border: 'none',
                outline: 'none',
                backgroundColor: 'transparent',
                fontFamily: 'inherit',
                fontSize: '14px',
                color: colors.ink
              }}
            />
          </div>

          <div style={{ display: 'flex', gap: '8px' }}>
            {[
              { value: 'all', label: 'All' },
              { value: 'active', label: 'Active' },
              { value: 'online', label: 'Online' },
              { value: 'suspended', label: 'Suspended' }
            ].map((opt) => (
              <button
                key={opt.value}
                onClick={() => setFilter(opt.value as any)}
                style={{
                  padding: '7px 13px',
                  borderRadius: '99px',
                  border: `1px solid ${filter === opt.value ? colors.brand : colors.line}`,
                  backgroundColor: filter === opt.value ? colors.brandSoft : colors.surface,
                  color: filter === opt.value ? colors.brandText : colors.muted,
                  fontWeight: '700',
                  fontSize: '13px',
                  cursor: 'pointer'
                }}
              >
                {opt.label}
              </button>
            ))}
          </div>

          <div style={{ color: colors.muted, fontSize: '13px', fontWeight: '700' }}>
            {filteredHelpers.length} helper{filteredHelpers.length !== 1 ? 's' : ''}
          </div>
        </div>

        {/* Table */}
        <Table
          columns={columns}
          data={filteredHelpers}
          onRowClick={handleSelectHelper}
          loading={loading}
          empty="No helpers found\nTry a different search or filter."
        />
      </div>

      {/* Drawer */}
      <Drawer
        isOpen={!!selectedHelper}
        onClose={() => setSelectedHelper(null)}
        title={selectedHelper?.id || ''}
        footer={
          selectedHelper && (
            <>
              <Button
                label="Call"
                onClick={() => showToast('Calling helper...', 'info')}
                variant="soft"
                fullWidth
              />
              {selectedHelper.status === 'suspended' ? (
                <Button
                  label="Reactivate"
                  onClick={handleReactivate}
                  variant="primary"
                  fullWidth
                />
              ) : (
                <Button
                  label="Suspend"
                  onClick={() => setSuspendModal(true)}
                  variant="danger"
                  fullWidth
                />
              )}
            </>
          )
        }
      >
        {selectedHelper && (
          <>
            {/* Header */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '14px', marginBottom: '14px' }}>
              <div
                style={{
                  width: '64px',
                  height: '64px',
                  borderRadius: '16px',
                  backgroundColor: colors.brandSoft,
                  display: 'grid',
                  placeItems: 'center',
                  color: colors.brandText,
                  fontWeight: '800',
                  fontSize: '24px'
                }}
              >
                {selectedHelper.name.charAt(0)}
              </div>
              <div>
                <div style={{ fontSize: '19px', fontWeight: '800', letterSpacing: '-0.02em' }}>
                  {selectedHelper.name}
                </div>
                <div style={{ fontSize: '12.5px', color: colors.muted }}>
                  {selectedHelper.area}, {selectedHelper.joined}
                </div>
                <div style={{ marginTop: '6px' }}>
                  <Pill
                    label={selectedHelper.status === 'suspended' ? 'Suspended' : selectedHelper.online ? 'Online' : 'Offline'}
                    tone={selectedHelper.status === 'suspended' ? 'bad' : selectedHelper.online ? 'ok' : 'mute'}
                  />
                </div>
              </div>
            </div>

            {/* Stats Grid */}
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(3, 1fr)',
                border: `1px solid ${colors.line}`,
                borderRadius: '14px',
                margin: '12px 0',
                overflow: 'hidden'
              }}
            >
              <div style={{ textAlign: 'center', padding: '10px 4px', borderRight: `1px solid ${colors.line}` }}>
                <div style={{ fontSize: '17px', fontWeight: '800' }}>{selectedHelper.rating}</div>
                <div style={{ fontSize: '11.5px', color: colors.muted }}>Rating</div>
              </div>
              <div style={{ textAlign: 'center', padding: '10px 4px', borderRight: `1px solid ${colors.line}` }}>
                <div style={{ fontSize: '17px', fontWeight: '800' }}>{selectedHelper.tasks}</div>
                <div style={{ fontSize: '11.5px', color: colors.muted }}>Tasks done</div>
              </div>
              <div style={{ textAlign: 'center', padding: '10px 4px' }}>
                <div style={{ fontSize: '17px', fontWeight: '800' }}>₹{selectedHelper.earn.toLocaleString('en-IN')}</div>
                <div style={{ fontSize: '11.5px', color: colors.muted }}>30-day earnings</div>
              </div>
            </div>

            {/* Info */}
            <div style={{ margin: '12px 0' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px', color: colors.muted }}>
                Phone
              </div>
              <div style={{ fontSize: '13.5px' }}>{selectedHelper.phone}</div>
            </div>

            <div style={{ margin: '12px 0' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px', color: colors.muted }}>
                Accepts
              </div>
              <div style={{ fontSize: '13.5px' }}>{selectedHelper.type} tasks</div>
            </div>

            <div style={{ margin: '12px 0' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px' }}>Skills</div>
              <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                {selectedHelper.skills.map((skill) => (
                  <span
                    key={skill}
                    style={{
                      padding: '5px 10px',
                      borderRadius: '10px',
                      backgroundColor: colors.surface2,
                      border: `1px solid ${colors.line}`,
                      fontSize: '12.5px',
                      fontWeight: '600'
                    }}
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            <div style={{ margin: '12px 0' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px' }}>Verification</div>
              <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                {['Identity', 'Background check', 'Bank account'].map((v) => (
                  <Pill key={v} label={`✓ ${v}`} tone="ok" size="small" />
                ))}
              </div>
            </div>

            {selectedHelper.recentTasks && selectedHelper.recentTasks.length > 0 && (
              <div style={{ margin: '12px 0' }}>
                <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px' }}>Recent tasks</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {selectedHelper.recentTasks.map((task) => (
                    <div
                      key={task.id}
                      style={{
                        padding: '10px 0',
                        borderTop: `1px solid ${colors.line}`,
                        fontSize: '13.5px'
                      }}
                    >
                      <div style={{ fontWeight: '700' }}>{task.title}</div>
                      <div style={{ fontSize: '12.5px', color: colors.muted }}>{task.id}</div>
                      <Pill label={task.status} tone="ok" size="small" />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )
      </Drawer>

      {/* Suspend Modal */}
      <Modal
        isOpen={suspendModal}
        onClose={() => {
          setSuspendModal(false)
          setSuspendReason('')
        }}
        title="Suspend helper"
        size="small"
        footer={
          <>
            <Button
              label="Cancel"
              onClick={() => {
                setSuspendModal(false)
                setSuspendReason('')
              }}
              variant="soft"
              fullWidth
            />
            <Button
              label="Suspend"
              onClick={handleSuspend}
              variant="danger"
              disabled={!suspendReason}
              fullWidth
            />
          </>
        }
      >
        <p style={{ color: colors.muted, marginBottom: '12px' }}>
          They will go offline and stop receiving tasks until you reactivate them.
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {['Repeated complaints', 'Verification issue', 'Safety concern', 'Inactive account'].map((reason) => (
            <button
              key={reason}
              onClick={() => setSuspendReason(reason)}
              style={{
                padding: '12px 14px',
                border: `1.5px solid ${suspendReason === reason ? colors.brand : colors.line}`,
                borderRadius: '14px',
                backgroundColor: suspendReason === reason ? colors.brandSoft : colors.surface2,
                color: suspendReason === reason ? colors.brandText : colors.ink,
                cursor: 'pointer',
                fontWeight: '700',
                fontSize: '14px',
                textAlign: 'left'
              }}
            >
              {reason}
            </button>
          ))}
        </div>
      </Modal>
    </div>
  )
}
