import React, { useState, useEffect } from 'react'
import { useTheme } from '../theme'
import { Icon } from '../components/Icon'
import { Button } from '../components/Button'
import { pricingApi } from '../api/client'
import { useUIStore } from '../store'

interface PricingConfig {
  base: number
  km: number
  min: number
  minFare: number
  bizMult: number
  fee: number
  cancel: number
  bonusTasks: number
  bonusAmt: number
}

interface FareCalc {
  km: number
  min: number
  isBusiness: boolean
  raw: number
  fare: number
  fee: number
  helperEarns: number
}

const FIELDS = [
  { key: 'base', label: 'Base fare', unit: '₹', help: 'Charged on every task' },
  { key: 'km', label: 'Per kilometre', unit: '₹', step: '0.5', help: 'Actual distance travelled' },
  { key: 'min', label: 'Per minute', unit: '₹', step: '0.5', help: 'Actual task time' },
  { key: 'minFare', label: 'Minimum fare', unit: '₹', help: 'Lowest a task can cost' },
  { key: 'bizMult', label: 'Business multiplier', unit: 'x', step: '0.05', help: 'Applied to business tasks' },
  { key: 'fee', label: 'Sahayakh fee', unit: '%', help: 'Taken from each task total' },
  { key: 'cancel', label: 'Cancellation fee', unit: '₹', help: 'After a helper is assigned' },
  { key: 'bonusTasks', label: 'Daily bonus tasks', unit: '', help: 'Tasks a helper must finish' },
  { key: 'bonusAmt', label: 'Daily bonus amount', unit: '₹', help: 'Paid on reaching the target' }
]

export const Pricing: React.FC = () => {
  const { getColors } = useTheme()
  const colors = getColors()
  const { showToast } = useUIStore()

  const [config, setConfig] = useState<PricingConfig>({
    base: 40,
    km: 15,
    min: 2.5,
    minFare: 80,
    bizMult: 1.25,
    fee: 15,
    cancel: 30,
    bonusTasks: 5,
    bonusAmt: 100
  })

  const [saved, setSaved] = useState<PricingConfig>(config)
  const [loading, setLoading] = useState(false)
  const [calc, setCalc] = useState({ km: 4.8, min: 37, isBusiness: false })
  const [calculatedFare, setCalculatedFare] = useState<FareCalc | null>(null)

  useEffect(() => {
    loadPricing()
  }, [])

  useEffect(() => {
    calculateFare()
  }, [calc, config])

  const loadPricing = async () => {
    setLoading(true)
    try {
      const res = await pricingApi.getPricing()
      setConfig(res.data)
      setSaved(res.data)
    } catch (error) {
      console.error('Failed to load pricing:', error)
      showToast('Failed to load pricing', 'error')
    } finally {
      setLoading(false)
    }
  }

  const calculateFare = async () => {
    try {
      const res = await pricingApi.calculateFare(calc.km, calc.min, calc.isBusiness)
      setCalculatedFare(res.data)
    } catch (error) {
      console.error('Failed to calculate fare:', error)
    }
  }

  const isDirty = JSON.stringify(config) !== JSON.stringify(saved)

  const handleSave = async () => {
    try {
      await pricingApi.updatePricing(config)
      setSaved(config)
      showToast('Pricing saved. New tasks will use these rates.', 'success')
    } catch (error) {
      console.error('Failed to save pricing:', error)
      showToast('Failed to save pricing', 'error')
    }
  }

  const handleReset = () => {
    setConfig(saved)
  }

  const handleFieldChange = (key: string, value: string) => {
    setConfig({
      ...config,
      [key]: key === 'bonusTasks' ? parseInt(value) || 0 : parseFloat(value) || 0
    })
  }

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
      <div style={{ padding: '24px' }}>
        <div style={{ marginBottom: '18px' }}>
          <h1 style={{ fontSize: '26px', fontWeight: '800', letterSpacing: '-0.03em', margin: 0 }}>
            Pricing & rules
          </h1>
          <p style={{ color: colors.muted, marginTop: '2px', margin: 0 }}>
            Set how tasks are priced and how much Sahayakh keeps
          </p>
        </div>

        {/* Two Column Layout */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '14px' }}>
          {/* Left: Rates Configuration */}
          <div
            style={{
              backgroundColor: colors.surface,
              border: `1px solid ${colors.line}`,
              borderRadius: '18px',
              padding: '16px'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
              <h2 style={{ fontSize: '15.5px', fontWeight: '800', letterSpacing: '-0.01em', margin: 0 }}>
                Rates
              </h2>
              <span style={{ fontSize: '12.5px', color: isDirty ? colors.warnInk : colors.muteInk, fontWeight: '700' }}>
                {isDirty ? 'You have unsaved changes' : 'All changes saved'}
              </span>
            </div>

            {/* Form Fields */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px 16px' }}>
              {FIELDS.map((field) => (
                <div key={field.key}>
                  <label style={{ fontSize: '12.5px', fontWeight: '700', marginBottom: '6px', display: 'block', color: colors.muted }}>
                    {field.label}
                  </label>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      border: `1.5px solid ${colors.line}`,
                      borderRadius: '12px',
                      padding: '0 12px',
                      backgroundColor: colors.surface2,
                      minHeight: '42px'
                    }}
                  >
                    {field.unit && (
                      <span style={{ color: colors.muted, fontWeight: '700' }}>{field.unit}</span>
                    )}
                    <input
                      type="number"
                      step={field.step || '1'}
                      value={config[field.key as keyof PricingConfig]}
                      onChange={(e) => handleFieldChange(field.key, e.target.value)}
                      style={{
                        flex: 1,
                        border: 'none',
                        outline: 'none',
                        backgroundColor: 'transparent',
                        fontFamily: 'inherit',
                        fontSize: '14px',
                        color: colors.ink,
                        textAlign: 'right'
                      }}
                    />
                  </div>
                  <small style={{ display: 'block', color: colors.muted, fontSize: '12px', marginTop: '4px' }}>
                    {field.help}
                  </small>
                </div>
              ))}
            </div>

            {/* Save/Reset Buttons */}
            <div style={{ display: 'flex', gap: '10px', marginTop: '18px' }}>
              <Button
                label="Save changes"
                onClick={handleSave}
                variant="primary"
                disabled={!isDirty}
                fullWidth
              />
              <Button
                label="Reset"
                onClick={handleReset}
                variant="soft"
                disabled={!isDirty}
                fullWidth
              />
            </div>
          </div>

          {/* Right: Fare Calculator */}
          <div
            style={{
              backgroundColor: colors.surface,
              border: `1px solid ${colors.line}`,
              borderRadius: '18px',
              padding: '16px'
            }}
          >
            <h2 style={{ fontSize: '15.5px', fontWeight: '800', letterSpacing: '-0.01em', marginBottom: '12px', margin: 0 }}>
              Fare calculator
            </h2>

            {/* Task Type Toggle */}
            <div
              style={{
                display: 'flex',
                padding: '3px',
                backgroundColor: colors.surface2,
                border: `1px solid ${colors.line}`,
                borderRadius: '12px',
                gap: '2px',
                marginBottom: '14px'
              }}
            >
              {[
                { value: false, label: 'Personal' },
                { value: true, label: 'Business' }
              ].map((opt) => (
                <button
                  key={String(opt.value)}
                  onClick={() => setCalc({ ...calc, isBusiness: opt.value })}
                  style={{
                    flex: 1,
                    height: '34px',
                    padding: '0 14px',
                    borderRadius: '9px',
                    fontWeight: '700',
                    fontSize: '13px',
                    color: calc.isBusiness === opt.value ? '#fff' : colors.muted,
                    backgroundColor:
                      calc.isBusiness === opt.value ? colors.brand : colors.surface2,
                    border: 'none',
                    cursor: 'pointer'
                  }}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            {/* Distance & Time Inputs */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '12px' }}>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: '700', marginBottom: '6px', display: 'block', color: colors.muted }}>
                  Distance (km)
                </label>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    border: `1.5px solid ${colors.line}`,
                    borderRadius: '12px',
                    padding: '0 12px',
                    backgroundColor: colors.surface2,
                    minHeight: '42px'
                  }}
                >
                  <input
                    type="number"
                    step="0.1"
                    value={calc.km}
                    onChange={(e) => setCalc({ ...calc, km: parseFloat(e.target.value) || 0 })}
                    style={{
                      flex: 1,
                      border: 'none',
                      outline: 'none',
                      backgroundColor: 'transparent',
                      fontFamily: 'inherit',
                      fontSize: '14px',
                      color: colors.ink,
                      textAlign: 'right'
                    }}
                  />
                </div>
              </div>
              <div>
                <label style={{ fontSize: '12.5px', fontWeight: '700', marginBottom: '6px', display: 'block', color: colors.muted }}>
                  Time (mins)
                </label>
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    border: `1.5px solid ${colors.line}`,
                    borderRadius: '12px',
                    padding: '0 12px',
                    backgroundColor: colors.surface2,
                    minHeight: '42px'
                  }}
                >
                  <input
                    type="number"
                    step="1"
                    value={calc.min}
                    onChange={(e) => setCalc({ ...calc, min: parseInt(e.target.value) || 0 })}
                    style={{
                      flex: 1,
                      border: 'none',
                      outline: 'none',
                      backgroundColor: 'transparent',
                      fontFamily: 'inherit',
                      fontSize: '14px',
                      color: colors.ink,
                      textAlign: 'right'
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Calculation Results */}
            {calculatedFare && (
              <div
                style={{
                  backgroundColor: colors.surface2,
                  borderRadius: '12px',
                  padding: '0 16px'
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    padding: '9px 0',
                    borderBottom: `1px solid ${colors.line}`,
                    fontSize: '14px'
                  }}
                >
                  <span style={{ color: colors.muted }}>Base fare</span>
                  <span>₹{config.base}</span>
                </div>
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    padding: '9px 0',
                    borderBottom: `1px solid ${colors.line}`,
                    fontSize: '14px'
                  }}
                >
                  <span style={{ color: colors.muted }}>Distance ({calc.km} km)</span>
                  <span>₹{(config.km * calc.km).toFixed(2)}</span>
                </div>
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    padding: '9px 0',
                    borderBottom: `1px solid ${colors.line}`,
                    fontSize: '14px'
                  }}
                >
                  <span style={{ color: colors.muted }}>Time ({calc.min} mins)</span>
                  <span>₹{(config.min * calc.min).toFixed(2)}</span>
                </div>
                {calculatedFare.raw < config.minFare && (
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      padding: '9px 0',
                      borderBottom: `1px solid ${colors.line}`,
                      fontSize: '14px'
                    }}
                  >
                    <span style={{ color: colors.muted }}>Minimum fare applied</span>
                    <span>₹{config.minFare}</span>
                  </div>
                )}
                {calc.isBusiness && (
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      padding: '9px 0',
                      borderBottom: `1px solid ${colors.line}`,
                      fontSize: '14px'
                    }}
                  >
                    <span style={{ color: colors.muted }}>Business rate (x{config.bizMult})</span>
                    <span></span>
                  </div>
                )}
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    padding: '9px 0',
                    fontSize: '18px',
                    fontWeight: '800',
                    color: colors.brandText
                  }}
                >
                  <span>Customer pays</span>
                  <span>₹{calculatedFare.fare.toFixed(2)}</span>
                </div>
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    padding: '9px 0',
                    borderTop: `1px solid ${colors.line}`,
                    fontSize: '14px'
                  }}
                >
                  <span style={{ color: colors.muted }}>Sahayakh fee ({config.fee}%)</span>
                  <span>₹{calculatedFare.fee.toFixed(2)}</span>
                </div>
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    padding: '9px 0',
                    fontSize: '14px'
                  }}
                >
                  <span>Helper earns</span>
                  <span style={{ fontWeight: '700' }}>₹{calculatedFare.helperEarns.toFixed(2)}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
