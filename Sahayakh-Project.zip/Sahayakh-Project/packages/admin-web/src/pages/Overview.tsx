import React, { useState, useEffect } from 'react'
import { useTheme } from '../theme'
import { Icon } from '../components/Icon'
import { overviewApi } from '../api/client'

interface KPI {
  id: string
  label: string
  value: string | number
  delta: number | null
  icon: string
  tone: string
  cmp: string
}

interface FeedEvent {
  id: string
  icon: string
  tone: string
  text: string
  time: string
  fresh?: boolean
}

interface OverviewProps {
  range: 'today' | 'week' | 'month'
  onRangeChange: (range: 'today' | 'week' | 'month') => void
}

export const Overview: React.FC<OverviewProps> = ({ range, onRangeChange }) => {
  const { getColors } = useTheme()
  const colors = getColors()
  const [kpis, setKPIs] = useState<KPI[]>([])
  const [feed, setFeed] = useState<FeedEvent[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    loadData()
    const interval = setInterval(loadData, 4500)
    return () => clearInterval(interval)
  }, [range])

  const loadData = async () => {
    setLoading(true)
    try {
      const [kpiRes, feedRes] = await Promise.all([
        overviewApi.getKPIs(range),
        overviewApi.getFeed(7)
      ])
      setKPIs(kpiRes.data || [])
      setFeed(feedRes.data || [])
    } catch (error) {
      console.error('Failed to load overview:', error)
    } finally {
      setLoading(false)
    }
  }

  const rangeOptions = [
    { value: 'today', label: 'Today' },
    { value: 'week', label: '7 days' },
    { value: 'month', label: '30 days' }
  ]

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
      <div style={{ padding: '24px' }}>
        <div style={{ marginBottom: '18px' }}>
          <div>
            <h1 style={{ fontSize: '26px', fontWeight: '800', letterSpacing: '-0.03em', lineHeight: 1.15, margin: 0 }}>
              Overview
            </h1>
            <p style={{ color: colors.muted, marginTop: '2px', margin: 0 }}>
              <span style={{ display: 'inline-block', width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#22C55E', marginRight: '6px', boxShadow: '0 0 0 0 rgba(34,197,94,.6)', animation: 'ping 1.8s infinite' }}></span>
              Live view of Sahayakh in Warangal
            </p>
          </div>
          <div style={{ display: 'flex', gap: '8px', marginTop: '12px' }}>
            {rangeOptions.map((opt) => (
              <button
                key={opt.value}
                onClick={() => onRangeChange(opt.value as 'today' | 'week' | 'month')}
                style={{
                  height: '34px',
                  padding: '0 14px',
                  borderRadius: '9px',
                  fontWeight: '700',
                  fontSize: '13px',
                  color: range === opt.value ? '#fff' : colors.muted,
                  backgroundColor: range === opt.value ? colors.brand : colors.surface2,
                  border: `1px solid ${colors.line}`,
                  cursor: 'pointer'
                }}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* KPIs Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '14px', marginBottom: '20px' }}>
          {kpis.map((kpi) => (
            <div key={kpi.id} style={{ padding: '16px', backgroundColor: colors.surface, border: `1px solid ${colors.line}`, borderRadius: '18px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px', color: colors.muted, fontSize: '13px', fontWeight: '600' }}>
                <span>{kpi.label}</span>
                <span style={{ width: '34px', height: '34px', borderRadius: '10px', display: 'grid', placeItems: 'center', backgroundColor: colors.brandSoft, color: colors.brandText }}>
                  <Icon name={kpi.icon as any} size={18} />
                </span>
              </div>
              <div style={{ fontSize: '30px', fontWeight: '800', letterSpacing: '-0.03em', marginBottom: '8px' }}>
                {kpi.value}
              </div>
              {kpi.delta !== null && (
                <span style={{ fontSize: '12.5px', fontWeight: '700', color: kpi.delta >= 0 ? colors.okInk : colors.badInk }}>
                  {kpi.delta >= 0 ? '+' : ''}{kpi.delta}% <span style={{ color: colors.muted, fontWeight: '500' }}>{kpi.cmp}</span>
                </span>
              )}
            </div>
          ))}
        </div>

        {/* Live Activity */}
        <div style={{ backgroundColor: colors.surface, border: `1px solid ${colors.line}`, borderRadius: '18px', padding: '16px' }}>
          <h2 style={{ fontSize: '15.5px', fontWeight: '800', marginBottom: '12px' }}>Live activity</h2>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {feed.map((event) => (
              <div
                key={event.id}
                style={{
                  display: 'flex',
                  gap: '10px',
                  alignItems: 'flex-start',
                  padding: '9px 0',
                  borderBottom: `1px solid ${colors.line}`,
                  fontSize: '13.5px',
                  animation: event.fresh ? 'fadein 0.5s' : 'none'
                }}
              >
                <span style={{ width: '28px', height: '28px', borderRadius: '9px', display: 'grid', placeItems: 'center', backgroundColor: colors.brandSoft, color: colors.brandText, flex: 0 }}>
                  <Icon name={event.icon as any} size={15} />
                </span>
                <div>
                  <span dangerouslySetInnerHTML={{ __html: event.text }} />
                  <div style={{ color: colors.muted, fontSize: '12px', marginTop: '2px' }}>{event.time}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes ping {
          0% { box-shadow: 0 0 0 0 rgba(34,197,94,.55); }
          70% { box-shadow: 0 0 0 8px rgba(34,197,94,0); }
          100% { box-shadow: 0 0 0 0 rgba(34,197,94,0); }
        }
        @keyframes fadein {
          from { opacity: 0; transform: translateY(-6px); }
          to { opacity: 1; transform: none; }
        }
      `}</style>
    </div>
  )
}
