import React, { useState, useEffect } from 'react'
import { useTheme } from '../theme'
import { Icon } from '../components/Icon'
import { Drawer, Modal } from '../components/Modal'
import { Table } from '../components/Table'
import { Button } from '../components/Button'
import { Pill } from '../components/Pill'
import { disputeApi, taskApi } from '../api/client'
import { useUIStore } from '../store'

interface DisputeMessage {
  userId: string
  userName: string
  text: string
  timestamp: string
}

interface Dispute {
  id: string
  taskId: string
  issue: string
  raisedBy: string
  against: string
  role: 'Customer' | 'Helper'
  priority: 'high' | 'medium' | 'low'
  status: 'open' | 'resolved'
  refundMax: number
  messages: DisputeMessage[]
}

interface DisputeDetail extends Dispute {
  taskDetails: {
    title: string
    amount: number
  }
  resolution?: {
    type: string
    notes: string
    resolvedAt: string
  }
}

const PRIORITY_MAP: Record<string, { tone: 'ok' | 'warn' | 'bad' | 'info' | 'mute', label: string }> = {
  high: { tone: 'bad', label: 'High' },
  medium: { tone: 'warn', label: 'Medium' },
  low: { tone: 'mute', label: 'Low' }
}

export const Disputes: React.FC = () => {
  const { getColors } = useTheme()
  const colors = getColors()
  const { showToast } = useUIStore()

  const [disputes, setDisputes] = useState<Dispute[]>([])
  const [selectedDispute, setSelectedDispute] = useState<DisputeDetail | null>(null)
  const [loading, setLoading] = useState(false)
  const [filter, setFilter] = useState<'open' | 'resolved' | 'all'>('open')
  const [resolveModal, setResolveModal] = useState(false)
  const [resolution, setResolution] = useState({
    type: 'customer_win',
    refundAmount: 0,
    helperPayoutAmount: 0,
    notes: ''
  })

  useEffect(() => {
    loadDisputes()
  }, [filter])

  const loadDisputes = async () => {
    setLoading(true)
    try {
      const res = await disputeApi.getDisputes({
        status: filter === 'all' ? undefined : filter,
        limit: 50
      })
      setDisputes(res.data || [])
    } catch (error) {
      console.error('Failed to load disputes:', error)
      showToast('Failed to load disputes', 'error')
    } finally {
      setLoading(false)
    }
  }

  const handleSelectDispute = async (dispute: Dispute) => {
    try {
      const res = await disputeApi.getDisputeDetails(dispute.id)
      setSelectedDispute(res.data)
      setResolution({
        type: 'customer_win',
        refundAmount: dispute.refundMax,
        helperPayoutAmount: 0,
        notes: ''
      })
    } catch (error) {
      console.error('Failed to load dispute details:', error)
      showToast('Failed to load dispute details', 'error')
    }
  }

  const handleResolve = async () => {
    if (!selectedDispute) return

    try {
      await disputeApi.resolveDispute(selectedDispute.id, resolution)
      setDisputes(disputes.filter((d) => d.id !== selectedDispute.id))
      setSelectedDispute(null)
      setResolveModal(false)
      showToast(`${selectedDispute.id} resolved`, 'success')
    } catch (error) {
      console.error('Failed to resolve:', error)
      showToast('Failed to resolve dispute', 'error')
    }
  }

  const columns = [
    {
      key: 'id',
      label: 'ID',
      width: '0.8fr',
      render: (val: string, row: Dispute) => (
        <div>
          <div style={{ fontWeight: '700' }}>{val}</div>
          <div style={{ fontSize: '12.5px', color: colors.muted }}>
            {row.taskId}
          </div>
        </div>
      )
    },
    {
      key: 'issue',
      label: 'Issue',
      width: '2.6fr',
      hideOnMobile: true,
      render: (val: string, row: Dispute) => (
        <div>
          <div style={{ fontWeight: '700' }}>{val}</div>
          <div style={{ fontSize: '12.5px', color: colors.muted }}>
            {row.raisedBy} vs {row.against}
          </div>
        </div>
      )
    },
    {
      key: 'raisedBy',
      label: 'Raised by',
      width: '1.5fr',
      hideOnMobile: true,
      render: (val: string, row: Dispute) => (
        <div>
          <div style={{ fontSize: '13.5px' }}>{val}</div>
          <div style={{ fontSize: '12px', color: colors.muted }}>{row.role}</div>
        </div>
      )
    },
    {
      key: 'priority',
      label: 'Priority',
      width: '0.9fr',
      render: (val: string) => {
        const p = PRIORITY_MAP[val]
        return <Pill label={p?.label || val} tone={p?.tone || 'mute'} size="small" />
      }
    },
    {
      key: 'status',
      label: 'Status',
      width: '0.9fr',
      render: (val: string) => (
        <Pill
          label={val === 'open' ? 'Open' : 'Resolved'}
          tone={val === 'open' ? 'warn' : 'ok'}
          size="small"
        />
      )
    }
  ]

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
      <div style={{ padding: '24px' }}>
        <div style={{ marginBottom: '18px' }}>
          <h1 style={{ fontSize: '26px', fontWeight: '800', letterSpacing: '-0.03em', margin: 0 }}>
            Disputes
          </h1>
          <p style={{ color: colors.muted, marginTop: '2px', margin: 0 }}>
            Complaints from customers and helpers that need a decision
          </p>
        </div>

        {/* Filters */}
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginBottom: '14px', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', gap: '8px' }}>
            {[
              { value: 'open', label: 'Open' },
              { value: 'resolved', label: 'Resolved' },
              { value: 'all', label: 'All' }
            ].map((opt) => (
              <button
                key={opt.value}
                onClick={() => setFilter(opt.value as any)}
                style={{
                  padding: '7px 13px',
                  borderRadius: '99px',
                  border: `1px solid ${filter === opt.value ? colors.brand : colors.line}`,
                  backgroundColor: filter === opt.value ? colors.brandSoft : colors.surface,
                  color: filter === opt.value ? colors.brandText : colors.muted,
                  fontWeight: '700',
                  fontSize: '13px',
                  cursor: 'pointer'
                }}
              >
                {opt.label}
              </button>
            ))}
          </div>

          <div style={{ color: colors.muted, fontSize: '13px', fontWeight: '700' }}>
            {disputes.length} dispute{disputes.length !== 1 ? 's' : ''}
          </div>
        </div>

        {/* Table */}
        <Table
          columns={columns}
          data={disputes}
          onRowClick={handleSelectDispute}
          loading={loading}
          empty="No disputes here\nNice. Nothing needs a decision right now."
        />
      </div>

      {/* Drawer */}
      <Drawer
        isOpen={!!selectedDispute}
        onClose={() => setSelectedDispute(null)}
        title={selectedDispute?.id || ''}
        footer={
          selectedDispute && selectedDispute.status === 'open' && (
            <Button
              label="Resolve dispute"
              onClick={() => setResolveModal(true)}
              variant="primary"
              fullWidth
            />
          )
        }
      >
        {selectedDispute && (
          <>
            {/* Type & Status */}
            <div style={{ display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap', marginBottom: '10px' }}>
              <Pill
                label={PRIORITY_MAP[selectedDispute.priority]?.label || selectedDispute.priority}
                tone={PRIORITY_MAP[selectedDispute.priority]?.tone || 'mute'}
              />
              <Pill
                label={selectedDispute.status === 'open' ? 'Open' : 'Resolved'}
                tone={selectedDispute.status === 'open' ? 'warn' : 'ok'}
              />
            </div>

            {/* Issue */}
            <h3 style={{ fontSize: '18px', fontWeight: '800', lineHeight: 1.3, margin: '10px 0' }}>
              {selectedDispute.issue}
            </h3>

            {/* Info */}
            <div style={{ marginTop: '12px' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px', color: colors.muted }}>
                Task
              </div>
              <div style={{ fontSize: '13.5px' }}>
                <button
                  style={{
                    color: colors.brandText,
                    fontWeight: '700',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    fontSize: '13.5px'
                  }}
                >
                  {selectedDispute.taskId}
                </button>
              </div>
            </div>

            <div style={{ marginTop: '12px' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px', color: colors.muted }}>
                Raised by
              </div>
              <div style={{ fontSize: '13.5px' }}>
                {selectedDispute.raisedBy} ({selectedDispute.role})
              </div>
            </div>

            <div style={{ marginTop: '12px' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px', color: colors.muted }}>
                Complaint against
              </div>
              <div style={{ fontSize: '13.5px' }}>{selectedDispute.against}</div>
            </div>

            {selectedDispute.taskDetails?.amount && (
              <div style={{ marginTop: '12px' }}>
                <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px', color: colors.muted }}>
                  Task amount
                </div>
                <div style={{ fontSize: '13.5px', fontWeight: '800' }}>
                  ₹{selectedDispute.taskDetails.amount}
                </div>
              </div>
            )}

            {/* Messages */}
            <div style={{ marginTop: '12px' }}>
              <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px' }}>Conversation</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {selectedDispute.messages.map((msg, idx) => (
                  <div
                    key={idx}
                    style={{
                      padding: '9px 12px',
                      borderRadius: '14px',
                      backgroundColor: idx % 2 === 0 ? colors.surface2 : colors.brandSoft,
                      color: idx % 2 === 0 ? colors.ink : colors.brandText,
                      fontSize: '13.5px'
                    }}
                  >
                    <div style={{ fontWeight: '700', fontSize: '11.5px', marginBottom: '2px', opacity: 0.85 }}>
                      {msg.userName}
                    </div>
                    {msg.text}
                  </div>
                ))}
              </div>
            </div>

            {/* Resolution Info */}
            {selectedDispute.resolution && (
              <div style={{ marginTop: '12px' }}>
                <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px' }}>Outcome</div>
                <div
                  style={{
                    backgroundColor: colors.surface2,
                    borderRadius: '12px',
                    padding: '12px',
                    fontSize: '13.5px'
                  }}
                >
                  {selectedDispute.resolution.notes || selectedDispute.resolution.type}
                </div>
              </div>
            )}
          </>
        )}
      </Drawer>

      {/* Resolution Modal */}
      <Modal
        isOpen={resolveModal}
        onClose={() => setResolveModal(false)}
        title="Resolve dispute"
        size="medium"
        footer={
          <>
            <Button
              label="Cancel"
              onClick={() => setResolveModal(false)}
              variant="soft"
              fullWidth
            />
            <Button
              label="Resolve"
              onClick={handleResolve}
              variant="primary"
              fullWidth
            />
          </>
        }
      >
        <div style={{ marginBottom: '16px' }}>
          <div style={{ fontSize: '13px', fontWeight: '700', marginBottom: '8px', color: colors.muted }}>
            Resolution type
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {[
              {
                value: 'customer_win',
                label: 'Refund the customer in full',
                desc: selectedDispute ? `Return ₹${selectedDispute.refundMax} to customer` : ''
              },
              {
                value: 'partial',
                label: 'Partial refund',
                desc: 'Choose amounts for customer & helper'
              },
              {
                value: 'helper_win',
                label: 'Pay helper, no refund',
                desc: 'Complaint not upheld'
              },
              {
                value: 'warn',
                label: 'Warn the person complained about',
                desc: 'Log warning and close'
              },
              {
                value: 'dismiss',
                label: 'Dismiss',
                desc: 'No action needed'
              }
            ].map((opt) => (
              <button
                key={opt.value}
                onClick={() => setResolution({ ...resolution, type: opt.value })}
                style={{
                  padding: '12px 14px',
                  border: `1.5px solid ${resolution.type === opt.value ? colors.brand : colors.line}`,
                  borderRadius: '14px',
                  backgroundColor: resolution.type === opt.value ? colors.brandSoft : colors.surface2,
                  color: resolution.type === opt.value ? colors.brandText : colors.ink,
                  cursor: 'pointer',
                  fontWeight: '700',
                  fontSize: '14px',
                  textAlign: 'left'
                }}
              >
                <div>{opt.label}</div>
                <div style={{ fontSize: '12.5px', fontWeight: '500', color: colors.muted }}>
                  {opt.desc}
                </div>
              </button>
            ))}
          </div>
        </div>

        {resolution.type === 'partial' && selectedDispute && (
          <div style={{ marginBottom: '16px', display: 'flex', gap: '12px' }}>
            <div style={{ flex: 1 }}>
              <label style={{ fontSize: '13px', fontWeight: '700', marginBottom: '6px', display: 'block', color: colors.muted }}>
                Refund to customer (₹)
              </label>
              <input
                type="number"
                value={resolution.refundAmount}
                onChange={(e) =>
                  setResolution({ ...resolution, refundAmount: parseInt(e.target.value) || 0 })
                }
                max={selectedDispute.refundMax}
                style={{
                  width: '100%',
                  padding: '10px 12px',
                  border: `1.5px solid ${colors.line}`,
                  borderRadius: '12px',
                  fontSize: '14px',
                  fontFamily: 'inherit',
                  color: colors.ink,
                  backgroundColor: colors.surface
                }}
              />
            </div>
            <div style={{ flex: 1 }}>
              <label style={{ fontSize: '13px', fontWeight: '700', marginBottom: '6px', display: 'block', color: colors.muted }}>
                Payout to helper (₹)
              </label>
              <input
                type="number"
                value={resolution.helperPayoutAmount}
                onChange={(e) =>
                  setResolution({
                    ...resolution,
                    helperPayoutAmount: parseInt(e.target.value) || 0
                  })
                }
                style={{
                  width: '100%',
                  padding: '10px 12px',
                  border: `1.5px solid ${colors.line}`,
                  borderRadius: '12px',
                  fontSize: '14px',
                  fontFamily: 'inherit',
                  color: colors.ink,
                  backgroundColor: colors.surface
                }}
              />
            </div>
          </div>
        )}

        <div>
          <label style={{ fontSize: '13px', fontWeight: '700', marginBottom: '6px', display: 'block', color: colors.muted }}>
            Note for both parties (optional)
          </label>
          <textarea
            value={resolution.notes}
            onChange={(e) => setResolution({ ...resolution, notes: e.target.value })}
            placeholder="Add a note explaining the decision..."
            style={{
              width: '100%',
              padding: '10px 12px',
              border: `1.5px solid ${colors.line}`,
              borderRadius: '12px',
              fontSize: '14px',
              fontFamily: 'inherit',
              color: colors.ink,
              backgroundColor: colors.surface,
              minHeight: '80px',
              resize: 'vertical'
            }}
          />
        </div>
      </Modal>
    </div>
  )
}
