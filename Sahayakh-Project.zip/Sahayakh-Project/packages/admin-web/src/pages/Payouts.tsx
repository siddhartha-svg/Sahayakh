import React, { useState, useEffect } from 'react'
import { useTheme } from '../theme'
import { Icon } from '../components/Icon'
import { Modal, Drawer } from '../components/Modal'
import { Table, StatBox } from '../components/Table'
import { Button } from '../components/Button'
import { Pill } from '../components/Pill'
import { payoutApi } from '../api/client'
import { useUIStore } from '../store'

interface Payout {
  id: string
  helperId: string
  helperName: string
  amount: number
  method: string // "UPI rohit@upi" or "HDFC Bank ****4821"
  requestedAt: string
  status: 'pending' | 'paid' | 'failed'
  failureReason?: string
}

interface PayoutSummary {
  waiting: number
  waitingCount: number
  paidThisWeek: number
  paidCount: number
  failedCount: number
}

export const Payouts: React.FC = () => {
  const { getColors } = useTheme()
  const colors = getColors()
  const { showToast } = useUIStore()

  const [payouts, setPayouts] = useState<Payout[]>([])
  const [summary, setSummary] = useState<PayoutSummary>({
    waiting: 0,
    waitingCount: 0,
    paidThisWeek: 0,
    paidCount: 0,
    failedCount: 0
  })
  const [selectedPayout, setSelectedPayout] = useState<Payout | null>(null)
  const [loading, setLoading] = useState(false)
  const [holdModal, setHoldModal] = useState(false)
  const [holdReason, setHoldReason] = useState('')
  const [payAllModal, setPayAllModal] = useState(false)

  useEffect(() => {
    loadPayouts()
  }, [])

  const loadPayouts = async () => {
    setLoading(true)
    try {
      const [payoutRes, summaryRes] = await Promise.all([
        payoutApi.getPayouts({ limit: 50 }),
        payoutApi.payoutSummary()
      ])
      setPayouts(payoutRes.data || [])
      setSummary(summaryRes.data || {})
    } catch (error) {
      console.error('Failed to load payouts:', error)
      showToast('Failed to load payouts', 'error')
    } finally {
      setLoading(false)
    }
  }

  const handlePayNow = async (payoutId: string) => {
    try {
      await payoutApi.processPayout(payoutId)
      setPayouts(
        payouts.map((p) =>
          p.id === payoutId ? { ...p, status: 'paid' as const } : p
        )
      )
      setSummary({
        ...summary,
        waiting: summary.waiting - payouts.find((p) => p.id === payoutId)?.amount || 0,
        waitingCount: summary.waitingCount - 1,
        paidThisWeek: summary.paidThisWeek + payouts.find((p) => p.id === payoutId)?.amount || 0,
        paidCount: summary.paidCount + 1
      })
      showToast('Payout processed', 'success')
    } catch (error) {
      console.error('Failed to process payout:', error)
      showToast('Failed to process payout', 'error')
    }
  }

  const handlePayAll = async () => {
    try {
      const pendingPayouts = payouts.filter((p) => p.status === 'pending')
      for (const payout of pendingPayouts) {
        await payoutApi.processPayout(payout.id)
      }
      setPayouts(payouts.map((p) => (p.status === 'pending' ? { ...p, status: 'paid' as const } : p)))
      setSummary({
        ...summary,
        waiting: 0,
        waitingCount: 0,
        paidThisWeek: summary.paidThisWeek + summary.waiting,
        paidCount: summary.paidCount + summary.waitingCount
      })
      setPayAllModal(false)
      showToast('All payouts processed', 'success')
    } catch (error) {
      console.error('Failed to process payouts:', error)
      showToast('Failed to process payouts', 'error')
    }
  }

  const handleRetry = async (payoutId: string) => {
    try {
      await payoutApi.retryPayout(payoutId)
      setPayouts(
        payouts.map((p) =>
          p.id === payoutId ? { ...p, status: 'pending' as const, failureReason: undefined } : p
        )
      )
      showToast('Payout retry initiated', 'success')
    } catch (error) {
      console.error('Failed to retry payout:', error)
      showToast('Failed to retry payout', 'error')
    }
  }

  const handleHold = async () => {
    if (!selectedPayout || !holdReason) return
    try {
      await payoutApi.holdPayout(selectedPayout.id, holdReason)
      showToast('Payout put on hold', 'success')
      setHoldModal(false)
      setHoldReason('')
    } catch (error) {
      console.error('Failed to hold payout:', error)
      showToast('Failed to hold payout', 'error')
    }
  }

  const columns = [
    {
      key: 'helperName',
      label: 'Helper',
      width: '2.2fr',
      render: (val: string, row: Payout) => (
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', minWidth: 0 }}>
          <div
            style={{
              width: '40px',
              height: '40px',
              borderRadius: '8px',
              backgroundColor: colors.brandSoft,
              display: 'grid',
              placeItems: 'center',
              color: colors.brandText,
              fontWeight: '800',
              flex: 0
            }}
          >
            {val.charAt(0)}
          </div>
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: '14px', fontWeight: '700', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {val}
            </div>
            <div style={{ fontSize: '12.5px', color: colors.muted, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {row.id}
            </div>
          </div>
        </div>
      )
    },
    {
      key: 'method',
      label: 'Payment Method',
      width: '1.6fr',
      hideOnMobile: true,
      render: (val: string, row: Payout) => (
        <div>
          <div style={{ fontSize: '13.5px' }}>{val}</div>
          {row.failureReason && (
            <div style={{ fontSize: '12px', color: colors.badInk, fontWeight: '600' }}>
              {row.failureReason}
            </div>
          )}
        </div>
      )
    },
    {
      key: 'amount',
      label: 'Amount',
      width: '0.9fr',
      hideOnMobile: true,
      render: (val: number) => (
        <span style={{ fontWeight: '800' }}>
          ₹{val.toLocaleString('en-IN')}
        </span>
      )
    },
    {
      key: 'status',
      label: 'Status',
      width: '0.9fr',
      render: (val: string, row: Payout) => {
        const tone = val === 'pending' ? 'warn' : val === 'paid' ? 'ok' : 'bad'
        const label = val === 'pending' ? 'Pending' : val === 'paid' ? 'Paid' : 'Failed'
        return <Pill label={label} tone={tone} size="small" />
      }
    },
    {
      key: 'id',
      label: 'Actions',
      width: '1.5fr',
      render: (val: string, row: Payout) => {
        if (row.status === 'pending') {
          return (
            <div style={{ display: 'flex', gap: '8px' }}>
              <Button
                label="Pay now"
                onClick={() => handlePayNow(val)}
                variant="primary"
                size="small"
              />
              <Button
                label="Hold"
                onClick={() => {
                  setSelectedPayout(row)
                  setHoldModal(true)
                }}
                variant="soft"
                size="small"
              />
            </div>
          )
        }
        if (row.status === 'failed') {
          return (
            <Button
              label="Retry"
              onClick={() => handleRetry(val)}
              variant="outline"
              size="small"
              icon={<Icon name="refresh" size={14} />}
            />
          )
        }
        return null
      }
    }
  ]

  const pendingPayouts = payouts.filter((p) => p.status === 'pending').length

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'auto' }}>
      <div style={{ padding: '24px' }}>
        <div style={{ marginBottom: '18px' }}>
          <h1 style={{ fontSize: '26px', fontWeight: '800', letterSpacing: '-0.03em', margin: 0 }}>
            Payouts
          </h1>
          <p style={{ color: colors.muted, marginTop: '2px', margin: 0 }}>
            Helper withdrawal requests
          </p>
        </div>

        {/* Summary Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '14px', marginBottom: '16px' }}>
          <StatBox
            label="Waiting to be paid"
            value={`₹${summary.waiting.toLocaleString('en-IN')}`}
            detail={`${summary.waitingCount} request${summary.waitingCount !== 1 ? 's' : ''}`}
            tone="warn"
          />
          <StatBox
            label="Paid this week"
            value={`₹${summary.paidThisWeek.toLocaleString('en-IN')}`}
            detail={`${summary.paidCount} payouts`}
            tone="ok"
          />
          <StatBox
            label="Failed"
            value={summary.failedCount.toString()}
            detail="Needs a corrected UPI or bank detail"
            tone="bad"
          />
        </div>

        {/* Action Bar */}
        {pendingPayouts > 0 && (
          <div style={{ marginBottom: '14px' }}>
            <Button
              label={`Pay all pending (₹${summary.waiting.toLocaleString('en-IN')})`}
              onClick={() => setPayAllModal(true)}
              variant="primary"
            />
          </div>
        )}

        {/* Table */}
        <Table
          columns={columns}
          data={payouts}
          loading={loading}
          empty="No payouts here\nAll helpers have been paid or there are no pending requests."
        />
      </div>

      {/* Hold Modal */}
      <Modal
        isOpen={holdModal}
        onClose={() => {
          setHoldModal(false)
          setHoldReason('')
          setSelectedPayout(null)
        }}
        title="Hold payout for review"
        size="small"
        footer={
          <>
            <Button
              label="Cancel"
              onClick={() => {
                setHoldModal(false)
                setHoldReason('')
                setSelectedPayout(null)
              }}
              variant="soft"
              fullWidth
            />
            <Button
              label="Hold"
              onClick={handleHold}
              variant="primary"
              disabled={!holdReason}
              fullWidth
            />
          </>
        }
      >
        <div style={{ marginBottom: '12px' }}>
          <label style={{ fontSize: '13px', fontWeight: '700', marginBottom: '6px', display: 'block', color: colors.muted }}>
            Reason for holding
          </label>
          <textarea
            value={holdReason}
            onChange={(e) => setHoldReason(e.target.value)}
            placeholder="e.g., Payment method needs verification"
            style={{
              width: '100%',
              padding: '10px 12px',
              border: `1.5px solid ${colors.line}`,
              borderRadius: '12px',
              fontSize: '14px',
              fontFamily: 'inherit',
              color: colors.ink,
              backgroundColor: colors.surface,
              minHeight: '80px',
              resize: 'vertical'
            }}
          />
        </div>
      </Modal>

      {/* Pay All Modal */}
      <Modal
        isOpen={payAllModal}
        onClose={() => setPayAllModal(false)}
        title="Pay all pending?"
        size="small"
        footer={
          <>
            <Button
              label="Cancel"
              onClick={() => setPayAllModal(false)}
              variant="soft"
              fullWidth
            />
            <Button
              label={`Pay ₹${summary.waiting.toLocaleString('en-IN')}`}
              onClick={handlePayAll}
              variant="primary"
              fullWidth
            />
          </>
        }
      >
        <p style={{ color: colors.muted }}>
          ₹{summary.waiting.toLocaleString('en-IN')} will be sent to {summary.waitingCount} helper{summary.waitingCount !== 1 ? 's' : ''} by UPI or bank transfer.
        </p>
      </Modal>
    </div>
  )
}
