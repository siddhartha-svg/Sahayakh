import React, { useState } from 'react'
import { useTheme } from './theme'
import { useUIStore } from './store'
import { Sidebar } from './components/Sidebar'
import { Topbar } from './components/Topbar'
import { Icon } from './components/Icon'
import { Overview } from './pages/Overview'
import { Approvals } from './pages/Approvals'
import { Helpers } from './pages/Helpers'
import { Tasks } from './pages/Tasks'
import { Disputes } from './pages/Disputes'
import { Payouts } from './pages/Payouts'
import { Pricing } from './pages/Pricing'

type Page = 'overview' | 'approvals' | 'helpers' | 'tasks' | 'disputes' | 'payouts' | 'pricing'

const navItems = [
  { id: 'overview', label: 'Overview', icon: <Icon name="grid" size={20} /> },
  { id: 'approvals', label: 'Approvals', icon: <Icon name="ucheck" size={20} /> },
  { id: 'helpers', label: 'Helpers', icon: <Icon name="users" size={20} /> },
  { id: 'tasks', label: 'Tasks', icon: <Icon name="list" size={20} /> },
  { id: 'disputes', label: 'Disputes', icon: <Icon name="alert" size={20} /> },
  { id: 'payouts', label: 'Payouts', icon: <Icon name="wallet" size={20} /> },
  { id: 'pricing', label: 'Pricing', icon: <Icon name="tag" size={20} /> },
]

export const App: React.FC = () => {
  const { colorMode, getColors } = useTheme()
  const { sidebarOpen, toggleSidebar } = useUIStore()
  const colors = getColors()
  const [currentPage, setCurrentPage] = useState<Page>('overview')
  const [range, setRange] = useState<'today' | 'week' | 'month'>('today')

  return (
    <div
      style={{
        height: '100vh',
        display: 'grid',
        gridTemplateColumns: sidebarOpen ? '252px 1fr' : '0 1fr',
        overflow: 'hidden',
        backgroundColor: colors.page,
        color: colors.ink,
        fontFamily: 'Plus Jakarta Sans, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
        fontSize: '14px',
        lineHeight: 1.45,
        transition: 'grid-template-columns 0.3s ease'
      }}
    >
      <Sidebar
        currentPage={currentPage}
        onPageChange={setCurrentPage}
        navItems={navItems.map(item => ({
          ...item,
          icon: typeof item.icon === 'string' ? <Icon name={item.icon as any} size={20} /> : item.icon
        }))}
        open={sidebarOpen}
      />

      <div style={{ display: 'flex', flexDirection: 'column', minWidth: 0, overflow: 'hidden' }}>
        <Topbar
          onMenuClick={toggleSidebar}
          title="Sahayakh Admin"
          city="Warangal, Telangana"
          onNotifications={() => alert('Notifications feature coming soon')}
          notificationCount={3}
        />

        <main style={{ flex: 1, overflow: 'auto', backgroundColor: colors.page }}>
          {currentPage === 'overview' && (
            <Overview range={range} onRangeChange={setRange} />
          )}
          {currentPage === 'approvals' && <Approvals />}
          {currentPage === 'helpers' && <Helpers />}
          {currentPage === 'tasks' && <Tasks />}
          {currentPage === 'disputes' && <Disputes />}
          {currentPage === 'payouts' && <Payouts />}
          {currentPage === 'pricing' && <Pricing />}
        </main>
      </div>
    </div>
  )
}
