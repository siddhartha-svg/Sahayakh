import { create } from 'zustand'
import { colors, ColorScheme } from './colors'

interface ThemeStore {
  colorMode: 'light' | 'dark'
  toggleTheme: () => void
  getColors: () => ColorScheme
}

export const useTheme = create<ThemeStore>((set, get) => ({
  colorMode: (localStorage.getItem('theme') as 'light' | 'dark') || 'light',
  toggleTheme: () => {
    set((state) => {
      const newMode = state.colorMode === 'light' ? 'dark' : 'light'
      localStorage.setItem('theme', newMode)
      document.documentElement.dataset.theme = newMode
      return { colorMode: newMode }
    })
  },
  getColors: () => colors[get().colorMode]
}))

export { colors }
export type { ColorScheme }
