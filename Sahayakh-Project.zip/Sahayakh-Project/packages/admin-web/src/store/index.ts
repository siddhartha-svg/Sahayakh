import { create } from 'zustand'

interface AdminUser {
  id: string
  name: string
  email: string
  role: 'operations' | 'support' | 'finance'
}

interface AdminStore {
  user: AdminUser | null
  token: string | null
  setUser: (user: AdminUser) => void
  setToken: (token: string) => void
  logout: () => void
}

export const useAuthStore = create<AdminStore>((set) => ({
  user: null,
  token: localStorage.getItem('adminToken'),
  setUser: (user) => set({ user }),
  setToken: (token) => {
    localStorage.setItem('adminToken', token)
    set({ token })
  },
  logout: () => {
    localStorage.removeItem('adminToken')
    set({ user: null, token: null })
  }
}))

interface UIStore {
  sidebarOpen: boolean
  toggleSidebar: () => void
  setSidebarOpen: (open: boolean) => void
  toast: { message: string; type: 'success' | 'error' | 'info' } | null
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void
  clearToast: () => void
}

export const useUIStore = create<UIStore>((set) => ({
  sidebarOpen: true,
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  toast: null,
  showToast: (message, type = 'success') => {
    set({ toast: { message, type } })
    setTimeout(() => set({ toast: null }), 3000)
  },
  clearToast: () => set({ toast: null })
}))
