import axios, { AxiosInstance } from 'axios'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api'

const axiosInstance: AxiosInstance = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

axiosInstance.interceptors.request.use((config) => {
  const token = localStorage.getItem('adminToken')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('adminToken')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export const overviewApi = {
  getKPIs: (range: 'today' | 'week' | 'month') =>
    axiosInstance.get(`/admin/overview/kpis?range=${range}`),
  getFeed: (limit?: number) =>
    axiosInstance.get(`/admin/overview/feed?limit=${limit || 10}`),
  getLiveStats: () =>
    axiosInstance.get(`/admin/overview/live-stats`),
}

export const approvalApi = {
  getApplications: (limit?: number, offset?: number) =>
    axiosInstance.get(`/admin/approvals/applications?limit=${limit || 10}&offset=${offset || 0}`),
  getApplicationDetails: (appId: string) =>
    axiosInstance.get(`/admin/approvals/applications/${appId}`),
  approveApplication: (appId: string) =>
    axiosInstance.post(`/admin/approvals/applications/${appId}/approve`),
  rejectApplication: (appId: string, reason: string) =>
    axiosInstance.post(`/admin/approvals/applications/${appId}/reject`, { reason }),
  verifyDocument: (appId: string, docType: string) =>
    axiosInstance.post(`/admin/approvals/applications/${appId}/documents/${docType}/verify`),
}

export const helperApi = {
  getHelpers: (filter?: { status?: string; query?: string; limit?: number; offset?: number }) =>
    axiosInstance.get('/admin/helpers', { params: filter }),
  getHelperDetails: (helperId: string) =>
    axiosInstance.get(`/admin/helpers/${helperId}`),
  suspendHelper: (helperId: string, reason: string) =>
    axiosInstance.post(`/admin/helpers/${helperId}/suspend`, { reason }),
  reactivateHelper: (helperId: string) =>
    axiosInstance.post(`/admin/helpers/${helperId}/reactivate`),
  getHelperStats: (helperId: string) =>
    axiosInstance.get(`/admin/helpers/${helperId}/stats`),
}

export const taskApi = {
  getTasks: (filter?: { status?: string; type?: string; query?: string; limit?: number; offset?: number }) =>
    axiosInstance.get('/admin/tasks', { params: filter }),
  getTaskDetails: (taskId: string) =>
    axiosInstance.get(`/admin/tasks/${taskId}`),
  assignTask: (taskId: string, helperId: string) =>
    axiosInstance.post(`/admin/tasks/${taskId}/assign`, { helper_id: helperId }),
  reassignTask: (taskId: string, helperId: string) =>
    axiosInstance.post(`/admin/tasks/${taskId}/reassign`, { helper_id: helperId }),
  cancelTask: (taskId: string, reason: string) =>
    axiosInstance.post(`/admin/tasks/${taskId}/cancel`, { reason }),
}

export const disputeApi = {
  getDisputes: (filter?: { status?: string; limit?: number; offset?: number }) =>
    axiosInstance.get('/admin/disputes', { params: filter }),
  getDisputeDetails: (disputeId: string) =>
    axiosInstance.get(`/admin/disputes/${disputeId}`),
  assignDispute: (disputeId: string, adminId: string) =>
    axiosInstance.post(`/admin/disputes/${disputeId}/assign`, { admin_id: adminId }),
  resolveDispute: (disputeId: string, resolution: any) =>
    axiosInstance.post(`/admin/disputes/${disputeId}/resolve`, resolution),
}

export const payoutApi = {
  getPayouts: (filter?: { status?: string; limit?: number; offset?: number }) =>
    axiosInstance.get('/admin/payouts', { params: filter }),
  payoutDetails: (payoutId: string) =>
    axiosInstance.get(`/admin/payouts/${payoutId}`),
  processPayout: (payoutId: string) =>
    axiosInstance.post(`/admin/payouts/${payoutId}/pay`),
  holdPayout: (payoutId: string, reason: string) =>
    axiosInstance.post(`/admin/payouts/${payoutId}/hold`, { reason }),
  retryPayout: (payoutId: string) =>
    axiosInstance.post(`/admin/payouts/${payoutId}/retry`),
  payoutSummary: () =>
    axiosInstance.get('/admin/payouts/summary'),
}

export const pricingApi = {
  getPricing: () =>
    axiosInstance.get('/admin/pricing/config'),
  updatePricing: (config: any) =>
    axiosInstance.put('/admin/pricing/config', config),
  calculateFare: (distance: number, duration: number, isBusinessTask: boolean) =>
    axiosInstance.post('/admin/pricing/calculate', { distance, duration, is_business: isBusinessTask }),
}

export default axiosInstance
