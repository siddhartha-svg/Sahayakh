import React from 'react'
import { Icon } from './Icon'
import { useTheme } from '../theme'

interface NavItem {
  id: string
  label: string
  icon: React.ReactNode
  badge?: number
}

interface SidebarProps {
  currentPage: string
  onPageChange: (page: string) => void
  navItems: NavItem[]
  adminName?: string
  adminRole?: string
  open?: boolean
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onPageChange,
  navItems,
  adminName = 'Meena Iyer',
  adminRole = 'Operations lead',
  open = true
}) => {
  const { colorMode, getColors } = useTheme()
  const colors = getColors()

  return (
    <aside
      style={{
        backgroundColor: colors.side,
        color: '#fff',
        display: 'flex',
        flexDirection: 'column',
        width: open ? '252px' : '0',
        overflow: 'hidden',
        transition: 'width 0.3s ease',
        padding: open ? '18px 14px' : '0',
      }}
    >
      {open && (
        <>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '18px' }}>
            <svg width="34" height="34" viewBox="0 0 24 24" fill="#fff">
              <path d="M12 22s-7-6.2-7-12a7 7 0 0 1 14 0c0 5.8-7 12-7 12z" />
              <circle cx="12" cy="10" r="3.2" fill={colors.side} />
            </svg>
            <div>
              <div style={{ fontSize: '20px', fontWeight: '800', lineHeight: 1.1 }}>Sahayakh</div>
              <div style={{ fontSize: '11.5px', opacity: 0.75 }}>Admin console</div>
            </div>
          </div>

          <nav style={{ display: 'flex', flexDirection: 'column', gap: '4px', flex: 1 }}>
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onPageChange(item.id)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '11px 12px',
                  borderRadius: '12px',
                  fontWeight: '600',
                  fontSize: '14px',
                  color: currentPage === item.id ? '#fff' : 'rgba(255,255,255,.82)',
                  backgroundColor:
                    currentPage === item.id
                      ? 'rgba(255,255,255,.16)'
                      : 'transparent',
                  border: 'none',
                  cursor: 'pointer',
                  width: '100%',
                  textAlign: 'left',
                  transition: 'all 0.2s ease'
                }}
              >
                {item.icon}
                <span style={{ flex: 1 }}>{item.label}</span>
                {item.badge ? (
                  <span
                    style={{
                      backgroundColor: '#F2A20C',
                      color: '#2a1a00',
                      fontSize: '11.5px',
                      fontWeight: '800',
                      borderRadius: '99px',
                      padding: '1px 8px'
                    }}
                  >
                    {item.badge}
                  </span>
                ) : null}
              </button>
            ))}
          </nav>

          <div
            style={{
              marginTop: 'auto',
              paddingTop: '14px',
              borderTop: '1px solid rgba(255,255,255,.1)',
              display: 'flex',
              alignItems: 'center',
              gap: '10px'
            }}
          >
            <div
              style={{
                width: '38px',
                height: '38px',
                borderRadius: '50%',
                backgroundColor: '#D9A47A',
                display: 'grid',
                placeItems: 'center',
                color: '#fff',
                fontWeight: '800',
                fontSize: '14px'
              }}
            >
              MI
            </div>
            <div>
              <div style={{ fontSize: '13.5px', fontWeight: '700' }}>{adminName}</div>
              <div style={{ fontSize: '12px', opacity: 0.75 }}>{adminRole}</div>
            </div>
          </div>
        </>
      )}
    </aside>
  )
}
