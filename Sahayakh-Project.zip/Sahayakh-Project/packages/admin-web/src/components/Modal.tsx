import React from 'react'
import { useTheme } from '../theme'
import { Icon } from './Icon'
import { Button } from './Button'

interface ModalProps {
  isOpen: boolean
  onClose: () => void
  title: string
  children: React.ReactNode
  footer?: React.ReactNode
  size?: 'small' | 'medium' | 'large'
}

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  children,
  footer,
  size = 'medium'
}) => {
  const { getColors } = useTheme()
  const colors = getColors()

  if (!isOpen) return null

  const sizeStyles = {
    small: { width: '320px' },
    medium: { width: '440px' },
    large: { width: '600px' }
  }

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 70,
        backgroundColor: 'rgba(6,14,10,.55)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '16px',
        backdropFilter: 'blur(2px)'
      }}
      onClick={onClose}
    >
      <div
        style={{
          ...sizeStyles[size],
          maxHeight: '90vh',
          overflowY: 'auto',
          backgroundColor: colors.surface,
          borderRadius: '20px',
          padding: '20px',
          boxShadow: '0 20px 50px rgba(0,0,0,.35)'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ marginBottom: '16px' }}>
          <h2 style={{ fontSize: '18px', fontWeight: '800', letterSpacing: '-0.01em', marginBottom: '6px' }}>
            {title}
          </h2>
        </div>

        <div style={{ marginBottom: '16px', fontSize: '14px', lineHeight: 1.5 }}>
          {children}
        </div>

        {footer && (
          <div style={{ display: 'flex', gap: '10px', marginTop: '16px' }}>
            {footer}
          </div>
        )}
      </div>
    </div>
  )
}

interface DrawerProps {
  isOpen: boolean
  onClose: () => void
  title: string
  children: React.ReactNode
  footer?: React.ReactNode
}

export const Drawer: React.FC<DrawerProps> = ({
  isOpen,
  onClose,
  title,
  children,
  footer
}) => {
  const { getColors } = useTheme()
  const colors = getColors()

  return (
    <>
      {isOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 60,
            backgroundColor: 'rgba(6,14,10,.5)',
            opacity: isOpen ? 1 : 0,
            visibility: isOpen ? 'visible' : 'hidden',
            transition: 'opacity 0.2s, visibility 0s linear',
            transitionDelay: isOpen ? '0s' : '0.2s'
          }}
          onClick={onClose}
        />
      )}

      <aside
        style={{
          position: 'fixed',
          top: 0,
          right: 0,
          bottom: 0,
          width: 'min(480px, 100%)',
          backgroundColor: colors.surface,
          display: 'flex',
          flexDirection: 'column',
          transform: isOpen ? 'translateX(0)' : 'translateX(100%)',
          transition: 'transform 0.28s cubic-bezier(.2,.7,.2,1)',
          zIndex: 60,
          paddingTop: 'env(safe-area-inset-top, 0px)',
          paddingBottom: 'env(safe-area-inset-bottom, 0px)'
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '10px',
            padding: '14px 18px',
            borderBottom: `1px solid ${colors.line}`
          }}
        >
          <h2 style={{ fontSize: '17px', fontWeight: '800', letterSpacing: '-0.01em' }}>
            {title}
          </h2>
          <button
            onClick={onClose}
            style={{
              width: '40px',
              height: '40px',
              borderRadius: '50%',
              border: 'none',
              backgroundColor: 'transparent',
              cursor: 'pointer',
              display: 'grid',
              placeItems: 'center',
              color: colors.ink
            }}
          >
            <Icon name="x" size={20} />
          </button>
        </div>

        <div
          style={{
            flex: 1,
            overflowY: 'auto',
            padding: '18px',
            fontSize: '13.5px',
            lineHeight: 1.5
          }}
        >
          {children}
        </div>

        {footer && (
          <div
            style={{
              padding: '12px 18px',
              borderTop: `1px solid ${colors.line}`,
              display: 'flex',
              gap: '10px'
            }}
          >
            {footer}
          </div>
        )}
      </aside>
    </>
  )
}
