import React from 'react'
import { Icon } from './Icon'

interface ButtonProps {
  label: string
  onClick?: () => void
  variant?: 'primary' | 'secondary' | 'danger' | 'soft' | 'outline'
  size?: 'small' | 'medium' | 'large'
  icon?: React.ReactNode
  disabled?: boolean
  loading?: boolean
  fullWidth?: boolean
  className?: string
  style?: React.CSSProperties
}

export const Button: React.FC<ButtonProps> = ({
  label,
  onClick,
  variant = 'primary',
  size = 'medium',
  icon,
  disabled = false,
  loading = false,
  fullWidth = false,
  className = '',
  style
}) => {
  const baseStyles: React.CSSProperties = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    border: 'none',
    borderRadius: '12px',
    fontWeight: '700',
    cursor: disabled ? 'not-allowed' : 'pointer',
    transition: 'all 0.2s ease',
    ...style
  }

  const variantStyles: Record<string, React.CSSProperties> = {
    primary: {
      backgroundColor: '#1B7A3E',
      color: '#fff',
      padding: size === 'small' ? '0 12px' : size === 'medium' ? '0 16px' : '0 20px',
      height: size === 'small' ? '34px' : size === 'medium' ? '42px' : '48px',
      fontSize: size === 'small' ? '13px' : '14px',
    },
    secondary: {
      backgroundColor: '#F5F8F6',
      color: '#0E2217',
      border: '1px solid #E0E8E2',
      padding: size === 'small' ? '0 12px' : size === 'medium' ? '0 16px' : '0 20px',
      height: size === 'small' ? '34px' : size === 'medium' ? '42px' : '48px',
      fontSize: size === 'small' ? '13px' : '14px',
    },
    danger: {
      backgroundColor: '#FBE6E3',
      color: '#B3311F',
      border: '1.5px solid #C0392B',
      padding: size === 'small' ? '0 12px' : size === 'medium' ? '0 16px' : '0 20px',
      height: size === 'small' ? '34px' : size === 'medium' ? '42px' : '48px',
      fontSize: size === 'small' ? '13px' : '14px',
    },
    soft: {
      backgroundColor: '#F5F8F6',
      color: '#0E2217',
      border: '1px solid #E0E8E2',
      padding: size === 'small' ? '0 12px' : size === 'medium' ? '0 16px' : '0 20px',
      height: size === 'small' ? '34px' : size === 'medium' ? '42px' : '48px',
      fontSize: size === 'small' ? '13px' : '14px',
    },
    outline: {
      backgroundColor: 'transparent',
      color: '#1B7A3E',
      border: '1.5px solid #1B7A3E',
      padding: size === 'small' ? '0 12px' : size === 'medium' ? '0 16px' : '0 20px',
      height: size === 'small' ? '34px' : size === 'medium' ? '42px' : '48px',
      fontSize: size === 'small' ? '13px' : '14px',
    }
  }

  const hoverStyles: React.CSSProperties = !disabled ? {
    opacity: 0.9,
    transform: 'translateY(1px)'
  } : {}

  const disabledStyles: React.CSSProperties = disabled ? {
    backgroundColor: '#F5F8F6',
    color: '#57675E',
    border: '1px solid #E0E8E2',
    cursor: 'not-allowed'
  } : {}

  return (
    <button
      onClick={onClick}
      disabled={disabled || loading}
      className={className}
      style={{
        ...baseStyles,
        ...variantStyles[variant],
        ...disabledStyles,
        width: fullWidth ? '100%' : 'auto'
      }}
      onMouseEnter={(e) => {
        if (!disabled && !loading) {
          Object.assign(e.currentTarget.style, hoverStyles)
        }
      }}
      onMouseLeave={(e) => {
        if (!disabled && !loading) {
          e.currentTarget.style.opacity = '1'
          e.currentTarget.style.transform = 'translateY(0)'
        }
      }}
    >
      {loading && <span>⟳</span>}
      {icon}
      {label}
    </button>
  )
}
