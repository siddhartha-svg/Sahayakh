import React from 'react'
import { useTheme } from '../theme'

interface BadgeProps {
  label: string
  tone?: 'ok' | 'warn' | 'bad' | 'info' | 'mute'
  icon?: React.ReactNode
  className?: string
}

export const Badge: React.FC<BadgeProps> = ({
  label,
  tone = 'info',
  icon,
  className = ''
}) => {
  const { getColors } = useTheme()
  const colors = getColors()

  const toneStyles = {
    ok: { bg: colors.okSoft, color: colors.okInk },
    warn: { bg: colors.warnSoft, color: colors.warnInk },
    bad: { bg: colors.badSoft, color: colors.badInk },
    info: { bg: colors.infoSoft, color: colors.infoInk },
    mute: { bg: colors.muteSoft, color: colors.muteInk }
  }

  return (
    <span
      className={className}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '5px',
        padding: '3px 10px',
        borderRadius: '99px',
        fontSize: '12px',
        fontWeight: '700',
        whiteSpace: 'nowrap',
        backgroundColor: toneStyles[tone].bg,
        color: toneStyles[tone].color
      }}
    >
      {icon}
      {label}
    </span>
  )
}

interface TagProps {
  label: string
  onRemove?: () => void
  className?: string
}

export const Tag: React.FC<TagProps> = ({ label, onRemove, className = '' }) => {
  const { getColors } = useTheme()
  const colors = getColors()

  return (
    <span
      className={className}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '6px',
        padding: '5px 10px',
        borderRadius: '10px',
        backgroundColor: colors.surface2,
        border: `1px solid ${colors.line}`,
        fontSize: '12.5px',
        fontWeight: '600'
      }}
    >
      {label}
      {onRemove && (
        <button
          onClick={onRemove}
          style={{
            border: 'none',
            background: 'none',
            cursor: 'pointer',
            color: colors.muted,
            padding: '0',
            lineHeight: 1
          }}
        >
          ×
        </button>
      )}
    </span>
  )
}
