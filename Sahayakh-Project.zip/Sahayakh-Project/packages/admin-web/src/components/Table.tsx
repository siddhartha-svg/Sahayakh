import React from 'react'
import { useTheme } from '../theme'
import { Icon } from './Icon'

interface Column {
  key: string
  label: string
  width?: string
  render?: (value: any, row: any) => React.ReactNode
  hideOnMobile?: boolean
}

interface TableProps {
  columns: Column[]
  data: any[]
  onRowClick?: (row: any) => void
  loading?: boolean
  empty?: string
  className?: string
}

export const Table: React.FC<TableProps> = ({
  columns,
  data,
  onRowClick,
  loading = false,
  empty = 'No data found',
  className = ''
}) => {
  const { getColors } = useTheme()
  const colors = getColors()

  const colsTemplate = columns.map((c) => c.width || '1fr').join(' ')

  return (
    <div
      style={{
        border: `1px solid ${colors.line}`,
        borderRadius: '18px',
        overflow: 'hidden',
        backgroundColor: colors.surface,
        boxShadow: colors.shadow
      }}
      className={className}
    >
      {/* Header */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: colsTemplate,
          gap: '12px',
          alignItems: 'center',
          padding: '12px 16px',
          fontSize: '12px',
          color: colors.muted,
          fontWeight: '700',
          backgroundColor: colors.surface2,
          borderBottom: `1px solid ${colors.line}`,
          textAlign: 'left'
        }}
      >
        {columns.map((col) =>
          !col.hideOnMobile ? (
            <span key={col.key}>{col.label}</span>
          ) : (
            <span key={col.key} style={{ display: 'none' }} className="hide-sm">
              {col.label}
            </span>
          )
        )}
      </div>

      {/* Body */}
      {loading ? (
        <div style={{ padding: '32px', textAlign: 'center', color: colors.muted }}>
          Loading...
        </div>
      ) : data.length === 0 ? (
        <div style={{ padding: '36px 16px', textAlign: 'center' }}>
          <div style={{ color: colors.ink, fontSize: '15px', fontWeight: '700', marginBottom: '2px' }}>
            {empty.split('\n')[0]}
          </div>
          <div style={{ color: colors.muted, fontSize: '14px' }}>
            {empty.split('\n')[1] || ''}
          </div>
        </div>
      ) : (
        data.map((row, idx) => (
          <button
            key={idx}
            onClick={() => onRowClick?.(row)}
            style={{
              display: 'grid',
              gridTemplateColumns: colsTemplate,
              gap: '12px',
              alignItems: 'center',
              padding: '12px 16px',
              borderTop: `1px solid ${colors.line}`,
              width: '100%',
              textAlign: 'left',
              backgroundColor: colors.surface,
              border: 'none',
              cursor: onRowClick ? 'pointer' : 'default',
              transition: 'background-color 0.2s ease'
            }}
            onMouseEnter={(e) => {
              if (onRowClick) e.currentTarget.style.backgroundColor = colors.surface2
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = colors.surface
            }}
          >
            {columns.map((col) => (
              <div
                key={col.key}
                style={col.hideOnMobile ? { display: 'none' } : {}}
                className="hide-sm"
              >
                {col.render ? col.render(row[col.key], row) : row[col.key]}
              </div>
            ))}
          </button>
        ))
      )}
    </div>
  )
}

interface StatBoxProps {
  label: string
  value: string | number
  detail?: string
  icon?: React.ReactNode
  tone?: 'ok' | 'warn' | 'bad' | 'info' | 'mute'
}

export const StatBox: React.FC<StatBoxProps> = ({
  label,
  value,
  detail,
  icon,
  tone = 'info'
}) => {
  const { getColors } = useTheme()
  const colors = getColors()

  const toneStyles = {
    ok: { bg: colors.okSoft, color: colors.okInk },
    warn: { bg: colors.warnSoft, color: colors.warnInk },
    bad: { bg: colors.badSoft, color: colors.badInk },
    info: { bg: colors.infoSoft, color: colors.infoInk },
    mute: { bg: colors.muteSoft, color: colors.muteInk }
  }

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        padding: '12px 16px',
        backgroundColor: colors.surface,
        border: `1px solid ${colors.line}`,
        borderRadius: '14px'
      }}
    >
      {icon && (
        <span
          style={{
            width: '38px',
            height: '38px',
            borderRadius: '12px',
            display: 'grid',
            placeItems: 'center',
            backgroundColor: toneStyles[tone].bg,
            color: toneStyles[tone].color,
            flex: 0
          }}
        >
          {icon}
        </span>
      )}
      <div style={{ flex: 1 }}>
        <div style={{ color: colors.muted, fontSize: '12.5px', fontWeight: '600' }}>
          {label}
        </div>
        <div style={{ fontSize: '14px', fontWeight: '700', color: colors.ink, marginTop: '2px' }}>
          {value}
        </div>
        {detail && (
          <div style={{ fontSize: '12.5px', color: colors.muted, marginTop: '2px' }}>
            {detail}
          </div>
        )}
      </div>
    </div>
  )
}
