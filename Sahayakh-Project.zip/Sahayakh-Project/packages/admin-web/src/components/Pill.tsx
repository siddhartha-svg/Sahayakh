import React from 'react'
import { useTheme } from '../theme'

interface PillProps {
  label: string
  tone?: 'ok' | 'warn' | 'bad' | 'info' | 'mute'
  size?: 'small' | 'medium'
  className?: string
}

export const Pill: React.FC<PillProps> = ({
  label,
  tone = 'info',
  size = 'medium',
  className = ''
}) => {
  const { getColors } = useTheme()
  const colors = getColors()

  const toneStyles = {
    ok: { bg: colors.okSoft, color: colors.okInk },
    warn: { bg: colors.warnSoft, color: colors.warnInk },
    bad: { bg: colors.badSoft, color: colors.badInk },
    info: { bg: colors.infoSoft, color: colors.infoInk },
    mute: { bg: colors.muteSoft, color: colors.muteInk }
  }

  const sizeStyles = {
    small: { padding: '3px 8px', fontSize: '11px' },
    medium: { padding: '4px 12px', fontSize: '12px' }
  }

  return (
    <span
      className={className}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '4px',
        borderRadius: '99px',
        fontWeight: '700',
        whiteSpace: 'nowrap',
        backgroundColor: toneStyles[tone].bg,
        color: toneStyles[tone].color,
        ...sizeStyles[size]
      }}
    >
      {label}
    </span>
  )
}
