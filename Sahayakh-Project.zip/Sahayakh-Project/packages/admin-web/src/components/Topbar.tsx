import React from 'react'
import { Icon } from './Icon'
import { useTheme } from '../theme'

interface TopbarProps {
  onMenuClick?: () => void
  title?: string
  city?: string
  onNotifications?: () => void
  notificationCount?: number
}

export const Topbar: React.FC<TopbarProps> = ({
  onMenuClick,
  title = 'Sahayakh Admin',
  city = 'Warangal, Telangana',
  onNotifications,
  notificationCount = 0
}) => {
  const { colorMode, toggleTheme, getColors } = useTheme()
  const colors = getColors()

  return (
    <header
      style={{
        position: 'sticky',
        top: 0,
        zIndex: 20,
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        padding: '10px 24px',
        backgroundColor: colors.surface,
        borderBottom: `1px solid ${colors.line}`
      }}
    >
      {onMenuClick && (
        <button
          onClick={onMenuClick}
          style={{
            width: '40px',
            height: '40px',
            borderRadius: '50%',
            border: 'none',
            backgroundColor: 'transparent',
            cursor: 'pointer',
            display: 'grid',
            placeItems: 'center',
            color: colors.ink
          }}
        >
          <Icon name="menu" size={22} />
        </button>
      )}

      <span style={{ fontSize: '17px', fontWeight: '800', color: colors.brandText, display: 'none' }} className="mobile-title">
        {title}
      </span>

      <div style={{ flex: 1 }} />

      <span
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: '6px',
          padding: '7px 12px',
          border: `1px solid ${colors.line}`,
          borderRadius: '99px',
          fontWeight: '600',
          fontSize: '13px',
          backgroundColor: colors.surface2
        }}
      >
        <Icon name="pin" size={15} style={{ color: colors.muted }} />
        {city}
      </span>

      <button
        onClick={toggleTheme}
        style={{
          width: '40px',
          height: '40px',
          borderRadius: '50%',
          border: 'none',
          backgroundColor: 'transparent',
          cursor: 'pointer',
          display: 'grid',
          placeItems: 'center',
          color: colors.ink
        }}
      >
        <Icon name={colorMode === 'dark' ? 'sun' : 'moon'} size={20} />
      </button>

      <button
        onClick={onNotifications}
        style={{
          width: '40px',
          height: '40px',
          borderRadius: '50%',
          border: 'none',
          backgroundColor: 'transparent',
          cursor: 'pointer',
          display: 'grid',
          placeItems: 'center',
          color: colors.ink,
          position: 'relative'
        }}
      >
        <Icon name="bell" size={22} />
        {notificationCount > 0 && (
          <span
            style={{
              position: 'absolute',
              top: '9px',
              right: '10px',
              width: '9px',
              height: '9px',
              borderRadius: '50%',
              backgroundColor: colors.bad,
              border: `2px solid ${colors.surface}`
            }}
          />
        )}
      </button>
    </header>
  )
}
