import { create } from 'zustand';
import { colors, ThemeMode, ColorMode } from './colors';
import { typography } from './typography';

export interface ThemeState {
  mode: ThemeMode;
  colorMode: ColorMode;
  setMode: (mode: ThemeMode) => void;
  toggleColorMode: () => void;
}

export const useTheme = create<ThemeState>((set) => ({
  mode: 'personal',
  colorMode: 'light',
  setMode: (mode: ThemeMode) => set({ mode }),
  toggleColorMode: () =>
    set((state) => ({
      colorMode: state.colorMode === 'light' ? 'dark' : 'light',
    })),
}));

export { colors, typography };
export type { ThemeMode, ColorMode };

// Helper to get current accent color
export const getAccentColor = (mode: ThemeMode, colorMode: ColorMode = 'light') => {
  if (colorMode === 'dark') return colors.dark.surface;
  return colors.light.accent[mode];
};

export const getAccentSoft = (mode: ThemeMode, colorMode: ColorMode = 'light') => {
  if (colorMode === 'dark') return colors.dark.surface2;
  return colors.light.accentSoft[mode];
};
