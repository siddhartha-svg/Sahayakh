export const colors = {
  // Primary colors by mode
  brand: {
    personal: '#1B7A3E',      // Green
    business: '#1D58BD',       // Blue
  },

  // Semantic colors (light mode)
  light: {
    // Surfaces
    surface: '#FFFFFF',
    surface2: '#F7F8F9',
    accent: {
      personal: '#1B7A3E',
      business: '#1D58BD',
    },
    accentSoft: {
      personal: '#E8F5EA',
      business: '#E3F2FD',
    },
    accentDeep: {
      personal: '#0D4620',
      business: '#0D2A5C',
    },
    accentText: {
      personal: '#0D4620',
      business: '#0D2A5C',
    },

    // Text
    ink: '#1A1A1A',
    muted: '#6B7280',

    // UI Elements
    line: '#E5E7EB',
    brandSoft: '#E8F5EA',
    brandText: '#0D4620',
    bizSoft: '#E3F2FD',
    bizText: '#0D2A5C',

    // Status
    success: '#22C55E',
    warning: '#F59E0B',
    error: '#EF4444',
    info: '#3B82F6',

    // Status backgrounds
    amberBg: '#FFFBEB',
    amberInk: '#92400E',

    // Special
    star: '#FFB800',
    shadow: '0 2px 8px rgba(0,0,0,0.08)',
  },

  // Dark mode (future)
  dark: {
    surface: '#1F2937',
    surface2: '#111827',
    ink: '#F9FAFB',
    muted: '#9CA3AF',
    line: '#374151',
  },
};

export type ThemeMode = 'personal' | 'business';
export type ColorMode = 'light' | 'dark';
