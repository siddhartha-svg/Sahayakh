import { Platform } from 'react-native';

export const typography = {
  fonts: {
    primary: Platform.select({
      ios: 'PlusJakartaSans-Regular',
      android: 'PlusJakartaSans',
      default: 'PlusJakartaSans',
    }),
  },

  sizes: {
    // Display
    h1: {
      fontSize: 32,
      lineHeight: 38,
      fontWeight: '800',
      letterSpacing: -0.8,
    },
    h2: {
      fontSize: 26,
      lineHeight: 31,
      fontWeight: '800',
      letterSpacing: -0.65,
    },
    h3: {
      fontSize: 23,
      lineHeight: 28,
      fontWeight: '800',
      letterSpacing: -0.575,
    },

    // Body
    body: {
      fontSize: 15,
      lineHeight: 22,
      fontWeight: '500',
    },
    bodySm: {
      fontSize: 13.5,
      lineHeight: 20,
      fontWeight: '500',
    },
    bodyXs: {
      fontSize: 12,
      lineHeight: 18,
      fontWeight: '500',
    },

    // Label
    label: {
      fontSize: 14,
      lineHeight: 20,
      fontWeight: '600',
    },
    labelSm: {
      fontSize: 12.5,
      lineHeight: 18,
      fontWeight: '600',
    },
    labelXs: {
      fontSize: 11,
      lineHeight: 16,
      fontWeight: '600',
    },

    // Caption
    caption: {
      fontSize: 11.5,
      lineHeight: 16,
      fontWeight: '500',
    },
  },
};
