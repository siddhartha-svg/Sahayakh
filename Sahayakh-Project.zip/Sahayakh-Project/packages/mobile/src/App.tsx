import React, { useEffect } from 'react';
import * as SplashScreen from 'expo-splash-screen';
import * as Font from 'expo-font';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { RootNavigator } from './navigation/RootNavigator';
import { useAuthStore } from './store';

// Keep splash screen visible while loading
SplashScreen.preventAutoHideAsync();

export const App: React.FC = () => {
  const [isReady, setIsReady] = React.useState(false);
  const { setToken } = useAuthStore();

  useEffect(() => {
    const bootstrapAsync = async () => {
      try {
        // Load fonts
        await Font.loadAsync({
          'PlusJakartaSans': require('./assets/PlusJakartaSans-Regular.ttf'),
          'PlusJakartaSans-Bold': require('./assets/PlusJakartaSans-Bold.ttf'),
        });

        // Restore auth token from storage
        const token = await AsyncStorage.getItem('auth-token');
        if (token) {
          setToken(token);
        }
      } catch (e) {
        console.warn('Error bootstrapping app:', e);
      } finally {
        setIsReady(true);
        await SplashScreen.hideAsync();
      }
    };

    bootstrapAsync();
  }, []);

  if (!isReady) {
    return null;
  }

  return <RootNavigator />;
};
