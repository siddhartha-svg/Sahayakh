import React from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  ViewStyle,
  TextStyle,
  ActivityIndicator,
} from 'react-native';
import { colors, typography } from '../theme';
import { useTheme } from '../theme';

interface ButtonProps {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'ghost';
  size?: 'lg' | 'md' | 'sm';
  disabled?: boolean;
  loading?: boolean;
  style?: ViewStyle;
}

export const Button: React.FC<ButtonProps> = ({
  label,
  onPress,
  variant = 'primary',
  size = 'md',
  disabled = false,
  loading = false,
  style,
}) => {
  const { mode, colorMode } = useTheme();
  const palette = colors.light;
  const accentColor = palette.accent[mode];
  const accentSoft = palette.accentSoft[mode];

  const containerStyles: StyleSheet.NamedStyles<ViewStyle> = {
    primary: {
      backgroundColor: accentColor,
      paddingHorizontal: 16,
      paddingVertical: 12,
      borderRadius: 10,
      alignItems: 'center',
      justifyContent: 'center',
    },
    secondary: {
      backgroundColor: accentSoft,
      paddingHorizontal: 16,
      paddingVertical: 12,
      borderRadius: 10,
      alignItems: 'center',
      justifyContent: 'center',
    },
    ghost: {
      paddingHorizontal: 16,
      paddingVertical: 12,
      borderRadius: 10,
      alignItems: 'center',
      justifyContent: 'center',
    },
  };

  const textStyles: StyleSheet.NamedStyles<TextStyle> = {
    primary: {
      color: '#fff',
      fontWeight: '700',
      fontSize: 15,
    },
    secondary: {
      color: palette.accentText[mode],
      fontWeight: '700',
      fontSize: 15,
    },
    ghost: {
      color: palette.accentText[mode],
      fontWeight: '700',
      fontSize: 15,
    },
  };

  return (
    <TouchableOpacity
      style={[
        containerStyles[variant],
        disabled && { opacity: 0.5 },
        style,
      ]}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.8}
    >
      {loading ? (
        <ActivityIndicator color={variant === 'primary' ? '#fff' : palette.accentText[mode]} />
      ) : (
        <Text style={textStyles[variant]}>{label}</Text>
      )}
    </TouchableOpacity>
  );
};
