import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface User {
  id: string;
  name: string;
  phone_number: string;
  email: string;
  avatar_url?: string;
  role: 'customer' | 'helper' | 'admin';
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  setUser: (user: User | null) => void;
  setToken: (token: string | null) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>(
  persist(
    (set) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      isLoading: false,
      setUser: (user) =>
        set({
          user,
          isAuthenticated: !!user,
        }),
      setToken: (token) =>
        set({
          token,
          isAuthenticated: !!token,
        }),
      logout: () =>
        set({
          user: null,
          token: null,
          isAuthenticated: false,
        }),
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => AsyncStorage),
    },
  ),
);

// Task creation state
export interface TaskState {
  description: string;
  photos: string[];
  location: string;
  coordinates?: { latitude: number; longitude: number };
  date: string;
  time: string;
  budget: string;
  bizName: string;
  gst: boolean;
  reset: () => void;
  update: (field: string, value: any) => void;
}

export const useTaskStore = create<TaskState>((set) => ({
  description: '',
  photos: [],
  location: 'Warangal, Telangana',
  date: new Date().toISOString().split('T')[0],
  time: '10:00',
  budget: '',
  bizName: '',
  gst: false,
  reset: () =>
    set({
      description: '',
      photos: [],
      location: 'Warangal, Telangana',
      date: new Date().toISOString().split('T')[0],
      time: '10:00',
      budget: '',
      bizName: '',
      gst: false,
    }),
  update: (field, value) => set((state) => ({ ...state, [field]: value })),
}));

// Navigation stack state
export interface NavigationState {
  stack: string[];
  pushScreen: (screen: string) => void;
  popScreen: () => void;
  resetStack: (screen: string) => void;
}

export const useNavigationStore = create<NavigationState>((set) => ({
  stack: ['home'],
  pushScreen: (screen) =>
    set((state) => ({
      stack: [...state.stack, screen],
    })),
  popScreen: () =>
    set((state) => ({
      stack: state.stack.slice(0, -1),
    })),
  resetStack: (screen) => set({ stack: [screen] }),
}));
