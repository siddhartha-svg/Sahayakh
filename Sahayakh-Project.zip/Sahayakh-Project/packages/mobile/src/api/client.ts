import axios, { AxiosInstance, AxiosError } from 'axios';
import { useAuthStore } from '../store';

const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:3000/api';

class ApiClient {
  private axiosInstance: AxiosInstance;

  constructor() {
    this.axiosInstance = axios.create({
      baseURL: API_URL,
      timeout: 10000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Add interceptor to include token
    this.axiosInstance.interceptors.request.use(
      (config) => {
        const { token } = useAuthStore.getState();
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => Promise.reject(error),
    );

    // Response interceptor for handling 401
    this.axiosInstance.interceptors.response.use(
      (response) => response,
      (error: AxiosError) => {
        if (error.response?.status === 401) {
          useAuthStore.getState().logout();
        }
        return Promise.reject(error);
      },
    );
  }

  // Auth endpoints
  async sendOtp(phoneNumber: string) {
    return this.axiosInstance.post('/auth/send-otp', { phone_number: phoneNumber });
  }

  async verifyOtp(phoneNumber: string, otp: string) {
    return this.axiosInstance.post('/auth/verify-otp', { phone_number: phoneNumber, otp });
  }

  async completeProfile(data: { name: string; email: string; profile_photo?: string }) {
    return this.axiosInstance.post('/auth/complete-profile', data);
  }

  // Task endpoints
  async getTasks(status?: string) {
    return this.axiosInstance.get('/tasks', {
      params: { status },
    });
  }

  async getTask(taskId: string) {
    return this.axiosInstance.get(`/tasks/${taskId}`);
  }

  async createTask(data: any) {
    return this.axiosInstance.post('/tasks', data);
  }

  // Helper endpoints
  async getHelpers(taskId: string) {
    return this.axiosInstance.get(`/tasks/${taskId}/available-helpers`);
  }

  async getHelperProfile(helperId: string) {
    return this.axiosInstance.get(`/helpers/${helperId}`);
  }

  async acceptHelper(taskId: string, helperId: string) {
    return this.axiosInstance.post(`/tasks/${taskId}/assign`, { helper_id: helperId });
  }

  // Payment endpoints
  async initiatePayment(taskId: string, data: any) {
    return this.axiosInstance.post(`/tasks/${taskId}/payment`, data);
  }

  async getPaymentStatus(taskId: string) {
    return this.axiosInstance.get(`/tasks/${taskId}/payment`);
  }

  // Tracking endpoints
  async getTaskTracking(taskId: string) {
    return this.axiosInstance.get(`/tasks/${taskId}/tracking`);
  }

  async completeTask(taskId: string, data: any) {
    return this.axiosInstance.post(`/tasks/${taskId}/complete`, data);
  }

  // Notification endpoints
  async registerDevice(token: string, platform: string) {
    return this.axiosInstance.post('/devices/register', { token, platform });
  }

  async getNotifications() {
    return this.axiosInstance.get('/notifications');
  }

  async markNotificationAsRead(notificationId: string) {
    return this.axiosInstance.post(`/notifications/${notificationId}/read`);
  }

  // User profile endpoints
  async getProfile() {
    return this.axiosInstance.get('/users/me');
  }

  async updateProfile(data: any) {
    return this.axiosInstance.put('/users/me', data);
  }

  // Generic error handler
  static handleError(error: AxiosError) {
    const message = error.response?.data?.message || error.message || 'An error occurred';
    return {
      status: error.response?.status,
      message,
      data: error.response?.data,
    };
  }
}

export const apiClient = new ApiClient();
