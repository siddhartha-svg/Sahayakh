import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Text, StyleSheet } from 'react-native';
import { useAuthStore } from '../store';
import {
  HomeScreen,
  CreateTaskScreen,
  FindingHelpersScreen,
  HelpersScreen,
  HelperProfileScreen,
  ConfirmTaskScreen,
  TrackingScreen,
  TaskCompletedScreen,
  TaskDetailsScreen,
} from '../screens';
import { colors } from '../theme';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// Placeholder screens
const AuthScreen = () => <View><Text>Auth Screen</Text></View>;
const TasksScreen = () => <View><Text>My Tasks</Text></View>;
const SupportScreen = () => <View><Text>Support</Text></View>;
const AccountScreen = () => <View><Text>Account</Text></View>;

const palette = colors.light;

const MainTabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: palette.surface,
          borderTopColor: palette.line,
          borderTopWidth: 1,
          paddingBottom: 8,
          paddingTop: 8,
          height: 60,
        },
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '600',
        },
        tabBarActiveTintColor: palette.accent.personal,
        tabBarInactiveTintColor: palette.muted,
      }}
    >
      <Tab.Screen
        name="HomeTab"
        component={HomeScreen}
        options={{
          title: 'Home',
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20 }}>🏠</Text>,
        }}
      />
      <Tab.Screen
        name="TasksTab"
        component={TasksScreen}
        options={{
          title: 'My Tasks',
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20 }}>📋</Text>,
        }}
      />
      <Tab.Screen
        name="SupportTab"
        component={SupportScreen}
        options={{
          title: 'Support',
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20 }}>💬</Text>,
        }}
      />
      <Tab.Screen
        name="AccountTab"
        component={AccountScreen}
        options={{
          title: 'Account',
          tabBarIcon: ({ color }) => <Text style={{ fontSize: 20 }}>👤</Text>,
        }}
      />
    </Tab.Navigator>
  );
};

export const RootNavigator = () => {
  const { isAuthenticated } = useAuthStore();

  return (
    <NavigationContainer>
      {!isAuthenticated ? (
        // Auth Stack
        <Stack.Navigator
          screenOptions={{
            headerShown: false,
            animationEnabled: true,
          }}
        >
          <Stack.Screen name="Auth" component={AuthScreen} />
        </Stack.Navigator>
      ) : (
        // Main App with Tab Navigation + Stack for task flow
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          <Stack.Group>
            <Stack.Screen
              name="MainTabs"
              component={MainTabNavigator}
              options={{ animationEnabled: false }}
            />
          </Stack.Group>

          {/* Task creation flow - modal stack */}
          <Stack.Group screenOptions={{ presentation: 'card' }}>
            <Stack.Screen
              name="Create"
              component={CreateTaskScreen}
              options={{
                animationEnabled: true,
                cardStyle: { backgroundColor: 'transparent' },
              }}
            />
            <Stack.Screen
              name="Finding"
              component={FindingHelpersScreen}
              options={{ animationEnabled: true }}
            />
            <Stack.Screen
              name="Helpers"
              component={HelpersScreen}
              options={{ animationEnabled: true }}
            />
            <Stack.Screen
              name="Profile"
              component={HelperProfileScreen}
              options={{ animationEnabled: true }}
            />
            <Stack.Screen
              name="Confirm"
              component={ConfirmTaskScreen}
              options={{ animationEnabled: true }}
            />
            <Stack.Screen
              name="Tracking"
              component={TrackingScreen}
              options={{ animationEnabled: true }}
            />
            <Stack.Screen
              name="Done"
              component={TaskCompletedScreen}
              options={{ animationEnabled: true }}
            />
            <Stack.Screen
              name="Details"
              component={TaskDetailsScreen}
              options={{ animationEnabled: true }}
            />
          </Stack.Group>
        </Stack.Navigator>
      )}
    </NavigationContainer>
  );
};
