import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Share,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useTheme, colors } from '../theme';
import { Button } from '../components';
import { useTaskStore } from '../store';

export const HelperProfileScreen: React.FC<{ navigation: any; route: any }> = ({
  navigation,
  route,
}) => {
  const { helper, taskId } = route.params;
  const { mode } = useTheme();
  const palette = colors.light;
  const accentColor = palette.accent[mode];
  const accentSoft = palette.accentSoft[mode];

  const handleSelectHelper = () => {
    // Store selected helper for confirm screen
    useTaskStore.setState({ selectedHelper: helper });
    navigation.navigate('Confirm', { helper, taskId });
  };

  const handleShare = async () => {
    try {
      await Share.share({
        message: `Check out ${helper.name} on Sahayakh - rated ${helper.rating}⭐`,
        title: 'Share Helper Profile',
      });
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: palette.surface }]}>
      {/* Top Buttons */}
      <View style={styles.topButtons}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={[styles.topButton, { color: palette.ink }]}>←</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={handleShare}>
          <Text style={[styles.topButton, { color: palette.ink }]}>Share</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Hero Section with Avatar */}
        <LinearGradient
          colors={[helper.look?.bg || accentSoft, palette.surface]}
          start={{ x: 0.5, y: 0 }}
          end={{ x: 0.5, y: 1 }}
          style={styles.heroSection}
        >
          <View style={styles.avatarContainer}>
            <View
              style={[
                styles.largeAvatar,
                {
                  backgroundColor: helper.look?.bg || accentSoft,
                },
              ]}
            >
              <Text style={styles.largeAvatarText}>👤</Text>
            </View>
            <View style={[styles.onlineBadge, { backgroundColor: palette.surface }]}>
              <Text style={{ color: '#22C55E', fontSize: 10 }}>● Online</Text>
            </View>
          </View>
        </LinearGradient>

        {/* Info Card */}
        <View style={[styles.infoCard, { backgroundColor: palette.surface }]}>
          <Text style={[styles.helperName, { color: palette.ink }]}>{helper.name}</Text>
          <View style={styles.ratingRow}>
            <Text>⭐</Text>
            <Text style={[styles.rating, { color: palette.ink }]}>
              {helper.rating}{' '}
              <Text style={[{ color: palette.muted, fontWeight: '500' }]}>
                ({helper.tasks} tasks)
              </Text>
            </Text>
          </View>
          <Text style={[styles.role, { color: palette.muted }]}>{helper.role}</Text>

          {/* Stats Grid */}
          <View style={[styles.statsGrid, { borderColor: palette.line }]}>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: palette.ink }]}>{helper.tasks}</Text>
              <Text style={[styles.statLabel, { color: palette.muted }]}>Tasks</Text>
            </View>
            <View
              style={[styles.statDivider, { backgroundColor: palette.line }]}
            />
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: palette.ink }]}>
                {helper.resp || 5} min
              </Text>
              <Text style={[styles.statLabel, { color: palette.muted }]}>Avg Response</Text>
            </View>
            <View
              style={[styles.statDivider, { backgroundColor: palette.line }]}
            />
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: palette.ink }]}>{helper.km} km</Text>
              <Text style={[styles.statLabel, { color: palette.muted }]}>Away</Text>
            </View>
          </View>

          {/* Badges */}
          <View style={styles.badges}>
            <View style={[styles.badge, { backgroundColor: accentSoft }]}>
              <Text style={[styles.badgeText, { color: accentColor }]}>✓ Verified Identity</Text>
            </View>
            <View style={[styles.badge, { backgroundColor: accentSoft }]}>
              <Text style={[styles.badgeText, { color: accentColor }]}>🛡️ Background Checked</Text>
            </View>
            <View style={[styles.badge, { backgroundColor: accentSoft }]}>
              <Text style={[styles.badgeText, { color: accentColor }]}>🎖️ Trained & Trusted</Text>
            </View>
          </View>

          {/* About */}
          <View>
            <Text style={[styles.sectionTitle, { color: palette.ink }]}>About</Text>
            <Text style={[styles.about, { color: palette.muted }]}>{helper.about}</Text>
          </View>

          {/* Skills */}
          <View>
            <Text style={[styles.sectionTitle, { color: palette.ink }]}>Skills</Text>
            <View style={styles.skillsList}>
              {helper.skills?.map((skill: string, i: number) => (
                <View key={i} style={[styles.skillTag, { borderColor: palette.line }]}>
                  <Text style={[styles.skillTagText, { color: palette.muted }]}>
                    {skill}
                  </Text>
                </View>
              ))}
            </View>
          </View>

          {/* Recent Review */}
          <View>
            <View style={styles.sectionHeader}>
              <Text style={[styles.sectionTitle, { color: palette.ink }]}>Recent Reviews</Text>
              <TouchableOpacity>
                <Text style={[styles.seeAllLink, { color: accentColor }]}>See All</Text>
              </TouchableOpacity>
            </View>

            {helper.rev && (
              <View style={styles.reviewItem}>
                <View
                  style={[
                    styles.reviewInitial,
                    { backgroundColor: accentSoft, borderColor: palette.line },
                  ]}
                >
                  <Text style={[styles.initialText, { color: accentColor }]}>
                    {helper.rev.who?.charAt(0) || 'A'}
                  </Text>
                </View>
                <View style={styles.reviewContent}>
                  <View style={styles.reviewHeader}>
                    <Text style={[styles.reviewerName, { color: palette.ink }]}>
                      {helper.rev.who}
                    </Text>
                    <Text style={[styles.reviewDate, { color: palette.muted }]}>
                      {helper.rev.date}
                    </Text>
                  </View>
                  <View style={styles.reviewRating}>
                    <Text>⭐</Text>
                    <Text style={[styles.reviewScore, { color: palette.ink }]}>
                      {helper.rev.rate}
                    </Text>
                  </View>
                  <Text style={[styles.reviewText, { color: palette.muted }]}>
                    "{helper.rev.text}"
                  </Text>
                </View>
              </View>
            )}
          </View>
        </View>
      </ScrollView>

      {/* Footer Button */}
      <View style={styles.footer}>
        <Button
          label="Select Helper"
          onPress={handleSelectHelper}
        />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  topButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 12,
  },
  topButton: {
    fontSize: 16,
    fontWeight: '700',
  },
  content: {
    paddingBottom: 80,
  },
  heroSection: {
    height: 250,
    justifyContent: 'flex-end',
    alignItems: 'center',
    paddingBottom: 30,
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: 20,
  },
  largeAvatar: {
    width: 250,
    height: 250,
    borderRadius: 125,
    justifyContent: 'center',
    alignItems: 'center',
  },
  largeAvatarText: {
    fontSize: 120,
  },
  onlineBadge: {
    position: 'absolute',
    bottom: 30,
    right: 20,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
  },
  infoCard: {
    marginHorizontal: 18,
    marginTop: -30,
    borderRadius: 24,
    padding: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  helperName: {
    fontSize: 23,
    fontWeight: '800',
    marginBottom: 6,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    marginBottom: 4,
  },
  rating: {
    fontSize: 15,
    fontWeight: '600',
  },
  role: {
    fontSize: 14,
    marginBottom: 14,
  },
  statsGrid: {
    flexDirection: 'row',
    borderWidth: 1,
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 14,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
  },
  statValue: {
    fontSize: 17,
    fontWeight: '800',
  },
  statLabel: {
    fontSize: 11,
    marginTop: 2,
  },
  statDivider: {
    width: 1,
  },
  badges: {
    gap: 8,
    marginBottom: 16,
  },
  badge: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
  },
  badgeText: {
    fontSize: 12,
    fontWeight: '700',
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 10,
    marginTop: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
    marginTop: 16,
  },
  seeAllLink: {
    fontSize: 12.5,
    fontWeight: '700',
  },
  about: {
    fontSize: 13.5,
    lineHeight: 20,
  },
  skillsList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  skillTag: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 11,
    paddingVertical: 7,
  },
  skillTagText: {
    fontSize: 12.5,
    fontWeight: '600',
  },
  reviewItem: {
    flexDirection: 'row',
    gap: 10,
    paddingVertical: 10,
  },
  reviewInitial: {
    width: 38,
    height: 38,
    borderRadius: 19,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    flexShrink: 0,
  },
  initialText: {
    fontSize: 15,
    fontWeight: '800',
  },
  reviewContent: {
    flex: 1,
  },
  reviewHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  reviewerName: {
    fontSize: 13.5,
    fontWeight: '700',
  },
  reviewDate: {
    fontSize: 11.5,
  },
  reviewRating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    marginBottom: 6,
  },
  reviewScore: {
    fontSize: 13,
    fontWeight: '700',
  },
  reviewText: {
    fontSize: 13,
    fontStyle: 'italic',
    lineHeight: 18,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 18,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: 'rgba(0,0,0,0.05)',
  },
});
