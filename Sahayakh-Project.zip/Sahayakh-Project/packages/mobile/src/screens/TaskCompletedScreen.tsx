import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useTheme, colors } from '../theme';
import { Button } from '../components';
import { apiClient } from '../api/client';

interface Helper {
  id: string;
  name: string;
  rating: number;
  look: any;
}

export const TaskCompletedScreen: React.FC<{ navigation: any; route: any }> = ({
  navigation,
  route,
}) => {
  const { taskId, helper } = route.params || {};
  const { mode } = useTheme();
  const palette = colors.light;
  const accentColor = palette.accent[mode];
  const accentSoft = palette.accentSoft[mode];

  const [rating, setRating] = useState(0);
  const [reviewText, setReviewText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [hasRated, setHasRated] = useState(false);

  // Demo helper
  const currentHelper: Helper = helper || {
    id: 'h1',
    name: 'Rohit Kumar',
    rating: 4.8,
    look: { bg: '#CDE7D6' },
  };

  // Burst animation colors
  const burstColors = ['#1B7A3E', '#F2A20C', '#2F6FEB', '#C0392B', '#7C5CE0', '#1B7A3E', '#F2A20C', '#2F6FEB'];

  const handleSubmitRating = async () => {
    if (rating === 0) {
      Alert.alert('Please rate', 'Please give a rating before submitting');
      return;
    }

    setSubmitting(true);
    try {
      // In production: await apiClient.submitReview(taskId, { rating, review_text: reviewText });
      // For demo, simulate the API call
      await new Promise((resolve) => setTimeout(resolve, 1200));

      setHasRated(true);
      setSubmitting(false);
    } catch (error) {
      Alert.alert('Error', 'Failed to submit rating. Please try again.');
      setSubmitting(false);
    }
  };

  const handleClose = () => {
    navigation.navigate('HomeTab');
  };

  if (hasRated) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: palette.surface }]}>
        <View style={styles.header}>
          <TouchableOpacity onPress={handleClose}>
            <Text style={[styles.closeButton, { color: palette.ink }]}>✕</Text>
          </TouchableOpacity>
          <Text style={[styles.headerTitle, { color: palette.ink }]}></Text>
          <View style={{ width: 24 }} />
        </View>

        <ScrollView contentContainerStyle={styles.successContent}>
          {/* Success Animation (Burst) */}
          <View style={styles.burstContainer}>
            <View style={[styles.checkmark, { backgroundColor: accentColor }]}>
              <Text style={styles.checkmarkIcon}>✓</Text>
            </View>
          </View>

          <Text style={[styles.successTitle, { color: palette.ink }]}>
            Thank you for your review!
          </Text>
          <Text style={[styles.successMessage, { color: palette.muted }]}>
            Your rating will help us improve our services.
          </Text>

          <View style={[styles.ratingDisplay, { backgroundColor: accentSoft }]}>
            <Text style={[styles.ratingDisplayValue, { color: accentColor }]}>
              {rating} ⭐
            </Text>
            <Text style={[styles.ratingDisplayLabel, { color: palette.muted }]}>
              Rating submitted
            </Text>
          </View>

          {reviewText && (
            <View style={[styles.reviewDisplay, { backgroundColor: palette.surface2 }]}>
              <Text style={[styles.reviewDisplayLabel, { color: palette.muted }]}>
                Your comment:
              </Text>
              <Text style={[styles.reviewDisplayText, { color: palette.ink }]}>
                "{reviewText}"
              </Text>
            </View>
          )}

          <View style={styles.successButtonGroup}>
            <Button
              label="Back to Home"
              onPress={handleClose}
            />
            <TouchableOpacity
              onPress={() => navigation.navigate('Details', { taskId })}
              style={[styles.detailsButton, { borderColor: accentColor }]}
            >
              <Text style={[styles.detailsButtonText, { color: accentColor }]}>
                View Task Details
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: palette.surface }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={handleClose}>
          <Text style={[styles.closeButton, { color: palette.ink }]}>✕</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: palette.ink }]}></Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Hero Section */}
        <View style={styles.heroSection}>
          <View style={[styles.burst, { backgroundColor: accentColor }]}>
            <Text style={styles.burstIcon}>🎉</Text>
          </View>
          <Text style={[styles.title, { color: palette.ink }]}>Task Completed!</Text>
          <Text style={[styles.subtitle, { color: palette.muted }]}>
            Thank you for trusting Sahayakh.
          </Text>
        </View>

        {/* Stats */}
        <View style={[styles.statsGrid, { borderColor: palette.line }]}>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: palette.ink }]}>₹275</Text>
            <Text style={[styles.statLabel, { color: palette.muted }]}>Amount Paid</Text>
          </View>
          <View style={[styles.statDivider, { backgroundColor: palette.line }]} />
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: palette.ink }]}>35 min</Text>
            <Text style={[styles.statLabel, { color: palette.muted }]}>Duration</Text>
          </View>
          <View style={[styles.statDivider, { backgroundColor: palette.line }]} />
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: palette.ink }]}>4.8 km</Text>
            <Text style={[styles.statLabel, { color: palette.muted }]}>Distance</Text>
          </View>
        </View>

        {/* Helper Info */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: palette.ink }]}>Rate Your Helper</Text>
          <View style={[styles.helperCard, { backgroundColor: palette.surface2 }]}>
            <View style={styles.helperRow}>
              <View
                style={[
                  styles.helperAvatar,
                  { backgroundColor: currentHelper.look?.bg },
                ]}
              >
                <Text style={styles.helperAvatarText}>👤</Text>
              </View>
              <View>
                <Text style={[styles.helperName, { color: palette.ink }]}>
                  {currentHelper.name}
                </Text>
                <Text style={[styles.helperInfo, { color: palette.muted }]}>
                  Service Rating: {currentHelper.rating}⭐
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* Rating Stars */}
        <View style={styles.section}>
          <View style={styles.starsContainer}>
            {[1, 2, 3, 4, 5].map((star) => (
              <TouchableOpacity
                key={star}
                onPress={() => setRating(star)}
                style={styles.starButton}
              >
                <Text style={[styles.star, { color: star <= rating ? '#FFB800' : palette.line }]}>
                  ★
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Review Text */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: palette.ink }]}>
            Add a comment <Text style={[{ color: palette.muted }]}>(optional)</Text>
          </Text>
          <TextInput
            style={[
              styles.reviewInput,
              { borderColor: palette.line, color: palette.ink },
            ]}
            placeholder="Tell others about your experience with this helper..."
            placeholderTextColor={palette.muted}
            multiline
            numberOfLines={4}
            value={reviewText}
            onChangeText={setReviewText}
            editable={!submitting}
          />
          <Text style={[styles.charCount, { color: palette.muted }]}>
            {reviewText.length}/500
          </Text>
        </View>

        {/* Submit Button */}
        <View style={styles.section}>
          <Button
            label={submitting ? 'Submitting...' : 'Submit Review'}
            onPress={handleSubmitRating}
            loading={submitting}
            disabled={submitting || rating === 0}
          />
        </View>

        {/* Help Section */}
        <TouchableOpacity onPress={() => { /* Help */ }}>
          <Text style={[styles.helpLink, { color: accentColor }]}>Need help?</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 12,
  },
  closeButton: {
    fontSize: 24,
    fontWeight: '600',
    width: 24,
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '700',
  },
  content: {
    padding: 18,
    gap: 20,
  },
  successContent: {
    padding: 18,
    alignItems: 'center',
    gap: 20,
  },
  heroSection: {
    alignItems: 'center',
    marginBottom: 20,
  },
  burst: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  burstIcon: {
    fontSize: 50,
  },
  burstContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  checkmark: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkmarkIcon: {
    fontSize: 44,
    color: '#fff',
    fontWeight: '700',
  },
  title: {
    fontSize: 26,
    fontWeight: '800',
    marginBottom: 8,
    textAlign: 'center',
  },
  successTitle: {
    fontSize: 20,
    fontWeight: '700',
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 13.5,
    lineHeight: 20,
    textAlign: 'center',
  },
  successMessage: {
    fontSize: 13.5,
    lineHeight: 20,
    textAlign: 'center',
  },
  statsGrid: {
    flexDirection: 'row',
    borderWidth: 1,
    borderRadius: 14,
    overflow: 'hidden',
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
  },
  statValue: {
    fontSize: 17,
    fontWeight: '800',
  },
  statLabel: {
    fontSize: 11,
    marginTop: 2,
  },
  statDivider: {
    width: 1,
  },
  section: {
    gap: 12,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: '800',
  },
  helperCard: {
    borderRadius: 14,
    padding: 12,
  },
  helperRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  helperAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  helperAvatarText: {
    fontSize: 26,
  },
  helperName: {
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 2,
  },
  helperInfo: {
    fontSize: 12,
  },
  starsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 12,
  },
  starButton: {
    padding: 6,
  },
  star: {
    fontSize: 32,
  },
  reviewInput: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 13.5,
    textAlignVertical: 'top',
    lineHeight: 20,
  },
  charCount: {
    fontSize: 11,
    textAlign: 'right',
    marginTop: 4,
  },
  helpLink: {
    textAlign: 'center',
    fontSize: 12.5,
    fontWeight: '700',
    marginBottom: 20,
  },
  ratingDisplay: {
    borderRadius: 14,
    padding: 20,
    alignItems: 'center',
    gap: 8,
    width: '100%',
  },
  ratingDisplayValue: {
    fontSize: 28,
    fontWeight: '800',
  },
  ratingDisplayLabel: {
    fontSize: 12.5,
  },
  reviewDisplay: {
    borderRadius: 14,
    padding: 14,
    width: '100%',
  },
  reviewDisplayLabel: {
    fontSize: 12,
    marginBottom: 8,
  },
  reviewDisplayText: {
    fontSize: 13.5,
    fontStyle: 'italic',
    lineHeight: 20,
  },
  successButtonGroup: {
    width: '100%',
    gap: 12,
  },
  detailsButton: {
    borderWidth: 1.5,
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: 'center',
  },
  detailsButtonText: {
    fontSize: 13,
    fontWeight: '700',
  },
});
