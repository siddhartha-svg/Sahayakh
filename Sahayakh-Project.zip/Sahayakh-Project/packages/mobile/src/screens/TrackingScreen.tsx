import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Animated,
  Dimensions,
} from 'react-native';
import { useTheme, colors } from '../theme';
import { Button } from '../components';

type TrackingStage = 'track1' | 'otp' | 'track2';

interface TaskRun {
  stage: TrackingStage;
  eta: number;
  etaStart: number;
  elapsed: number;
  startAt: Date;
  otp: string;
}

interface Helper {
  id: string;
  name: string;
  rating: number;
  look: any;
  km: number;
  resp?: number;
}

export const TrackingScreen: React.FC<{ navigation: any; route: any }> = ({
  navigation,
  route,
}) => {
  const { taskId, helper } = route.params || {};
  const { mode } = useTheme();
  const palette = colors.light;
  const accentColor = palette.accent[mode];
  const accentSoft = palette.accentSoft[mode];

  const [stage, setStage] = useState<TrackingStage>('track1');
  const [eta, setEta] = useState(8);
  const [elapsed, setElapsed] = useState(0);
  const [showOTP, setShowOTP] = useState(false);
  const [otpInput, setOtpInput] = useState('');
  const [verifying, setVerifying] = useState(false);

  // Demo helper
  const currentHelper: Helper = helper || {
    id: 'h1',
    name: 'Rohit Kumar',
    rating: 4.8,
    km: 1.2,
    resp: 4,
    look: { bg: '#CDE7D6' },
  };

  // Simulate tracking
  useEffect(() => {
    if (stage === 'track1' && eta > 0) {
      const timer = setInterval(() => {
        setEta((prev) => {
          if (prev <= 1) {
            // Auto-transition to OTP screen
            setStage('otp');
            setShowOTP(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [stage, eta]);

  // Simulate progress after OTP verified
  useEffect(() => {
    if (stage === 'track2' && elapsed < 37) {
      const timer = setInterval(() => {
        setElapsed((prev) => {
          if (prev >= 36) {
            // Task completed
            setTimeout(() => {
              navigation.navigate('Done', { taskId, helper: currentHelper });
            }, 500);
            return 37;
          }
          return prev + 3;
        });
      }, 900);
      return () => clearInterval(timer);
    }
  }, [stage, elapsed, navigation, currentHelper]);

  const handleVerifyOTP = async () => {
    if (otpInput.length !== 4) {
      return;
    }

    setVerifying(true);
    try {
      // Simulate OTP verification API call
      // In production: await apiClient.verifyOTP(taskId, otpInput);

      // Simulate delay
      await new Promise((resolve) => setTimeout(resolve, 800));

      // Success - transition to track2
      setStage('track2');
      setShowOTP(false);
      setVerifying(false);
    } catch (error) {
      setVerifying(false);
      setOtpInput('');
    }
  };

  const handleSkipDemo = () => {
    if (stage === 'track1') {
      setEta(0);
      setStage('otp');
      setShowOTP(true);
    } else if (stage === 'track2') {
      setElapsed(37);
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: palette.surface }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={[styles.headerBackButton, { color: palette.ink }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: palette.ink }]}>
          {stage === 'track1' ? 'Task in Progress' : stage === 'otp' ? 'Helper has reached' : 'Task in Progress'}
        </Text>
        <TouchableOpacity onPress={() => { /* Help action */ }}>
          <Text style={[styles.headerButton, { color: accentColor }]}>Help</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Status Steps */}
        {stage !== 'otp' && <StatusSteps stage={stage} palette={palette} accentColor={accentColor} />}

        {/* Status Card */}
        <View style={[styles.statusCard, { backgroundColor: accentSoft }]}>
          <Text style={[styles.statusIcon, { fontSize: 24 }]}>🚗</Text>
          {stage === 'track1' && (
            <View style={{ flex: 1 }}>
              <Text style={[styles.statusTitle, { color: accentColor }]}>Helper is on the way</Text>
              <Text style={[styles.statusSubtitle, { color: accentColor }]}>
                Arriving in {eta} mins
              </Text>
            </View>
          )}
          {stage === 'track2' && (
            <View style={{ flex: 1 }}>
              <Text style={[styles.statusTitle, { color: accentColor }]}>Task is in progress</Text>
              <Text style={[styles.statusSubtitle, { color: accentColor }]}>
                Started at {new Date().toLocaleTimeString()}
              </Text>
            </View>
          )}
        </View>

        {/* OTP Screen */}
        {stage === 'otp' && showOTP && (
          <OTPSection
            otpInput={otpInput}
            setOtpInput={setOtpInput}
            verifying={verifying}
            onVerify={handleVerifyOTP}
            accentColor={accentColor}
            palette={palette}
          />
        )}

        {/* Map placeholder */}
        {stage !== 'otp' && (
          <View style={[styles.mapPlaceholder, { backgroundColor: palette.surface2 }]}>
            <Text style={[styles.mapText, { color: palette.muted }]}>📍 Live Map</Text>
            <Text style={[styles.mapSubtext, { color: palette.muted }]}>
              {stage === 'track1'
                ? `${currentHelper.name} is ${currentHelper.km} km away`
                : `Distance covered: ${(currentHelper.km * elapsed / 37).toFixed(1)} km`}
            </Text>
          </View>
        )}

        {/* Helper Info */}
        {stage !== 'otp' && (
          <View style={[styles.panel, { backgroundColor: palette.surface }]}>
            <HelperRow helper={currentHelper} subtitle={stage === 'track1' ? 'On the way to your location' : 'Working on your task'} />
            <ContactButtons accentColor={accentColor} palette={palette} />
            {stage === 'track1' && (
              <View style={[styles.liveNote, { backgroundColor: palette.surface2, borderColor: palette.line }]}>
                <Text style={[styles.liveIcon, { color: accentColor }]}>📍</Text>
                <Text style={[styles.liveText, { color: palette.muted }]}>
                  Live location enabled. OTP will be shared on arrival.
                </Text>
              </View>
            )}
            {stage === 'track2' && (
              <View style={styles.metricsContainer}>
                <MetricBox
                  icon="⏱️"
                  label="Time elapsed"
                  value={`${Math.floor(elapsed)} min`}
                  accentColor={accentColor}
                  palette={palette}
                />
                <MetricBox
                  icon="📍"
                  label="Distance covered"
                  value={`${(currentHelper.km * elapsed / 37).toFixed(1)} km`}
                  accentColor={accentColor}
                  palette={palette}
                />
              </View>
            )}
            {stage === 'track2' && (
              <View style={[styles.statusBox, { backgroundColor: palette.surface2 }]}>
                <Text style={[styles.statusIcon2, { color: accentColor }]}>ℹ️</Text>
                <View>
                  <Text style={[styles.statusLabel, { color: palette.muted }]}>Current status</Text>
                  <Text style={[styles.statusValue, { color: palette.ink }]}>
                    {elapsed < 14 ? 'At task location' : elapsed < 30 ? 'Working on task' : 'Wrapping up'}
                  </Text>
                </View>
              </View>
            )}
            <TouchableOpacity
              onPress={handleSkipDemo}
              style={[styles.demoButton, { backgroundColor: palette.surface2 }]}
            >
              <Text style={[styles.demoButtonText, { color: palette.muted }]}>
                {stage === 'track1' ? 'Skip to OTP (demo)' : 'Skip to completion (demo)'}
              </Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

// Status Steps Component
const StatusSteps = ({
  stage,
  palette,
  accentColor,
}: {
  stage: TrackingStage;
  palette: any;
  accentColor: string;
}) => {
  const steps = ['Assigned', 'On the way', 'Reached', 'In progress', 'Completed'];
  const currentIndex = stage === 'track1' ? 1 : 3;

  return (
    <View style={styles.stepsContainer}>
      {steps.map((label, i) => {
        const isDone = i < currentIndex;
        const isCurrent = i === currentIndex;

        return (
          <View key={i} style={styles.stepRow}>
            <View
              style={[
                styles.stepIcon,
                {
                  backgroundColor: isDone ? accentColor : palette.surface,
                  borderColor: isDone ? accentColor : palette.line,
                },
              ]}
            >
              {isDone ? (
                <Text style={{ color: '#fff', fontWeight: '700' }}>✓</Text>
              ) : isCurrent ? (
                <Text style={{ color: accentColor, fontWeight: '700' }}>◉</Text>
              ) : null}
            </View>
            {i < steps.length - 1 && (
              <View
                style={[
                  styles.stepLine,
                  {
                    backgroundColor: isDone || isCurrent ? accentColor : palette.line,
                  },
                ]}
              />
            )}
            <Text
              style={[
                styles.stepLabel,
                {
                  color: isDone || isCurrent ? palette.ink : palette.muted,
                },
              ]}
            >
              {label}
            </Text>
          </View>
        );
      })}
    </View>
  );
};

// OTP Section Component
const OTPSection = ({
  otpInput,
  setOtpInput,
  verifying,
  onVerify,
  accentColor,
  palette,
}: any) => {
  const otpDigits = otpInput.padEnd(4, ' ').split('');

  return (
    <View style={styles.otpContainer}>
      <Text style={[styles.otpTitle, { color: palette.ink }]}>
        Please share this OTP with the helper
      </Text>

      {/* OTP Display */}
      <View style={styles.otpDisplay}>
        {otpDigits.map((digit, i) => (
          <View
            key={i}
            style={[
              styles.otpDigit,
              {
                borderColor: digit !== ' ' ? accentColor : palette.line,
                backgroundColor: palette.surface,
              },
            ]}
          >
            <Text style={[styles.otpDigitText, { color: palette.ink }]}>
              {digit === ' ' ? '' : digit}
            </Text>
          </View>
        ))}
      </View>

      {/* Security Message */}
      <View style={[styles.securityBox, { backgroundColor: palette.surface2 }]}>
        <Text style={[styles.securityIcon, { color: accentColor }]}>🔒</Text>
        <Text style={[styles.securityText, { color: palette.muted }]}>
          Once OTP is verified, actual time and distance calculation will begin.
        </Text>
      </View>

      {/* Warning */}
      <View style={[styles.warningBox, { backgroundColor: '#FFFBEB' }]}>
        <Text style={[styles.warningIcon, { color: '#F59E0B' }]}>⚠️</Text>
        <Text style={[styles.warningText, { color: '#92400E' }]}>
          <Text style={{ fontWeight: '700' }}>For your safety: </Text>
          Share the OTP only when the helper is physically at the location.
        </Text>
      </View>

      {/* Helper Enters OTP */}
      <TouchableOpacity
        onPress={onVerify}
        disabled={otpInput.length !== 4 || verifying}
        style={[
          styles.otpButton,
          {
            backgroundColor:
              otpInput.length === 4 ? accentColor : palette.surface2,
            opacity: otpInput.length === 4 ? 1 : 0.5,
          },
        ]}
      >
        <Text
          style={[
            styles.otpButtonText,
            {
              color: otpInput.length === 4 ? '#fff' : palette.muted,
            },
          ]}
        >
          {verifying ? 'Verifying...' : 'Helper Enters OTP (Demo)'}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => { /* Help */ }}>
        <Text style={[styles.helpLink, { color: accentColor }]}>Need help?</Text>
      </TouchableOpacity>
    </View>
  );
};

// Helper Row Component
const HelperRow = ({
  helper,
  subtitle,
}: {
  helper: Helper;
  subtitle: string;
}) => {
  return (
    <View style={styles.helperRow}>
      <View style={[styles.helperAvatar, { backgroundColor: helper.look?.bg }]}>
        <Text style={styles.helperAvatarText}>👤</Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.helperName}>{helper.name}</Text>
        <Text style={styles.helperRating}>⭐ {helper.rating}</Text>
        <Text style={styles.helperSubtitle}>{subtitle}</Text>
      </View>
    </View>
  );
};

// Contact Buttons Component
const ContactButtons = ({ accentColor, palette }: any) => {
  return (
    <View style={styles.contactButtons}>
      <TouchableOpacity style={[styles.contactButton, { borderColor: palette.line }]}>
        <Text style={[styles.contactButtonIcon, { color: accentColor }]}>☎️</Text>
        <Text style={[styles.contactButtonText, { color: palette.ink }]}>Call</Text>
      </TouchableOpacity>
      <TouchableOpacity style={[styles.contactButton, { borderColor: palette.line }]}>
        <Text style={[styles.contactButtonIcon, { color: accentColor }]}>💬</Text>
        <Text style={[styles.contactButtonText, { color: palette.ink }]}>Chat</Text>
      </TouchableOpacity>
    </View>
  );
};

// Metric Box Component
const MetricBox = ({
  icon,
  label,
  value,
  accentColor,
  palette,
}: any) => {
  return (
    <View style={{ flex: 1, gap: 6 }}>
      <Text style={{ fontSize: 18 }}>{icon}</Text>
      <Text style={[{ fontSize: 12, color: palette.muted }]}>{label}</Text>
      <Text style={[{ fontSize: 15, fontWeight: '700', color: palette.ink }]}>
        {value}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.05)',
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '700',
  },
  headerBackButton: {
    fontSize: 24,
    fontWeight: '600',
    width: 24,
  },
  headerButton: {
    fontSize: 14,
    fontWeight: '700',
    width: 50,
    textAlign: 'right',
  },
  content: {
    padding: 18,
    gap: 16,
  },
  stepsContainer: {
    gap: 12,
  },
  stepRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  stepIcon: {
    width: 28,
    height: 28,
    borderRadius: 14,
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    flexShrink: 0,
  },
  stepLine: {
    width: 2,
    height: 24,
    marginRight: 12,
  },
  stepLabel: {
    fontSize: 12.5,
    fontWeight: '600',
    flex: 1,
  },
  statusCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderRadius: 16,
    padding: 12,
  },
  statusIcon: {
    fontSize: 20,
  },
  statusTitle: {
    fontSize: 15,
    fontWeight: '700',
  },
  statusSubtitle: {
    fontSize: 12.5,
    fontWeight: '500',
    marginTop: 2,
  },
  mapPlaceholder: {
    height: 150,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 4,
  },
  mapText: {
    fontSize: 14,
    fontWeight: '700',
  },
  mapSubtext: {
    fontSize: 12,
  },
  panel: {
    borderRadius: 22,
    padding: 14,
    gap: 12,
  },
  helperRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  helperAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  helperAvatarText: {
    fontSize: 22,
  },
  helperName: {
    fontSize: 14,
    fontWeight: '700',
  },
  helperRating: {
    fontSize: 12,
    fontWeight: '600',
  },
  helperSubtitle: {
    fontSize: 12,
  },
  contactButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  contactButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1,
    borderRadius: 10,
    paddingVertical: 10,
  },
  contactButtonIcon: {
    fontSize: 16,
  },
  contactButtonText: {
    fontSize: 13,
    fontWeight: '700',
  },
  liveNote: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 9,
  },
  liveIcon: {
    fontSize: 15,
  },
  liveText: {
    fontSize: 12,
    flex: 1,
  },
  metricsContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  statusBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  statusIcon2: {
    fontSize: 18,
  },
  statusLabel: {
    fontSize: 12,
  },
  statusValue: {
    fontSize: 13,
    fontWeight: '700',
    marginTop: 2,
  },
  demoButton: {
    borderRadius: 10,
    paddingVertical: 10,
    alignItems: 'center',
  },
  demoButtonText: {
    fontSize: 12,
    fontWeight: '600',
  },
  otpContainer: {
    gap: 16,
  },
  otpTitle: {
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
    marginTop: 20,
  },
  otpDisplay: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 12,
  },
  otpDigit: {
    width: 44,
    height: 56,
    borderWidth: 1.5,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  otpDigitText: {
    fontSize: 24,
    fontWeight: '700',
  },
  securityBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  securityIcon: {
    fontSize: 18,
  },
  securityText: {
    fontSize: 12.5,
    flex: 1,
  },
  warningBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 12,
  },
  warningIcon: {
    fontSize: 18,
  },
  warningText: {
    fontSize: 12.5,
    flex: 1,
    lineHeight: 18,
  },
  otpButton: {
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: 'center',
    marginTop: 8,
  },
  otpButtonText: {
    fontSize: 13,
    fontWeight: '700',
  },
  helpLink: {
    textAlign: 'center',
    fontSize: 12.5,
    fontWeight: '700',
    marginTop: 12,
  },
});
