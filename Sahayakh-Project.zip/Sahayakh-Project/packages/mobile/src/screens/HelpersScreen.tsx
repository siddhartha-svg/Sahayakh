import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  FlatList,
  TouchableOpacity,
  Image,
  Picker,
  Platform,
} from 'react-native';
import { useTheme, colors } from '../theme';

type SortOption = 'nearest' | 'rating' | 'price';

interface Helper {
  id: string;
  name: string;
  rating: number;
  tasks: string;
  role: string;
  km: number;
  eta: number;
  range: [number, number];
  final: number;
  look: any;
  skills: string[];
  about: string;
  rev: any;
}

export const HelpersScreen: React.FC<{ navigation: any; route: any }> = ({
  navigation,
  route,
}) => {
  const { taskId, helpers: initialHelpers } = route.params;
  const { mode } = useTheme();
  const palette = colors.light;
  const accentColor = palette.accent[mode];
  const accentSoft = palette.accentSoft[mode];

  const [sortBy, setSortBy] = useState<SortOption>('nearest');
  const [taskLocation] = useState('Warangal, Telangana'); // From task data

  // Sort helpers
  const sortedHelpers = useMemo(() => {
    const sorted = [...initialHelpers];
    if (sortBy === 'rating') {
      sorted.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    } else if (sortBy === 'price') {
      sorted.sort((a, b) => (a.range?.[0] || 0) - (b.range?.[0] || 0));
    } else {
      sorted.sort((a, b) => (a.km || 0) - (b.km || 0));
    }
    return sorted;
  }, [initialHelpers, sortBy]);

  const handleSelectHelper = (helper: Helper) => {
    // Navigate to helper profile with full data
    navigation.navigate('Profile', { helper, taskId });
  };

  const renderHelperCard = ({ item: helper }: { item: Helper }) => (
    <TouchableOpacity
      style={[styles.card, { borderColor: palette.line }]}
      onPress={() => handleSelectHelper(helper)}
      activeOpacity={0.7}
    >
      {/* Avatar and Info */}
      <View style={styles.cardTop}>
        <View style={styles.avatarWrapper}>
          {/* Avatar placeholder - would be actual image */}
          <View
            style={[
              styles.avatar,
              {
                backgroundColor: helper.look?.bg || accentSoft,
              },
            ]}
          >
            <Text style={styles.avatarText}>👤</Text>
          </View>
          <View style={[styles.onlineBadge, { backgroundColor: '#22C55E' }]} />
        </View>

        <View style={styles.helperInfo}>
          <Text style={[styles.helperName, { color: palette.ink }]}>{helper.name}</Text>
          <View style={styles.ratingRow}>
            <Text style={{ fontSize: 11 }}>⭐</Text>
            <Text style={[styles.rating, { color: palette.ink }]}>
              {helper.rating} <Text style={[{ color: palette.muted }]}>({helper.tasks})</Text>
            </Text>
          </View>
          <Text style={[styles.role, { color: palette.muted }]}>{helper.role}</Text>
          <View style={styles.metaRow}>
            <Text style={[styles.meta, { color: palette.muted }]}>
              📍 {helper.km} km away • ETA: {helper.eta} mins
            </Text>
          </View>
          <Text style={[styles.price, { color: palette.ink }]}>
            Estimated: ₹{helper.range?.[0]?.toLocaleString()} - ₹{helper.range?.[1]?.toLocaleString()}
          </Text>
        </View>
      </View>

      {/* Badges and Button */}
      <View style={styles.cardBottom}>
        <View style={styles.badges}>
          <View style={[styles.badge, { backgroundColor: accentSoft }]}>
            <Text style={[styles.badgeText, { color: accentColor }]}>✓ Verified</Text>
          </View>
          <View style={[styles.badge, { backgroundColor: accentSoft }]}>
            <Text style={[styles.badgeText, { color: accentColor }]}>🛡️ Background Checked</Text>
          </View>
        </View>
        <TouchableOpacity
          style={[styles.selectButton, { backgroundColor: accentColor }]}
          onPress={() => handleSelectHelper(helper)}
        >
          <Text style={styles.selectButtonText}>Select</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: palette.surface }]}>
      {/* Header with sort */}
      <View style={[styles.header, { borderBottomColor: palette.line }]}>
        <View style={styles.headerLeft}>
          <Text style={[styles.location, { color: palette.muted }]}>📍 {taskLocation}</Text>
        </View>
        <View style={styles.sortContainer}>
          <Text style={[styles.sortLabel, { color: palette.muted }]}>Sort by</Text>
          {Platform.OS === 'ios' ? (
            <View style={[styles.pickerWrapper, { borderColor: palette.line }]}>
              <Picker
                selectedValue={sortBy}
                onValueChange={(value) => setSortBy(value)}
                style={[styles.picker, { color: palette.ink }]}
              >
                <Picker.Item label="Nearest" value="nearest" />
                <Picker.Item label="Top rated" value="rating" />
                <Picker.Item label="Lowest price" value="price" />
              </Picker>
            </View>
          ) : (
            <View style={[styles.pickerWrapper, { borderColor: palette.line }]}>
              <Picker
                selectedValue={sortBy}
                onValueChange={(value) => setSortBy(value)}
                style={[styles.picker, { color: palette.ink }]}
              >
                <Picker.Item label="Nearest" value="nearest" />
                <Picker.Item label="Top rated" value="rating" />
                <Picker.Item label="Lowest price" value="price" />
              </Picker>
            </View>
          )}
        </View>
      </View>

      {/* Helpers List */}
      <FlatList
        data={sortedHelpers}
        renderItem={renderHelperCard}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        ListFooterComponent={
          <Text style={[styles.footerNote, { color: palette.muted }]}>
            Final price is based on actual distance and time.
          </Text>
        }
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderBottomWidth: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerLeft: {
    flex: 1,
  },
  location: {
    fontSize: 12.5,
    fontWeight: '600',
  },
  sortContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  sortLabel: {
    fontSize: 12.5,
    fontWeight: '600',
  },
  pickerWrapper: {
    borderWidth: 1,
    borderRadius: 8,
    overflow: 'hidden',
    width: 100,
  },
  picker: {
    height: 32,
  },
  listContent: {
    paddingHorizontal: 18,
    paddingVertical: 12,
  },
  card: {
    borderWidth: 1,
    borderRadius: 14,
    padding: 12,
    marginBottom: 12,
    backgroundColor: '#fff',
  },
  cardTop: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 12,
  },
  avatarWrapper: {
    position: 'relative',
  },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 26,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    fontSize: 26,
  },
  onlineBadge: {
    position: 'absolute',
    right: 0,
    top: 0,
    width: 13,
    height: 13,
    borderRadius: 6.5,
    borderWidth: 2.5,
    borderColor: '#fff',
  },
  helperInfo: {
    flex: 1,
  },
  helperName: {
    fontSize: 14,
    fontWeight: '800',
    marginBottom: 2,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 2,
  },
  rating: {
    fontSize: 12.5,
    fontWeight: '600',
  },
  role: {
    fontSize: 12.5,
    marginBottom: 4,
  },
  metaRow: {
    marginBottom: 4,
  },
  meta: {
    fontSize: 12.5,
  },
  price: {
    fontSize: 13,
    fontWeight: '700',
  },
  cardBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  badges: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
    flex: 1,
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  badgeText: {
    fontSize: 11,
    fontWeight: '700',
  },
  selectButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  selectButtonText: {
    color: '#fff',
    fontSize: 13,
    fontWeight: '700',
  },
  footerNote: {
    textAlign: 'center',
    fontSize: 12,
    marginVertical: 12,
    marginHorizontal: 18,
  },
});
