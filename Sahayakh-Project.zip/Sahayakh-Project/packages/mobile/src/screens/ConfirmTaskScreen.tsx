import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useTheme, colors } from '../theme';
import { useTaskStore } from '../store';
import { Button } from '../components';
import { apiClient } from '../api/client';

type PaymentOption = 'after' | 'now';

export const ConfirmTaskScreen: React.FC<{ navigation: any; route: any }> = ({
  navigation,
  route,
}) => {
  const { helper, taskId } = route.params;
  const { mode } = useTheme();
  const palette = colors.light;
  const accentColor = palette.accent[mode];
  const accentSoft = palette.accentSoft[mode];

  const taskStore = useTaskStore();
  const [paymentOption, setPaymentOption] = useState<PaymentOption>('after');
  const [confirming, setConfirming] = useState(false);

  const handleEditTask = () => {
    navigation.navigate('Create');
  };

  const handleConfirm = async () => {
    setConfirming(true);
    try {
      // Assign helper to task
      const response = await apiClient.acceptHelper(taskId, helper.id);

      // Create payment
      await apiClient.initiatePayment(taskId, {
        payment_method: paymentOption === 'now' ? 'card' : 'after_completion',
        amount: helper.range[0],
      });

      // Success
      Alert.alert('Success!', 'Task assigned to helper. You will receive updates shortly.', [
        {
          text: 'Track Task',
          onPress: () => navigation.navigate('Tracking', { taskId }),
        },
      ]);
    } catch (error) {
      Alert.alert('Error', 'Failed to assign helper. Please try again.');
      console.error(error);
    } finally {
      setConfirming(false);
    }
  };

  const formatBudget = () => {
    if (!taskStore.budget) return 'Not set';
    const parts = taskStore.budget.split('-').map((b) => b.trim());
    return parts.map((p) => `₹${p}`).join(' - ');
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: palette.surface }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={[styles.headerBackButton, { color: palette.ink }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: palette.ink }]}>Confirm Task</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Task Details Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: palette.ink }]}>Task Details</Text>
            <TouchableOpacity onPress={handleEditTask}>
              <Text style={[styles.editLink, { color: accentColor }]}>Edit</Text>
            </TouchableOpacity>
          </View>

          <View style={[styles.card, { backgroundColor: palette.surface2 }]}>
            {/* Description */}
            <View style={styles.detailRow}>
              <Text style={[styles.detailIcon, { color: accentColor }]}>📄</Text>
              <Text style={[styles.detailText, { color: palette.ink }]}>
                {taskStore.description}
              </Text>
            </View>

            {/* Business Name */}
            {mode === 'business' && taskStore.bizName && (
              <View style={styles.detailRow}>
                <Text style={[styles.detailIcon, { color: accentColor }]}>🏢</Text>
                <Text style={[styles.detailText, { color: palette.ink }]}>
                  {taskStore.bizName}
                  {taskStore.gst && ' (GST bill needed)'}
                </Text>
              </View>
            )}

            {/* Location */}
            <View style={styles.detailRow}>
              <Text style={[styles.detailIcon, { color: accentColor }]}>📍</Text>
              <Text style={[styles.detailText, { color: palette.ink }]}>
                {taskStore.location}
              </Text>
            </View>

            {/* Date & Time */}
            <View style={styles.detailRow}>
              <Text style={[styles.detailIcon, { color: accentColor }]}>📅</Text>
              <Text style={[styles.detailText, { color: palette.ink }]}>
                {taskStore.date}, {taskStore.time}
              </Text>
            </View>

            {/* Budget */}
            <View style={styles.detailRow}>
              <Text style={[styles.detailIcon, { color: accentColor }]}>₹</Text>
              <Text style={[styles.detailText, { color: palette.ink }]}>
                Budget: {formatBudget()}
              </Text>
            </View>
          </View>
        </View>

        {/* Selected Helper Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: palette.ink }]}>Selected Helper</Text>
          <View style={[styles.card, { backgroundColor: palette.surface2 }]}>
            <View style={styles.helperRow}>
              <View
                style={[
                  styles.avatar,
                  { backgroundColor: helper.look?.bg || accentSoft },
                ]}
              >
                <Text style={styles.avatarText}>👤</Text>
              </View>
              <View style={styles.helperInfo}>
                <Text style={[styles.helperName, { color: palette.ink }]}>
                  {helper.name}
                </Text>
                <View style={styles.ratingRow}>
                  <Text>⭐</Text>
                  <Text style={[styles.rating, { color: palette.ink }]}>
                    {helper.rating}{' '}
                    <Text style={[{ color: palette.muted, fontWeight: '500' }]}>
                      ({helper.tasks})
                    </Text>
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </View>

        {/* Estimated Amount Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: palette.ink }]}>Estimated Amount</Text>
          <Text style={[styles.amount, { color: accentColor }]}>
            ₹{helper.range[0].toLocaleString()} - ₹{helper.range[1].toLocaleString()}
          </Text>
          <Text style={[styles.amountNote, { color: palette.muted }]}>
            Final amount is based on actual distance and time.
          </Text>
        </View>

        {/* Payment Option Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: palette.ink }]}>Payment Option</Text>

          {/* Pay After Completion */}
          <TouchableOpacity
            style={[
              styles.paymentOption,
              {
                borderColor:
                  paymentOption === 'after' ? accentColor : palette.line,
                backgroundColor:
                  paymentOption === 'after' ? accentSoft : palette.surface2,
              },
            ]}
            onPress={() => setPaymentOption('after')}
          >
            <View
              style={[
                styles.radio,
                {
                  borderColor:
                    paymentOption === 'after' ? accentColor : palette.muted,
                  backgroundColor:
                    paymentOption === 'after' ? accentColor : 'transparent',
                },
              ]}
            >
              {paymentOption === 'after' && (
                <View
                  style={[
                    styles.radioInner,
                    { backgroundColor: palette.surface },
                  ]}
                />
              )}
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.paymentOptionTitle, { color: palette.ink }]}>
                Pay after completion (Recommended)
              </Text>
              <Text style={[styles.paymentOptionDesc, { color: palette.muted }]}>
                Pay based on actual distance and time
              </Text>
            </View>
          </TouchableOpacity>

          {/* Pay Now */}
          <TouchableOpacity
            style={[
              styles.paymentOption,
              {
                borderColor:
                  paymentOption === 'now' ? accentColor : palette.line,
                backgroundColor:
                  paymentOption === 'now' ? accentSoft : palette.surface2,
              },
            ]}
            onPress={() => setPaymentOption('now')}
          >
            <View
              style={[
                styles.radio,
                {
                  borderColor:
                    paymentOption === 'now' ? accentColor : palette.muted,
                  backgroundColor:
                    paymentOption === 'now' ? accentColor : 'transparent',
                },
              ]}
            >
              {paymentOption === 'now' && (
                <View
                  style={[
                    styles.radioInner,
                    { backgroundColor: palette.surface },
                  ]}
                />
              )}
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.paymentOptionTitle, { color: palette.ink }]}>
                Pay now
              </Text>
              <Text style={[styles.paymentOptionDesc, { color: palette.muted }]}>
                Pre-authorize the amount
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Footer */}
      <View style={styles.footer}>
        <Button
          label={confirming ? 'Confirming...' : 'Confirm & Assign'}
          onPress={handleConfirm}
          loading={confirming}
          disabled={confirming}
        />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.05)',
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '700',
  },
  headerBackButton: {
    fontSize: 24,
    fontWeight: '600',
    width: 24,
  },
  content: {
    padding: 18,
    paddingBottom: 100,
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: '800',
  },
  editLink: {
    fontSize: 13,
    fontWeight: '700',
  },
  card: {
    borderRadius: 14,
    padding: 14,
    gap: 12,
  },
  detailRow: {
    flexDirection: 'row',
    gap: 10,
    alignItems: 'flex-start',
  },
  detailIcon: {
    fontSize: 18,
    marginTop: 2,
  },
  detailText: {
    fontSize: 13.5,
    flex: 1,
    lineHeight: 20,
  },
  helperRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    fontSize: 26,
  },
  helperInfo: {
    flex: 1,
  },
  helperName: {
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 4,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
  },
  rating: {
    fontSize: 13,
    fontWeight: '600',
  },
  amount: {
    fontSize: 28,
    fontWeight: '800',
    marginBottom: 4,
  },
  amountNote: {
    fontSize: 12.5,
  },
  paymentOption: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderWidth: 1.5,
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
  },
  radio: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  radioInner: {
    width: 4,
    height: 4,
    borderRadius: 2,
  },
  paymentOptionTitle: {
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 2,
  },
  paymentOptionDesc: {
    fontSize: 12.5,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 18,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: 'rgba(0,0,0,0.05)',
  },
});
