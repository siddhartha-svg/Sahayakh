import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Switch,
  Alert,
  ActivityIndicator,
  Image,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import { useTheme, colors } from '../theme';
import { useTaskStore } from '../store';
import { Button } from '../components';
import { apiClient } from '../api/client';

const CHIPS = {
  personal: [
    { label: 'Pick up medicine', desc: 'Pick up medicine from the pharmacy and deliver it to my home.' },
    { label: 'Visit a location', desc: 'Visit a location and send me photos of how it looks.' },
    { label: 'Submit a document', desc: 'Submit a document at the government office and share the receipt.' },
    { label: 'Check on someone', desc: 'Visit my parents at home, check they are okay and call me.' },
  ],
  business: [
    { label: 'Deliver documents', desc: 'Deliver signed documents to a client and get a receiving signature.' },
    { label: 'Vendor pickup', desc: 'Pick up an order from our vendor and bring it to our shop.' },
    { label: 'Bank or GST office', desc: 'Submit forms at the bank or GST office and bring back the acknowledgment.' },
    { label: 'Site check', desc: 'Visit our site, take photos and send a short progress report.' },
  ],
};

export const CreateTaskScreen: React.FC<{ navigation: any }> = ({ navigation }) => {
  const { mode } = useTheme();
  const palette = colors.light;
  const accentColor = palette.accent[mode];
  const accentSoft = palette.accentSoft[mode];

  const taskStore = useTaskStore();
  const [loading, setLoading] = useState(false);
  const [descError, setDescError] = useState('');
  const [locationLoading, setLocationLoading] = useState(false);

  const handleChipSelect = (chip: typeof CHIPS.personal[0]) => {
    taskStore.update('description', chip.desc);
    setDescError('');
  };

  const handleAddPhoto = async () => {
    if (taskStore.photos.length >= 3) {
      Alert.alert('Limit reached', 'You can add up to 3 photos');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      aspect: [4, 3],
      quality: 0.7,
    });

    if (!result.canceled && result.assets[0]) {
      taskStore.update('photos', [...taskStore.photos, result.assets[0].uri]);
    }
  };

  const handleRemovePhoto = (index: number) => {
    taskStore.update(
      'photos',
      taskStore.photos.filter((_, i) => i !== index),
    );
  };

  const handleGetLocation = async () => {
    setLocationLoading(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission denied', 'We need location permission to find nearby helpers');
        return;
      }

      const location = await Location.getCurrentPositionAsync({});
      const { latitude, longitude } = location.coords;

      // TODO: Call reverse geocoding API to get address
      // For now, just store coordinates
      taskStore.update('coordinates', { latitude, longitude });
      taskStore.update('location', `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
    } catch (error) {
      Alert.alert('Error', 'Failed to get location');
    } finally {
      setLocationLoading(false);
    }
  };

  const handleFindHelpers = async () => {
    const desc = taskStore.description.trim();
    if (!desc) {
      setDescError('Describe your task so helpers know what to do.');
      return;
    }

    setLoading(true);
    try {
      const taskData = {
        task_type: mode === 'personal' ? 'household' : 'business',
        category: mode === 'personal' ? 'general' : 'business_errands',
        title: desc.substring(0, 50),
        description: desc,
        location: taskStore.location,
        coordinates: taskStore.coordinates,
        date: taskStore.date,
        time: taskStore.time,
        budget: taskStore.budget ? taskStore.budget.split('-').map((b) => parseInt(b.trim())) : undefined,
        photos: taskStore.photos,
        ...(mode === 'business' && {
          business_name: taskStore.bizName,
          gst_required: taskStore.gst,
        }),
      };

      // Create task on backend
      const response = await apiClient.createTask(taskData);
      const taskId = response.data.id;

      // Mock helpers for demo (replace with real API response)
      const mockHelpers = [
        {
          id: 'h1',
          name: 'Rohit Kumar',
          rating: 4.8,
          tasks: '320+',
          role: 'Local Task Specialist',
          km: 1.2,
          eta: 8,
          range: [150, 300],
          final: 280,
          look: { bg: '#CDE7D6' },
          skills: ['Pickup & Delivery', 'Local Visits'],
          about: 'I can help with medicine pickup, document submission, local visits, and other nearby tasks.',
          rev: { who: 'Priya S.', rate: '5.0', date: '12 Sep 2026', text: 'Very helpful and on time!' },
        },
        {
          id: 'h2',
          name: 'Sneha Verma',
          rating: 4.9,
          tasks: '450+',
          role: 'Healthcare & Personal Help',
          km: 2.8,
          eta: 14,
          range: [160, 310],
          final: 290,
          look: { bg: '#F0DDE8' },
          skills: ['Pharmacy Pickup', 'Lab Reports'],
          about: 'Former nursing assistant. I help with medicine, lab reports and check-ins for elders.',
          rev: { who: 'Suresh R.', rate: '5.0', date: '2 Sep 2026', text: 'Checked on my mother and called me right away.' },
        },
      ];

      // Navigate to finding helpers screen with task ID and mock helpers
      navigation.navigate('Finding', { taskId, helpers: mockHelpers });
    } catch (error) {
      Alert.alert('Error', 'Failed to create task. Please try again.');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const isBusiness = mode === 'business';
  const chips = CHIPS[mode];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: palette.surface }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={[styles.headerBackButton, { color: accentColor }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: palette.ink }]}>Create a Task</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Mode Toggle */}
        <View style={styles.modeToggle}>
          <TouchableOpacity
            style={[
              styles.modeButton,
              !isBusiness && { backgroundColor: accentColor },
            ]}
            onPress={() => useTheme.getState().setMode('personal')}
          >
            <Text
              style={[
                styles.modeButtonText,
                { color: !isBusiness ? '#fff' : palette.ink },
              ]}
            >
              👤 Personal
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.modeButton,
              isBusiness && { backgroundColor: accentColor },
            ]}
            onPress={() => useTheme.getState().setMode('business')}
          >
            <Text
              style={[
                styles.modeButtonText,
                { color: isBusiness ? '#fff' : palette.ink },
              ]}
            >
              💼 Business
            </Text>
          </TouchableOpacity>
        </View>

        {/* Question */}
        <Text style={[styles.question, { color: palette.ink }]}>
          {isBusiness
            ? 'What does your business need?'
            : 'What do you need help with?'}
        </Text>

        {/* Description Input */}
        <View style={styles.fieldGroup}>
          <TextInput
            style={[
              styles.textArea,
              {
                borderColor: descError ? '#EF4444' : palette.line,
                color: palette.ink,
              },
            ]}
            placeholder={
              isBusiness
                ? 'Describe the work in detail. Example: deliver documents to a client, collect an order from a vendor...'
                : 'Describe your task in detail. Example: pick up medicine, visit a location, submit a document...'
            }
            placeholderTextColor={palette.muted}
            multiline
            numberOfLines={4}
            value={taskStore.description}
            onChangeText={(text) => {
              taskStore.update('description', text);
              if (text.trim()) setDescError('');
            }}
          />
          {descError && <Text style={styles.error}>{descError}</Text>}
        </View>

        {/* Chip Suggestions */}
        <Text style={[styles.sectionLabel, { color: palette.muted }]}>Quick suggestions:</Text>
        <View style={styles.chipsContainer}>
          {chips.map((chip, i) => (
            <TouchableOpacity
              key={i}
              style={[styles.chip, { borderColor: accentColor }]}
              onPress={() => handleChipSelect(chip)}
            >
              <Text style={[styles.chipText, { color: accentColor }]}>{chip.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Business-specific fields */}
        {isBusiness && (
          <>
            <Text style={[styles.sectionLabel, { color: palette.ink }]}>
              Business name <Text style={[styles.optional, { color: palette.muted }]}>(optional)</Text>
            </Text>
            <TextInput
              style={[styles.field, { borderColor: palette.line, color: palette.ink }]}
              placeholder="e.g. Sri Lakshmi Traders"
              placeholderTextColor={palette.muted}
              value={taskStore.bizName}
              onChangeText={(text) => taskStore.update('bizName', text)}
            />

            <View style={[styles.toggleRow, { borderBottomColor: palette.line }]}>
              <View style={{ flex: 1 }}>
                <Text style={[styles.toggleLabel, { color: palette.ink }]}>
                  I need a GST bill
                </Text>
                <Text style={[styles.toggleHint, { color: palette.muted }]}>
                  The helper will collect a tax invoice
                </Text>
              </View>
              <Switch
                value={taskStore.gst}
                onValueChange={(value) => taskStore.update('gst', value)}
                trackColor={{ false: palette.line, true: accentSoft }}
                thumbColor={taskStore.gst ? accentColor : palette.muted}
              />
            </View>
          </>
        )}

        {/* Photos */}
        <Text style={[styles.sectionLabel, { color: palette.ink }]}>
          Add Photos <Text style={[styles.optional, { color: palette.muted }]}>(optional)</Text>
        </Text>
        <View style={styles.photosContainer}>
          {taskStore.photos.length < 3 && (
            <TouchableOpacity
              style={[styles.photoButton, { borderColor: accentColor }]}
              onPress={handleAddPhoto}
            >
              <Text style={[styles.photoButtonText, { color: accentColor }]}>+</Text>
              <Text style={[styles.photoButtonLabel, { color: accentColor }]}>Add Photo</Text>
            </TouchableOpacity>
          )}
          {taskStore.photos.map((photo, i) => (
            <View key={i} style={styles.photoItem}>
              <Image source={{ uri: photo }} style={styles.photoImage} />
              <TouchableOpacity
                style={styles.removePhotoButton}
                onPress={() => handleRemovePhoto(i)}
              >
                <Text style={styles.removePhotoText}>✕</Text>
              </TouchableOpacity>
            </View>
          ))}
        </View>

        {/* Location */}
        <Text style={[styles.sectionLabel, { color: palette.ink }]}>Task Location</Text>
        <TouchableOpacity
          style={[styles.locationField, { borderColor: palette.line }]}
          onPress={handleGetLocation}
          disabled={locationLoading}
        >
          <Text style={[styles.locationIcon, { color: accentColor }]}>📍</Text>
          <View style={{ flex: 1 }}>
            <Text style={[styles.locationLabel, { color: palette.muted }]}>Current location</Text>
            <Text style={[styles.locationValue, { color: palette.ink }]}>
              {locationLoading ? 'Getting location...' : taskStore.location}
            </Text>
          </View>
          {!locationLoading && <Text style={[styles.locationButton, { color: accentColor }]}>🎯</Text>}
        </TouchableOpacity>

        {/* Date & Time */}
        <Text style={[styles.sectionLabel, { color: palette.ink }]}>Preferred Date & Time</Text>
        <View style={styles.dateTimeContainer}>
          <TextInput
            style={[styles.dateTimeInput, { borderColor: palette.line, color: palette.ink }]}
            placeholder="YYYY-MM-DD"
            placeholderTextColor={palette.muted}
            value={taskStore.date}
            onChangeText={(text) => taskStore.update('date', text)}
          />
          <TextInput
            style={[styles.dateTimeInput, { borderColor: palette.line, color: palette.ink }]}
            placeholder="HH:MM"
            placeholderTextColor={palette.muted}
            value={taskStore.time}
            onChangeText={(text) => taskStore.update('time', text)}
          />
        </View>

        {/* Budget */}
        <Text style={[styles.sectionLabel, { color: palette.ink }]}>
          Budget <Text style={[styles.optional, { color: palette.muted }]}>(optional)</Text>
        </Text>
        <View style={[styles.budgetField, { borderColor: palette.line }]}>
          <Text style={[styles.budgetCurrency, { color: accentColor }]}>₹</Text>
          <TextInput
            style={[styles.budgetInput, { color: palette.ink }]}
            placeholder="e.g. 200 - 500"
            placeholderTextColor={palette.muted}
            keyboardType="numeric"
            value={taskStore.budget}
            onChangeText={(text) => taskStore.update('budget', text)}
          />
        </View>

        {/* Submit Button */}
        <View style={styles.footer}>
          <Button
            label={loading ? 'Finding Helpers...' : 'Find Helpers →'}
            onPress={handleFindHelpers}
            loading={loading}
            disabled={loading}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.05)',
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '700',
  },
  headerBackButton: {
    fontSize: 24,
    fontWeight: '600',
    width: 24,
  },
  content: {
    padding: 18,
  },
  modeToggle: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 20,
  },
  modeButton: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: 'rgba(0,0,0,0.1)',
    alignItems: 'center',
  },
  modeButtonText: {
    fontWeight: '700',
    fontSize: 14,
  },
  question: {
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 16,
  },
  fieldGroup: {
    marginBottom: 16,
  },
  textArea: {
    borderWidth: 1,
    borderRadius: 10,
    padding: 12,
    fontSize: 15,
    lineHeight: 22,
    minHeight: 100,
  },
  error: {
    color: '#EF4444',
    fontSize: 12,
    marginTop: 6,
  },
  sectionLabel: {
    fontSize: 13.5,
    fontWeight: '600',
    marginBottom: 12,
    marginTop: 16,
  },
  optional: {
    fontWeight: '400',
    fontSize: 12,
  },
  chipsContainer: {
    gap: 8,
    marginBottom: 20,
  },
  chip: {
    borderWidth: 1.5,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  chipText: {
    fontSize: 13,
    fontWeight: '600',
  },
  field: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 15,
    marginBottom: 12,
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 14,
    borderBottomWidth: 1,
    marginBottom: 20,
  },
  toggleLabel: {
    fontSize: 14,
    fontWeight: '700',
  },
  toggleHint: {
    fontSize: 12,
    marginTop: 2,
  },
  photosContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 20,
  },
  photoButton: {
    width: '30%',
    aspectRatio: 1,
    borderWidth: 2,
    borderRadius: 10,
    borderStyle: 'dashed',
    justifyContent: 'center',
    alignItems: 'center',
  },
  photoButtonText: {
    fontSize: 28,
    fontWeight: '600',
  },
  photoButtonLabel: {
    fontSize: 11,
    marginTop: 4,
  },
  photoItem: {
    width: '30%',
    aspectRatio: 1,
    borderRadius: 10,
    overflow: 'hidden',
    position: 'relative',
  },
  photoImage: {
    flex: 1,
  },
  removePhotoButton: {
    position: 'absolute',
    top: 4,
    right: 4,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  removePhotoText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '700',
  },
  locationField: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 12,
    marginBottom: 20,
  },
  locationIcon: {
    fontSize: 20,
  },
  locationLabel: {
    fontSize: 12,
    marginBottom: 2,
  },
  locationValue: {
    fontSize: 14,
    fontWeight: '600',
  },
  locationButton: {
    fontSize: 18,
  },
  dateTimeContainer: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 20,
  },
  dateTimeInput: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
  },
  budgetField: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 10,
    paddingLeft: 12,
    marginBottom: 20,
  },
  budgetCurrency: {
    fontSize: 16,
    fontWeight: '700',
    marginRight: 8,
  },
  budgetInput: {
    flex: 1,
    paddingHorizontal: 0,
    paddingVertical: 10,
    fontSize: 15,
  },
  footer: {
    paddingBottom: 20,
  },
});
