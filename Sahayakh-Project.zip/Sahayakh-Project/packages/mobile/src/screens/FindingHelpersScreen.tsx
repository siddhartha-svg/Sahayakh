import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Animated,
  Easing,
  ActivityIndicator,
} from 'react-native';
import { useTheme, colors } from '../theme';
import { apiClient } from '../api/client';

const STEPS = [
  'Searching nearby helpers',
  'Checking availability',
  'Verifying backgrounds',
  'Calculating distance & ETA',
];

export const FindingHelpersScreen: React.FC<{ navigation: any; route: any }> = ({
  navigation,
  route,
}) => {
  const { taskId, helpers: mockHelpers = [] } = route.params;
  const { mode } = useTheme();
  const palette = colors.light;
  const accentColor = palette.accent[mode];

  const [currentStep, setCurrentStep] = useState(0);
  const [error, setError] = useState<string | null>(null);

  // Animations
  const pulseAnim1 = React.useRef(new Animated.Value(0)).current;
  const pulseAnim2 = React.useRef(new Animated.Value(0.5)).current;
  const spinAnim = React.useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Pulse animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim1, {
          toValue: 1,
          duration: 2400,
          useNativeDriver: false,
        }),
        Animated.timing(pulseAnim1, {
          toValue: 0,
          duration: 0,
          useNativeDriver: false,
        }),
      ]),
    ).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim2, {
          toValue: 1,
          duration: 2400,
          delay: 1200,
          useNativeDriver: false,
        }),
        Animated.timing(pulseAnim2, {
          toValue: 0.5,
          duration: 0,
          useNativeDriver: false,
        }),
      ]),
    ).start();

    // Spin animation
    Animated.loop(
      Animated.timing(spinAnim, {
        toValue: 1,
        duration: 800,
        easing: Easing.linear,
        useNativeDriver: true,
      }),
    ).start();
  }, [pulseAnim1, pulseAnim2, spinAnim]);

  // Step progression
  useEffect(() => {
    const stepInterval = setInterval(() => {
      setCurrentStep((prev) => {
        const next = prev + 1;
        if (next >= STEPS.length) {
          clearInterval(stepInterval);
          // Fetch helpers after all steps done
          fetchHelpers();
          return prev;
        }
        return next;
      });
    }, 800);

    return () => clearInterval(stepInterval);
  }, []);

  const fetchHelpers = async () => {
    try {
      // For demo, use mock helpers passed from CreateTask
      // In production, this would call: const response = await apiClient.getHelpers(taskId);

      // Navigate after short delay for UX
      setTimeout(() => {
        navigation.replace('Helpers', { taskId, helpers: mockHelpers });
      }, 650);
    } catch (err) {
      setError('Failed to find helpers. Please try again.');
      console.error(err);
    }
  };

  const spinRotation = spinAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  const pulse1Scale = pulseAnim1.interpolate({
    inputRange: [0, 1],
    outputRange: [0.4, 1],
  });

  const pulse1Opacity = pulseAnim1.interpolate({
    inputRange: [0, 1],
    outputRange: [0.7, 0],
  });

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: palette.surface }]}>
      <View style={styles.header}>
        <Text style={[styles.headerTitle, { color: palette.ink }]}>Finding Helpers</Text>
      </View>

      <View style={styles.content}>
        {/* Radar Animation */}
        <View style={styles.radarContainer}>
          {/* Outer ring (pulsing) */}
          <Animated.View
            style={[
              styles.ring,
              styles.ring1,
              {
                backgroundColor: accentColor,
                transform: [{ scale: pulse1Scale }],
                opacity: pulse1Opacity,
              },
            ]}
          />

          {/* Middle ring */}
          <View
            style={[
              styles.ring,
              styles.ring2,
              { backgroundColor: palette.surface, opacity: 0.55 },
            ]}
          />

          {/* Inner ring */}
          <View
            style={[
              styles.ring,
              styles.ring3,
              { backgroundColor: accentColor, opacity: 0.9 },
            ]}
          />

          {/* Second pulse (delayed) */}
          <Animated.View
            style={[
              styles.ring,
              styles.ring1,
              {
                backgroundColor: accentColor,
                transform: [{ scale: pulseAnim2 }],
                opacity: pulseAnim2.interpolate({
                  inputRange: [0.5, 1],
                  outputRange: [0, 0],
                }),
              },
            ]}
          />

          {/* Center lens with spinning icon */}
          <View style={[styles.lens, { backgroundColor: palette.surface, borderColor: accentColor }]}>
            <Animated.View
              style={{
                transform: [{ rotate: spinRotation }],
              }}
            >
              <Text style={[styles.searchIcon, { color: accentColor }]}>🔍</Text>
            </Animated.View>
          </View>

          {/* Pin markers */}
          <View style={[styles.pin, { top: '10%', left: '10%' }]}>
            <Text style={{ fontSize: 16 }}>📍</Text>
          </View>
          <View style={[styles.pin, { top: '15%', right: '15%' }]}>
            <Text style={{ fontSize: 16 }}>📍</Text>
          </View>
          <View style={[styles.pin, { bottom: '15%', right: '10%' }]}>
            <Text style={{ fontSize: 16 }}>📍</Text>
          </View>
          <View style={[styles.pin, { bottom: '20%', left: '15%' }]}>
            <Text style={{ fontSize: 16 }}>📍</Text>
          </View>
        </View>

        {/* Title and Description */}
        <Text style={[styles.title, { color: accentColor }]}>
          Finding trusted people near you…
        </Text>
        <Text style={[styles.subtitle, { color: palette.muted }]}>
          This will only take a moment.
        </Text>

        {/* Progress Steps */}
        <View style={styles.stepsContainer}>
          {STEPS.map((step, i) => {
            const isDone = i < currentStep;
            const isCurrent = i === currentStep;

            return (
              <View key={i} style={styles.stepRow}>
                <View
                  style={[
                    styles.stepIndicator,
                    {
                      backgroundColor: isDone ? accentColor : palette.surface,
                      borderColor: isDone ? accentColor : palette.line,
                    },
                  ]}
                >
                  {isDone ? (
                    <Text style={styles.stepCheckmark}>✓</Text>
                  ) : isCurrent ? (
                    <ActivityIndicator color={accentColor} size="small" />
                  ) : null}
                </View>
                <Text
                  style={[
                    styles.stepText,
                    {
                      color: isDone || isCurrent ? palette.ink : palette.muted,
                      fontWeight: isDone || isCurrent ? '600' : '500',
                    },
                  ]}
                >
                  {step}
                </Text>
              </View>
            );
          })}
        </View>

        {/* Trust Message */}
        <View style={[styles.trustBox, { backgroundColor: palette.surface2 }]}>
          <Text style={[styles.trustIcon, { color: accentColor }]}>🛡️</Text>
          <Text style={[styles.trustText, { color: palette.muted }]}>
            We only show verified and background checked helpers.
          </Text>
        </View>

        {error && (
          <View style={[styles.errorBox, { backgroundColor: '#FEE' }]}>
            <Text style={styles.errorText}>{error}</Text>
          </View>
        )}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.05)',
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '700',
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 18,
    paddingVertical: 20,
  },
  radarContainer: {
    width: 230,
    height: 230,
    marginBottom: 24,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  ring: {
    position: 'absolute',
    borderRadius: 999,
  },
  ring1: {
    width: 230,
    height: 230,
  },
  ring2: {
    width: 186,
    height: 186,
  },
  ring3: {
    width: 142,
    height: 142,
  },
  lens: {
    width: 92,
    height: 92,
    borderRadius: 46,
    borderWidth: 5,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
  searchIcon: {
    fontSize: 40,
  },
  pin: {
    position: 'absolute',
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    marginBottom: 8,
    textAlign: 'center',
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 13.5,
    lineHeight: 20,
    marginBottom: 20,
    textAlign: 'center',
  },
  stepsContainer: {
    width: '100%',
    marginBottom: 20,
    gap: 12,
  },
  stepRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  stepIndicator: {
    width: 28,
    height: 28,
    borderRadius: 14,
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    flexShrink: 0,
  },
  stepCheckmark: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '700',
  },
  stepText: {
    flex: 1,
    fontSize: 13.5,
  },
  trustBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 14,
    width: '100%',
  },
  trustIcon: {
    fontSize: 20,
  },
  trustText: {
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  errorBox: {
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 10,
    marginTop: 12,
  },
  errorText: {
    color: '#C53030',
    fontSize: 13,
    fontWeight: '600',
  },
});
