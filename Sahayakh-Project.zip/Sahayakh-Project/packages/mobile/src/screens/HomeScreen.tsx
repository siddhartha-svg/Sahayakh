import React, { useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  SafeAreaView,
  ImageBackground,
  Animated,
  Dimensions,
} from 'react-native';
import { useTheme, colors, typography } from '../theme';
import { Button } from '../components';
import { useAuthStore, useTaskStore } from '../store';

const { width } = Dimensions.get('window');

export const HomeScreen: React.FC<{ navigation: any }> = ({ navigation }) => {
  const { mode, setMode } = useTheme();
  const { isAuthenticated } = useAuthStore();
  const palette = colors.light;
  const accentColor = palette.accent[mode];
  const accentSoft = palette.accentSoft[mode];

  const scaleAnim = React.useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (!isAuthenticated) {
      navigation.replace('Auth');
    }
  }, [isAuthenticated]);

  const handleModeChange = (newMode: 'personal' | 'business') => {
    Animated.spring(scaleAnim, {
      toValue: 0.95,
      useNativeDriver: true,
    }).start(() => {
      setMode(newMode);
      Animated.spring(scaleAnim, {
        toValue: 1,
        useNativeDriver: true,
      }).start();
    });
  };

  const handleCreateTask = () => {
    // Clear previous task state
    useTaskStore.setState({
      description: '',
      photos: [],
      location: 'Warangal, Telangana',
      date: new Date().toISOString().split('T')[0],
      time: '10:00',
      budget: '',
      bizName: '',
      gst: false,
    });
    navigation.navigate('Create');
  };

  const handleMyTasks = () => {
    navigation.navigate('TasksTab');
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: palette.surface }]}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Header with Logo */}
        <View style={styles.header}>
          <Text style={[styles.logo, { color: accentColor }]}>Sahayakh</Text>
          <Text style={[styles.tagline, { color: palette.muted }]}>
            Help when you need it, from people you trust
          </Text>
        </View>

        {/* Hero Section */}
        <View style={[styles.hero, { backgroundColor: accentSoft }]}>
          <Text style={[styles.heroTitle, { color: accentColor }]}>
            What do you need help with?
          </Text>
          <Text style={[styles.heroSubtitle, { color: palette.muted }]}>
            Choose your task type to get started
          </Text>
        </View>

        {/* Mode Selection Cards */}
        <View style={styles.modeContainer}>
          {/* Personal Mode Card */}
          <Animated.View
            style={[
              styles.modeCard,
              {
                backgroundColor: mode === 'personal' ? palette.accentSoft.personal : palette.surface2,
                borderColor: mode === 'personal' ? palette.accent.personal : palette.line,
                transform: [{ scale: mode === 'personal' ? scaleAnim : 1 }],
              },
            ]}
          >
            <Button
              label="Personal Tasks"
              onPress={() => handleModeChange('personal')}
              variant={mode === 'personal' ? 'primary' : 'secondary'}
              style={styles.modeButton}
            />
            <Text style={[styles.modeFeatures, { color: palette.muted }]}>
              📍 Pick up medicine{'\n'}
              📄 Submit documents{'\n'}
              🏠 Check on someone{'\n'}
              📸 Take location photos
            </Text>
          </Animated.View>

          {/* Business Mode Card */}
          <Animated.View
            style={[
              styles.modeCard,
              {
                backgroundColor: mode === 'business' ? palette.accentSoft.business : palette.surface2,
                borderColor: mode === 'business' ? palette.accent.business : palette.line,
                transform: [{ scale: mode === 'business' ? scaleAnim : 1 }],
              },
            ]}
          >
            <Button
              label="Business Tasks"
              onPress={() => handleModeChange('business')}
              variant={mode === 'business' ? 'primary' : 'secondary'}
              style={styles.modeButton}
            />
            <Text style={[styles.modeFeatures, { color: palette.muted }]}>
              💼 Vendor deliveries{'\n'}
              📋 GST submissions{'\n'}
              🏢 Site inspections{'\n'}
              🤝 Client errands
            </Text>
          </Animated.View>
        </View>

        {/* Features Grid */}
        <View style={styles.featuresSection}>
          <Text style={[styles.featuresTitle, { color: palette.ink }]}>Why choose us?</Text>
          <View style={styles.gridContainer}>
            {[
              { icon: '⭐', title: 'Trusted Helpers', desc: 'Verified & rated professionals' },
              { icon: '💰', title: 'Fair Pricing', desc: 'Transparent costs, no hidden fees' },
              { icon: '🚀', title: 'Quick Response', desc: 'Helpers respond within minutes' },
              { icon: '🔒', title: 'Secure', desc: 'Your data is safe and private' },
            ].map((feature, i) => (
              <View
                key={i}
                style={[styles.featureCard, { backgroundColor: palette.surface2, borderColor: palette.line }]}
              >
                <Text style={styles.featureIcon}>{feature.icon}</Text>
                <Text style={[styles.featureTitle, { color: palette.ink }]}>{feature.title}</Text>
                <Text style={[styles.featureDesc, { color: palette.muted }]}>{feature.desc}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionContainer}>
          <Button
            label={`Create ${mode === 'personal' ? 'Personal' : 'Business'} Task`}
            onPress={handleCreateTask}
            style={{ marginBottom: 12 }}
          />
          <Button
            label="View My Tasks"
            onPress={handleMyTasks}
            variant="secondary"
          />
        </View>

        {/* Banner */}
        <View style={[styles.banner, { backgroundColor: accentColor }]}>
          <Text style={styles.bannerTitle}>🎯 First task 15% off!</Text>
          <Text style={styles.bannerText}>Use code WELCOME15 for your first booking</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 18,
    paddingVertical: 20,
  },
  header: {
    marginBottom: 24,
  },
  logo: {
    fontSize: 32,
    fontWeight: '800',
    marginBottom: 8,
  },
  tagline: {
    fontSize: 13.5,
    lineHeight: 20,
  },
  hero: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  heroTitle: {
    fontSize: 23,
    fontWeight: '800',
    marginBottom: 8,
  },
  heroSubtitle: {
    fontSize: 13.5,
    lineHeight: 20,
  },
  modeContainer: {
    marginBottom: 28,
  },
  modeCard: {
    borderWidth: 1.5,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
  },
  modeButton: {
    marginBottom: 16,
  },
  modeFeatures: {
    fontSize: 12.5,
    lineHeight: 20,
  },
  featuresSection: {
    marginBottom: 28,
  },
  featuresTitle: {
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 16,
  },
  gridContainer: {
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 12,
  },
  featureCard: {
    width: (width - 36 - 12) / 2,
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: 'center',
  },
  featureIcon: {
    fontSize: 28,
    marginBottom: 8,
  },
  featureTitle: {
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 4,
  },
  featureDesc: {
    fontSize: 11.5,
    textAlign: 'center',
    lineHeight: 16,
  },
  actionContainer: {
    marginBottom: 24,
  },
  banner: {
    borderRadius: 14,
    padding: 16,
    marginBottom: 20,
  },
  bannerTitle: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 4,
  },
  bannerText: {
    color: '#fff',
    fontSize: 12.5,
    fontWeight: '500',
  },
});
