import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { useTheme, colors } from '../theme';

interface TaskDetail {
  id: string;
  title: string;
  description: string;
  status: 'completed' | 'in_progress' | 'cancelled';
  taskType: 'personal' | 'business';
  location: string;
  date: string;
  time: string;
  budget: {
    min: number;
    max: number;
  };
  finalAmount: number;
  duration: number;
  distance: number;
  helper: {
    id: string;
    name: string;
    rating: number;
    avatar?: string;
  };
  payment: {
    amount: number;
    method: string;
    status: string;
    completedAt: string;
  };
  rating?: {
    stars: number;
    review: string;
    createdAt: string;
  };
  startedAt: string;
  completedAt: string;
}

export const TaskDetailsScreen: React.FC<{ navigation: any; route: any }> = ({
  navigation,
  route,
}) => {
  const { taskId } = route.params || {};
  const { mode } = useTheme();
  const palette = colors.light;
  const accentColor = palette.accent[mode];
  const accentSoft = palette.accentSoft[mode];

  const [task, setTask] = useState<TaskDetail | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Mock task details
    const mockTask: TaskDetail = {
      id: taskId || 'T-12345',
      title: 'Collect lab report from clinic',
      description: 'Pick up lab report from the clinic near Begumpet and deliver it home.',
      status: 'completed',
      taskType: 'personal',
      location: 'Begumpet, Hyderabad',
      date: '2026-09-22',
      time: '10:00',
      budget: { min: 150, max: 300 },
      finalAmount: 275,
      duration: 35,
      distance: 4.8,
      helper: {
        id: 'h1',
        name: 'Rohit Kumar',
        rating: 4.8,
      },
      payment: {
        amount: 275,
        method: 'Pay After Completion',
        status: 'completed',
        completedAt: '2026-09-22T11:35:00Z',
      },
      rating: {
        stars: 5,
        review: 'Very helpful and on time. The helper was professional and completed the task efficiently.',
        createdAt: '2026-09-22T11:36:00Z',
      },
      startedAt: '2026-09-22T10:00:00Z',
      completedAt: '2026-09-22T11:35:00Z',
    };

    // Simulate API call
    const timer = setTimeout(() => {
      setTask(mockTask);
      setLoading(false);
    }, 500);

    return () => clearTimeout(timer);
  }, [taskId]);

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: palette.surface }]}>
        <View style={[styles.centerContent, { justifyContent: 'center' }]}>
          <ActivityIndicator size="large" color={accentColor} />
        </View>
      </SafeAreaView>
    );
  }

  if (!task) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: palette.surface }]}>
        <View style={styles.centerContent}>
          <Text style={[styles.errorText, { color: palette.muted }]}>Task not found</Text>
        </View>
      </SafeAreaView>
    );
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: palette.surface }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={[styles.headerBackButton, { color: palette.ink }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: palette.ink }]}>Task Details</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Status Bar */}
        <View style={[styles.statusBar, { backgroundColor: accentSoft }]}>
          <Text style={[styles.statusIcon, { color: accentColor }]}>✓</Text>
          <View style={{ flex: 1 }}>
            <Text style={[styles.statusTitle, { color: accentColor }]}>Completed</Text>
            <Text style={[styles.statusDate, { color: palette.muted }]}>
              {formatDate(task.completedAt)}
            </Text>
          </View>
        </View>

        {/* Task Details Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: palette.ink }]}>Task Details</Text>
          <View style={[styles.card, { backgroundColor: palette.surface2 }]}>
            <DetailRow
              icon="📄"
              label="Task"
              value={task.title}
              palette={palette}
            />
            <DetailRow
              icon="🏷️"
              label="Type"
              value={task.taskType === 'personal' ? 'Personal Help' : 'Business Help'}
              palette={palette}
            />
            <DetailRow
              icon="📍"
              label="Location"
              value={task.location}
              palette={palette}
            />
            <DetailRow
              icon="📅"
              label="Scheduled"
              value={`${task.date}, ${task.time}`}
              palette={palette}
            />
            <DetailRow
              icon="💰"
              label="Budget"
              value={`₹${task.budget.min} - ₹${task.budget.max}`}
              palette={palette}
            />
          </View>
        </View>

        {/* Helper Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: palette.ink }]}>Helper</Text>
          <View style={[styles.helperCard, { backgroundColor: palette.surface2 }]}>
            <View style={styles.helperRow}>
              <View style={[styles.helperAvatar, { backgroundColor: accentSoft }]}>
                <Text style={styles.helperAvatarText}>👤</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.helperName, { color: palette.ink }]}>
                  {task.helper.name}
                </Text>
                <Text style={[styles.helperRating, { color: palette.muted }]}>
                  ⭐ {task.helper.rating}
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* Execution Details Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: palette.ink }]}>Execution</Text>
          <View style={[styles.statsGrid, { borderColor: palette.line }]}>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: palette.ink }]}>
                {task.duration} min
              </Text>
              <Text style={[styles.statLabel, { color: palette.muted }]}>Duration</Text>
            </View>
            <View style={[styles.statDivider, { backgroundColor: palette.line }]} />
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: palette.ink }]}>
                {task.distance} km
              </Text>
              <Text style={[styles.statLabel, { color: palette.muted }]}>Distance</Text>
            </View>
            <View style={[styles.statDivider, { backgroundColor: palette.line }]} />
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: palette.ink }]}>
                ₹{task.finalAmount}
              </Text>
              <Text style={[styles.statLabel, { color: palette.muted }]}>Final Amount</Text>
            </View>
          </View>
        </View>

        {/* Payment Section */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: palette.ink }]}>Payment</Text>
          <View style={[styles.card, { backgroundColor: palette.surface2 }]}>
            <DetailRow
              icon="💳"
              label="Amount"
              value={`₹${task.payment.amount}`}
              palette={palette}
            />
            <DetailRow
              icon="📋"
              label="Method"
              value={task.payment.method}
              palette={palette}
            />
            <DetailRow
              icon="✓"
              label="Status"
              value={task.payment.status.charAt(0).toUpperCase() + task.payment.status.slice(1)}
              palette={palette}
            />
            <DetailRow
              icon="🕒"
              label="Completed"
              value={formatDate(task.payment.completedAt)}
              palette={palette}
            />
          </View>
        </View>

        {/* Rating Section */}
        {task.rating && (
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: palette.ink }]}>Your Rating</Text>
            <View style={[styles.card, { backgroundColor: palette.surface2 }]}>
              <View style={styles.ratingRow}>
                <Text style={[styles.ratingStars, { color: '#FFB800' }]}>
                  {'★'.repeat(task.rating.stars)}
                  {'☆'.repeat(5 - task.rating.stars)}
                </Text>
                <Text style={[styles.ratingValue, { color: palette.ink }]}>
                  {task.rating.stars}.0
                </Text>
              </View>
              {task.rating.review && (
                <Text style={[styles.reviewText, { color: palette.muted, marginTop: 10 }]}>
                  "{task.rating.review}"
                </Text>
              )}
              <Text style={[styles.ratedDate, { color: palette.muted, marginTop: 8 }]}>
                Rated on {formatDate(task.rating.createdAt)}
              </Text>
            </View>
          </View>
        )}

        {/* Action Buttons */}
        <View style={styles.section}>
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: accentColor }]}
            onPress={() => { /* Share task */ }}
          >
            <Text style={styles.actionButtonText}>📤 Share Task</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.actionButton, { borderWidth: 1, borderColor: accentColor }]}
            onPress={() => { /* Raise dispute */ }}
          >
            <Text style={[styles.actionButtonText, { color: accentColor }]}>
              🚨 Raise Dispute
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: palette.surface2 }]}
            onPress={() => navigation.goBack()}
          >
            <Text style={[styles.actionButtonText, { color: palette.ink }]}>Back</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

// Detail Row Component
const DetailRow = ({
  icon,
  label,
  value,
  palette,
}: {
  icon: string;
  label: string;
  value: string;
  palette: any;
}) => {
  return (
    <View style={styles.detailRow}>
      <Text style={styles.detailIcon}>{icon}</Text>
      <View>
        <Text style={[styles.detailLabel, { color: palette.muted }]}>{label}</Text>
        <Text style={[styles.detailValue, { color: palette.ink }]}>{value}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  centerContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.05)',
  },
  headerTitle: {
    fontSize: 17,
    fontWeight: '700',
  },
  headerBackButton: {
    fontSize: 24,
    fontWeight: '600',
    width: 24,
  },
  content: {
    padding: 18,
    gap: 20,
  },
  statusBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderRadius: 14,
    padding: 14,
  },
  statusIcon: {
    fontSize: 20,
    fontWeight: '700',
  },
  statusTitle: {
    fontSize: 14,
    fontWeight: '700',
  },
  statusDate: {
    fontSize: 11,
    marginTop: 2,
  },
  section: {
    gap: 12,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: '800',
  },
  card: {
    borderRadius: 14,
    padding: 14,
    gap: 12,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  detailIcon: {
    fontSize: 18,
    marginTop: 2,
  },
  detailLabel: {
    fontSize: 11,
    marginBottom: 2,
  },
  detailValue: {
    fontSize: 13.5,
    fontWeight: '600',
  },
  helperCard: {
    borderRadius: 14,
    padding: 12,
  },
  helperRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  helperAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
  },
  helperAvatarText: {
    fontSize: 26,
  },
  helperName: {
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 2,
  },
  helperRating: {
    fontSize: 12,
  },
  statsGrid: {
    flexDirection: 'row',
    borderWidth: 1,
    borderRadius: 14,
    overflow: 'hidden',
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
  },
  statValue: {
    fontSize: 15,
    fontWeight: '800',
  },
  statLabel: {
    fontSize: 11,
    marginTop: 2,
  },
  statDivider: {
    width: 1,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  ratingStars: {
    fontSize: 20,
  },
  ratingValue: {
    fontSize: 16,
    fontWeight: '700',
  },
  reviewText: {
    fontSize: 13.5,
    fontStyle: 'italic',
    lineHeight: 20,
  },
  ratedDate: {
    fontSize: 11,
  },
  actionButton: {
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: 'center',
    marginBottom: 10,
  },
  actionButtonText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#fff',
  },
  errorText: {
    fontSize: 14,
  },
});
