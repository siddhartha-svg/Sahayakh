# Sahayakh Mobile App

Production React Native mobile app for Sahayakh customer platform, built with Expo, TypeScript, and Zustand.

## Features Implemented

### Home Screen
- ✅ Logo and branding
- ✅ Personal/Business mode selection with theme switching
- ✅ Features grid (4 core benefits)
- ✅ Action buttons (Create Task, View Tasks)
- ✅ Promotional banner
- ✅ Animated mode card transitions

### Navigation
- ✅ Tab-based navigation (Home, Tasks, Support, Account)
- ✅ Real navigation stack (not prototype state)
- ✅ Auth-aware routing (redirects to login if not authenticated)
- ✅ Theme context integration

### Design System
- ✅ Color variables for personal/business modes
- ✅ Typography system (Plus Jakarta Sans)
- ✅ Button component with variants (primary, secondary, ghost)
- ✅ Safe area awareness
- ✅ Responsive layout

### State Management
- ✅ Auth store (user, token, login/logout)
- ✅ Task creation store
- ✅ Navigation stack store
- ✅ Theme store (mode, color mode toggle)
- ✅ Persistent storage via AsyncStorage

### API Integration
- ✅ Axios client with request/response interceptors
- ✅ Bearer token auth
- ✅ 401 auto-logout
- ✅ All backend endpoints available

## Project Structure

```
packages/mobile/
├── src/
│   ├── api/               # API client and endpoints
│   ├── components/        # Reusable UI components
│   ├── screens/           # Screen components
│   ├── navigation/        # Navigation structure
│   ├── store/            # Zustand stores
│   ├── theme/            # Design system
│   ├── assets/           # Images, fonts, icons
│   └── App.tsx           # Root component
├── app.json              # Expo configuration
├── babel.config.js       # Babel config
├── index.js              # Entry point
└── package.json          # Dependencies

```

## Quick Start

### Prerequisites
- Node.js 18+
- npm or yarn
- Expo CLI: `npm install -g expo-cli`

### Installation

```bash
# Install dependencies
cd packages/mobile
npm install

# Create .env from example
cp .env.example .env

# Edit .env with your backend URL
nano .env
```

### Running the App

```bash
# Start Expo dev server
npm start

# Open on iOS (macOS only)
npm run ios

# Open on Android (if emulator running)
npm run android

# Open on web (for development)
npm run web
```

### Building for Production

```bash
# Build for Android
npm run build:android

# Build for iOS
npm run build:ios

# Both platforms
npm run build
```

## Architecture

### Design System
- **Colors**: Personal (green #1B7A3E) and Business (blue #1D58BD) modes
- **Typography**: Plus Jakarta Sans with 8 size scales
- **Components**: Button, Card, Modal, Input (to be added)
- **Theme Context**: Zustand store for mode + colorMode switching

### State Management
All state is managed via Zustand stores:
- `useAuthStore`: User authentication state
- `useTaskStore`: Task creation form state
- `useNavigationStore`: Navigation history
- `useTheme`: Theme/mode switching

### Navigation
- **Root**: Conditional (Auth or Tabs)
- **Auth**: Single stack (Login, Verify OTP, Complete Profile)
- **Tabs**: 4 bottom tabs with nested stacks (Home, Tasks, Support, Account)
- **Modals**: Global sheets for task creation, helper selection, etc.

### API Communication
- Single axios instance with automatic auth headers
- Automatic 401 logout on expired tokens
- Error handling and response transformation
- All 20+ backend endpoints pre-configured

## Features to Implement Next

### Screens (8 remaining)
1. **Create Task** - Multi-step form with location, photos, budget
2. **Finding Helpers** - Loading state with radar animation
3. **Available Helpers** - List view with sorting/filtering
4. **Helper Profile** - Detailed profile with reviews/skills
5. **Confirm Task** - Order review with payment options
6. **Task Tracking** - Real-time location + status steps
7. **Task Completion** - Rating and review submission
8. **Task Details** - Historical task view

### Components to Build
- Input field with validation
- ImagePicker for photos
- Location picker with map
- Modal/BottomSheet for dialogs
- Card components
- Status indicators
- Rating stars
- Avatar display

### Integrations
- Push notifications (FCM/APNs)
- Location services (GPS tracking)
- Image upload to S3
- Payment gateway (Razorpay)
- Real-time WebSocket (Socket.io)

## Configuration

### Environment Variables

```env
# .env
EXPO_PUBLIC_API_URL=http://localhost:3000/api
EXPO_PUBLIC_APP_ENV=development
EXPO_PUBLIC_SOCKET_URL=http://localhost:3000
```

### Fonts
Install Plus Jakarta Sans:
```bash
# Download from Google Fonts
# Place in src/assets/
# Pre-load in App.tsx via expo-font
```

### App.json Settings
- Bundle ID: `com.sahayakh.app`
- Package: `com.sahayakh.app`
- Scheme: `sahayakh://`
- EAS Project ID: (configure after setup)

## Testing

```bash
# Run Jest tests
npm test

# Watch mode
npm test -- --watch

# Coverage
npm test -- --coverage
```

## Type Safety

```bash
# Type check without building
npm run type-check

# Full build check
npm run build
```

## Development Workflow

1. **Feature branch**: `git checkout -b feature/screen-name`
2. **Test in Expo**: `npm start` → scan QR code
3. **Type check**: `npm run type-check`
4. **Lint**: `npm run lint`
5. **Commit**: Standard format
6. **PR**: Link to issue, test checklist

## Performance Optimization

- ✅ Lazy component imports
- ✅ Memoized components
- ✅ Redux DevTools for debugging
- ✅ Image compression
- ✅ Code splitting ready

## Troubleshooting

### Expo won't start
```bash
rm -rf node_modules package-lock.json
npm install
npm start -- --clear
```

### Can't connect to backend
- Check `EXPO_PUBLIC_API_URL` in `.env`
- Ensure backend is running on that port
- On Android emulator: use `10.0.2.2` instead of `localhost`
- On iOS: use actual machine IP

### TypeScript errors
```bash
npm run type-check
# Fix errors or update tsconfig.json
```

### Build fails
```bash
npx expo prebuild --clean
npm run build
```

## Next Steps

1. ✅ Home screen with mode selection (DONE)
2. → Create Task form and flow
3. → Helper discovery and matching
4. → Real-time task tracking
5. → Payment integration
6. → Push notifications
7. → Admin dashboard (separate package)

## Documentation

- [Expo Documentation](https://docs.expo.dev)
- [React Native Docs](https://reactnative.dev)
- [Zustand Guide](https://github.com/pmndrs/zustand)
- [TypeScript Handbook](https://www.typescriptlang.org/docs)

## License

Proprietary - Sahayakh Platform
