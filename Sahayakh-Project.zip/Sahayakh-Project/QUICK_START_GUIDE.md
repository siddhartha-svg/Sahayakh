# Sahayakh Quick Start Guide

## 🚀 Getting Started

### 1. Install Dependencies
```bash
npm install
```

### 2. Generate Prisma Client
```bash
npx prisma generate
```

### 3. Set Up Database
```bash
# Create/migrate database
npx prisma migrate dev

# Seed sample data
npm run db:seed

# (Optional) View data in Prisma Studio
npx prisma studio
```

### 4. Start Development Server
```bash
npm run dev:backend
```

Server will start on `http://localhost:3000`

Health check: `GET http://localhost:3000/health`

---

## 📱 Testing the APIs

### Authentication Flow
```bash
# 1. Register (phone + OTP)
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "phone_number": "+919876543210",
    "name": "Test User",
    "role": "customer"
  }'
# Response: { "otp_sent": true, "expires_in": 120 }

# 2. Verify OTP (check logs for OTP in development)
curl -X POST http://localhost:3000/api/auth/verify-otp \
  -H "Content-Type: application/json" \
  -d '{
    "phone_number": "+919876543210",
    "otp_code": "123456"
  }'
# Response: { "access_token": "...", "refresh_token": "...", "user_id": "...", "role": "customer" }

# 3. Get current user
curl -X GET http://localhost:3000/api/auth/me \
  -H "Authorization: Bearer <access_token>"
```

### Task Creation & Matching Flow
```bash
# 1. Create task
curl -X POST http://localhost:3000/api/tasks \
  -H "Authorization: Bearer <customer_token>" \
  -H "Content-Type: application/json" \
  -d '{
    "task_type": "personal",
    "category": "pickup_delivery",
    "description": "Pick up medicine from Apollo Pharmacy",
    "location_name": "Apollo Pharmacy, Hanamkonda",
    "location_point": {"latitude": 17.36, "longitude": 78.48},
    "preferred_date": "2026-09-25",
    "preferred_time": "14:30",
    "budget_min": 150,
    "budget_max": 300
  }'
# Response: { "task": { ... }, "estimated_price_range": { "min": ..., "max": ... } }

# 2. Find nearby helpers
curl -X GET "http://localhost:3000/api/tasks/<task_id>/helpers/nearby?sort_by=nearest" \
  -H "Authorization: Bearer <customer_token>"
# Response: { "helpers": [ { name, rating, distance_km, ... } ], "count": 5 }

# 3. Assign helper (triggers 45-second request)
curl -X POST http://localhost:3000/api/tasks/<task_id>/assign \
  -H "Authorization: Bearer <customer_token>" \
  -H "Content-Type: application/json" \
  -d '{"helper_id": "<helper_id>"}'
# Response: { "task": { ... }, "message": "Helper assigned successfully" }
```

### Helper Request Flow (45-Second Countdown)
```bash
# 1. Helper connects via WebSocket
# See WebSocket client examples below

# 2. Helper receives request (via Socket.IO)
# Event: request:new
# Data: { request_id, task_id, title, distance_km, payment_estimate, countdown_sec: 45 }

# 3. Helper accepts
curl -X POST http://localhost:3000/api/requests/<request_id>/accept \
  -H "Authorization: Bearer <helper_token>"
# Response: { "request": { "status": "accepted" }, "message": "..." }

# 4. Customer receives notification (via Socket.IO)
# Event: request:accepted
# Data: { task_id, helper_id, helper_name, status: "assigned" }
```

---

## 🔌 WebSocket Testing

### Using node-gyp WebSocket client
```bash
# Install ws client
npm install ws
```

### Helper Connects
```javascript
const WebSocket = require('ws');

const socket = new WebSocket('ws://localhost:3000/socket.io/?transport=websocket', {
  headers: { Authorization: 'Bearer <helper_token>' }
});

socket.on('open', () => {
  console.log('Connected');
  // Subscribe to location
  socket.send(JSON.stringify({
    type: 'subscribe_location',
    data: { zoneId: 'warangal:north', helperId: '<helper_id>' }
  }));
});

socket.on('message', (data) => {
  const event = JSON.parse(data);
  console.log('Event:', event);
  
  if (event.type === 'request:new') {
    console.log('New task received!');
    console.log('Countdown:', event.data.countdown_sec, 'seconds');
  }
});
```

### Using Socket.IO Client
```bash
# Install socket.io-client
npm install socket.io-client
```

```javascript
const io = require('socket.io-client');

// Helper connection
const helperSocket = io('http://localhost:3000/helpers');

helperSocket.on('connect', () => {
  console.log('Connected to helpers namespace');
  helperSocket.emit('subscribe_location', {
    zoneId: 'warangal:north',
    helperId: '<helper_id>'
  });
});

helperSocket.on('request:new', (data) => {
  console.log('Task request:', data);
  // Start countdown UI
  console.log(`Countdown: ${data.countdown_sec} seconds`);
});

helperSocket.on('request:expired', () => {
  console.log('Request expired');
});

// Customer connection
const customerSocket = io('http://localhost:3000/customers');

customerSocket.on('connect', () => {
  console.log('Connected to customers namespace');
  customerSocket.emit('subscribe_task', {
    taskId: '<task_id>',
    customerId: '<customer_id>'
  });
});

customerSocket.on('request:accepted', (data) => {
  console.log('Helper accepted:', data.helper_name);
});

customerSocket.on('request:declined', (data) => {
  console.log('Helper declined:', data.reason);
});
```

---

## 🧪 Running Tests

```bash
# Run all tests
npm run test --workspace=packages/backend

# Run tests in watch mode
npm run test:watch --workspace=packages/backend

# Run specific test file
npm run test -- requests.test.ts --workspace=packages/backend

# Run with coverage
npm run test:coverage --workspace=packages/backend
```

---

## 📋 Key Endpoints Summary

| Method | Endpoint | Auth | Purpose |
|--------|----------|------|---------|
| POST | `/api/auth/register` | - | Register with phone + OTP |
| POST | `/api/auth/verify-otp` | - | Verify OTP → get tokens |
| POST | `/api/auth/refresh` | - | Refresh access token |
| GET | `/api/auth/me` | ✅ | Get current user |
| POST | `/api/tasks` | ✅ | Create task |
| GET | `/api/tasks/:id/helpers/nearby` | ✅ | Find nearby helpers |
| POST | `/api/tasks/:id/assign` | ✅ | Assign helper (starts 45s timer) |
| POST | `/api/requests/:id/accept` | ✅ | Accept request |
| POST | `/api/requests/:id/decline` | ✅ | Decline request |

---

## 🔍 Debugging

### Enable Logs
```bash
# Set in .env
DEBUG=*
LOG_LEVEL=debug
```

### Database Inspection
```bash
# Open Prisma Studio
npx prisma studio

# Direct SQL query
psql -U postgres -d sahayakh_dev -c "SELECT * FROM \"TaskRequest\";"
```

### Redis Inspection
```bash
# Connect to Redis CLI
redis-cli

# Check active requests
KEYS "request:*"
GET "request:task_id:helper_id"
TTL "request:task_id:helper_id"
```

### Socket.IO Debug
```bash
# In .env
DEBUG=socket.io:*
```

---

## 📊 Sample Data

After running `npm run db:seed`, you have:
- 5 helpers (Rohit Kumar, Sneha Verma, Anil Reddy, Priya Singh, Raj Patel)
- 4 customers (Alice, Bob, Carol, Dave)
- 22 sample tasks
- 10 payments
- 3 payouts

Use these to test the APIs:
```bash
# Customer token (Alice)
curl ... -H "Authorization: Bearer <alice_token>"

# Helper token (Rohit)
curl ... -H "Authorization: Bearer <rohit_token>"
```

---

## 🚨 Common Issues

### "Database does not exist"
```bash
createdb sahayakh_dev
npx prisma migrate dev
```

### "Redis connection refused"
```bash
# Start Redis
redis-server

# Or with Docker
docker run -d -p 6379:6379 redis:latest
```

### "Module not found"
```bash
npm install
npx prisma generate
```

### "Socket.IO not connecting"
- Check CORS origin in config
- Verify server is running on correct port
- Check browser console for errors

### "OTP never arrives"
In development, OTP is logged to console:
```
✓ OTP generated: 123456
```

---

## 📚 Documentation Files

- **SAHAYAKH_PRD.md** - Complete product requirements
- **SAHAYAKH_SYSTEM_ARCHITECTURE.md** - Technical architecture & API specs
- **TASK_API_IMPLEMENTATION.md** - Task creation & matching details
- **HELPER_REQUEST_FLOW_IMPLEMENTATION.md** - 45-second countdown details
- **IMPLEMENTATION_SUMMARY.md** - Overview of all features

---

## 🎯 Next Steps

1. ✅ Server running locally
2. ✅ Tests passing
3. ⬜ Connect frontend to Socket.IO
4. ⬜ Implement countdown UI in helper app
5. ⬜ Implement accept/decline UI in helper app
6. ⬜ Implement status tracking in customer app
7. ⬜ Test end-to-end flow
8. ⬜ Deploy to staging

---

## 🤝 Support

- Check error responses for error codes and messages
- Review test files for usage examples
- Check console logs for detailed debugging
- Refer to SAHAYAKH_SYSTEM_ARCHITECTURE.md for API specs

---

**Happy testing! 🚀**
