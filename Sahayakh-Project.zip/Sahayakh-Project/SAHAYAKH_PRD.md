# Sahayakh - Product Requirements Document (PRD)

**Version:** 1.0  
**Last Updated:** September 2026  
**Status:** In Development  
**Product:** Hyperlocal Task/Errand Marketplace  
**Location Focus:** Warangal, India  
**Author:** Based on HTML Prototypes Analysis

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Product Overview](#product-overview)
3. [User Roles & Personas](#user-roles--personas)
4. [Core Platforms](#core-platforms)
5. [Feature Specifications](#feature-specifications)
6. [Task Lifecycle](#task-lifecycle)
7. [OTP Verification System](#otp-verification-system)
8. [Pricing & Fee Model](#pricing--fee-model)
9. [Payment Flow](#payment-flow)
10. [Helper Payouts](#helper-payouts)
11. [Disputes & Resolution](#disputes--resolution)
12. [Admin Controls](#admin-controls)
13. [Ambiguities & Decisions Required](#ambiguities--decisions-required)
14. [Success Metrics](#success-metrics)

---

## Executive Summary

**Sahayakh** is a three-sided hyperlocal marketplace connecting customers who need help with everyday tasks to verified helpers/gig workers who complete them for a fee. The platform operates in Warangal, India, and takes a 15% commission on each transaction.

### Key Values
- **For Customers:** Convenience, reliability, transparency
- **For Helpers:** Flexible earning opportunity, fair pay, safety
- **For Platform:** Revenue (15% take), scale, quality control

### Business Model
- Commission: 15% of task value
- Payment: Both "pay now" and "pay after" options supported
- Market: Initial focus on Warangal, scalable to other Indian cities

---

## Product Overview

### What Sahayakh Does
Sahayakh enables customers to post tasks they need help with and connect them with verified helpers in their local area. The platform manages the entire transaction lifecycle from task posting through completion, payment, and ratings.

### Core Problem Solved
- **For Customers:** Finding trustworthy, vetted people to help with local tasks
- **For Helpers:** Discovering nearby opportunities to earn money on flexible schedules
- **For Platform:** Building a sustainable marketplace with trust, quality, and safety

### Geographic Scope
**Initial Launch:** Warangal, Telangana, India  
**Expansion Strategy:** Other tier-2 cities (to be determined)

---

## User Roles & Personas

### 1. **Customer (Task Poster)**

#### Primary Characteristics
- Age: 25-55 years
- Tech-savvy to moderate smartphone users
- Willing to outsource tasks they don't have time for
- Primary concern: Trust, timeliness, proof of work

#### Use Cases
- **Personal Tasks:** Pick up medicine, submit documents, visit family, check on property
- **Business Tasks:** Deliver documents, collect invoices, site visits, errands

#### Needs
- Browse helpers with ratings & reviews
- Post tasks with clear descriptions & budgets
- Real-time tracking of helper's location
- Ability to communicate with helper
- Proof of completion (photos, receipts)
- Clear pricing upfront

#### Pain Points
- Finding trustworthy helpers
- Lack of transparency in pricing
- No proof of work completion
- Difficulty in communication

---

### 2. **Helper (Gig Worker)**

#### Primary Characteristics
- Age: 20-55 years
- Looking for flexible income generation
- Local knowledge of Warangal geography
- Primary concern: Fair pay, safety, consistent work

#### Profile Requirements
- Must be 18+ years old
- Must pass background verification
- Must have phone capable of GPS & photography
- Must be able to travel within Warangal

#### Needs
- Clear task discovery mechanism
- Fair pricing with transparent earnings
- Flexibility in accepting/rejecting tasks
- Safety (emergency contact, task verification)
- Timely payments
- Ability to build reputation

#### Pain Points
- Lack of consistent work opportunities
- Unfair pricing in competing platforms
- Delayed payments
- No protection against false accusations

---

### 3. **Admin/Operations Team**

#### Primary Characteristics
- Manages platform health, quality, and disputes
- Monitors financial metrics
- Handles customer support escalations
- Enforces policies and guidelines

#### Responsibilities
- Approve new helper applications
- Monitor task completion quality
- Resolve disputes between customers & helpers
- Process payouts
- Set pricing rules
- Monitor key metrics

#### Needs
- Real-time dashboard with KPIs
- Ability to verify documents & background checks
- Dispute resolution tools
- Payment management interface
- Pricing flexibility
- Analytics & reporting

---

## Core Platforms

### 1. **Helper App (Mobile - Android/iOS)**

**Purpose:** Help gig workers discover, accept, and complete tasks

#### Key Screens (from prototype)
- **Home:** Online/offline toggle, available tasks, today's earnings
- **Task Request:** Task details, customer info, payment estimate, countdown timer
- **Navigation:** Live tracking, customer details, contact options
- **OTP Verification:** Enter 6-digit OTP to confirm arrival
- **Task In Progress:** Checklist of steps, photo uploads, time/distance tracker
- **Summary:** Review earnings breakdown before submission
- **Completion:** Success screen, rating opportunity, bonus notification

#### Primary Functions
- Real-time task notifications
- Accept/decline tasks with 45-second countdown
- Navigation to task location
- OTP-based arrival verification
- Task completion with checklist & photo proof
- Real-time earnings tracking
- Direct chat with customers
- Weekly payout withdrawals

#### Technical Constraints
- GPS tracking required
- Camera access for photo upload
- Location services always-on during active task
- Push notifications critical

---

### 2. **Customer App (Mobile - Android/iOS)**

**Purpose:** Allow customers to post tasks and find helpers

#### Key Screens (from prototype)
- **Home:** Quick mode selection (Personal/Business)
- **Task Creation:** Description, location, date/time, budget, photos
- **Helper Search:** Discovery with filters (rating, distance, price)
- **Helper Profile:** Reviews, skills, background check status
- **Task Confirmation:** Payment method selection, booking confirmation
- **Live Tracking:** Real-time helper location on map
- **Task Completion:** Rating & review submission
- **Earnings History:** Task history & withdrawal management

#### Primary Functions
- Create tasks (personal & business categories)
- Search & filter helpers by rating/distance/price
- View detailed helper profiles
- Real-time task tracking
- Chat with helper
- Rate & review after completion
- Task history & analytics

#### Technical Constraints
- Maps integration (Google Maps or Mapbox)
- Payment gateway integration
- Photo upload capability
- Real-time location updates

---

### 3. **Admin Dashboard (Web)**

**Purpose:** Manage platform operations, helpers, disputes, and financials

#### Key Screens (from prototype)
- **Overview:** Real-time KPIs, activity feed, attention items
- **Helper Approvals:** Document verification, background check status
- **Helpers:** Search, filter, manage status (online/offline/suspended)
- **Tasks:** Monitor live task progress, assign helpers, resolve issues
- **Disputes:** Review conversations, mediate, resolve with refunds/warnings
- **Payouts:** Process withdrawal requests, track payment status
- **Pricing:** Configure base fare, per-km charge, per-minute charge, fees

#### Primary Functions
- Real-time monitoring of platform activity
- Helper verification & approval workflow
- Helper account management (suspend/reactivate)
- Task assignment & troubleshooting
- Dispute investigation & resolution
- Payout processing
- Dynamic pricing configuration
- Key metrics tracking & analytics

#### Technical Constraints
- Desktop-first design (can be responsive)
- Real-time data updates (WebSockets)
- Document verification tools
- Payment processing integration

---

## Feature Specifications

### 1. **Task Creation & Management**

#### Task Categories
```
Personal Tasks:
- Pickup & Delivery (medicine, parcels, documents)
- Local Visits (check on property, visit family, queue management)
- Document Work (bill payment, government office submissions)
- Other (flexible category)

Business Tasks:
- Vendor Pickups (collect orders, invoices)
- Client Deliveries (deliver samples, documents)
- Site Visits (inspections, progress photos)
- Bank/GST Office (form submission, acknowledgment collection)
- Other (flexible category)
```

#### Task Attributes
```
Required:
- Title (short description)
- Description (detailed task explanation)
- Category (personal/business + subcategory)
- Location (customer address with map pin)
- Date & Time (preferred date/time for task)
- Budget (min-max range, e.g., ₹150-300)

Optional:
- Photos (up to 3 photos showing context)
- Special Instructions (notes for helper)
- Business Name (if business task)
- GST Bill Required (checkbox for business tasks)
```

#### Task Status Flow
```
Unassigned → Assigned → On the Way → Reached → 
In Progress → Review/Complete → Completed
(or Cancelled at any point)
```

#### Task Discovery (Helper App)
- Real-time notifications for new tasks
- 45-second countdown timer before auto-expiring
- Display: Distance, ETA, estimated earnings range
- Helper can accept/decline (once declined, cannot re-accept)
- Multiple helpers can see same task; first to accept gets it

---

### 2. **Helper Profile & Verification**

#### Helper Onboarding
```
Step 1: Phone Registration
- Phone number verification via OTP
- Profile creation (name, photo, location)

Step 2: Background Verification
- Government ID (Aadhaar/PAN/DL)
- Selfie for face matching
- Bank account details for payouts

Step 3: Admin Review
- Admin reviews documents
- Runs background check (third-party service)
- Approves or requests revisions

Step 4: Activation
- Helper can go online and accept tasks
```

#### Helper Profile Information
```
Public (Visible to Customers):
- Name & Photo
- Overall Rating (average of all reviews)
- Number of Tasks Completed
- Response Time (average)
- Skills/Categories (what they accept)
- Recent Reviews (last 3-5)

Private (Admin Only):
- Phone Number
- Government ID
- Verification Status
- Background Check Result
- Bank Account Details
- Historical Earnings
- Dispute History
- Suspension Status
```

#### Helper Status States
```
Active:      Can accept tasks, visible to customers
Online:      Currently active and accepting tasks
Offline:     Not accepting tasks temporarily
Suspended:   Cannot accept tasks, hidden from customers (due to complaints/violations)
Inactive:    No activity for extended period
```

---

### 3. **Customer Profile & Payment Methods**

#### Customer Registration
```
Step 1: Phone Registration
- Phone number with OTP verification
- Basic profile (name, address)

Step 2: Payment Setup
- Add payment method (UPI/Card/Bank)
- Verify payment method

Step 3: Ready to Post
- Can immediately create and post tasks
```

#### Payment Methods Supported
```
Primary (India):
- UPI (Google Pay, PhonePe, Paytm)
- Credit/Debit Cards
- Bank Transfer (NetBanking)

Future:
- Digital Wallets
- Buy Now Pay Later
```

---

## Task Lifecycle

### Complete Task Journey

```
PHASE 1: TASK CREATION
├─ Customer creates task with details, budget, location
├─ Task status: UNASSIGNED
├─ Notification sent to nearby available helpers
└─ 45-second countdown begins for auto-expiry

PHASE 2: HELPER ACCEPTANCE
├─ Helper sees task notification
├─ Helper can accept or decline
├─ First helper to accept gets the task
├─ Task status: ASSIGNED
├─ OTP generated (6 digits)
├─ Customer notified of assigned helper
├─ Helper notified with customer details
└─ 30-minute timer: Helper must reach location

PHASE 3: NAVIGATION TO LOCATION
├─ Task status: ON_THE_WAY
├─ Helper navigates using in-app maps
├─ Real-time location updates sent to customer
├─ Customer can contact helper via chat
├─ Helper can request help via support
└─ Timer shows: Time until ETA

PHASE 4: ARRIVAL & VERIFICATION
├─ Helper reaches location
├─ Helper requests OTP from customer (in-app or verbal)
├─ Task status: REACHED
├─ Customer provides 6-digit OTP
├─ Helper enters OTP in app to verify arrival
├─ If OTP correct: Task transitions to IN_PROGRESS
├─ If OTP wrong (after 3 attempts): Admin involvement required
└─ Timer starts: Task completion timer

PHASE 5: TASK EXECUTION
├─ Task status: IN_PROGRESS
├─ Helper completes task steps (shown as checklist)
├─ Helper takes photos as proof (required: at least 1)
├─ Helper notes any issues (optional)
├─ Timer shows: Time elapsed, distance covered
├─ Customer can contact helper if needed
└─ Helper cannot submit without completing all steps + ≥1 photo

PHASE 6: REVIEW & COMPLETION
├─ Helper submits task
├─ Task status: REVIEW (pending customer acceptance)
├─ Summary shows:
│  - Distance traveled
│  - Time taken
│  - Photos uploaded
│  - Amount to be paid to helper
│  - Amount paid to platform
├─ System auto-approves if no customer dispute within 24 hours
├─ Customer can dispute (triggers admin review) or accept
└─ Upon acceptance/auto-approval: Status = COMPLETED

PHASE 7: PAYMENT & RATING
├─ Task status: COMPLETED
├─ Payment processed immediately (or per payment method)
├─ Customer receives payment confirmation
├─ Helper receives payout (within 24-48 hours)
├─ Both parties can rate each other (1-5 stars + review text)
├─ Rating becomes visible on profiles after 24 hours
└─ Task moves to history
```

### Task Cancellation

#### By Customer
```
Before Assignment:
- Full refund if payment was collected
- Task immediately marked as cancelled

After Assignment:
- Cancellation Fee: ₹30 (or per TBD rule)
- Helper gets cancellation fee
- Remaining balance refunded to customer

After Task Started:
- NOT allowed without admin approval
- Requires dispute resolution
```

#### By Helper
```
Before Acceptance:
- Can simply decline (no penalty)

After Acceptance but Before Reaching:
- Cancellation Fee: ₹30 (paid by helper to platform, not customer)
- Task reassigned to next available helper
- Customer refunded full amount

During/After Task Started:
- NOT allowed without admin approval
- Requires dispute resolution
```

#### Auto-Cancellation
```
If Helper doesn't reach within 30 minutes of acceptance:
- Task auto-cancels
- Helper gets cancelled (not completion bonus)
- Task relisting available to other helpers
- Customer notified, can re-post
```

---

## OTP Verification System

### OTP Generation & Validation

#### When OTP is Generated
1. **At task acceptance** (immediately after helper accepts)
2. **Unique per task** (not per helper; can't reuse across tasks)
3. **6 digits** (100,000 different combinations)
4. **Valid for 2 hours** (or per requirements TBD)
5. **Single-use** (once entered correctly, becomes invalid)

#### OTP Delivery Methods
```
Primary: In-app notification to customer
Secondary: SMS to customer phone number
Tertiary: Customer reads from app screen and shares verbally
```

#### OTP Verification Flow

```
Helper Arrives at Location
  ↓
Helper taps "I've Reached" in app
  ↓
OTP sent to customer via push notification + SMS
  ↓
Helper can request customer to share OTP in-app
(or request verbally and enter what customer says)
  ↓
Helper enters OTP in app (6 input fields)
  ↓
System validates OTP
  ↓
If Correct:
├─ Task status changes to IN_PROGRESS
├─ Timer starts (tracking time spent on task)
├─ Customer can no longer cancel without losing money
└─ Helper begins task checklist

If Wrong:
├─ Error message shown
├─ Attempt counter incremented
├─ Helper can retry immediately
├─ After 3 failed attempts:
│  └─ Task flagged for admin review
│     (possible OTP request from different helper)
└─ Customer can share new OTP
```

### OTP Abuse Prevention

#### Security Measures
```
1. Rate limiting: Max 10 OTP requests per task per hour
2. Verification delay: Helper can only request OTP every 30 seconds
3. Attempt limit: Max 3 wrong entries before admin escalation
4. Auto-expiry: OTP expires after 2 hours (or TBD)
5. Single-use: Once correct entry, OTP becomes invalid
6. Timestamp logging: All OTP requests/entries logged for audit
```

#### When Admin Involvement is Triggered
```
- 3 consecutive wrong OTP entries
- Helper location inconsistent with stated location
- OTP requested but customer unreachable
- Task time exceeds reasonable bounds
```

---

## Pricing & Fee Model

### Fee Structure

#### Platform Commission
```
Standard Calculation:
1. Customer-stated budget or agreed task price
2. Dynamic surcharges (optional):
   - Distance surcharge: ₹X per km beyond 2 km
   - Time surcharge: ₹X per minute beyond 30 minutes
   - Peak hour surcharge: 1.25x multiplier during 6-10pm
3. Platform fee: 15% of final amount
4. Helper earns: 85% of final amount
5. Sahayakh keeps: 15% of final amount

Example:
Customer budget: ₹100
Distance surcharge: 0 (within 2km)
Time surcharge: ₹10 (50 min task, 20 min extra)
Peak surcharge: Not applicable
Final amount: ₹110

Sahayakh fee (15%): ₹16.50
Helper payout: ₹93.50
```

#### Task Type Multipliers
```
Personal Tasks: 1.0x (base rate)
Business Tasks: 1.25x (higher value tasks)
Rush/Same-day: 1.2x multiplier
Evening (6pm-11pm): 1.1x multiplier
Night (11pm-6am): Not available in MVP
```

#### Minimum & Maximum Amounts
```
Minimum per task: ₹80-100 (TBD)
Maximum per task: No limit initially
Daily earnings cap per helper: No limit initially
```

#### Admin Pricing Configuration
```
Base fare (not component, but starting reference): ₹40
Per-km charge: ₹15 per km
Per-minute charge: ₹2.50 per minute
Minimum fare: ₹80
Cancellation fee: ₹30
Helper takes: 85%
Platform takes: 15%

Note: Distance/time surcharges may be automatic
or negotiated per task. Prototype shows "estimated"
range (e.g., ₹150-300) which is dynamic.
```

---

## Payment Flow

### Payment Options

#### Option 1: "Pay After Completion" (Default)

```
Workflow:
1. Customer creates task with budget
2. Helper accepts task
3. Task is completed
4. Admin/system confirms completion
5. Payment is initiated
6. Payment reaches helper account within 24-48 hours
7. Sahayakh takes 15% immediately

Advantages:
- Customer only pays if task is done
- Lower friction for customer
- Encourages quality work from helpers

Disadvantages:
- Helper bears risk of non-payment
- Requires trust in platform
- Possible payment disputes
```

#### Option 2: "Pay Now" (Pre-authorization)

```
Workflow:
1. Customer creates task and chooses "Pay Now"
2. Payment method selection screen
3. Customer authorizes ₹X + platform fee
4. Payment processed immediately
5. Helper notified of confirmed payment
6. Task proceeds normally
7. Full amount minus platform fee goes to helper

Advantages:
- Helper has certainty of payment
- No payment disputes post-task
- Customer commits (reduces cancellations)

Disadvantages:
- Customer friction (must pre-pay)
- Customer must refund if task fails
- Lower conversion for "try it" customers
```

### Customer Payment Process

#### Payment Method Selection
```
Screen displays:
1. Task details
2. Final amount breakdown:
   - Base amount: ₹X
   - Distance/time adjustment: ±₹Y
   - Platform fee (15%): ₹Z
   - Total: ₹(X+Y+Z)
3. Payment method options:
   ☑ Pay After (default)
   ☐ Pay Now (requires immediate payment)
4. If Pay Now selected:
   - Choose payment method (UPI/Card/Bank)
   - Enter details or authorize saved method
   - One-time password for verification
   - Confirmation screen
```

#### Payment Failure Handling
```
If payment fails:
- Customer notified immediately
- Task remains unassigned
- Customer can retry with same or different method
- After 3 failed attempts: Task automatically cancelled
- No funds charged to customer
```

### Refund & Dispute Scenarios

#### Automatic Refunds
```
1. Helper doesn't reach within 30 min → Full refund
2. Helper cancels after 10 min start → Full refund
3. Customer cancels before assignment → Full refund
4. System error prevents completion → Full refund
```

#### Disputed/Manual Refunds
```
Scenarios requiring admin decision:
1. Helper completed but customer disputes quality
2. Helper partially completed task
3. Customer claims task wasn't done
4. OTP disputes (false arrival claims)
5. Both parties disagreeing on final outcome

Admin determines:
- Percentage refund to customer (0-100%)
- Percentage payout to helper (0-100%)
- Warning/suspension for either party if applicable
```

---

## Helper Payouts

### Payout Schedule

#### Weekly Payouts (Recommended)
```
Cutoff: Sunday 11:59 PM
Processing: Monday-Tuesday
Delivery: Wednesday (within 24-48 hours)
Method: Automated bank transfer/UPI
```

#### On-Demand Payouts
```
Request anytime: Yes (fee: ₹10-20 per withdrawal, TBD)
Processing time: 24 hours
Methods: Direct to bank account or UPI
Minimum withdrawal: ₹100
Maximum per day: No limit (initially)
```

#### Payout Breakdown (Helper App View)
```
Earnings Summary shows:
- Today's earnings: ₹XXX
- This week's earnings: ₹XXX
- Pending (in review): ₹XXX
- Available to withdraw: ₹XXX
- Total lifetime earnings: ₹XXX

Detailed history by task:
- Task ID
- Customer name
- Amount earned (before platform fee shown)
- Amount charged as fee
- Net received
- Date completed
- Payment status (Pending/Paid/Failed)
```

#### Payout Methods
```
Primary: Bank account transfer (NEFT/IMPS)
Secondary: UPI ID
Tertiary: Digital wallet (if integrated)

Requirements:
- Helper must have verified bank account on file
- Account must be in helper's name
- Account must be active (tested with small transfer)
```

#### Failed Payouts
```
Reasons:
1. Invalid bank account details
2. Account closed/frozen
3. Name mismatch (account name ≠ helper registered name)
4. Technical error from bank
5. Dispute flag on account

Resolution:
1. Admin notifies helper of failure
2. Helper updates bank details
3. Re-attempt triggered manually
4. Max 3 auto-retry attempts
5. After 3 failures: Manual support required
```

### Payout Withholding

#### Reasons to Withhold Payout (Temporary)
```
1. Incomplete task (under admin review)
2. Dispute flagged (under investigation)
3. Multiple complaints (temporary hold while reviewing)
4. Account verification pending
5. Background check pending
```

#### Reasons to Withhold/Cancel Payout (Permanent)
```
1. Helper account suspended (due to violations)
2. Helper disputes not yet resolved
3. Helper engaged in fraud
4. Bank account verification failed
5. Helper requested account deletion
```

---

## Disputes & Resolution

### Dispute Types

#### Category 1: Quality Issues
```
- Task not completed properly
- Photos don't show actual completion
- Helper didn't follow instructions
- Partially completed task
- Damaged items during task

Example:
Customer says: "Helper picked up medicine but 
forgot to include receipt. I can't verify authenticity."
```

#### Category 2: Pricing Issues
```
- Final amount exceeds agreed budget significantly
- Hidden charges added unexpectedly
- Distance/time calculation seems wrong
- Unclear fee breakdown

Example:
Customer says: "I agreed to ₹150-200 but was charged ₹350. 
Justification of distance/time seems inflated."
```

#### Category 3: Behavior Issues
```
- Helper was rude/unprofessional
- Helper asked for tips/extra payment
- Helper was dishonest about completion
- Safety concerns

Example:
Helper says: "Customer was rude and refused to share OTP. 
Tried for 30 minutes. Asked admin for help."
```

#### Category 4: OTP/Verification Issues
```
- Helper claims reached but customer disputes location
- OTP exchange confusion/failure
- Customer refuses to verify completion
- False arrival claims

Example:
Helper says: "I reached location and tried 3 times to verify 
but customer claimed I'm at wrong place."
```

#### Category 5: Non-Completion
```
- Helper abandoned task
- Task time greatly exceeded estimate
- Helper cancelled unexpectedly
- Technical issues prevented task

Example:
Customer says: "Helper accepted task, said 'on the way', 
then disappeared. Task never completed."
```

### Dispute Workflow

```
STEP 1: INITIATION
├─ Either party (customer or helper) can raise dispute
├─ Dispute window: Within 24 hours of task completion (or TBD)
├─ Reason selection from dropdown + description
├─ Evidence upload (screenshots, photos, timestamps)
└─ Task status: DISPUTED (affects both parties)

STEP 2: ADMIN NOTIFICATION
├─ Admin dashboard gets alert with "High Priority" badge
├─ Payout to helper is placed on hold
├─ Customer refund (if applicable) is on hold
├─ Both parties notified dispute is being reviewed
└─ Admin SLA: Response within 24 hours (or TBD)

STEP 3: INVESTIGATION
├─ Admin reviews:
│  - Task details & completion photos
│  - Chat history between parties
│  - Location data (helper's GPS trail)
│  - OTP entry logs
│  - Timestamps of all actions
│  - Ratings given by both parties
│  - Historical complaints from either party
├─ Admin may request additional info from either party
└─ Investigation timeline: 48 hours (or TBD)

STEP 4: RESOLUTION
Admin decides on:

Option A: CUSTOMER WIN
├─ Full refund issued to customer
├─ Helper gets ₹0 for this task
├─ Warning added to helper's record
└─ If pattern: Helper account may be suspended

Option B: HELPER WIN
├─ Helper gets full payout (minus platform fee)
├─ Customer refund: ₹0
├─ Complaint noted on customer's record
└─ If pattern: Customer may have restrictions

Option C: PARTIAL RESOLUTION
├─ Customer refund: X% of task amount
├─ Helper payout: Y% of earned amount
├─ Resolution documented for both parties
└─ Both may receive warnings

Option D: MUTUAL AGREEMENT
├─ Both parties can mutually agree on resolution
├─ Admin approves if reasonable
├─ No fault assigned
├─ Both records stay clean
└─ Task marked as "Resolved Mutually"

STEP 5: PAYMENT EXECUTION
├─ Decided refunds processed immediately
├─ Helper payouts executed within 24 hours
├─ Both parties receive detailed resolution email
└─ Ratings become permanent (visible after resolution)

STEP 6: POST-RESOLUTION
├─ Both parties can appeal within 7 days if new evidence surfaces
├─ Pattern tracking: Multiple disputes may trigger restrictions
├─ Learning: Admin reviews common dispute reasons
└─ Policy update: May trigger rule/workflow changes
```

### Dispute Resolution Criteria

#### Evidence Evaluation
```
Strong Evidence:
✓ GPS location data showing helper was/wasn't at location
✓ Photos with timestamp metadata
✓ Chat history clearly showing misunderstanding
✓ OTP entry logs showing multiple failed attempts
✓ Task completion photos showing work (or lack thereof)

Weak Evidence:
✗ Verbal claims without corroboration
✗ Photos without metadata
✗ Chat screenshot without confirmation of authenticity
✗ Complaints matching known patterns of false claims
```

#### History & Pattern Analysis
```
First Complaint from Party A:
- Give benefit of doubt
- Light warning if appropriate

2nd-3rd Complaints from Party A:
- Stricter evaluation
- Consider account restrictions

4th+ Complaints from Party A:
- Pattern recognition: Account may be flagged as
  "Frequently files disputes" or "Frequently gets complaints"
- Consider account suspension if pattern suggests abuse

Perfect Record (0 complaints, high ratings):
- More lenient evaluation if dispute arises
- Assume good faith
```

### Appeals Process

```
If either party disagrees with resolution:
1. Can appeal within 7 days
2. Must provide additional evidence not previously submitted
3. Second admin reviews (different from first)
4. Decision is final after second review
5. (No further appeals)
```

---

## Admin Controls

### Admin Dashboard - Overview Page

```
Real-Time Metrics (KPIs):
- Tasks completed today: XXX
- Customer payments: ₹XXX
- Helper payouts processed: ₹XXX
- Helpers online: XXX / YYY
- Active tasks in progress: XXX
- Disputes open: XXX
- Payout requests pending: XXX

Activity Feed (Live):
- [2:30 PM] Helper "Rohit Kumar" came online
- [2:28 PM] New personal task posted by Anil Reddy
- [2:15 PM] Task SKT74811 completed by Rohit Kumar
- [2:10 PM] Dispute raised for task SKT74810
- [1:50 PM] Payment failed for helper Sneha Verma

Attention Items (Links to specific workflows):
- 4 Helper applications pending review
- 3 Open disputes needing resolution
- 2 Payment failed (requires action)
- 1 Helper flagged for multiple complaints
```

### Admin Dashboard - Helper Approvals

```
Application Review Workflow:

List View:
- Applicant name, photo, phone
- Applied date & time
- Document verification status (Aadhaar, PAN, Selfie, Bank)
- Progress indicator: X of 4 documents verified
- Action: "Review" button → Detail view

Detail View:
- Full profile details
- Documents displayed:
  ☑ Aadhaar (verified) | Date verified, by whom
  ☐ PAN (pending review)
  ☑ Selfie (verified) | Face match confidence: 98%
  ☑ Bank account (verified) | Last 4 digits: XXXX
- Background check status:
  ○ Not started
  ○ In progress (third-party service)
  ✓ Clear
  ✗ Red flag found
- Skills/Categories they accept
- Admin actions:
  [Approve Helper] [Request Document Changes] [Reject]
  [Run BG Check] [Contact Applicant]
```

### Admin Dashboard - Helper Management

```
Helper List View:
- Helper name, rating, photo
- Status: Online/Offline/Suspended/Inactive
- This week: X tasks, ₹Y earnings
- Complaints: X
- Last activity: X hours ago
- Sort by: Rating, Tasks, Earnings, Complaints, Online Status
- Search/filter by: Name, ID, Area, Status

Helper Detail View:
- Full profile (name, phone, address, joined date)
- Verification badges (Identity, Background Check, Trained)
- Stats:
  - Tasks completed: XXX
  - Average rating: 4.8/5.0
  - Response time: 4 min average
  - Earnings (30 days): ₹XXX
  - Complaints: X
  - Disputes: X
- Recent tasks (last 5 with ratings)
- Recent reviews/complaints
- Actions available:
  [Go Online] [Go Offline] [Suspend] [Reactivate]
  [View Chat History] [Send Message]
  [Clear Suspension] [Delete Account]
```

### Admin Dashboard - Task Management

```
Task List View:
- Task ID, type (personal/business), status
- Customer name
- Helper name (if assigned)
- Amount
- Time (created / completed)
- Action: [View Details] [Assign Helper] [Cancel]

Task Detail View:
- Full task description & photos
- Timeline:
  ✓ Posted: 2:00 PM
  ✓ Assigned to Rohit: 2:01 PM
  ✓ Reached location: 2:15 PM (OTP entered)
  ○ In progress: 2:16 PM - 3:00 PM
  ○ Submitted: 3:00 PM (awaiting customer review)
  ○ Completed: (pending)
- Customer details & chat
- Helper details & GPS trail
- Actions available:
  [Cancel Task] [Force Complete] [Assign Different Helper]
  [Request OTP Retry] [View Payment Status]
```

### Admin Dashboard - Dispute Management

```
Dispute List View:
- Dispute ID, task ID
- Raised by: Customer or Helper (name)
- Against: (other party name)
- Category: Quality / Pricing / Behavior / OTP / Non-Completion
- Priority: Low / Medium / High
- Status: Open / Investigating / Resolved
- Time: When raised
- Action: [Review] [Assign to Admin]

Dispute Detail View:
- All messages between parties (chat history)
- Task details & completion evidence (photos)
- Evidence submitted by complainant
- Timeline of task execution
- Requested resolution by complainant
- Admin's investigation notes field
- Decision template:
  ☐ Customer Win (100% refund)
  ☐ Helper Win (100% payout)
  ☐ Partial (Customer % / Helper %)
  ☐ Mutual Agreement
- Add resolution notes
- Actions: [Approve Resolution] [Request More Info]
          [Contact Customer] [Contact Helper]
```

### Admin Dashboard - Payout Management

```
Payout Request List:
- Helper name & ID
- Amount requested
- Requested date & time
- Withdrawal method (Bank/UPI)
- Status: Pending / Processing / Paid / Failed
- Action: [Process] [Retry] [Mark Failed]

Payout Detail:
- Helper details
- Breakdown of earnings by task (linked)
- Withdrawal destination details
- Previous payout history (last 10)
- Failed payout reasons (if applicable)
- Retry options & history
- Actions: [Force Process] [Mark as Failed]
          [Adjust Amount] [Cancel Payout]
```

### Admin Dashboard - Pricing Configuration

```
Settings Page:
- Base fare: ₹40 [Edit]
- Per-km rate: ₹15 [Edit]
- Per-minute rate: ₹2.50 [Edit]
- Minimum task amount: ₹80 [Edit]
- Platform fee: 15% [Edit]
- Cancellation fee: ₹30 [Edit]

Multipliers (Task Type):
- Personal base: 1.0x [Edit]
- Business base: 1.25x [Edit]

Peak pricing:
- Evening (6pm-11pm): 1.1x multiplier [Edit]
- Night (11pm-6am): (Not available in MVP)

Special rules:
- [Add new pricing rule]

Test Fare Calculator:
- Distance: ___ km
- Time: ___ minutes
- Task type: (Personal / Business)
- Estimated fare: ₹XXX (calculated in real-time)
```

---

## Ambiguities & Decisions Required

### 🚨 **CRITICAL DECISIONS NEEDED**

#### 1. **OTP Expiry & Validity**
**Current Understanding:** OTP is valid for 2 hours, single-use, 6 digits

**Ambiguities:**
- Can customer provide same OTP to multiple helpers if first attempt fails?
- What if customer loses OTP and doesn't have SMS access?
- Should OTP be time-limited or attempt-limited or both?

**Required Decisions:**
- [ ] OTP validity duration (default: 2 hours)
- [ ] Max OTP request attempts per task
- [ ] Fallback if customer can't access OTP (alt verification method?)
- [ ] Can OTP be regenerated if lost? How many times?

---

#### 2. **Payment Timing - "Pay After" Processing**
**Current Understanding:** Customer pays after task is submitted/approved

**Ambiguities:**
- At what exact point is payment charged?
  - When helper submits task?
  - When customer approves?
  - Auto-approve if customer doesn't respond in 24 hours?
- What if customer disputes after approval?
- What's the refund process timeline?

**Required Decisions:**
- [ ] Auto-approval time window (default: 24 hours)
- [ ] Payment processing trigger (submission vs. approval)
- [ ] Dispute window (can customer dispute after payment is processed?)
- [ ] Refund timeline (immediate vs. next cycle)

---

#### 3. **Task Cancellation Fees**
**Current Understanding:** ₹30 cancellation fee in certain scenarios

**Ambiguities:**
- When exactly can customer cancel?
  - Before assignment: Always free?
  - After assignment but before helper moves: ₹30?
  - After helper started moving: ₹30 or higher?
  - After helper reached: ₹30 or full amount?
- When can helper cancel without penalty?
- Who pays the cancellation fee?

**Required Decisions:**
- [ ] Cancellation fee by stage (timeline for each phase)
- [ ] Customer cancellation fee structure (fixed or percentage?)
- [ ] Helper cancellation fee structure
- [ ] Free cancellation windows (first 30 sec? First 5 min?)

---

#### 4. **Dynamic Pricing Components**
**Current Understanding:** Base + distance + time surcharges, multipliers for task type/time

**Ambiguities:**
- How are distance/time calculated?
  - Actual route distance or straight-line?
  - Time estimated or actual?
- When are surcharges applied?
  - Before task (as estimate)?
  - After task (actual calculation)?
- Can customer negotiate final price after task?
- Is the "₹150-300" budget range a hard cap or estimate?

**Required Decisions:**
- [ ] Distance calculation method (route vs. straight-line)
- [ ] Time estimation vs. actual (charge based on which?)
- [ ] Surcharge timing (pre-task estimate vs. post-task actual)
- [ ] Price negotiation: Allowed? Only for disputes?
- [ ] Budget range: Hard cap or soft estimate?

---

#### 5. **Rating & Review Timing**
**Current Understanding:** Ratings visible after 24 hours (from prototype)

**Ambiguities:**
- Can ratings be changed after submission?
- Are ratings immediately visible or with delay?
- What if one party rates but other doesn't?
- Can ratings be deleted by admin?
- Do disputed tasks have ratings held back indefinitely?

**Required Decisions:**
- [ ] Rating visibility delay (default: 24 hours from submission)
- [ ] Can ratings be edited after submission?
- [ ] What happens to ratings if dispute is in progress?
- [ ] Rating removal policy (can admin delete ratings?)

---

#### 6. **Helper Suspension & Reactivation**
**Current Understanding:** Admin can suspend helpers, presumably can reactivate

**Ambiguities:**
- What triggers suspension?
  - Number of complaints?
  - Specific complaint type?
  - Single violation or pattern?
- Can helper appeal suspension?
- What's required for reactivation?
  - Time period?
  - Conditions to meet?
  - Admin manual approval?
- Is there a permanent ban, or always a path back?

**Required Decisions:**
- [ ] Suspension triggers (X complaints, specific violations, etc.)
- [ ] Appeal process for suspended helpers
- [ ] Reactivation requirements & timeline
- [ ] Permanent ban criteria (if any)

---

#### 7. **Dispute Resolution Criteria**
**Current Understanding:** Admin reviews evidence and decides winner/partial resolution

**Ambiguities:**
- What percentage splits are common?
  - Always 0/100 or 100/0, or often 50/50?
- How are subjective disputes judged (e.g., "rude behavior")?
- What's the tie-breaker if evidence is inconclusive?
- How much weight is given to rating/history?

**Required Decisions:**
- [ ] Common dispute resolution patterns (document examples)
- [ ] Subjective dispute judgment criteria
- [ ] Tie-breaker rules (unclear evidence)
- [ ] Weight of helper/customer history in decisions

---

#### 8. **Platform Fee Structure**
**Current Understanding:** 15% fee on all tasks

**Ambiguities:**
- Is 15% fixed or variable by task type?
- Are there any task types that are 0% fee (promos)?
- What about failed/disputed tasks?
  - If customer gets full refund, does platform get fee?
  - If helper gets partial payout, does platform get full fee?
- Are referral bonuses/incentives deducted from fee?

**Required Decisions:**
- [ ] Is 15% fixed or flexible per market/category?
- [ ] Fee in failure scenarios (disputes, failed delivery, etc.)
- [ ] Promotional windows (zero-fee tasks for growth)?

---

### 🟡 **MEDIUM PRIORITY CLARIFICATIONS**

#### 9. **OTP Delivery & Backup Methods**
**Current Understanding:** Push notification + SMS

**Ambiguities:**
- What if customer doesn't have SMS?
- What if app notifications are disabled?
- Should there be a fallback like email or call?
- What if customer phone is offline?

**Suggested Decisions:**
- [ ] Primary: In-app notification
- [ ] Secondary: SMS
- [ ] Tertiary: Phone call with OTP read aloud?
- [ ] Escalation: Admin contacts customer if none work

---

#### 10. **Task Lifecycle Timing**
**Current Understanding:** 30-min window to reach location, timer tracks time on task

**Ambiguities:**
- If helper takes 45 min to reach, does customer pay extra time charge?
- Is the 30-min window hard cutoff or soft (warning only)?
- Who decides what counts as "time on task"? (pickup time? Setup time?)
- What if task takes much longer than estimate?

**Suggested Decisions:**
- [ ] 30-min reach window: Hard deadline for auto-cancel or soft?
- [ ] Extra time charges: Applied if exceed estimate by what %?
- [ ] Time tracking: Start from OTP verification or task acceptance?

---

#### 11. **Photo Requirements**
**Current Understanding:** At least 1 photo required for task completion

**Ambiguities:**
- Minimum photo count: 1 or more?
- Photo quality standards?
- What if photo doesn't show proof of work?
- Can customer request more photos?
- Are photos deleted after task or kept long-term?

**Suggested Decisions:**
- [ ] Min photos: 1, 2, or 3?
- [ ] Photo quality standards (clarity, metadata required?)
- [ ] Photo retention: How long stored?
- [ ] Photosquality disputes: What's the process?

---

#### 12. **Weekend & Holiday Operations**
**Current Understanding:** Prototype shows all days available

**Ambiguities:**
- Are there different rates on weekends?
- Are holidays (Diwali, Holi, etc.) excluded?
- What about emergency tasks (hospital run)?
- Can customer request specific date/time?

**Suggested Decisions:**
- [ ] Weekend multipliers (if any)?
- [ ] Holiday availability (restricted or full service)?
- [ ] Same-day turnaround: Always available or only weekdays?

---

#### 13. **Business Task GST Handling**
**Current Understanding:** "GST bill needed" checkbox on business tasks

**Ambiguities:**
- Does Sahayakh need to issue GST invoice to customer?
- If helper must collect GST bill, who collects it? (helper or vendor?)
- If customer can't collect GST bill, what's the resolution?
- Does task fail if GST bill isn't provided?
- How is GST bill proof verified by admin?

**Suggested Decisions:**
- [ ] GST bill collection: Mandatory or best-effort?
- [ ] If not collected: Task still marks complete or disputed?
- [ ] Admin verification of GST bills: Random audit or all tasks?

---

### 🟢 **LOWER PRIORITY / POST-MVP**

#### 14. **Referral System**
**Current Understanding:** Not visible in prototypes

**Questions:**
- Should platform offer referral bonuses?
- Bonus for customer referrals, helper referrals, or both?
- Fixed bonus or percentage of first transaction?

---

#### 15. **Insurance/Safety Features**
**Current Understanding:** Background checks done, but no insurance mentioned

**Questions:**
- Should platform carry liability insurance?
- Should helpers carry insurance?
- What about customer protection against helper fraud?
- What about helper protection against customer false claims?

---

#### 16. **Rating Weights**
**Current Understanding:** Overall rating shown, but how is it calculated?

**Questions:**
- Simple average of all ratings or weighted (recent higher)?
- Minimum ratings before helper is visible (e.g., 10 ratings)?
- Can customer search by specific category ratings (punctuality, quality)?

---

---

## Success Metrics

### Adoption Metrics
```
Week 1-2:
- Helpers registered: 100+
- Helpers verified: 50+
- Customers registered: 500+
- Tasks created: 200+
- Tasks completed: 50+
- Completion rate: 25%

Month 1:
- Helpers online: 100+
- DAU (Daily Active Users): 200+
- Tasks per day: 30+
- Completion rate: 60%+
- Repeat customer rate: 10%+

Month 3:
- Helpers online: 300+
- DAU: 1,000+
- Tasks per day: 200+
- Completion rate: 85%+
- Repeat customer rate: 30%+
```

### Quality Metrics
```
- Average helper rating: 4.5+ / 5.0
- Average customer rating: 4.5+ / 5.0
- Task completion rate: 85%+
- Customer satisfaction: 90%+ (manual survey)
- Dispute rate: <2% of tasks
- Refund rate: <3% of tasks
- Photo submission rate: 95%+ (of completed tasks)
```

### Financial Metrics
```
- Average task value: ₹200+
- Helper earnings per day: ₹500-1000 (20 tasks)
- Platform revenue per task: ₹30+
- Monthly platform revenue: ₹10,000+ (at 500+ tasks/month)
- Helper retention after 5 tasks: 70%+
- Customer retention (repeat booking): 30%+ after first task
```

### Operational Metrics
```
- Avg time to assign task: <5 minutes
- Avg time for helper to reach location: 15-25 minutes
- Avg task duration: 30-45 minutes
- Admin dispute resolution time: <24 hours
- Payment processing success rate: 99%+
- Payout processing success rate: 98%+
```

---

## Summary: Outstanding Issues

| Priority | Issue | Status |
|----------|-------|--------|
| 🚨 Critical | OTP expiry & validity | ⚠️ Needs Decision |
| 🚨 Critical | Payment timing & approval | ⚠️ Needs Decision |
| 🚨 Critical | Cancellation fee structure | ⚠️ Needs Decision |
| 🚨 Critical | Dynamic pricing details | ⚠️ Needs Decision |
| 🟡 Medium | Rating visibility timing | ⚠️ Needs Decision |
| 🟡 Medium | Helper suspension triggers | ⚠️ Needs Decision |
| 🟡 Medium | Dispute resolution patterns | ⚠️ Needs Decision |
| 🟡 Medium | OTP backup methods | ⚠️ Needs Decision |
| 🟢 Low | Photo requirements | ⚠️ Needs Decision |
| 🟢 Low | Weekend/holiday handling | ⚠️ Needs Decision |

---

## Appendix: Glossary

```
Term              Definition
──────────────────────────────────────────────────────────
Helper            Gig worker completing tasks for customers
Customer          User posting tasks
Task              Work item (pickup, delivery, visit, etc.)
OTP               One-Time Password (6-digit verification)
Completion        Helper marks task done with photos/checklist
Payout            Payment to helper for completed work
Platform Fee      15% commission Sahayakh retains
Dispute           Disagreement about task completion/payment
Refund            Return of customer's payment
Suspension        Temporarily remove helper from platform
```

---

**Document Status:** ✅ DRAFT - Awaiting decision on ambiguities  
**Next Steps:** Review decisions list, schedule decision-making meeting  
**Owner:** Product Manager  
**Contributors:** Needed - Engineering, Ops, Finance
