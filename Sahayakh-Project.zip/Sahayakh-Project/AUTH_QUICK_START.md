# Authentication Quick Start Guide

**Get Sahayakh authentication running in 5 minutes**

---

## Prerequisites

- PostgreSQL 15+ (`psql --version`)
- Redis 7+ (`redis-cli --version`)
- Node.js 18+ (`node --version`)

---

## 1. Setup (2 minutes)

```bash
# Create database
createdb sahayakh_dev

# Load schema
psql sahayakh_dev < 001_sahayakh_initial_schema.sql

# Copy environment
cp packages/backend/.env.example packages/backend/.env

# Install dependencies
npm install
```

---

## 2. Start Services (1 minute)

```bash
# Terminal 1: Start PostgreSQL + Redis (if not running)
docker-compose up postgres redis

# Terminal 2: Start backend
npm run dev:backend

# You should see:
# ✓ Database connection established
# ✓ Redis connection established
# ✓ Sahayakh v0.1.0 listening on port 3000
```

---

## 3. Test Authentication (2 minutes)

### Register User

```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "phone_number": "+919876543210",
    "name": "John Doe",
    "role": "customer"
  }'
```

**Response:**
```json
{
  "otp_sent": true,
  "expires_in": 120,
  "otp": "123456"  // Only in dev mode!
}
```

### Verify OTP

```bash
curl -X POST http://localhost:3000/api/auth/verify-otp \
  -H "Content-Type: application/json" \
  -d '{
    "phone_number": "+919876543210",
    "otp_code": "123456"
  }'
```

**Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIs...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIs...",
  "user_id": "550e8400-e29b-41d4-a716-446655440000",
  "role": "customer",
  "user": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "name": "John Doe",
    "phone_number": "+919876543210",
    "role": "customer",
    "status": "active"
  }
}
```

### Get Current User

```bash
# Replace TOKEN with your access_token from above
curl -X GET http://localhost:3000/api/auth/me \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIs..."
```

**Response:**
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "John Doe",
  "phone_number": "+919876543210",
  "role": "customer",
  "status": "active"
}
```

### Refresh Token

```bash
curl -X POST http://localhost:3000/api/auth/refresh \
  -H "Content-Type: application/json" \
  -d '{
    "refresh_token": "eyJhbGciOiJIUzI1NiIs..."
  }'
```

**Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIs...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIs..."
}
```

---

## 4. Run Tests (Optional)

```bash
# Create test database
createdb sahayakh_test
psql sahayakh_test < 001_sahayakh_initial_schema.sql

# Run all tests
npm run test --workspace=packages/backend

# With coverage
npm run test:coverage --workspace=packages/backend

# Watch mode (reruns on file changes)
npm run test:watch --workspace=packages/backend
```

---

## API Endpoints Reference

### Auth Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/auth/register` | Register with phone number |
| `POST` | `/api/auth/verify-otp` | Verify OTP code |
| `POST` | `/api/auth/refresh` | Refresh access token |
| `GET` | `/api/auth/me` | Get current user (protected) |
| `POST` | `/api/auth/logout` | Logout |
| `GET` | `/health` | Health check |

### Error Codes

| Code | Status | Meaning |
|------|--------|---------|
| `PHONE_ALREADY_EXISTS` | 409 | Phone already registered |
| `INVALID_PHONE_NUMBER` | 400 | Phone format invalid |
| `INVALID_OTP` | 400 | OTP code incorrect |
| `OTP_EXPIRED` | 400 | OTP not found (expired) |
| `TOO_MANY_ATTEMPTS` | 429 | Max OTP attempts (3) exceeded |
| `RATE_LIMIT_EXCEEDED` | 429 | Too many requests (>10/hr) |
| `INVALID_TOKEN` | 401 | Token signature invalid |
| `UNAUTHORIZED` | 401 | No authorization header |
| `USER_NOT_FOUND` | 404 | User doesn't exist |

---

## Environment Variables

### Essential
```env
NODE_ENV=development
PORT=3000
DATABASE_URL=postgresql://sahayakh:password@localhost:5432/sahayakh_dev
REDIS_URL=redis://localhost:6379/0
JWT_SECRET=dev-secret-key-change-in-production
JWT_REFRESH_SECRET=dev-refresh-secret-change-in-production
```

### Optional (defaults shown)
```env
LOG_LEVEL=debug
OTP_LENGTH=6
OTP_EXPIRY_MINUTES=120
OTP_MAX_ATTEMPTS=3
BCRYPT_ROUNDS=10
CORS_ORIGINS=http://localhost:3000,http://localhost:5173
```

---

## Common Issues & Fixes

### "Cannot connect to database"
```bash
# Check PostgreSQL
psql --version

# Start PostgreSQL
brew services start postgresql@15  # macOS
sudo service postgresql start      # Linux

# Create database
createdb sahayakh_dev
psql sahayakh_dev -c "\dt"
```

### "Cannot connect to Redis"
```bash
# Check Redis
redis-cli ping  # Should return PONG

# Start Redis
brew services start redis  # macOS
sudo service redis start   # Linux
redis-server              # Direct
```

### "Port 3000 already in use"
```bash
# Option 1: Change port in .env
PORT=3001

# Option 2: Kill process on port 3000
lsof -ti:3000 | xargs kill -9
```

### "OTP test failures"
```bash
# Clear test database
dropdb sahayakh_test
createdb sahayakh_test
psql sahayakh_test < 001_sahayakh_initial_schema.sql

# Clear Redis test db
redis-cli -n 1 FLUSHALL

# Run tests again
npm run test --workspace=packages/backend
```

---

## File Structure

```
packages/backend/src/
├── config/          # Database, Redis, env config
├── middleware/      # Auth, error handling
├── utils/           # JWT, OTP generation
├── services/        # User, auth, OTP logic
├── routes/          # REST endpoints
└── index.ts         # Express app
```

---

## Development Workflow

```bash
# 1. Make changes to src/
# 2. Tests rerun automatically (if using npm run test:watch)
# 3. Backend restarts automatically (if using npm run dev:backend)

# 4. Lint & fix
npm run lint --workspace=packages/backend
npm run lint:fix --workspace=packages/backend

# 5. Type check
npm run type-check --workspace=packages/backend

# 6. Build
npm run build --workspace=packages/backend
```

---

## Next: Frontend Integration

### Mobile Apps (React Native)

```typescript
import axios from 'axios';

const API_URL = 'http://localhost:3000/api';

// 1. Register
const response = await axios.post(`${API_URL}/auth/register`, {
  phone_number: '+919876543210',
  name: 'User Name',
  role: 'customer'
});
console.log('OTP sent:', response.data.expires_in);

// 2. Verify OTP
const authResponse = await axios.post(`${API_URL}/auth/verify-otp`, {
  phone_number: '+919876543210',
  otp_code: '123456'
});

// 3. Store tokens
const { access_token, refresh_token } = authResponse.data;
await SecureStore.setItemAsync('access_token', access_token);
await SecureStore.setItemAsync('refresh_token', refresh_token);

// 4. Use token in requests
const config = {
  headers: { Authorization: `Bearer ${access_token}` }
};
const user = await axios.get(`${API_URL}/auth/me`, config);
```

### Web Apps (React/Vite)

```typescript
// Store tokens in localStorage (or use http-only cookie for more security)
localStorage.setItem('access_token', access_token);
localStorage.setItem('refresh_token', refresh_token);

// Add to axios interceptors
axiosInstance.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});
```

---

## Documentation

- **Full API**: [packages/backend/README.md](./packages/backend/README.md)
- **Implementation Details**: [AUTH_IMPLEMENTATION_SUMMARY.md](./AUTH_IMPLEMENTATION_SUMMARY.md)
- **System Architecture**: [SAHAYAKH_SYSTEM_ARCHITECTURE.md](./SAHAYAKH_SYSTEM_ARCHITECTURE.md)
- **Monorepo Setup**: [MONOREPO_README.md](./MONOREPO_README.md)

---

**Ready to authenticate! 🚀**

Questions? Check the full documentation or run: `npm run test --workspace=packages/backend`
