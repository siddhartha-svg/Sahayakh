# Sahayakh Monorepo Setup Guide

**Complete guide to setting up and running the Sahayakh monorepo locally.**

---

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Initial Setup](#initial-setup)
3. [Environment Configuration](#environment-configuration)
4. [Running Locally](#running-locally)
5. [Monorepo Commands](#monorepo-commands)
6. [Troubleshooting](#troubleshooting)
7. [Development Workflow](#development-workflow)

---

## ✅ Prerequisites

Before you begin, ensure you have the following installed:

### Required
- **Node.js** v18+ ([Download](https://nodejs.org/))
- **npm** v9+ (comes with Node.js)
- **Git** ([Download](https://git-scm.com/))

### Recommended
- **PostgreSQL** v15+ ([Download](https://www.postgresql.org/download/))
- **Redis** v7+ ([Download](https://redis.io/download))
- **Docker & Docker Compose** ([Download](https://www.docker.com/products/docker-desktop/))
  - If using Docker, PostgreSQL and Redis are provided via docker-compose

### Optional
- **Android Studio** or **Xcode** (for mobile development)
- **Expo CLI** (for running React Native apps)

### Verify Installation
```bash
# Check Node.js version
node --version  # Should be v18+

# Check npm version
npm --version   # Should be v9+

# Check Git version
git --version
```

---

## 🚀 Initial Setup

### 1. Clone Repository
```bash
git clone https://github.com/yourusername/sahayakh.git
cd sahayakh
```

### 2. Install Dependencies
The monorepo uses npm workspaces. This installs dependencies for all packages:

```bash
# Install all dependencies (one command for entire monorepo)
npm install

# This runs:
# - npm install in root
# - npm install in packages/backend
# - npm install in packages/shared
# - npm install in packages/customer-app
# - npm install in packages/helper-app
# - npm install in packages/admin-dashboard
```

### 3. Verify Installation
```bash
# List all workspaces
npm ls --depth=0

# Check workspace integrity
npm ls -a

# Should output something like:
# sahayakh-monorepo@0.1.0
# ├── @sahayakh/admin-dashboard@0.1.0
# ├── @sahayakh/backend@0.1.0
# ├── @sahayakh/customer-app@0.1.0
# ├── @sahayakh/helper-app@0.1.0
# └── @sahayakh/shared@0.1.0
```

---

## 🔐 Environment Configuration

### Quick Setup (Using Docker)
If you're using Docker Compose, you can skip manual PostgreSQL/Redis setup:

```bash
# Start PostgreSQL and Redis containers
docker-compose up -d postgres redis

# Containers are now ready for backend to connect
```

### Manual Setup (macOS/Linux)

#### PostgreSQL Setup
```bash
# Install PostgreSQL (macOS with Homebrew)
brew install postgresql@15

# Start PostgreSQL
brew services start postgresql@15

# Create database
createdb sahayakh_dev

# Verify connection
psql -U postgres -d sahayakh_dev -c "SELECT 1;"
```

#### Redis Setup
```bash
# Install Redis (macOS with Homebrew)
brew install redis

# Start Redis
brew services start redis

# Verify connection
redis-cli ping  # Should output: PONG
```

### Manual Setup (Windows)

#### PostgreSQL
1. Download PostgreSQL installer from [postgresql.org](https://www.postgresql.org/download/windows/)
2. Run installer, choose password for postgres user
3. Enable pgAdmin during installation
4. Open pgAdmin and create database `sahayakh_dev`

#### Redis
1. Install via Windows Subsystem for Linux (WSL):
   ```bash
   wsl --install  # Install WSL if not already installed
   wsl  # Open WSL terminal
   sudo apt-get install redis-server  # Install Redis
   redis-server  # Start Redis
   ```
   Or use Windows native: [Redis for Windows](https://github.com/tporadowski/redis/releases)

### Create Environment Files

For each service, copy `.env.example` → `.env`:

```bash
# Backend
cp packages/backend/.env.example packages/backend/.env

# Customer App
cp packages/customer-app/.env.example packages/customer-app/.env

# Helper App
cp packages/helper-app/.env.example packages/helper-app/.env

# Admin Dashboard
cp packages/admin-dashboard/.env.example packages/admin-dashboard/.env
```

### Configure Environment Variables

Edit each `.env` file:

#### Backend (packages/backend/.env)
```env
NODE_ENV=development
PORT=3000
DATABASE_URL=postgresql://sahayakh:password@localhost:5432/sahayakh_dev
REDIS_URL=redis://localhost:6379
JWT_SECRET=dev-secret-key
JWT_REFRESH_SECRET=dev-refresh-secret
LOG_LEVEL=debug
```

#### Mobile Apps (packages/customer-app/.env & packages/helper-app/.env)
```env
REACT_APP_API_URL=http://localhost:3000/api
REACT_APP_SOCKET_URL=http://localhost:3000
REACT_APP_ENV=development
```

#### Admin Dashboard (packages/admin-dashboard/.env)
```env
VITE_API_URL=http://localhost:3000/api
VITE_SOCKET_URL=http://localhost:3000
VITE_ENV=development
```

---

## 🏃 Running Locally

### Option 1: Using Docker Compose (Recommended for Clean Setup)

```bash
# Start all services (PostgreSQL, Redis, Backend, Admin)
docker-compose up

# Output should show:
# ✓ postgres started
# ✓ redis started
# ✓ backend running on port 3000
# ✓ admin running on port 5173

# In another terminal, run mobile apps:
npm run dev:customer   # Or dev:helper
```

**Verify Services:**
- Backend API: http://localhost:3000
- Admin Dashboard: http://localhost:5173
- PostgreSQL: localhost:5432
- Redis: localhost:6379

### Option 2: Run Everything Concurrently

Start all services in one command (requires local PostgreSQL/Redis):

```bash
# Terminal 1: Start all services together
npm run dev

# Services start in parallel:
# - Backend on http://localhost:3000
# - Admin Dashboard on http://localhost:5173
# - Customer App on Expo
# - Helper App on Expo
```

### Option 3: Run Services Individually

Start each service in its own terminal:

```bash
# Terminal 1: Backend API
npm run dev:backend

# Terminal 2: Customer App
npm run dev:customer

# Terminal 3: Helper App
npm run dev:helper

# Terminal 4: Admin Dashboard
npm run dev:admin
```

---

## 📦 Monorepo Commands

### Workspace Commands

```bash
# Run a command in a specific workspace
npm run <script> --workspace=packages/<workspace-name>

# Examples:
npm run dev --workspace=packages/backend
npm run test --workspace=packages/shared
npm run build --workspace=packages/admin-dashboard
```

### All Packages Commands

```bash
# Build all packages
npm run build

# Test all packages
npm run test

# Run tests in watch mode
npm run test:watch

# Run linter on all packages
npm run lint

# Fix linting issues
npm run lint:fix

# Type check all packages
npm run type-check

# Clean build outputs
npm run clean
```

### Development Commands

```bash
# Start backend development server
npm run dev:backend

# Start customer app with Expo
npm run dev:customer

# Start helper app with Expo
npm run dev:helper

# Start admin dashboard with Vite
npm run dev:admin

# Start all services concurrently
npm run dev
```

### Database Commands

```bash
# Run migrations
npm run db:migrate --workspace=packages/backend

# Seed database with sample data
npm run db:seed --workspace=packages/backend

# Reset database (CAUTION!)
npm run db:reset --workspace=packages/backend
```

---

## 📱 Mobile App Development

### Setup Expo (for React Native)

```bash
# Install Expo CLI globally (optional but recommended)
npm install -g expo-cli

# Start Expo development server
npm run dev:customer

# Scan QR code with:
# - iPhone: Use built-in Camera app
# - Android: Use Expo Go app (install from Play Store)
```

### Run on Simulators/Emulators

```bash
# iOS (macOS only)
npm run ios --workspace=packages/customer-app

# Android
npm run android --workspace=packages/customer-app
```

---

## 🧪 Testing

### Run All Tests
```bash
npm run test
```

### Run Tests for One Package
```bash
npm run test --workspace=packages/backend
npm run test --workspace=packages/shared
```

### Watch Mode (Reruns on File Changes)
```bash
npm run test:watch
```

### Coverage Report
```bash
npm run test -- --coverage
```

---

## 🔍 Linting & Code Quality

### Run Linter
```bash
npm run lint
```

### Fix Linting Issues
```bash
npm run lint:fix
```

### Type Check
```bash
npm run type-check
```

### Format Code with Prettier
```bash
npm run format
```

---

## 🚨 Troubleshooting

### "Port 3000 already in use"
```bash
# Change port in packages/backend/.env
PORT=3001

# Or kill process on port 3000:
# macOS/Linux
lsof -ti:3000 | xargs kill -9

# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

### "Cannot connect to PostgreSQL"
```bash
# Check if PostgreSQL is running
psql --version

# Try connecting manually
psql -U sahayakh -d sahayakh_dev

# If connection fails, check credentials in .env
# DATABASE_URL should be: postgresql://user:password@host:port/database
```

### "Cannot connect to Redis"
```bash
# Check if Redis is running
redis-cli ping

# Should output: PONG

# If not running, start it:
# macOS
brew services start redis

# Linux
redis-server

# Windows (WSL)
wsl redis-server
```

### "Module not found" errors
```bash
# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install

# Clear npm cache
npm cache clean --force
npm install
```

### "Socket.IO connection refused"
```bash
# Verify backend is running
npm run dev:backend

# Check REACT_APP_SOCKET_URL in mobile/admin .env matches backend URL
# Default: http://localhost:3000
```

---

## 👨‍💻 Development Workflow

### Adding a Feature

1. **Create a branch**
   ```bash
   git checkout -b feature/my-feature
   ```

2. **Make changes** in relevant package(s)

3. **Run linter and tests**
   ```bash
   npm run lint
   npm run test
   ```

4. **Fix any issues**
   ```bash
   npm run lint:fix
   ```

5. **Commit changes**
   ```bash
   git add .
   git commit -m "feat: add my feature"
   ```

6. **Push and create PR**
   ```bash
   git push origin feature/my-feature
   gh pr create  # Or use GitHub UI
   ```

### Debugging

#### Backend Debugging
```bash
# Add this to packages/backend/.env
DEBUG_MODE=true
LOG_LEVEL=debug

# Or use Node debugger
node --inspect src/index.ts
```

#### Mobile App Debugging
```bash
# Expo provides built-in debugging
# Press 'd' in Expo terminal to open debugger
# Or use React Native Debugger:
# https://github.com/jhen0409/react-native-debugger
```

#### Admin Dashboard Debugging
```bash
# Use browser DevTools (F12)
# Vite provides source maps automatically in dev mode
```

---

## 📝 Useful npm Scripts

| Command | What It Does |
|---------|------------|
| `npm install` | Install all dependencies |
| `npm run dev` | Start all services |
| `npm run build` | Build all packages |
| `npm run test` | Run all tests |
| `npm run lint` | Check code style |
| `npm run lint:fix` | Fix code style issues |
| `npm run type-check` | Check TypeScript types |
| `npm run clean` | Remove build outputs |
| `npm run dev:backend` | Start backend API only |
| `npm run dev:admin` | Start admin dashboard only |
| `npm run dev:customer` | Start customer app only |
| `npm run db:migrate` | Run database migrations |

---

## ✅ Verification Checklist

After setup, verify everything works:

- [ ] Node.js v18+ installed
- [ ] Dependencies installed: `npm install`
- [ ] PostgreSQL running and accessible
- [ ] Redis running and accessible
- [ ] Backend starts: `npm run dev:backend`
- [ ] Admin dashboard accessible: http://localhost:5173
- [ ] Backend responds: `curl http://localhost:3000/health`
- [ ] Tests pass: `npm run test`
- [ ] Linter passes: `npm run lint`

---

## 🎓 Next Steps

1. **Read the architecture document:** [SAHAYAKH_SYSTEM_ARCHITECTURE.md](./SAHAYAKH_SYSTEM_ARCHITECTURE.md)
2. **Explore the backend:** See [packages/backend/README.md](./packages/backend/README.md)
3. **Read the API spec:** See [docs/API.md](./docs/API.md)
4. **Check the database schema:** [001_sahayakh_initial_schema.sql](./001_sahayakh_initial_schema.sql)

---

**Happy coding! 🚀**

For questions or issues, check the troubleshooting section or open an issue on GitHub.
