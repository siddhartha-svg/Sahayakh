# Sahayakh System Architecture Document

**Version:** 1.0  
**Last Updated:** September 2026  
**Status:** Design Phase  
**Team Size:** 1-3 developers  
**Timeline:** 8 weeks to MVP

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [System Architecture Overview](#system-architecture-overview)
3. [Component Diagram & Descriptions](#component-diagram--descriptions)
4. [Data Flow](#data-flow)
5. [API Design](#api-design)
6. [Real-Time Architecture](#real-time-architecture)
7. [Live Location Tracking](#live-location-tracking)
8. [OTP Verification Security](#otp-verification-security)
9. [Payment Flow](#payment-flow)
10. [Push Notifications](#push-notifications)
11. [Authentication & Authorization](#authentication--authorization)
12. [Scalability & Performance](#scalability--performance)
13. [Security & Compliance](#security--compliance)
14. [Deployment Architecture](#deployment-architecture)
15. [Error Handling & Resilience](#error-handling--resilience)

---

## Executive Summary

**Sahayakh** is a three-sided hyperlocal marketplace built on a **microservices-lite architecture** with:

- **Frontend:** React Native (single app, iOS/Android) + React Web (admin)
- **Backend:** Node.js + Express (REST API)
- **Real-Time Layer:** Socket.IO (WebSockets)
- **Database:** PostgreSQL + PostGIS + Redis
- **Payments:** Razorpay
- **Push Notifications:** Firebase Cloud Messaging
- **Location Tracking:** GPS via Socket.IO + Redis
- **OTP Verification:** Redis-based token storage with encryption

**Architecture Principles:**
- Single language (JavaScript) across stack
- Real-time-first (all updates via Socket.IO, fallback to polling)
- Location-native (PostGIS for geographic queries)
- Scalable from day 1 (can handle 10K concurrent users)
- Minimal DevOps burden (Railway hosting)

---

## System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                          CLIENT LAYER                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────────┐        ┌──────────────────────┐     │
│  │  React Native App    │        │  React Web Admin     │     │
│  │  (iOS/Android)       │        │  Dashboard           │     │
│  │                      │        │                      │     │
│  │  - Customer Mode     │        │  - Helper Mgmt       │     │
│  │  - Helper Mode       │        │  - Disputes          │     │
│  │  - Real-time UI      │        │  - Payouts           │     │
│  │  - Offline support   │        │  - Pricing Config    │     │
│  └────────┬─────────────┘        └──────────┬───────────┘     │
│           │                                 │                  │
└───────────┼─────────────────────────────────┼──────────────────┘
            │                                 │
        HTTPS/WebSocket                       │
            │                                 │
            ▼                                 ▼
┌──────────────────────────────────────────────────────────────────┐
│                    API GATEWAY / LOAD BALANCER                   │
│              (Railway / Render managed routing)                 │
└──────────────────────────────────────────────────────────────────┘
            │
            ▼
┌──────────────────────────────────────────────────────────────────┐
│                      APPLICATION LAYER                           │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │     Node.js + Express Backend API                          │ │
│  │     (on Railway, auto-scaled, ~$7/month)                  │ │
│  │                                                            │ │
│  │  REST Endpoints:                                           │ │
│  │  ├─ /auth/* (login, register, OTP)                       │ │
│  │  ├─ /tasks/* (CRUD, discovery, assignment)               │ │
│  │  ├─ /helpers/* (profile, status, verification)           │ │
│  │  ├─ /payments/* (checkout, confirmation)                 │ │
│  │  ├─ /payouts/* (withdrawal, history)                     │ │
│  │  ├─ /disputes/* (creation, resolution)                   │ │
│  │  ├─ /admin/* (dashboard data, actions)                   │ │
│  │  └─ /health (monitoring)                                  │ │
│  │                                                            │ │
│  │  Business Logic:                                           │ │
│  │  ├─ Task assignment algorithm                            │ │
│  │  ├─ Dynamic pricing calculator                           │ │
│  │  ├─ OTP generation & validation                          │ │
│  │  ├─ Payment processing (Razorpay integration)            │ │
│  │  ├─ Payout scheduling                                    │ │
│  │  └─ Dispute resolution workflow                          │ │
│  │                                                            │ │
│  │  Socket.IO Handlers:                                      │ │
│  │  ├─ task:new                                              │ │
│  │  ├─ task:accepted                                         │ │
│  │  ├─ location:update                                       │ │
│  │  ├─ otp:send                                              │ │
│  │  ├─ task:completed                                        │ │
│  │  └─ notification:* (all real-time events)                │ │
│  └──────────┬─────────────────────────────┬──────────────────┘ │
│             │                             │                    │
└─────────────┼─────────────────────────────┼────────────────────┘
              │                             │
        REST HTTP/1.1                    WebSocket
              │                             │
              ▼                             ▼
┌────────────────────────────────┐  ┌──────────────────────────────┐
│    DATABASE LAYER              │  │   REAL-TIME LAYER            │
├────────────────────────────────┤  ├──────────────────────────────┤
│                                │  │                              │
│  PostgreSQL                    │  │  Redis                       │
│  (on Railway, managed)         │  │  (on Railway, managed)       │
│                                │  │                              │
│  Tables:                       │  │  Caches:                     │
│  ├─ users                      │  │  ├─ Active tasks (45s TTL)   │
│  ├─ helpers                    │  │  ├─ Helper locations (2s)    │
│  ├─ tasks                      │  │  ├─ OTP tokens (2h)         │
│  ├─ payments                   │  │  ├─ User sessions           │
│  ├─ payouts                    │  │  ├─ Task state              │
│  ├─ disputes                   │  │  └─ Rate limits             │
│  ├─ reviews                    │  │                              │
│  ├─ pricing_config             │  │  Pub/Sub:                    │
│  └─ audit_logs                 │  │  ├─ task:new notifications   │
│                                │  │  ├─ location:updates        │
│  Extensions:                   │  │  ├─ otp:delivery            │
│  ├─ PostGIS (geo queries)      │  │  └─ payment:events          │
│  ├─ UUID (unique IDs)          │  │                              │
│  └─ JSON (flexible data)       │  │  Rate Limiting:              │
│                                │  │  ├─ OTP requests (10/hour)   │
│  Indexes:                      │  │  ├─ API calls (1000/min)     │
│  ├─ location_point (GIST)      │  │  └─ Location updates (100/s) │
│  ├─ status (multi-column)      │  │                              │
│  └─ timestamps (DESC)          │  │  Queues:                     │
│                                │  │  ├─ Payout processing       │
│                                │  │  ├─ Notification dispatch    │
│                                │  │  └─ Analytics aggregation    │
└────────────────────────────────┘  └──────────────────────────────┘
         │                                    │
         └────────────────┬───────────────────┘
                          ▼
          ┌────────────────────────────────┐
          │   EXTERNAL SERVICES            │
          ├────────────────────────────────┤
          │                                │
          │  Razorpay (Payments)           │
          │  ├─ Order creation             │
          │  ├─ Payment verification       │
          │  └─ Refund processing          │
          │                                │
          │  Firebase (Push Notifications) │
          │  ├─ Token registration         │
          │  ├─ Message dispatch           │
          │  └─ Delivery tracking          │
          │                                │
          │  Google Maps API               │
          │  ├─ Reverse geocoding          │
          │  ├─ Distance matrix            │
          │  └─ Direction API              │
          │                                │
          └────────────────────────────────┘
```

---

## Component Diagram & Descriptions

### **Layer 1: Presentation Layer (Frontend)**

#### **1.1 React Native Mobile App**
```
Single App, Two Modes (Role-Based Switching)

CUSTOMER MODE:
├─ Home Screen
│  ├─ Quick task creation
│  ├─ Helper search (map view)
│  └─ Upcoming tasks list
├─ Task Posting
│  ├─ Category selection
│  ├─ Location picker (maps)
│  ├─ Budget input
│  ├─ Photo upload
│  └─ Publish
├─ Live Tracking
│  ├─ Helper location on map
│  ├─ Real-time status updates
│  └─ Direct chat
└─ Payments
   ├─ Payment method selection
   ├─ Razorpay checkout
   └─ Receipt display

HELPER MODE:
├─ Home Screen
│  ├─ Online/Offline toggle
│  ├─ Available tasks (list/map)
│  └─ Today's earnings
├─ Task Acceptance
│  ├─ 45-second countdown
│  ├─ Task details preview
│  └─ Accept/Decline
├─ Navigation
│  ├─ In-app maps (Google Maps)
│  ├─ Real-time location sharing
│  └─ Customer details
├─ OTP Verification
│  ├─ 6-digit input
│  └─ Attempt counter
├─ Task Completion
│  ├─ Checklist steps
│  ├─ Photo uploads
│  └─ Submit
└─ Earnings & Payouts
   ├─ Weekly summary
   ├─ Withdrawal request
   └─ Payment history

TECHNICAL STACK:
- React Native 0.71+
- React Navigation (routing)
- Socket.IO Client (real-time)
- Axios (REST calls)
- React Query (data fetching)
- Mapbox GL Native (maps)
- Firebase (push notifications)
- Redux or Context (state management)
- Secure Storage (tokens, OTP)
```

**Key Features:**
- Offline-first architecture (queue actions, sync later)
- Location tracking every 2 seconds (when active)
- OTP input auto-clears on success
- Automatic reconnection to Socket.IO
- Camera access for photo proof
- Battery optimization (location only when needed)

---

#### **1.2 React Web Admin Dashboard**
```
ADMIN DASHBOARD MODULES:

Overview:
├─ Real-time KPI metrics
├─ Activity feed (live)
├─ Alerts & notifications
└─ Quick stats (helpers online, tasks in progress)

Helper Management:
├─ Approval queue (pending documents)
├─ Active helpers list (filter by status/rating)
├─ Individual helper profiles
├─ Suspension/reactivation
└─ Document verification view

Task Management:
├─ Live task list
├─ Task detail view (full chat + GPS trail)
├─ Manual assignment
└─ Force completion (if needed)

Dispute Resolution:
├─ Open disputes queue
├─ Evidence review (photos, chat history)
├─ Resolution interface (customer win/helper win/partial)
└─ Appeal management

Payout Management:
├─ Withdrawal request queue
├─ Manual processing
├─ Failed payout history
└─ Retry mechanism

Pricing Configuration:
├─ Base fare settings
├─ Per-km/per-minute rates
├─ Multipliers (task type, time of day)
├─ Test calculator
└─ Version history

TECHNICAL STACK:
- React 18+
- Vite (fast dev build)
- Socket.IO Client (live updates)
- Axios (REST API calls)
- TailwindCSS (styling)
- React Query (data sync)
- React Table (complex grids)
- React Admin (if CRUD heavy)
- Charts.js (analytics)
```

**Key Features:**
- Real-time KPI updates via Socket.IO
- No page refresh needed
- One-click actions (suspend, approve, resolve dispute)
- Audit trail for all admin actions
- Export functionality (CSV, PDF)
- Role-based access (if multiple admins)

---

### **Layer 2: API Layer**

#### **2.1 REST API Design**

```
BASE URL: https://api.sahayakh.com/v1

DESIGN CHOICE: REST (NOT GraphQL)

JUSTIFICATION:
✅ Simpler for 1-3 developers (less complexity)
✅ Better caching (HTTP cache headers work natively)
✅ Easier monitoring & debugging (standard HTTP tools)
✅ Less expensive to host (no query optimization needed)
✅ Faster dev speed (no schema versioning)
✅ Better for mobile (predictable data sizes)
✅ Proven at scale (Uber, Swiggy, all use REST for core)
✅ Real-time via Socket.IO (doesn't need GraphQL subscriptions)

❌ GraphQL not needed because:
- Only 10-15 main endpoints (not hundreds)
- Real-time via separate Socket.IO connection (not GraphQL subscriptions)
- Over-fetching not a major issue (mobile has fast pipes in India)
- Mutation cost (training, testing, hosting) > benefit for MVP
- Can add GraphQL later if API explodes (9-month+ timeframe)
```

---

#### **2.2 REST API Endpoints**

```
=======================
AUTH ENDPOINTS
=======================

POST /auth/register
├─ Request: { phone_number, name, email }
├─ Response: { user_id, requires_otp: true }
├─ OTP sent via SMS
└─ Status: 201

POST /auth/verify-otp
├─ Request: { phone_number, otp_code }
├─ Response: { access_token, refresh_token, user_id, role }
├─ Token stored securely (mobile keychain, HTTP-only cookie web)
└─ Status: 200

POST /auth/refresh
├─ Request: { refresh_token }
├─ Response: { access_token }
└─ Status: 200

POST /auth/logout
├─ Request: {}
├─ Action: Invalidate refresh token in Redis
└─ Status: 204

=======================
HELPER ENDPOINTS
=======================

POST /helpers/register
├─ Request: { user_id, category_preferences, service_radius_km }
├─ Response: { helper_id, verification_status: 'pending' }
├─ Creates helper profile, status='inactive' until verified
└─ Status: 201

GET /helpers/:id
├─ Response: { name, rating, tasks_completed, response_time, reviews }
├─ Cache: 60 seconds (Redis)
└─ Status: 200

PUT /helpers/:id/documents
├─ Request: FormData with file uploads
├─ Files: aadhaar, pan, selfie, bank_account
├─ Response: { verification_status: 'pending_review' }
└─ Status: 200

PUT /helpers/:id/status
├─ Request: { status: 'online' | 'offline' }
├─ Action: Updates helper_status in DB + Redis
├─ Socket.IO broadcasts status to nearby customers
└─ Status: 200

GET /helpers/nearby
├─ Query: { latitude, longitude, radius_km }
├─ Response: [ { id, name, rating, distance, eta_minutes } ]
├─ Query: PostGIS ST_DWithin for nearby helpers
├─ Cache: 30 seconds
└─ Status: 200

=======================
TASK ENDPOINTS
=======================

POST /tasks
├─ Request: {
│   title, description, category, location { lat, lng, address },
│   preferred_date, preferred_time, budget_min, budget_max,
│   task_type: 'personal' | 'business', photos_urls[]
│ }
├─ Response: { task_id, task_id_display, status: 'unassigned' }
├─ Action:
│  1. Create task in DB
│  2. Store in Redis (45s TTL for countdown)
│  3. Find nearby helpers via PostGIS
│  4. Emit Socket.IO event: task:new
├─ Status: 201
└─ Rate limit: 10/hour per user

GET /tasks/:id
├─ Response: {
│   id, task_id_display, customer { name, rating },
│   helper { name, rating, location },
│   status, title, description, budget_min, budget_max,
│   location, preferred_time, estimated_price,
│   status_timeline [ { status, timestamp, otp_verified?, distance? } ]
│ }
├─ Cache: 10 seconds
└─ Status: 200

GET /tasks (list, with filters)
├─ Query: { status, category, location_bounds, sort_by }
├─ For Customers: GET /tasks?role=customer (posted by me, others)
├─ For Helpers: GET /tasks?role=helper (available, assigned to me)
├─ Response: [ { id, title, distance, budget_est, helper_rating } ]
├─ Pagination: 20 items/page
└─ Status: 200

POST /tasks/:id/accept
├─ Request: { helper_id }
├─ Action:
│  1. Check helper online status
│  2. Assign task (task.helper_id = helper_id)
│  3. Generate OTP in Redis (6 digits, 2h TTL)
│  4. Create task_status_history entry
│  5. Emit Socket.IO: task:accepted
│  6. Send push notification to customer
├─ Response: { task_id, otp_delivery_status: 'sms_sent' }
└─ Status: 200

PUT /tasks/:id/status
├─ Request: { new_status, metadata: { otp_entered?, lat?, lng? } }
├─ Allowed transitions:
│  - assigned → on_the_way
│  - on_the_way → reached (with OTP verification)
│  - reached → in_progress
│  - in_progress → completed (with photos)
├─ Action:
│  1. Validate status transition
│  2. Create task_status_history entry
│  3. Update task.status
│  4. Emit Socket.IO: task:status_changed
│  5. Update real-time counters in Redis
├─ Response: { task_id, status, updated_at }
└─ Status: 200

POST /tasks/:id/cancel
├─ Request: { reason, cancellation_fee_applied }
├─ Validation: Only before in_progress (or with admin approval)
├─ Response: { refund_amount, cancellation_fee }
└─ Status: 200

=======================
PAYMENT ENDPOINTS
=======================

POST /payments/checkout
├─ Request: { task_id, payment_method: 'upi', payment_timing: 'pay_now' }
├─ Action:
│  1. Fetch task (with budget_min, budget_max)
│  2. Calculate final_price (base + distance + time + multipliers)
│  3. Create Razorpay order
│  4. Store order_id in DB
├─ Response: {
│   razorpay_order_id,
│   amount_paise,
│   customer_name,
│   payment_method_options
│ }
└─ Status: 201

POST /payments/verify
├─ Request: {
│   razorpay_order_id,
│   razorpay_payment_id,
│   razorpay_signature
│ }
├─ Action:
│  1. Verify signature (Razorpay + secret key)
│  2. Update payment.payment_status = 'completed'
│  3. Store helper_payout_amount (85%)
│  4. Emit Socket.IO: payment:completed
│  5. Trigger notification: "Payment confirmed"
├─ Response: { payment_id, status: 'completed' }
└─ Status: 200

GET /payments/:id
├─ Response: { task_id, amount, status, razorpay_refs }
└─ Status: 200

POST /payments/:id/refund
├─ Request: { reason, refund_amount_paise }
├─ Action:
│  1. Validate refund window (within 24h of payment)
│  2. Create Razorpay refund via API
│  3. Update payment.refund_status = 'completed'
├─ Response: { refund_id, status }
└─ Status: 200

=======================
PAYOUT ENDPOINTS
=======================

POST /payouts/withdraw
├─ Request: { amount_rupees, withdrawal_method: 'bank' | 'upi' }
├─ Validation:
│  1. Helper has >= amount in available balance
│  2. Bank details are verified
│  3. No pending disputes
├─ Action:
│  1. Create payout record (status='pending')
│  2. Add to Redis queue for processing
│  3. Emit Socket.IO: payout:requested
├─ Response: { payout_id, payout_id_display, status: 'pending' }
├─ Processing: Every night (batch process)
└─ Status: 201

GET /payouts
├─ Response: [ { payout_id_display, amount, status, requested_at, processed_at } ]
├─ Only helper's own payouts (auth check)
└─ Status: 200

GET /payouts/:id
├─ Response: { amount, status, destination, failure_reason?, retry_count? }
└─ Status: 200

=======================
DISPUTE ENDPOINTS
=======================

POST /disputes
├─ Request: {
│   task_id, raised_by_user_id, category: 'quality' | 'pricing' | ...,
│   title, description, evidence_urls[]
│ }
├─ Action:
│  1. Create dispute record (status='open')
│  2. Put task.payment in hold (refund & payout both pending)
│  3. Emit Socket.IO: dispute:created
│  4. Alert admin dashboard
├─ Response: { dispute_id, dispute_id_display, status: 'open' }
└─ Status: 201

GET /disputes (admin only)
├─ Response: [
│   { dispute_id_display, task_id, raised_by, category, status, created_at }
│ ]
├─ Filter: { status: 'open', assigned_to, priority }
└─ Status: 200

GET /disputes/:id
├─ Response: {
│   dispute_id, task_id, raised_by, against, category,
│   description, evidence_urls,
│   chat_history, task_details, resolution_decision
│ }
├─ Only: Admin OR parties involved
└─ Status: 200

PUT /disputes/:id/resolve
├─ Request: (admin only) {
│   resolution_type: 'customer_win' | 'helper_win' | 'partial',
│   customer_refund_percent, helper_payout_percent,
│   resolution_notes
│ }
├─ Action:
│  1. Validate request (admin_only)
│  2. Update dispute.status = 'resolved'
│  3. Calculate refund & payout amounts
│  4. Trigger payments (via background job)
│  5. Send emails to both parties
├─ Response: { dispute_id, status: 'resolved', amounts }
└─ Status: 200

=======================
ADMIN ENDPOINTS
=======================

GET /admin/dashboard
├─ Response: {
│   metrics: { tasks_today, revenue_today, helpers_online, disputes_open },
│   activity_feed: [ { timestamp, action, entity_type, entity_id } ],
│   alerts: [ { severity, message, action_link } ]
│ }
├─ Auth: admin_only
├─ Real-time: via Socket.IO (not this endpoint)
└─ Status: 200

GET /admin/helpers/pending-approval
├─ Response: [
│   { helper_id, name, phone, applied_at, documents_verified_count }
│ ]
├─ Auth: admin_only
└─ Status: 200

PUT /admin/helpers/:id/approve
├─ Request: { action: 'approve' | 'reject', reason_if_reject }
├─ Action: Update helper.verification_status
├─ Response: { helper_id, verification_status }
└─ Status: 200

PUT /admin/helpers/:id/suspend
├─ Request: { reason, suspension_duration_days }
├─ Action:
│  1. Update helper.helper_status = 'suspended'
│  2. Create helper_suspension_log entry
│  3. Emit Socket.IO: helper:suspended
├─ Response: { helper_id, suspension_end_at }
└─ Status: 200

PUT /admin/pricing
├─ Request: {
│   base_fare, per_km_rate, per_minute_rate, platform_fee_percent
│ }
├─ Action: Create new pricing_config (version control)
├─ Response: { config_id, effective_from }
└─ Status: 200

GET /admin/analytics
├─ Query: { start_date, end_date, metrics: ['gmv', 'commission', 'disputes'] }
├─ Response: { time_series_data, summary }
└─ Status: 200

=======================
COMMON PATTERNS
=======================

All Endpoints:
├─ Authentication: Bearer token in Authorization header
├─ Validation: Input validation + rate limiting
├─ Error handling: { error_code, message, details }
├─ Pagination: offset, limit (default 20)
├─ Sorting: sort_by, sort_order
└─ Timestamps: ISO 8601 UTC

Rate Limiting (Redis-based):
├─ Authenticated users: 1000 req/min
├─ Public endpoints: 100 req/min per IP
├─ OTP requests: 10/hour per phone
└─ Location updates: 100/second per helper

Caching Strategy:
├─ Helper profiles: 60s (L1 Redis)
├─ Available tasks: 30s
├─ Pricing config: 24h (rarely changes)
├─ User session: 7 days (refresh token)
└─ Dispute details: no caching (always fresh)
```

---

### **Layer 3: Real-Time Layer (Socket.IO)**

#### **3.1 Socket.IO Architecture**

```
SOCKET.IO NAMESPACE DESIGN:

/task
├─ Rooms: task:{task_id}
├─ Events (client → server):
│  ├─ task:request_location
│  │  └─ Payload: { task_id, lat, lng, accuracy_meters }
│  │  └─ Frequency: Every 2 seconds (active task)
│  │  └─ Redis store: tasks:locations:{task_id}
│  │
│  ├─ task:otp_request
│  │  └─ Payload: { task_id }
│  │  └─ Action: Generate OTP, send SMS + push
│  │
│  ├─ task:otp_submit
│  │  └─ Payload: { task_id, otp_entered }
│  │  └─ Action: Validate (Redis), mark task:reached
│  │
│  └─ task:photo_upload_complete
│     └─ Payload: { task_id, photo_urls[] }
│     └─ Action: Update task, notify customer
│
├─ Events (server → client):
│  ├─ task:new_available
│  │  └─ To: Nearby helpers (room: helpers:location:{zone})
│  │  └─ Payload: { task_id, title, distance, budget_est, countdown_sec }
│  │  └─ Rate: Instant (no queue)
│  │
│  ├─ task:accepted
│  │  └─ To: Customer (room: task:{task_id})
│  │  └─ Payload: { task_id, helper_id, helper_name, eta_minutes }
│  │  └─ Trigger: Push notification
│  │
│  ├─ task:status_update
│  │  └─ To: Both parties (room: task:{task_id})
│  │  └─ Payload: { task_id, new_status, timestamp }
│  │  └─ Example: on_the_way → reached
│  │
│  ├─ location:update
│  │  └─ To: Customer only (room: task:{task_id}:customer)
│  │  └─ Payload: { helper_lat, helper_lng, eta_seconds }
│  │  └─ Frequency: Every 2 seconds
│  │  └─ Optimization: Only if moved > 10m or ETA changed
│  │
│  ├─ otp:sent
│  │  └─ To: Both parties (room: task:{task_id})
│  │  └─ Payload: { task_id, delivery_method: 'sms' | 'push' }
│  │  └─ Trigger: SMS + in-app notification
│  │
│  └─ payment:confirmation
│     └─ To: Both parties (room: task:{task_id})
│     └─ Payload: { task_id, amount, status: 'completed' }

/chat
├─ Rooms: task:{task_id}:chat
├─ Events:
│  ├─ chat:send
│  │  └─ Payload: { task_id, message_text, sender_id }
│  │  └─ Store in DB + Redis (recent 10 messages)
│  │
│  └─ chat:received
│     └─ Payload: { message_id, timestamp, sender_name }

/admin
├─ Rooms: admin (all connected admins)
├─ Events (server → admin):
│  ├─ dashboard:kpi_update
│  │  └─ Payload: { tasks_today, revenue, helpers_online, disputes_open }
│  │  └─ Frequency: Every 5 seconds
│  │
│  ├─ dispute:new_open
│  │  └─ Payload: { dispute_id, task_id, raised_by_name }
│  │  └─ Frequency: Instant
│  │
│  ├─ helper:pending_approval
│  │  └─ Payload: { helper_id, name, documents_count }
│  │  └─ Frequency: Instant
│  │
│  └─ alert:action_required
│     └─ Payload: { severity, message, entity_id }

AUTHENTICATION & AUTHORIZATION:
├─ Socket connection: Bearer token in query string (?token=...)
├─ Room assignment: Based on user_id + role
├─ Message validation: All events validated on server
└─ Disconnection handling: Cleanup on 'disconnect' event
```

---

## Real-Time Architecture Details

### **3.2 Location Tracking System**

```
LIVE LOCATION TRACKING FLOW:

┌─────────────────────┐
│  Helper App         │
│                     │
│  Every 2 seconds:   │
│  - Get GPS coords   │
│  - Calculate delta  │
│  - If moved > 10m   │
│    OR ETA changed:  │
│    → Emit Socket.IO │
│      location:update│
└──────────┬──────────┘
           │
           │ Socket.IO (WebSocket)
           │
           ▼
┌──────────────────────────────────────┐
│  Node.js Backend                     │
│                                      │
│  Socket.IO Handler:                  │
│  socket.on('task:request_location')  │
│    1. Validate auth (token check)    │
│    2. Get task_id from payload       │
│    3. Store in Redis:                │
│       tasks:locations:{task_id}      │
│       {lat, lng, timestamp, accuracy}│
│    4. Calculate distance to customer │
│    5. Calculate new ETA              │
│    6. Broadcast to customer room:    │
│       location:update                │
│    7. Log in task_status_history     │
└──────────────────────────────────────┘
           │
           │ (1 message per 2 sec = 30 msg/min)
           │
           ▼
┌──────────────────────────────────────┐
│  Redis (In-Memory Store)             │
│                                      │
│  Key: tasks:locations:{task_id}      │
│  Value: {                            │
│    lat: 17.3850,                     │
│    lng: 78.4867,                     │
│    timestamp: 1695382800,            │
│    accuracy_meters: 5,               │
│    distance_to_customer_m: 1200,     │
│    eta_minutes: 4                    │
│  }                                   │
│                                      │
│  TTL: 30 minutes (auto-cleanup)      │
└──────────────────────────────────────┘
           │
           │ Broadcast to Customer
           │
           ▼
┌──────────────────────────────────────┐
│  Customer App                        │
│                                      │
│  Socket.IO listener:                 │
│  socket.on('location:update')        │
│    1. Receive new coords             │
│    2. Update map marker              │
│    3. Redraw polyline                │
│    4. Update ETA display             │
│    5. Battery optimization:          │
│       Only update if visible         │
└──────────────────────────────────────┘

TECHNICAL DETAILS:

Location Accuracy:
├─ Minimum accuracy: 10m (filter noisy GPS)
├─ Update threshold: Moved > 10m OR ETA changed > 1 min
├─ Frequency: Every 2 seconds maximum
└─ Battery impact: Minimal (WiFi + cellular triangulation)

Customer Privacy:
├─ Location only shared with assigned helper
├─ Location deleted after task completion (GDPR)
├─ Helper can't see customer's home location (task location only)
└─ No location history stored

Performance:
├─ Data per location: ~150 bytes
├─ 1000 active tasks = 1000 locations/2sec = 500 msg/sec
├─ Redis throughput: 100K ops/sec (plenty of headroom)
├─ Memory: 1000 locations = ~150 KB (negligible)
└─ Network: 500 msg/sec * 150 bytes = 75 KB/sec per server

Offline Handling:
├─ If GPS signal lost:
│  1. Store locally (React Native AsyncStorage)
│  2. Mark as "location uncertain"
│  3. Retry every 5 seconds
│  4. Fall back to last known location
│
├─ If WebSocket disconnected:
│  1. Buffer locations locally
│  2. Reconnect with exponential backoff
│  3. Replay buffered locations on reconnect
│
└─ If app backgrounded:
   1. GPS updates slow (every 30 seconds)
   2. Only on foreground transition
   3. Wake lock: 5 minutes only (battery)

Precision:
├─ Map zoom: Use 6 decimal places (0.1m precision)
├─ ETA calculation: Google Maps Distance Matrix API
├─ Polyline: Use Google's encoded polyline format
└─ Real-time speed: 1s latency (network + processing)
```

---

## OTP Verification Security

### **4.1 OTP System Architecture**

```
SECURE OTP-BASED TASK VERIFICATION:

PHASE 1: OTP GENERATION (at task acceptance)
┌──────────────────────────────────────┐
│ 1. Helper accepts task               │
│    Event: task:accepted              │
│                                      │
│ 2. Backend generates 6-digit OTP:    │
│    - Random number: 100000-999999    │
│    - Uniqueness: Check Redis cache   │
│    - Cryptographic RNG: crypto.js   │
│                                      │
│ 3. Store in Redis (encrypted):       │
│    Key: otp:{task_id}                │
│    Value: {                          │
│      code_hash: sha256(otp_code),    │
│      generated_at: timestamp,        │
│      attempt_count: 0,               │
│      max_attempts: 3,                │
│      ttl: 7200 seconds (2 hours)     │
│    }                                 │
│                                      │
│ 4. Send OTP via dual channels:       │
│    a) SMS via Twilio/AWS SNS         │
│       - "Your OTP: 123456 (valid 2h)"
│    b) Push notification (in-app)     │
│       - "Helper arrived. Share code" │
│       - Code also visible in app     │
│    c) In-app notification:           │
│       - Shows OTP to customer        │
│                                      │
│ 5. Log event:                        │
│    task_status_history {             │
│      task_id,                        │
│      event: 'otp_generated',         │
│      timestamp                       │
│    }                                 │
└──────────────────────────────────────┘

PHASE 2: OTP VERIFICATION (helper enters code)
┌──────────────────────────────────────┐
│ 1. Helper enters 6-digit code        │
│    in app (input validation)         │
│                                      │
│ 2. Helper submits:                   │
│    Event: task:otp_submit            │
│    Payload: { task_id, otp_entered } │
│                                      │
│ 3. Backend validation:               │
│                                      │
│    a) Rate limiting check:           │
│       - Max 10 OTP attempts total    │
│       - Max 3 wrong per 30sec        │
│       - 30-second cooldown after 3rd │
│       - Store in Redis: otp:limits   │
│                                      │
│    b) OTP existence check:           │
│       key = otp:{task_id}            │
│       if !exists: return error       │
│                                      │
│    c) Expiry check:                  │
│       if (now - generated_at) > 2h:  │
│         return "OTP expired"         │
│         expire Redis key immediately │
│                                      │
│    d) Verification logic:            │
│       stored_hash = redis.get(...)   │
│       input_hash = sha256(input_otp) │
│       if hash_equals(stored, input): │
│         ✓ OTP correct               │
│       else:                          │
│         ✗ OTP wrong                 │
│         attempt_count++             │
│         if attempt_count >= 3:       │
│           trigger admin alert       │
│           flag for manual review    │
│                                      │
│ 4. On success:                       │
│    a) Delete OTP from Redis          │
│    b) Update task.status:            │
│       → 'reached' (with OTP verified)│
│    c) Create task_status_history:    │
│       { otp_verified: true, ... }    │
│    d) Start task timer (if needed)   │
│    e) Broadcast Socket.IO:           │
│       task:status_update (reached)   │
│    f) Notify customer (push):        │
│       "Helper verified, task started"│
│                                      │
│ 5. On failure (3x wrong):            │
│    a) Flag task for admin review     │
│    b) Send email to both parties     │
│    c) Start manual verification flow │
│    d) Hold payment until resolved    │
│    e) Log security event:            │
│       { task_id, reason: 'otp_fail..│
└──────────────────────────────────────┘

PHASE 3: BACKUP VERIFICATION (if OTP fails)
┌──────────────────────────────────────┐
│ If OTP verification fails 3x:        │
│                                      │
│ 1. Admin can manually verify:        │
│    - Check GPS location              │
│    - Check customer confirmation     │
│    - Review chat history             │
│                                      │
│ 2. Admin actions:                    │
│    - "Mark as verified" (manual)     │
│    - "Reject verification" (flag)    │
│    - "Request new OTP" (regenerate)  │
│                                      │
│ 3. Customer fallback:                │
│    - Can confirm in app:             │
│      "I confirm helper is here"      │
│    - Sets otp_verified = true        │
│    - Requires phone confirmation     │
│                                      │
│ 4. Escalation:                       │
│    - If unresolved after 30 min      │
│    - Flag as potential fraud         │
│    - Hold payment indefinitely       │
│    - Admin contact both parties      │
└──────────────────────────────────────┘

SECURITY FEATURES:

1. Hash-based Comparison:
   └─ Never store plain OTP in Redis
   └─ Use crypto.timingSafeEqual() for comparison
   └─ Prevents timing attacks

2. Expiry Management:
   └─ OTP valid 2 hours (long enough for network issues)
   └─ Auto-delete from Redis after TTL
   └─ No manual cleanup needed

3. Rate Limiting:
   └─ 10 OTP requests per task per hour
   └─ 30-second cooldown after 3 failures
   └─ Track by (task_id, timestamp)
   └─ Redis key: otp:attempts:{task_id}

4. Audit Trail:
   └─ Every OTP event logged:
   └─ task_status_history {
       event: 'otp_generated' | 'otp_verified' | 'otp_failed',
       attempt_number,
       timestamp,
       helper_id,
       customer_id
     }

5. Multiple Delivery Channels:
   └─ SMS (if app offline)
   └─ Push notification (if app online)
   └─ In-app display (always visible)
   └─ Ensures customer gets it

6. Regeneration:
   └─ Customer can request new OTP:
      event: task:otp_request (max 3x)
   └─ Each regeneration increments counter
   └─ Old OTP becomes invalid immediately

7. Location Verification (bonus):
   └─ Helper GPS location checked
   └─ Must be within 100m of task location
   └─ If > 100m away: OTP marked suspicious
   └─ Admin gets alert

ATTACK PREVENTION:

Brute Force Attack:
├─ 6-digit code = 1 million combinations
├─ Max 10 attempts per 2-hour window
├─ So max 10 guesses, 1/100,000 success rate
├─ After 3 failures: Cooldown + admin alert
└─ Defense: Rate limiting + exponential backoff

Dictionary Attack:
├─ Not applicable (6-digit random)
└─ No common patterns

Replay Attack:
├─ OTP deleted immediately after use
├─ One-time use enforced
├─ Cannot reuse same OTP
└─ Defense: delete-on-use

Man-in-the-Middle (MITM):
├─ All communication: HTTPS + WSS (encrypted)
├─ OTP over SMS (encrypted by carrier)
├─ Token stored in secure enclave (mobile)
└─ Defense: TLS 1.3 + device security

Phishing:
├─ OTP shown in-app (not email/SMS link)
├─ Helper must manually enter
├─ No clickable links with OTP
└─ Defense: No phishing vector

Session Hijacking:
├─ OTP is separate from auth token
├─ Stolen token ≠ can verify task arrival
├─ OTP tied to specific task_id
└─ Defense: Defense in depth
```

---

## Payment Flow

### **5.1 Complete Payment Architecture**

```
PAYMENT FLOW (Pay After Completion):

STEP 1: Task Posted
┌─────────────────────────────┐
│ Customer posts task:        │
│ - No payment yet            │
│ - Task status: unassigned   │
│ - Payment method selected   │
│   (for later charging)      │
└─────────────────────────────┘

STEP 2: Helper Accepts
┌─────────────────────────────┐
│ Helper accepts task:        │
│ - Task status: assigned     │
│ - OTP generated in Redis    │
│ - Still no charge           │
└─────────────────────────────┘

STEP 3: Task Completion
┌─────────────────────────────┐
│ Helper submits task:        │
│ - Photos uploaded           │
│ - Task status: review       │
│ - Customer notified         │
│ - Still no charge           │
└─────────────────────────────┘

STEP 4: Customer Approval
┌─────────────────────────────┐
│ Customer approves OR auto   │
│ approval after 24h:         │
│ - Task status: completed    │
│ - NOW trigger payment flow  │
│ - Payment status: pending   │
└─────────────────────────────┘
          │
          ▼
PAYMENT PROCESSING:
          │
┌─────────────────────────────────────────────────┐
│ 1. Calculate Final Amount:                      │
│                                                 │
│    task_amount = customer budget (or estimate)  │
│    + distance_surcharge (if >2km)               │
│    + time_surcharge (if >30min)                 │
│    + peak_multiplier (if 6-11pm)                │
│    + business_multiplier (if business task)     │
│    = final_amount (e.g., ₹250)                  │
│                                                 │
│    platform_fee = final_amount * 0.15 (₹37.5)   │
│    helper_payout = final_amount - fee (₹212.5) │
│                                                 │
│ 2. Create Payment Record in DB:                │
│    payments {                                   │
│      id: uuid,                                  │
│      task_id,                                   │
│      customer_id,                               │
│      final_amount: 250,                         │
│      platform_fee_amount: 37.5,                 │
│      helper_payout_amount: 212.5,               │
│      payment_status: 'pending',                 │
│      razorpay_order_id: null                    │
│    }                                            │
│                                                 │
│ 3. Create Razorpay Order:                       │
│    POST https://api.razorpay.com/v1/orders     │
│    {                                            │
│      amount: 25000,  // paise                   │
│      currency: 'INR',                           │
│      receipt: task_id,                          │
│      payment_capture: 1,  // auto capture       │
│      notes: { task_id, customer_id }            │
│    }                                            │
│    Response: { id: 'order_xxx', ... }           │
│                                                 │
│ 4. Update Payment Record:                       │
│    Update payments                              │
│    SET razorpay_order_id = 'order_xxx'         │
│                                                 │
│ 5. Initiate Payment:                            │
│    (Multiple options available)                 │
│    a) UPI:                                      │
│       - Send UPI link to customer              │
│       - "Pay ₹250 for SKT74811"                 │
│    b) Card:                                     │
│       - Razorpay checkout form                  │
│    c) Wallet:                                   │
│       - Direct payment                          │
│                                                 │
│ 6. Customer Makes Payment:                      │
│    - Customer clicks payment link              │
│    - Selects UPI app (Google Pay, etc)         │
│    - Authorizes transaction                    │
│    - ₹250 charged from customer's bank         │
│                                                 │
│ 7. Razorpay Webhook (CRITICAL):                │
│    Event: payment.authorized                    │
│    Payload: { payment_id, order_id, status,... }│
│                                                 │
│    Backend processing:                          │
│    a) Verify webhook signature                 │
│       (prevent spoofing)                       │
│    b) Update payment record:                    │
│       UPDATE payments                          │
│       SET payment_status = 'completed',         │
│           razorpay_payment_id = 'pay_xxx',     │
│           completed_at = now()                 │
│                                                 │
│    c) Create payout record for helper:          │
│       INSERT INTO payouts {                     │
│         helper_id,                              │
│         payout_amount: 212.5,                   │
│         status: 'pending',                      │
│         requested_at: now()                     │
│       }                                         │
│                                                 │
│    d) Emit Socket.IO:                           │
│       payment:completed                         │
│       {task_id, amount, status}                 │
│                                                 │
│    e) Send notifications:                       │
│       - Customer: "Payment confirmed"           │
│       - Helper: "₹212.5 earned, pending payout" │
│                                                 │
│ 8. Handle Payment Failure:                      │
│    If Razorpay returns 'failed':                │
│    a) Update payment_status = 'failed'          │
│    b) Notify customer with retry link           │
│    c) Don't charge customer (no duplicate)      │
│    d) Keep task in 'review' state               │
│    e) Customer can retry (max 3 times)         │
│                                                 │
│ 9. Handle Timeout/No Response:                  │
│    If no webhook within 2 minutes:              │
│    a) Backend polls Razorpay API               │
│    b) Check order status via API                │
│    c) Update database accordingly               │
│                                                 │
│ 10. Schedule Payout:                            │
│     Batch job (nightly):                        │
│     - Find all completed payments               │
│     - Group by helper                           │
│     - Sum helper_payout_amounts                 │
│     - Create payout batch                       │
│     - Send to bank (NEFT/IMPS)                  │
│     - Track in database                         │
└─────────────────────────────────────────────────┘

PAYMENT STATE MACHINE:

Task Status          Payment Status      Action
─────────────────────────────────────────────────
unassigned         (none)              No payment
assigned           (none)              No payment
on_the_way         (none)              No payment
reached            (none)              No payment
in_progress        (none)              No payment
review             pending             Customer approves/times out
completed          pending → processing → completed
                   
If customer disputes:
completed          pending → on_hold     Manual admin resolution

REFUND FLOW (if disputed):

1. Dispute raised:
   Task status: completed → disputed
   Payment status: completed → on_hold
   Payout status: pending → on_hold

2. Admin investigates:
   Reviews photos, chat, location data

3. Admin resolves:
   a) Customer Win:
      - Create refund order in Razorpay
      - Charge = ₹250 (full refund)
      - Helper gets ₹0 for this task
      - Platform fee: Keep (₹37.5)
   
   b) Helper Win:
      - No refund issued
      - Release payout (₹212.5)
      - Platform keeps fee (₹37.5)
   
   c) Partial:
      - Refund = ₹125 (customer gets back)
      - Payout = ₹106.25 (helper gets)
      - Platform keeps = ₹18.75 (reduced)

WEBHOOK SECURITY:

1. Signature Verification:
   Razorpay sends header: X-Razorpay-Signature
   Backend verifies:
   
   const crypto = require('crypto');
   const hmac = crypto
     .createHmac('sha256', RAZORPAY_SECRET)
     .update(body)
     .digest('hex');
   
   if (hmac === signature) {
     // Webhook is authentic
   }

2. Idempotency:
   Store received webhook IDs in Redis
   If duplicate: Ignore (don't process twice)

3. Replay Attack Prevention:
   Check timestamp: Webhook must be < 5 minutes old

4. Webhook Retry Logic:
   If backend doesn't ACK within 3 seconds:
   Razorpay retries (exponential backoff)
   - 1st retry: 1 second
   - 2nd retry: 5 seconds
   - 3rd retry: 30 seconds
   - 4th retry: 2 minutes (max 5 retries)
```

---

## Push Notifications

### **6.1 Firebase Cloud Messaging (FCM) Flow**

```
PUSH NOTIFICATION ARCHITECTURE:

REGISTRATION (First App Launch):
┌──────────────────────────────────┐
│ 1. App starts (React Native)     │
│                                  │
│ 2. Request permission:           │
│    const msg = messaging()       │
│    requestPermission()           │
│                                  │
│ 3. Get FCM token:               │
│    const token = await          │
│      messaging().getToken()      │
│    Example: "cfkLdMn5..." (152ch)│
│                                  │
│ 4. Send token to backend:        │
│    POST /auth/register-fcm-token │
│    { fcm_token, device_type }    │
│                                  │
│ 5. Backend stores in DB:         │
│    INSERT INTO users (fcm_token) │
│    WHERE user_id = ?             │
│                                  │
│ 6. Also store in Redis:          │
│    KEY: fcm:user:{user_id}       │
│    VALUE: { token, device_type } │
│    TTL: 30 days                  │
└──────────────────────────────────┘

NOTIFICATION SENDING:

From Backend:

1. Build notification payload:
   {
     notification: {
       title: "New task available",
       body: "Medicine pickup - ₹250",
       sound: "default"
     },
     data: {
       task_id: "t_123",
       action: "task:new",
       priority: "high"
     },
     android: {
       priority: "high",
       notification: {
         sound: "default",
         channelId: "tasks"
       }
     },
     apns: {
       headers: {
         apns-priority: "10"
       }
     }
   }

2. Send via Firebase Admin SDK:
   
   const message = {
     notification: { title, body },
     data: { ... },
     token: fcm_token  // To specific device
   };
   
   const response = await 
     admin.messaging().send(message);
   
   Returns: "projects/xxx/messages/123"

3. Send to topic (broadcast):
   
   const message = { ... };
   const response = await 
     admin.messaging()
     .sendToTopic('task:new', message);

NOTIFICATION TYPES:

1. Task Available (to helpers):
   Title: "New task: Medicine pickup"
   Body: "Location: Hanamkonda | Est. ₹250"
   Data: { task_id, countdown_sec }
   Priority: HIGH (wakes device)
   
2. Task Accepted (to customer):
   Title: "Rohit accepted your task"
   Body: "Rating: 4.8⭐ | ETA: 12 min"
   Data: { task_id, helper_id }
   Priority: HIGH
   
3. Helper Arrived (to customer):
   Title: "Helper reached location"
   Body: "Share OTP to verify arrival"
   Data: { task_id }
   Priority: HIGH
   
4. Task Completed (to customer):
   Title: "Task completed"
   Body: "Photos uploaded. Pay ₹250?"
   Data: { task_id, payment_link }
   Priority: NORMAL
   
5. Payment Confirmation (both):
   Title: "Payment confirmed ✓"
   Body: "₹250 charged. Thank you!"
   Data: { payment_id, receipt_url }
   Priority: NORMAL
   
6. Dispute Alert (admin):
   Title: "⚠️ Dispute raised"
   Body: "Task SKT74811 - Quality issue"
   Data: { dispute_id, severity }
   Priority: HIGH
   
7. OTP Reminder (customer, if needed):
   Title: "OTP Code: 123456"
   Body: "Valid for 2 hours"
   Data: { task_id, otp_code }
   Priority: HIGH

HANDLING NOTIFICATIONS (Client Side):

1. Foreground (app open):
   messaging().onMessage((message) => {
     // App is open, show in-app alert
     displayBannerNotification(message);
     // Also trigger sound/vibration
   });

2. Background (app backgrounded):
   messaging().onNotificationOpenedApp((msg) => {
     // User tapped notification
     navigateTo(msg.data.action);
   });

3. Terminated (app closed):
   messaging().getInitialMessage()
     .then((msg) => {
       // App was closed, user tapped notification
       // This is how background notifications work
     });

DELIVERY TRACKING:

Backend logs all sends:
{
  notification_id: uuid,
  user_id,
  type: 'task:new',
  fcm_token_hash,  // for privacy
  sent_at,
  payload_size_bytes,
  delivery_status: 'sent'  // not guaranteed delivery
}

Analytics:
- Total sent: dashboard
- Delivery rate: ~98% (FCM is reliable)
- Click-through rate: Task:new → Accept rate
- Opt-out rate: Users disabling notifications

OPTIMIZATION:

1. Batch Notifications:
   Instead of 1000 individual sends,
   group by topic (task:new) and send once

2. Rate Limiting:
   Max 5 notifications per user per hour
   (unless critical/high-priority)

3. Quiet Hours:
   Don't send 11pm - 7am
   (unless critical)

4. Frequency Capping:
   Don't send > 1 notif per 5 min
   (unless action required)

FAILURE HANDLING:

1. Invalid token:
   FCM returns error (InvalidArgument)
   Backend marks token as invalid
   Don't send to this token again

2. Token expired:
   FCM returns error (RegistrationTokenNotRegistered)
   Backend requests new token from app
   App fetches new token on next launch

3. Rate limit:
   FCM returns error (QuotaExceeded)
   Backend queues and retries in 5 seconds
   Uses exponential backoff

PRIVACY & COMPLIANCE:

- Don't include sensitive data in notification
  (Don't send OTP in push, only in SMS)
- User can disable notifications per type
- Delete token on account deletion
- GDPR: Token = personal data, handle carefully
```

---

## Authentication & Authorization

### **7.1 Token-Based Security**

```
AUTH FLOW:

┌─────────────────────────────────────────────┐
│ STEP 1: USER REGISTRATION                   │
├─────────────────────────────────────────────┤
│ POST /auth/register                         │
│ { phone_number, name, email }               │
│                                             │
│ Backend:                                    │
│ 1. Validate phone format                   │
│ 2. Check if user exists                    │
│ 3. Generate 6-digit OTP                    │
│ 4. Send OTP via Twilio/AWS SNS             │
│ 5. Store temp record:                      │
│    temp_signup {                            │
│      phone_number,                          │
│      otp_hash: sha256(otp),                │
│      attempts: 0,                           │
│      expires_at: now + 10min                │
│    }                                        │
│ 6. Return: { requires_otp: true }          │
└─────────────────────────────────────────────┘

┌─────────────────────────────────────────────┐
│ STEP 2: OTP VERIFICATION                    │
├─────────────────────────────────────────────┤
│ POST /auth/verify-otp                       │
│ { phone_number, otp_code }                  │
│                                             │
│ Backend:                                    │
│ 1. Fetch temp_signup record                │
│ 2. Check expiry (< 10 min)                 │
│ 3. Verify OTP hash                         │
│ 4. If correct:                             │
│    - Create user record in DB              │
│    - Generate access & refresh tokens      │
│    - Delete temp_signup                    │
│ 5. Return tokens:                          │
│    {                                        │
│      access_token: "jwt...",               │
│      refresh_token: "jwt...",              │
│      user_id: uuid,                        │
│      role: 'customer'                      │
│    }                                        │
└─────────────────────────────────────────────┘

ACCESS TOKEN STRUCTURE (JWT):

Header: { alg: "HS256", typ: "JWT" }

Payload: {
  sub: user_id,              // Subject
  role: 'customer',          // Role
  phone: "+919876543210",    // Phone
  exp: 1695387600,           // Expires in 1 hour
  iat: 1695384000,           // Issued at
  jti: "token_id_xyz"        // JWT ID (for revocation)
}

Signature: HMAC-SHA256(
  base64(header) + "." + base64(payload),
  SECRET_KEY
)

Validation on each request:
1. Check signature (secret key)
2. Check expiry (exp < now)
3. Check revocation list (Redis)
4. Extract user_id from 'sub'

REFRESH TOKEN STRUCTURE:

Payload: {
  sub: user_id,
  type: 'refresh',
  exp: 1700000000,          // Expires in 30 days
  iat: 1695384000
}

Stored in Redis:
KEY: refresh_token:{token_id}
VALUE: { user_id, created_at, revoked: false }
TTL: 30 days

USING TOKENS:

Mobile App (React Native):
1. Store tokens in secure storage:
   SecureStore.setItemAsync('access_token', token)
   SecureStore.setItemAsync('refresh_token', token)

2. Send with each API request:
   headers: {
     'Authorization': `Bearer ${access_token}`
   }

3. On 401 response:
   - Clear tokens
   - Redirect to login
   - OR try refresh (if refresh not expired)

Web Admin (React):
1. Store in secure HTTP-only cookie:
   Set-Cookie: access_token=...; HttpOnly; Secure

2. Browser sends automatically with requests

3. Check expiry before each call:
   if (token_exp < now + 5min) {
     refresh_token_silently();
   }

LOGOUT:

POST /auth/logout
Backend:
1. Invalidate refresh token:
   Redis DELETE refresh_token:{token_id}
2. Add access token to blacklist:
   Redis SET access_token_blacklist:{jti} 1
   TTL: 1 hour (lifetime of token)
3. Clear cookies (web)
4. Return: { success: true }

TOKEN REFRESH:

POST /auth/refresh
{ refresh_token }

Backend:
1. Validate refresh token signature
2. Check if revoked in Redis
3. Check expiry (< 30 days)
4. Generate new access token
5. Keep refresh token (or rotate it)
6. Return: { access_token, refresh_token }

AUTHORIZATION (Role-Based):

Middleware checks role:
- /helpers/register: customer OR new user
- /tasks/*: customer OR helper
- /admin/*: admin only
- /payments/*: auth user
- /payouts/*: helper only
- /disputes/:id/resolve: admin only

SECURITY BEST PRACTICES:

1. Token Expiry:
   - Access token: 1 hour (short-lived)
   - Refresh token: 30 days (long-lived)
   - Silent refresh: When < 5 min to expire

2. Secure Transmission:
   - HTTPS only (TLS 1.3+)
   - WSS (WebSocket Secure) for Socket.IO

3. Secure Storage:
   - Mobile: Secure Enclave / Keychain
   - Web: HTTP-only, Secure, SameSite cookies
   - Never localStorage (vulnerable to XSS)

4. CSRF Protection:
   - Web: Double-submit cookies
   - CORS: Only trusted origins

5. XSS Prevention:
   - Content Security Policy headers
   - Sanitize all user input
   - Never use dangerouslySetInnerHTML

6. Rate Limiting:
   - OTP requests: 10/hour per phone
   - Login attempts: 5/hour per phone
   - API calls: 1000/min per user

7. Token Rotation:
   - Refresh token: Rotate on each refresh
   - Old token invalidated immediately
   - Prevents token reuse

8. Monitoring:
   - Log all auth events
   - Alert on suspicious patterns
   - Monitor failed login attempts
```

---

## Scalability & Performance

### **8.1 Horizontal Scaling**

```
CURRENT ARCHITECTURE (MVP - Single Server):

┌──────────────────────────────────┐
│ Railway (Managed)                │
├──────────────────────────────────┤
│ Node.js Backend (1 instance)     │
│ Capacity: ~1000 concurrent users │
│ PostgreSQL (1 instance)          │
│ Redis (1 instance)               │
│                                  │
│ Costs: ~$7-15/month              │
└──────────────────────────────────┘

FUTURE ARCHITECTURE (If 10K+ concurrent users):

┌─────────────────────────────────────────────────┐
│ Load Balancer (nginx / HAProxy)                 │
└──────────┬──────────────────────┬───────────────┘
           │                      │
      ┌────▼─────┐          ┌─────▼────┐
      │ API      │          │ API      │
      │ Server 1 │          │ Server 2 │
      │ (Railway)│          │ (Railway)│
      └────┬─────┘          └─────┬────┘
           │ Redis Pub/Sub         │
           └───────┬───────────────┘
                   ▼
        ┌──────────────────────┐
        │ Redis Cluster        │
        │ (for cache & queues) │
        │ (Railway managed)    │
        └──────────────────────┘
                   │
                   ▼
        ┌──────────────────────┐
        │ PostgreSQL (Primary) │
        │ (Railway managed)    │
        └──────────────────────┘
                   │
                   ▼
        ┌──────────────────────┐
        │ PostgreSQL (Replica) │
        │ (read-only)          │
        └──────────────────────┘

DATABASE OPTIMIZATION:

Current Indexes (should handle 100K tasks):
├─ tasks(status, created_at DESC)
├─ tasks(location_point) GIST
├─ users(location_point) GIST
├─ helpers(rating DESC)
├─ payments(task_id, payment_status)
└─ disputes(status, created_at DESC)

Future (if 1M+ tasks):
├─ Partition tasks by date (monthly)
├─ Partition payments by date
├─ Archive old disputes
├─ Use read replicas for analytics

CACHING STRATEGY:

Level 1: In-Memory (Redis)
├─ Helper profiles: 60 sec
├─ Active task list: 30 sec
├─ Pricing config: 24 hours
└─ Frequent users: 5 min

Level 2: HTTP Cache
├─ Public endpoints: 300 sec
├─ Admin endpoints: 30 sec
└─ User data: No cache (always fresh)

Level 3: Application Cache
├─ Nearby helpers: Computed every 30 sec
├─ Task discovery: Real-time (Socket.IO)
└─ Location data: 2 sec (real-time)

PERFORMANCE TARGETS:

API Response Times:
├─ Auth endpoints: < 200 ms
├─ Task CRUD: < 300 ms
├─ Payment: < 500 ms (Razorpay call)
├─ Location: < 100 ms
└─ Admin dashboard: < 500 ms

WebSocket Latency:
├─ Location update: < 1 second
├─ Task notification: < 2 seconds
├─ OTP delivery: < 5 seconds
└─ Payment confirmation: < 10 seconds

Database Queries:
├─ Find nearby helpers: < 50 ms (PostGIS GIST)
├─ Task lookup: < 10 ms (index)
├─ User auth: < 50 ms (index)
└─ Complex joins: < 200 ms
```

---

## Security & Compliance

### **9.1 Security Architecture**

```
SECURITY LAYERS:

1. Network Security:
   ├─ HTTPS (TLS 1.3) - all traffic encrypted
   ├─ WSS (WebSocket Secure) - real-time encrypted
   ├─ DDoS protection (Railway managed)
   ├─ Web Application Firewall (WAF)
   └─ Rate limiting (per IP, per user)

2. Application Security:
   ├─ Input validation (all user inputs)
   ├─ SQL injection prevention (parameterized queries)
   ├─ XSS prevention (CSP headers, sanitization)
   ├─ CSRF protection (SameSite cookies)
   ├─ Command injection prevention
   └─ File upload validation (virus scan)

3. Data Security:
   ├─ Encryption at rest:
   │  ├─ Database: PostgreSQL native encryption
   │  ├─ OTP codes: Hashed in Redis
   │  └─ Passwords: Never stored (OAuth/OTP only)
   ├─ Encryption in transit:
   │  ├─ TLS for API
   │  ├─ WSS for WebSocket
   │  └─ HTTPS for external APIs
   └─ Tokenization:
      └─ PCI-DSS: Never touch raw card data
         (Razorpay handles PCI compliance)

4. API Security:
   ├─ Authentication: JWT tokens
   ├─ Authorization: Role-based (RBAC)
   ├─ Rate limiting: Tokens + user + IP
   ├─ Versioning: /v1/, /v2/ paths
   └─ Deprecation: 90-day notice

5. Data Privacy:
   ├─ GDPR compliance:
   │  ├─ User can request data export
   │  ├─ User can request data deletion
   │  ├─ Privacy policy clear
   │  └─ Consent for location tracking
   ├─ Data retention:
   │  ├─ Old disputes: delete after 1 year
   │  ├─ Photos: delete after 3 months
   │  ├─ Logs: delete after 90 days
   │  └─ Payment records: keep for 7 years (tax)
   └─ Minimal collection:
      └─ Only collect data needed for MVP

6. Third-Party Security:
   ├─ Razorpay: PCI-DSS Level 1
   ├─ Firebase: SOC 2 Type II
   ├─ Google Maps: Standard terms
   └─ Twilio: SOC 2 Type II

VULNERABILITY MANAGEMENT:

1. Code Security:
   ├─ Dependency scanning: npm audit
   ├─ SAST: snyk / SonarQube
   ├─ Secrets management: .env (not in git)
   └─ Code review: Before merge to main

2. Deployment Security:
   ├─ Environment parity: dev = prod
   ├─ Secrets in environment: Never in code
   ├─ Supply chain: Verify npm packages
   └─ Container scanning: Docker images

3. Incident Response:
   ├─ Security.txt endpoint for bug reports
   ├─ 48-hour fix SLA for critical bugs
   ├─ Disclosure policy: Responsible disclosure
   └─ Logging: All security events logged

COMPLIANCE:

1. Data Protection:
   ├─ India: Not regulated yet (prepare for future)
   ├─ GDPR (if EU users): Full compliance
   └─ PCI-DSS: Via Razorpay (not direct)

2. Financial:
   ├─ GST: Collect on marketplace fees (per Indian law)
   ├─ Tax reporting: Annual summaries for users
   └─ Payment: Razorpay handles settlement

3. Labor:
   ├─ Gig worker classification:
   │  ├─ Not employees (independent contractors)
   │  ├─ Platform not liable for insurance
   │  └─ Helpers responsible for taxes
   └─ Terms of Service: Clear in app

4. Fraud Prevention:
   ├─ Duplicate account detection:
   │  └─ Same phone = one account only
   ├─ Payment fraud:
   │  └─ Razorpay fraud detection
   ├─ Refund fraud:
   │  └─ Limit refund eligibility (1 per week)
   └─ Dispute abuse:
      └─ Flag accounts with > 5 disputes/month
```

---

## Deployment Architecture

### **10.1 Deployment Pipeline**

```
DEVELOPMENT WORKFLOW:

┌────────────────┐
│ Developer      │
│ (local machine)│
└────────┬───────┘
         │
         │ git push origin feature/xyz
         │
         ▼
┌─────────────────────────┐
│ GitHub (source control) │
│ (or similar)            │
└────────┬────────────────┘
         │
         │ Webhook triggers:
         ▼
┌──────────────────────────────────┐
│ GitHub Actions / Railway Deploy  │
├──────────────────────────────────┤
│ 1. Lint (ESLint)                 │
│ 2. Type check (TypeScript)       │
│ 3. Security scan (Snyk)          │
│ 4. Run tests (Jest)              │
│ 5. Build Docker image            │
│ 6. Push to registry              │
│ 7. Deploy to Railway             │
│ 8. Run migrations                │
│ 9. Health checks                 │
│ 10. Rollback if failed           │
└──────────────────────────────────┘

DEPLOYMENT TARGETS:

Development:
├─ Branch: develop
├─ URL: https://dev-api.sahayakh.com
├─ Database: Separate (sandbox)
└─ Auto-deploy on every push

Staging:
├─ Branch: staging
├─ URL: https://staging-api.sahayakh.com
├─ Database: Copy of production (anonymized)
└─ Deploy on manual trigger

Production:
├─ Branch: main
├─ URL: https://api.sahayakh.com
├─ Database: Real (PostgreSQL on Railway)
├─ Auto-deploy after manual approval
└─ Requires code review + tests passing

INFRASTRUCTURE AS CODE (IaC):

docker-compose.yml (local development):
services:
  backend:
    image: node:18-alpine
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=development
      - DATABASE_URL=postgresql://user:pass@db:5432/sahayakh
      - REDIS_URL=redis://redis:6379
    depends_on:
      - db
      - redis
  
  db:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: sahayakh
      POSTGRES_USER: user
      POSTGRES_PASSWORD: pass
    volumes:
      - postgres_data:/var/lib/postgresql/data
  
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

Dockerfile (production build):
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY src ./src

EXPOSE 3000
CMD ["node", "src/index.js"]

MONITORING & LOGGING:

1. Application Monitoring:
   ├─ Uptime monitoring: Uptime Robot
   ├─ Error tracking: Sentry
   ├─ APM: New Relic (if budget)
   └─ Metrics: Prometheus + Grafana

2. Logging:
   ├─ Centralized logging: ELK Stack (or LogRocket)
   ├─ Structured logs: JSON format
   ├─ Log retention: 30 days
   └─ Alerting: Critical errors email

3. Database Monitoring:
   ├─ Query performance: pg_stat_statements
   ├─ Disk space: Railway dashboard
   ├─ Backups: Daily automated
   └─ Retention: 30 days backup history

ROLLBACK STRATEGY:

If deployment fails:
1. Automatic rollback (Railway feature)
2. Previous version serves traffic
3. Alert sent to team
4. Manual investigation required

If production issue discovered:
1. Hotfix branch from main
2. Minimal code change
3. Deploy to staging first
4. Approve and deploy to production
5. Communicate with users (if needed)
```

---

## Error Handling & Resilience

### **11.1 Error Scenarios**

```
NETWORK FAILURES:

Scenario: Customer loses internet during task
├─ Mobile app:
│  ├─ Queue location updates locally
│  ├─ Attempt reconnect every 5 sec
│  ├─ Show "Offline" indicator
│  ├─ Resume syncing on reconnect
│  └─ Don't notify about offline (reduce noise)
│
└─ Backend: Detect heartbeat loss
   ├─ Wait 30 seconds for reconnection
   ├─ Pause OTP timer (extend window)
   ├─ After 2 min: Flag as inactive
   └─ Customer can re-sync location

DATABASE FAILURES:

Scenario: PostgreSQL unavailable
├─ Read queries: Failover to read replica (if available)
├─ Write queries: Queue in Redis, retry every 10 sec
├─ After 1 hour: Return error to client
└─ Monitoring: Alert ops immediately

Scenario: Redis unavailable
├─ OTP verification: Fallback to database (slower)
├─ Location caching: Skip caching (still works)
├─ Session storage: Use database instead
└─ Performance: Degraded but functional

PAYMENT FAILURES:

Scenario: Razorpay API timeout
├─ Timeout > 30 sec: Retry after 5 seconds
├─ Timeout > 2 min: Queue for manual processing
├─ After 24 hours: Refund customer (if charged)
└─ Notify customer + admin

Scenario: Duplicate payment (race condition)
├─ Idempotency key: Razorpay checks for duplicates
├─ Same order_id twice: Returns existing payment
├─ Backend: Check payment.payment_status before retry
└─ Result: Only charged once

OTP FAILURES:

Scenario: SMS provider (Twilio) down
├─ Fallback: Send OTP via push notification
├─ Show OTP in app (visual backup)
├─ Rate limit SMS attempts (prevent spam)
└─ Alert ops team

Scenario: OTP takes > 2 min to arrive
├─ Resend: User can click "Resend"
├─ New OTP generated: Old one invalidated
├─ Show countdown: "Resend in 30 seconds"
└─ After 5 resends: Trigger manual verification

WEBHOOK FAILURES:

Scenario: Payment webhook missed
├─ Backend polls Razorpay every minute:
│  GET https://api.razorpay.com/v1/orders/{order_id}
│  Check status field
├─ If "paid" but webhook missed: Process payment
├─ Idempotency: Won't process twice
└─ Result: Payment always captured

Scenario: Webhook timeout
├─ Razorpay retries (5 times, exponential backoff)
├─ Eventually succeeds or fails
├─ Backend reconciles via polling
└─ Last resort: Admin manual verification

LOCATION TRACKING FAILURES:

Scenario: GPS signal weak
├─ Use last known location (up to 5 min old)
├─ Mark as "location uncertain" in UI
├─ Fall back to cellular triangulation (if available)
└─ Show warning: "Location outdated"

Scenario: Location service disabled by user
├─ Can't track location
├─ Show message: "Enable location for live tracking"
├─ Offer manual status updates:
│  └─ "I'm nearby" button (no GPS needed)
└─ Can still complete task (just less smooth)

SCALING ISSUES:

Scenario: Sudden spike (1000x users)
├─ API rate limiting kicks in:
│  ├─ Returns 429 (Too Many Requests)
│  └─ Client implements exponential backoff
├─ Non-critical operations deprioritized:
│  └─ Analytics writes queued
├─ Database: Slow queries timeout gracefully
└─ Result: Service stays up, some degradation

SECURITY INCIDENTS:

Scenario: Suspicious activity detected
├─ IP brute-forcing auth:
│  ├─ Block IP for 24 hours
│  ├─ Notify admin
│  └─ Log incident
├─ Unusual payment patterns:
│  ├─ Flag account for review
│  ├─ Require manual verification
│  └─ Alert anti-fraud team
└─ OTP spam attacks:
   ├─ Rate limit: 10/hour per phone
   ├─ Temporary cooldown: 1 hour after 3 failures
   └─ Escalate to admin after 10 attempts

GRACEFUL DEGRADATION:

Full System Available:
├─ Real-time location ✓
├─ OTP verification ✓
├─ Instant notifications ✓
└─ All features work

Degraded Mode (Redis down):
├─ Real-time location: Slower (polling instead)
├─ OTP: Via database (still works)
├─ Notifications: Delayed (batch sending)
└─ Still usable

Minimal Mode (Database down):
├─ No new tasks
├─ No payments
├─ Can view cached data only
└─ Return error: "Service temporarily unavailable"

MONITORING FOR ISSUES:

1. Error Rate:
   ├─ Alert if > 1% of requests fail
   ├─ Alert if > 5% timeout
   └─ Action: Page on-call engineer

2. Latency:
   ├─ Alert if p95 > 1 second
   ├─ Alert if p99 > 5 seconds
   └─ Action: Check database / network

3. Business Metrics:
   ├─ Alert if conversion rate drops 10%
   ├─ Alert if OTP success rate < 95%
   └─ Action: Investigate root cause

4. Resource Usage:
   ├─ Alert if CPU > 80%
   ├─ Alert if Memory > 85%
   ├─ Alert if Disk > 90%
   └─ Action: Scale or optimize
```

---

## Summary: Architecture Decision Matrix

```
DECISION                    CHOICE              RATIONALE
────────────────────────────────────────────────────────────────
API Design                  REST                Simplicity, caching, maturity
Frontend                    React Native        Code reuse, speed, team size
Backend                     Node.js + Express   JavaScript everywhere
Database                    PostgreSQL          PostGIS, ACID, structured data
Real-Time Layer             Socket.IO           WebSocket built-in, easy deployment
Location Tracking           Socket.IO + Redis   Real-time, stateless
OTP Verification            Redis + SMS         Secure, fast, distributed
Payments                    Razorpay            UPI, gig-economy proven
Push Notifications          Firebase            Free, reliable, integrated
Hosting                     Railway             Managed, simple, affordable
Auth                        JWT + Refresh       Stateless, scalable
Caching                     Redis + HTTP cache  Multi-level optimization
Monitoring                  Open source         Sentry, Prometheus, ELK
CI/CD                       GitHub Actions      Built-in, no extra cost
IaC                         Docker + compose    Reproducibility
Scalability                 Horizontal (future) Start simple, scale when needed
```

---

## Next Steps

1. **Share with team:** Distribute this architecture document
2. **Review with CTO:** Validate technology choices
3. **Create API specification:** From REST endpoints above
4. **Create database migration files:** From schema document
5. **Set up development environment:** Docker + local PostgreSQL
6. **Begin backend implementation:** Start with Auth endpoints
7. **Parallel mobile development:** Using Storybook for components

---

**Architecture Version:** 1.0  
**Last Updated:** September 2026  
**Status:** Ready for Implementation  
**Team Size:** 1-3 developers  
**Timeline:** 8 weeks to MVP
