# Sahayakh Fee & Payout System Implementation

## Overview

Implemented a complete fee and payout system that:
- Calculates final task amounts with configurable pricing (base fare, per-km, per-min, surcharges)
- Applies platform commission (15% configurable) and credits 85% to helper earnings
- Manages helper withdrawals via UPI or bank transfer
- Tracks payout status with admin approval workflow
- Provides real-time earnings visibility to helpers

## Architecture

### Services Implemented

#### 1. **Pricing Service** (`packages/backend/src/services/pricing.ts` - 220 lines)

**Capabilities:**
- `getPricingConfig()` - Retrieve current pricing with Redis caching
- `getOrCreatePricingConfig()` - Initialize default pricing if missing
- `calculateFinalAmount()` - Full pricing calculation including:
  - Base fare + distance charges (per km)
  - Distance surcharge for distances > 2km (50% of per-km rate)
  - Time surcharge for durations > 30 minutes
  - Peak hour multiplier (1.1x between 6pm-11pm)
  - Business task multiplier (1.25x)
  - Minimum fare enforcement
- `calculatePaymentBreakdown()` - Calculate 15% platform fee + 85% helper payout
- `updatePricingConfig()` - Admin endpoint to modify pricing with audit logging
- `isPeakHour()` - Check if current time is peak hour

**Key Features:**
- Redis caching (5-min TTL) for high-frequency config requests
- Comprehensive validation for all inputs
- Audit trail logging for all pricing changes
- Support for time-based multipliers

#### 2. **Payment Service** (`packages/backend/src/services/payment.ts` - 240 lines)

**Capabilities:**
- `createPayment()` - Create payment record on task completion
- `updatePaymentStatus()` - Transition payment through states (pending → processing → completed/failed)
- `getHelperPaymentHistory()` - Get all completed payments for a helper
- `getTaskPayment()` - Look up payment for specific task
- `processPaymentForCompletedTask()` - Main entry point for processing completed tasks
  - Validates task completion and no duplicate payment
  - Calculates final amount with actual distance/duration
  - Handles disputed tasks (pending admin review)
  - Tracks payment breakdown
- `getHelperEarningsSummary()` - Break down earnings by time period

**Key Features:**
- Validation of task ownership and completion status
- Duplicate payment prevention
- Dispute handling (payments in disputed tasks held for admin review)
- Earnings breakdown: today, week, month, pending, lifetime
- Auto-completion for non-disputed tasks

#### 3. **Payout Service** (`packages/backend/src/services/payout.ts` - 350 lines)

**Capabilities:**
- `calculateHelperBalance()` - Available balance = completed payments - completed payouts
- `requestPayout()` - Helper requests withdrawal with validation:
  - Minimum amount: ₹100
  - Maximum: available balance
  - Helper verification & background check required
  - No active disputes allowed
  - Valid bank details required (bank transfer or UPI)
- `approvePayout()` - Admin approves pending payout (pending → processing)
- `completePayout()` - Admin marks payout as completed (processing → completed)
- `failPayout()` - Admin or system marks payout as failed with reason
- `getPayoutHistory()` - Get last N payouts for helper
- `getPayoutDetails()` - Detailed payout info for admin or helper view
- `getAdminPayoutList()` - Filtered payout list for admin dashboard
- `shouldWithholdPayout()` - Check if payouts should be withheld (suspended, disputed, unverified)

**Key Features:**
- Comprehensive validation (verification, background check, balance, disputes)
- Auto-increment payout IDs (P-000001, P-000002, etc.)
- Support for both bank transfer and UPI withdrawal methods
- Secure bank detail validation
- Dispute detection and payout withholding
- Admin audit logging for all state changes
- Task ID tracking for payout breakdown

## Database Models (Existing - No Schema Changes)

### Payment Model (schema.prisma lines 339-368)
```
id                 UUID (PK)
task_id            UUID (FK, unique to Task)
customer_id        UUID (FK to User)
final_amount       Decimal (what task ultimately costs)
task_amount        Decimal (base + surcharges)
distance_surcharge Decimal (for distances > 2km)
time_surcharge     Decimal (for durations > 30min)
peak_multiplier    Decimal (1.0 or 1.1x)
platform_fee_amount    Decimal (15% of final)
helper_payout_amount   Decimal (85% of final)
payment_method     PaymentMethod enum (pending, upi, card, netbanking, wallet)
status             PaymentStatus enum (pending, processing, completed, failed, refunded)
razorpay_order_id  String (optional, for Razorpay integration)
razorpay_payment_id String (optional)
created_at         DateTime
completed_at       DateTime (optional)
```

### Payout Model (schema.prisma lines 370-392)
```
id                 UUID (PK)
payout_id_display  String (unique, e.g., P-000001)
helper_id          UUID (FK to User)
total_amount       Decimal (withdrawal amount)
payout_method      PayoutMethod enum (bank_transfer, upi)
status             PayoutStatus enum (pending, processing, completed, failed)
bank_account_number String (optional, for bank transfers)
upi_id             String (optional, for UPI)
task_ids           UUID[] (array of task IDs included in this payout)
created_at         DateTime
processed_at       DateTime (optional)
```

### PricingConfig Model (schema.prisma lines 443-465)
```
id                         UUID (PK)
config_key                 String (unique, e.g., 'current')
base_fare_rupees           Decimal (₹40 default)
per_km_rate                Decimal (₹15 default)
per_minute_rate            Decimal (₹2.50 default)
minimum_fare_rupees        Decimal (₹80 default)
cancellation_fee_rupees    Decimal (₹30 default)
platform_fee_percent       Decimal (15% default)
business_task_multiplier   Decimal (1.25x default)
peak_hour_multiplier       Decimal (1.1x for 6pm-11pm)
daily_bonus_tasks_required Int
daily_bonus_amount         Decimal
effective_from             DateTime
effective_to               DateTime (optional)
created_at                 DateTime
updated_at                 DateTime
```

## REST API Endpoints (To Be Implemented)

### Admin Pricing Management

**`GET /admin/pricing-config`** (Admin Only)
- Returns current pricing configuration
- Response includes all pricing parameters and effective_from timestamp
- Cached for 5 minutes to reduce DB queries

**`POST /admin/pricing-config`** (Admin Only)
- Update pricing configuration
- Body: { base_fare_rupees?, per_km_rate?, minimum_fare_rupees?, platform_fee_percent?, business_multiplier?, peak_multiplier? }
- Validates all inputs before updating
- Logs changes to AuditLog for compliance
- Clears pricing cache
- Response: updated config with effective_from = now()

### Admin Payout Management

**`GET /admin/payouts`** (Admin Only)
- List payouts with optional filtering
- Query params: status (pending/processing/completed/failed), limit, offset
- Returns: [{ payout_id_display, helper_name, amount, status, method, created_at }]
- Sorted by creation date (newest first)

**`GET /admin/payouts/:payout_id`** (Admin Only)
- Get detailed payout info for admin review
- Returns: payout details + helper info + task breakdown + history

**`POST /admin/payouts/:payout_id/approve`** (Admin Only)
- Approve pending payout (pending → processing)
- Validates payout exists and status = pending
- Logs admin action to AuditLog
- Returns: updated payout

**`POST /admin/payouts/:payout_id/complete`** (Admin Only)
- Mark payout as completed
- Body: { transfer_ref_id?, notes? }
- Validates status = processing
- Sets processed_at = now()
- Notifies helper of successful receipt
- Returns: completed payout

**`POST /admin/payouts/:payout_id/fail`** (Admin Only)
- Mark payout as failed
- Body: { reason, notes? }
- Validates status in [pending, processing]
- Stores failure reason
- Notifies helper to retry with updated bank details
- Returns: failed payout

### Helper Earnings & Withdrawal

**`GET /helpers/me/earnings`** (Helper Only)
- Get earnings breakdown
- Returns: { today: ₹X, this_week: ₹X, this_month: ₹X, pending: ₹X, available_balance: ₹X, lifetime: ₹X }
- Used for helper dashboard earnings card
- Helper sees real-time earning progression

**`GET /helpers/me/available-balance`** (Helper Only)
- Check withdrawal eligibility
- Returns: { available_balance, min_withdrawal: ₹100, can_withdraw: true/false, reason_if_no?: string }
- Used to show/hide withdrawal button in UI

**`POST /helpers/me/payouts/request`** (Helper Only)
- Request withdrawal
- Body: { amount, payout_method: 'bank_transfer'|'upi', bank_details: { account_number?, ifsc_code?, holder_name?, upi_id? } }
- Validates:
  - Amount >= ₹100
  - Amount <= available_balance
  - Helper is verified + background checked + not suspended
  - No active disputes
  - Bank details match method
- Creates Payout record with status = 'pending'
- Auto-generates payout_id_display (P-000001, etc.)
- Notifies admin of new payout request
- Response: { payout_id_display, status: 'pending', amount, estimated_completion: 'within 24-48 hours' }

**`GET /helpers/me/payouts/history`** (Helper Only)
- Get withdrawal history
- Query params: limit (default 10), offset (default 0)
- Returns: [{ payout_id_display, amount, status, method, created_at, processed_at, failure_reason? }]
- Sorted by creation date (newest first)

**`GET /helpers/me/payouts/:payout_id`** (Helper Only)
- Get specific payout details
- Returns: { payout details + status update history + retry option if failed }

**`POST /helpers/me/payouts/:payout_id/retry`** (Helper Only)
- Retry failed payout
- Only allowed if status = 'failed'
- Body: { bank_details? } (optional, to update if changed)
- Updates bank details if provided
- Resets status to 'pending' (or creates new Payout)
- Notifies admin of retry
- Response: payout with status = 'pending'

## Payment Processing Flow

### Task Completion → Payment Creation

**Trigger:** When task transitions to 'completed' (Phase 3 integration)

**Process:**
1. Validate task exists and belongs to customer
2. Check no payment already exists for task
3. Get pricing config
4. Calculate final amount:
   - Base = base_fare + (distance_km * per_km_rate)
   - Add distance surcharge if distance > 2km
   - Add time surcharge if duration > 30min
   - Apply peak multiplier if 6pm-11pm
   - Apply business multiplier if task_type = 'business'
   - Enforce minimum fare
5. Calculate breakdown:
   - platform_fee_amount = finalAmount * 15% / 100
   - helper_payout_amount = finalAmount - platform_fee_amount
6. Create Payment record:
   - If task is disputed: status = 'pending' (awaits admin review)
   - If not disputed: status = 'completed' (auto-approved)
7. Update Task.final_amount field
8. Increment helper earnings (tracked via Payment records)

**Example Calculation:**
- Distance: 2.5 km, Duration: 25 min, Personal task, Non-peak, Config: base=₹40, per_km=₹15, min=₹80, fee=15%
- Base: 40 + (2.5 × 15) = 40 + 37.5 = 77.50
- Distance surcharge: (2.5 - 2) × 15 × 0.5 = 0.5 × 15 × 0.5 = ₹3.75
- Time surcharge: 0 (< 30 min)
- Subtotal: 77.50 + 3.75 = ₹81.25
- Peak multiplier: 1.0 (not peak hour)
- Business multiplier: 1.0 (personal task)
- Final: max(81.25, 80) = ₹81.25
- Platform fee: 81.25 × 15 / 100 = ₹12.19 → ₹12 (rounded)
- Helper gets: 81.25 - 12 = **₹69.25**

### Payout Request → Admin Processing → Completion

**Flow:**
1. Helper requests withdrawal:
   - Specifies amount (₹100 minimum)
   - Chooses method (bank transfer or UPI)
   - Provides bank details
   - Payout created with status = 'pending'
   - Payout ID auto-generated (P-000001)
   - Admin notified

2. Admin reviews and approves:
   - POST /admin/payouts/:payout_id/approve
   - Status → 'processing'
   - Bank transfer API queued (or manual transfer)

3. Admin completes:
   - POST /admin/payouts/:payout_id/complete
   - Status → 'completed'
   - processed_at = now()
   - Helper notified: "Withdrawal successful! ₹X received"

4. If fails:
   - POST /admin/payouts/:payout_id/fail { reason }
   - Status → 'failed'
   - Helper can retry with updated bank details
   - Helper notified: "Withdrawal failed. Please update bank details and retry."

## Configuration & Customization

### Pricing Configuration

Admin can update any pricing parameter via POST /admin/pricing-config:

```json
{
  "base_fare_rupees": 40,
  "per_km_rate": 15,
  "per_minute_rate": 2.5,
  "minimum_fare_rupees": 80,
  "platform_fee_percent": 15,
  "business_task_multiplier": 1.25,
  "peak_hour_multiplier": 1.1
}
```

All changes are:
- Logged to AuditLog with old_values and new_values
- Effective immediately (effective_from = now())
- Cached for 5 minutes
- Stored in database for audit trail

### Minimum Payout Amount

Currently hardcoded to ₹100 in payout.ts (MINIMUM_PAYOUT_AMOUNT constant).

To make configurable: Add to PricingConfig model and read from there.

### Peak Hour Definition

Currently: 6pm-11pm (18:00-23:00)

To modify: Edit isPeakHour() function in pricing.ts

## Error Handling

### Payment Errors
- TASK_NOT_FOUND - Task doesn't exist
- UNAUTHORIZED - Not task creator
- TASK_NOT_COMPLETED - Task not in completed state
- PAYMENT_EXISTS - Payment already created
- PAYMENT_NOT_FOUND - Payment lookup failed
- PRICING_CONFIG_NOT_FOUND - Pricing not initialized

### Payout Errors
- HELPER_NOT_FOUND - Helper doesn't exist
- HELPER_SUSPENDED - Suspended helpers can't request payouts
- HELPER_NOT_VERIFIED - Must be verified
- BACKGROUND_CHECK_INCOMPLETE - Background check must be cleared
- ACTIVE_DISPUTE - Can't withdraw with active disputes
- AMOUNT_TOO_LOW - Less than ₹100 minimum
- INSUFFICIENT_BALANCE - Requested > available
- INVALID_BANK_DETAILS - Missing required fields
- INVALID_UPI - UPI ID required
- PAYOUT_NOT_FOUND - Payout doesn't exist
- PAYOUT_NOT_PENDING - Can't approve non-pending
- PAYOUT_NOT_PROCESSING - Can't complete non-processing

## Testing Strategy

### Unit Tests (payment.test.ts - ~200 lines)
- Pricing calculation with various distances/durations
- Payment breakdown (15% fee, 85% payout)
- Peak hour detection
- Disputed task handling
- Payment status transitions
- Duplicate payment prevention
- Authorization checks

### Unit Tests (payout.test.ts - ~200 lines)
- Balance calculation
- Payout request validation
- Minimum amount enforcement
- Helper status checks (verified, background check, not suspended)
- Dispute detection
- Bank detail validation
- Payout status transitions
- Admin approval workflow
- Payout history retrieval

### Integration Test Scenario
```
1. Admin updates pricing: fee=15%, base=₹40, per_km=₹15
2. Customer creates task (budget ₹300)
3. Customer assigns helper
4. Helper completes task (2.5km, 25min, not disputed)
5. POST /complete triggers payment:
   - Final = ₹81.25
   - Platform fee = ₹12
   - Helper gets = ₹69.25
   - Payment.status = 'completed'
6. GET /helpers/me/earnings → available_balance: ₹69.25
7. Helper requests withdrawal: POST /helpers/me/payouts/request
   - Amount: ₹69.25
   - Method: 'upi'
   - UPI: 'user@upi'
   - Creates Payout P-000001 (status='pending')
8. Admin approves: POST /admin/payouts/P-000001/approve
   - Status → 'processing'
9. Admin completes: POST /admin/payouts/P-000001/complete
   - Status → 'completed'
   - processed_at = now()
10. Helper notified: "Withdrawal successful! ₹69.25 received"
11. GET /helpers/me/available-balance → 0
```

## Production Considerations

### Bank Transfer Integration
- Currently mock implementation (sets status = 'processing' and waits for admin to complete)
- Production: Integrate with Razorpay Payouts API or similar
- Implement automatic completion webhook on successful transfer
- Implement automatic failure handling on transfer errors

### UPI Integration
- Currently mock (stores UPI ID)
- Production: Use NPCI UMAPI or Razorpay UPI payouts
- Handle UPI timeout scenarios
- Implement retry logic for failed transfers

### Dispute Handling
- Currently: Check task.status = 'disputed'
- Production: May need separate Dispute model with hold period
- Auto-release payouts after dispute resolution
- Prevent payout requests during disputes

### Scalability
- Payment lookups indexed by (task_id), (customer_id), (status)
- Payout lookups indexed by (helper_id), (status), (created_at)
- Consider archiving old completed payments/payouts to separate table
- Redis caching for pricing config (5-min TTL)

### Compliance & Audit
- All pricing changes logged to AuditLog
- All admin payout actions logged to AuditLog
- Task ID array in Payout for transaction reconciliation
- Timestamps for all state transitions
- Maintains full audit trail for financial audits

## Files Implemented

**Services (3 files):**
- `packages/backend/src/services/pricing.ts` (220 lines) - ✅ Complete
- `packages/backend/src/services/payment.ts` (240 lines) - ✅ Complete
- `packages/backend/src/services/payout.ts` (350 lines) - ✅ Complete

**Routes (2 files - To Be Implemented):**
- `packages/backend/src/routes/admin.ts` (~200 lines)
- `packages/backend/src/routes/helpers.ts` (~150 lines)

**Tests (2 files - To Be Implemented):**
- `packages/backend/tests/payment.test.ts` (~200 lines)
- `packages/backend/tests/payout.test.ts` (~200 lines)

**Integration (1 file - To Be Integrated):**
- `packages/backend/src/services/task.ts` - Call payment.processPaymentForCompletedTask on task completion

## Next Steps

1. Create admin.ts routes for pricing and payout management
2. Create helpers.ts routes for earnings and withdrawal requests
3. Write comprehensive unit and integration tests
4. Integrate payment processing with task completion flow (Phase 3)
5. Test end-to-end: create task → complete → process payment → request withdrawal → approve → complete
6. Deploy and monitor for edge cases (disputes, failed transfers, balance discrepancies)

---

**Implementation Status:** ✅ 60% Complete (Services done, Routes & Tests pending)

**Last Updated:** 2026-09-22
