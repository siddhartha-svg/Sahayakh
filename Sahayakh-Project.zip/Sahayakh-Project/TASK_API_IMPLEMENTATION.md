# Task Creation & Helper Matching API Implementation

## Summary

Successfully implemented the core task marketplace APIs that enable customers to post tasks and find nearby verified helpers to complete them.

## What Was Built

### 1. **Task Service** (`packages/backend/src/services/task.ts`)

- **`createTask(customerId, input)`** - Creates a new task with validation and auto-incremented task ID (SKT00001, SKT00002, etc.)
- **`findTaskById(taskId)`** - Retrieves task with customer and helper details
- **`getNearbyHelpers(taskId, customerId, options)`** - Finds helpers within radius who:
  - Are online or active
  - Are verified and background-checked
  - Accept the task type (personal/business)
  - Match category preferences (if any)
  - Are within service radius
  - Supports 3 sort options: nearest (default), rating, price
- **`assignHelperToTask(taskId, customerId, helperId)`** - Assigns helper and creates notification

### 2. **Utilities**

**Location Utils** (`packages/backend/src/utils/location.ts`)
- `validateLocation()` - Validates lat/lng within Warangal bounds (16.5-18.5°N, 77.5-79.5°E)
- `calculateDistance()` - Haversine formula for distance in km
- `estimateETA()` - Linear estimate: distance / 40 km/hr
- `estimatePrice()` - Calculates estimated price range with business multiplier

**Task Validators** (`packages/backend/src/utils/task-validators.ts`)
- Joi schema for comprehensive input validation
- Date validation (today to 30 days out)
- Time validation (HH:MM format, 00:00-23:59)
- Location bounds validation

### 3. **REST API Routes** (`packages/backend/src/routes/tasks.ts`)

**POST /api/tasks** - Create task
- Request: task_type, category, description, location, dates, budget, business_name (if business), photos
- Response (201): task object + estimated_price_range
- Validations: role==customer, all inputs, location bounds, budget >= ₹30, business_name for business tasks

**GET /api/tasks/:task_id/helpers/nearby** - Find nearby helpers
- Query params: latitude, longitude (optional overrides), radius_km (1-50, default 25), sort_by (nearest/rating/price)
- Response (200): array of up to 10 helpers with:
  - Contact: name, phone, rating, task count, response time
  - Status: online, verified, background-checked
  - Distance/ETA/pricing calculations
  - Badges indicating verification status
- Returns empty array if no helpers found (still 200 status)

**POST /api/tasks/:task_id/assign** - Assign helper
- Request: helper_id
- Response (200): updated task with assigned helper_id
- Creates notification for helper
- Logs status transition in TaskStatusHistory

### 4. **Filtering & Sorting Logic**

**Implicit Filters (non-customizable):**
- helper_status in ('online', 'active')
- verification_status == 'verified'
- background_check_status == 'cleared'
- NOT suspended

**Task-Based Filters:**
- Task type acceptance (accepts_personal_tasks or accepts_business_tasks)
- Category preference (if helper has preferences, must match; if empty, accepts all)
- Service radius (distance_km <= helper.service_radius_km)
- Search radius (distance_km <= radius_km parameter)

**Sorting:**
1. **Nearest** (default) - Ascending distance
2. **Rating** - Descending rating, then ascending distance
3. **Price** - Ascending estimated_price_min

### 5. **Tests** (`packages/backend/tests/tasks.test.ts`)

Comprehensive test suite covering:
- Task creation with valid/invalid inputs
- Budget validation (≥ ₹30)
- Location validation (Warangal bounds)
- Date/time validation
- Business task business_name requirement
- Helper filtering by task type
- Sorting by all three options
- Radius validation
- Assignment authorization (only task owner)
- Duplicate assignment rejection
- Notification creation on assignment
- Authentication requirements

## Database Integration

Uses Prisma ORM queries:
- Task creation with auto-incrementing display ID
- Helper queries with filtering on status, verification, background check
- Location stored as JSON string (can be extended to PostGIS ST_DWithin for true proximity)
- Notification creation on assignment
- TaskStatusHistory logging

## Error Handling

All endpoints return standardized error responses:
```json
{
  "error_code": "CODE",
  "message": "Human readable message",
  "status": 400
}
```

Error codes:
- VALIDATION_ERROR (400) - Input validation failed
- UNAUTHORIZED (401/403) - Auth or authorization issue
- INVALID_LOCATION (400) - Outside Warangal
- BUDGET_TOO_LOW (400) - < ₹30
- DATE_INVALID (400) - Past or > 30 days
- TIME_INVALID (400) - Invalid HH:MM format
- MISSING_BUSINESS_NAME (400) - Business task without name
- TASK_NOT_FOUND (404) - Task doesn't exist
- TASK_ALREADY_ASSIGNED (400) - Already has helper
- HELPER_NOT_FOUND (404) - Helper doesn't exist
- HELPER_NOT_VERIFIED (400) - Helper not verified
- HELPER_SUSPENDED (400) - Helper suspended
- INVALID_RADIUS (400) - Out of 1-50 km range
- INVALID_SORT (400) - Invalid sort option

## Technical Decisions

1. **Location Calculation**: Used Haversine formula (no external API calls) with JSON string storage for coordinates. Can be extended to PostGIS ST_DWithin() for true spatial queries.

2. **Price Estimation**: Calculated client-side based on distance estimate and pricing config. Provides min/max range to customer before commitment.

3. **Distance Filtering**: Applied on application layer after fetching helpers. Can be optimized to PostGIS queries if performance becomes an issue.

4. **Sorting**: Applied after filtering to ensure all sort orders have same data set. Supports switching between nearest/rating/price dynamically.

5. **Notifications**: Created synchronously on assignment. Future: Could be moved to queue for async processing.

## What's NOT Included (Out of Scope)

- Payment processing
- OTP verification for task start
- Task completion flow
- Dispute resolution
- Review/rating system
- Real-time WebSocket updates
- Google Distance Matrix API for true ETA
- S3 photo upload endpoint (photos stored as URLs)

## Files Modified

- `packages/backend/src/index.ts` - Added tasks router mount

## Files Created

- `packages/backend/src/services/task.ts` (250 lines)
- `packages/backend/src/utils/location.ts` (65 lines)
- `packages/backend/src/utils/task-validators.ts` (75 lines)
- `packages/backend/src/routes/tasks.ts` (160 lines)
- `packages/backend/tests/tasks.test.ts` (280 lines)

## Total Lines of Code

~830 lines (including tests)

## API Usage Examples

### Create a Task
```bash
curl -X POST http://localhost:3000/api/tasks \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "task_type": "personal",
    "category": "pickup_delivery",
    "description": "Pick up medicine from Apollo Pharmacy",
    "location_name": "Apollo Pharmacy, Hanamkonda",
    "location_point": {"latitude": 17.36, "longitude": 78.48},
    "preferred_date": "2026-09-25",
    "preferred_time": "14:30",
    "budget_min": 150,
    "budget_max": 300
  }'
```

### Get Nearby Helpers (Sorted by Rating)
```bash
curl -X GET "http://localhost:3000/api/tasks/<task_id>/helpers/nearby?sort_by=rating" \
  -H "Authorization: Bearer <token>"
```

### Assign Helper
```bash
curl -X POST http://localhost:3000/api/tasks/<task_id>/assign \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"helper_id": "<helper_id>"}'
```

## Next Steps

1. Run tests: `npm run test --workspace=packages/backend`
2. Start dev server: `npm run dev:backend`
3. Test endpoints with curl or Postman
4. Extend with payment processing, OTP verification, dispute handling
