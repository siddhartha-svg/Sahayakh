#!/bin/bash

##############################################################################
# Sahayakh Deployment Script
#
# Usage:
#   ./scripts/deploy.sh staging   # Deploy to staging
#   ./scripts/deploy.sh prod      # Deploy to production
#   ./scripts/deploy.sh admin     # Deploy admin dashboard only
#   ./scripts/deploy.sh mobile    # Build mobile apps only
##############################################################################

set -e  # Exit on error

ENVIRONMENT=${1:-staging}
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Helper functions
print_header() {
  echo -e "${BLUE}════════════════════════════════════════${NC}"
  echo -e "${BLUE}$1${NC}"
  echo -e "${BLUE}════════════════════════════════════════${NC}"
}

print_success() {
  echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
  echo -e "${RED}❌ $1${NC}"
}

print_warning() {
  echo -e "${YELLOW}⚠️  $1${NC}"
}

print_info() {
  echo -e "${BLUE}ℹ️  $1${NC}"
}

# Load environment variables
load_env() {
  local env_file="$PROJECT_ROOT/.env.$ENVIRONMENT"
  if [ ! -f "$env_file" ]; then
    print_error "Environment file not found: $env_file"
    exit 1
  fi

  # Export variables from .env file
  set -a
  source "$env_file"
  set +a

  print_success "Loaded environment: $ENVIRONMENT"
}

# Deploy backend to Railway
deploy_backend() {
  print_header "Deploying Backend to Railway ($ENVIRONMENT)"

  local project_id
  local env_name

  if [ "$ENVIRONMENT" = "staging" ]; then
    project_id="$RAILWAY_PROJECT_ID_STAGING"
    env_name="staging"
  elif [ "$ENVIRONMENT" = "prod" ]; then
    project_id="$RAILWAY_PROJECT_ID_PROD"
    env_name="production"

    # Confirmation for production
    print_warning "You are about to deploy to PRODUCTION"
    read -p "Type 'yes' to confirm: " confirm
    if [ "$confirm" != "yes" ]; then
      print_error "Deployment cancelled"
      exit 1
    fi
  else
    print_error "Invalid environment: $ENVIRONMENT"
    exit 1
  fi

  print_info "Building Docker image..."
  docker build -f "$PROJECT_ROOT/packages/backend/Dockerfile" \
    -t sahayakh-backend:latest \
    -t sahayakh-backend:"$ENVIRONMENT" \
    "$PROJECT_ROOT"

  print_success "Docker image built"

  print_info "Installing Railway CLI..."
  npm install -g @railway/cli@latest

  print_info "Logging in to Railway..."
  railway login --token "$RAILWAY_API_TOKEN"

  print_info "Switching to project..."
  railway project:switch "$project_id"
  railway environment:switch "$env_name"

  print_info "Deploying to Railway..."
  railway up --detach

  print_success "Deployment initiated"

  print_info "Checking deployment status..."
  sleep 10

  railway logs --follow &
  LOGS_PID=$!

  # Wait for health check to pass
  local max_attempts=30
  local attempt=0
  while [ $attempt -lt $max_attempts ]; do
    if [ "$ENVIRONMENT" = "staging" ]; then
      if curl -f https://api-staging.sahayakh.com/health 2>/dev/null | grep -q '"status":"ok"'; then
        print_success "Health check passed!"
        kill $LOGS_PID 2>/dev/null || true
        return 0
      fi
    else
      if curl -f https://api.sahayakh.com/health 2>/dev/null | grep -q '"status":"ok"'; then
        print_success "Health check passed!"
        kill $LOGS_PID 2>/dev/null || true
        return 0
      fi
    fi

    echo "Waiting for deployment... ($((attempt+1))/$max_attempts)"
    sleep 5
    ((attempt++))
  done

  print_error "Health check failed after $max_attempts attempts"
  kill $LOGS_PID 2>/dev/null || true
  exit 1
}

# Deploy admin dashboard to Vercel
deploy_admin() {
  print_header "Deploying Admin Dashboard to Vercel ($ENVIRONMENT)"

  print_info "Installing Vercel CLI..."
  npm install -g vercel@latest

  cd "$PROJECT_ROOT/packages/admin-web"

  if [ "$ENVIRONMENT" = "staging" ]; then
    print_info "Building for staging..."
    VITE_API_URL="https://api-staging.sahayakh.com" \
    VITE_SOCKET_URL="wss://api-staging.sahayakh.com" \
    vercel deploy \
      --token="$VERCEL_TOKEN" \
      --scope="$VERCEL_ORG_ID" \
      --project-id="$VERCEL_PROJECT_ID" \
      --env VITE_API_URL=https://api-staging.sahayakh.com \
      --env VITE_SOCKET_URL=wss://api-staging.sahayakh.com \
      --alias admin-staging.sahayakh.com

    print_success "Staging deployment complete: https://admin-staging.sahayakh.com"
  else
    print_info "Building for production..."
    VITE_API_URL="https://api.sahayakh.com" \
    VITE_SOCKET_URL="wss://api.sahayakh.com" \
    vercel deploy \
      --token="$VERCEL_TOKEN" \
      --scope="$VERCEL_ORG_ID" \
      --project-id="$VERCEL_PROJECT_ID" \
      --prod \
      --env VITE_API_URL=https://api.sahayakh.com \
      --env VITE_SOCKET_URL=wss://api.sahayakh.com

    print_success "Production deployment complete: https://admin.sahayakh.com"
  fi

  cd "$PROJECT_ROOT"
}

# Build mobile apps with EAS
build_mobile() {
  print_header "Building Mobile Apps with EAS ($ENVIRONMENT)"

  print_info "Installing EAS CLI..."
  npm install -g eas-cli@latest expo-cli@latest

  # Authenticate with Expo
  if [ -z "$EXPO_TOKEN" ]; then
    print_error "EXPO_TOKEN not set"
    exit 1
  fi

  # Build customer app
  print_info "Building Customer App..."
  cd "$PROJECT_ROOT/packages/mobile"
  eas build --platform android,ios --non-interactive
  print_success "Customer App build complete"

  # Build helper app
  print_info "Building Helper App..."
  cd "$PROJECT_ROOT/packages/mobile-helper"
  eas build --platform android,ios --non-interactive
  print_success "Helper App build complete"

  cd "$PROJECT_ROOT"
}

# Main deployment logic
main() {
  print_header "Sahayakh Deployment Tool"
  print_info "Environment: $ENVIRONMENT"
  print_info "Working directory: $PROJECT_ROOT"

  # Load environment
  load_env

  # Run tests
  print_header "Running Tests"
  npm test --workspace=packages/backend || {
    print_error "Tests failed"
    exit 1
  }
  print_success "Tests passed"

  # Deploy based on command
  case "$ENVIRONMENT" in
    staging)
      deploy_backend
      deploy_admin
      ;;
    prod|production)
      deploy_backend
      deploy_admin
      ;;
    admin)
      deploy_admin
      ;;
    mobile)
      build_mobile
      ;;
    *)
      print_error "Invalid environment: $ENVIRONMENT"
      echo "Usage: ./scripts/deploy.sh [staging|prod|admin|mobile]"
      exit 1
      ;;
  esac

  print_header "Deployment Complete!"
  print_success "All services deployed successfully"
}

# Run main function
main
