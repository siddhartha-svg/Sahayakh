# Sahayakh Project Structure

## 📁 Folder Organization

```
Sahayakh-Project/
├── README.md                          # Project overview
├── PROJECT_STRUCTURE.md               # This file
├── TECH_STACK.md                      # Technology & architecture details
├── prototypes/
│   ├── INDEX.html                     # Navigation hub for all prototypes
│   ├── sahayakh-helper-app.html       # Helper/Worker mobile app
│   ├── sahayakh-app.html              # Customer mobile app
│   └── sahayakh-admin-dashboard.html  # Admin operations dashboard
├── docs/                              # Documentation (to be created)
│   ├── API_DESIGN.md
│   ├── DATABASE_SCHEMA.md
│   ├── USER_FLOWS.md
│   └── FEATURE_LIST.md
├── backend/                           # Backend code (to be created)
│   ├── api/
│   ├── models/
│   ├── services/
│   └── migrations/
├── frontend/                          # Frontend application (to be created)
│   ├── web/
│   ├── mobile/
│   └── shared/
└── deployment/                        # Deployment configs (to be created)
    ├── docker/
    ├── kubernetes/
    └── ci-cd/
```

## 🎯 What is Sahayakh?

**Sahayakh** (Sanskrit: "co-helper") is a **gig economy platform** that connects:

- **Helpers/Workers** - People who want to earn money by completing local tasks
- **Customers** - People who need help with personal or business tasks
- **Admin/Operations Team** - People managing the platform

### Similar Platforms
- TaskRabbit (US)
- Airtasker (Australia)
- Urban Company (India)
- Swiggy Genie (India)

## 📱 Three Main Applications

### 1. Helper App (`sahayakh-helper-app.html`)
**Who uses it:** People providing services (workers/gig workers)

**Key Features:**
- Browse available tasks nearby
- Accept/decline tasks based on type and location
- Real-time navigation to task location
- OTP verification when reaching location
- Task completion workflow with photo upload
- Real-time earnings tracking
- Payment withdrawal system
- Profile & ratings management
- Chat with customers

**Key Screens:**
1. Home - Available tasks, online status toggle
2. New Request - Task details, customer info, earnings estimate
3. Navigate - Live tracking, customer details, chat
4. OTP - Verification at location
5. Task In Progress - Checklist, photo upload, notes
6. Summary - Review earnings, payment details
7. Done - Rating, bonus notification
8. Earnings - Payment history, withdrawal

**Business Logic:**
- Task matching based on location, skill, task type
- Real-time ETA calculation
- OTP-based arrival verification
- Dynamic pricing based on distance and time
- Ratings & review system
- Weekly earnings & payout cycle

---

### 2. Customer App (`sahayakh-app.html`)
**Who uses it:** People needing help with tasks

**Key Features:**
- Create tasks (personal or business)
- Browse available helpers filtered by rating/location/price
- View detailed helper profiles
- Book a helper with payment options
- Live tracking of helper on map
- Chat with helper during task
- Review and rate helper after completion
- Task history and earnings management
- Support chat system

**Key Screens:**
1. Home - Quick mode selection (Personal/Business)
2. Create Task - Task description, photos, location, budget
3. Finding - Search animation, helper discovery
4. Helpers List - Sorted by nearest/rating/price
5. Helper Profile - Details, skills, reviews, rating
6. Confirm - Task review, payment method selection
7. Tracking - Helper's live location on map
8. Task Complete - Rating, review, earnings
9. Task Details - Full history and information

**Business Logic:**
- Task creation with flexible categories
- Helper discovery & filtering
- Skill-based matching
- Real-time location tracking
- Payment handling (pay now or after)
- Rating & feedback system
- Task history & analytics
- Support escalation

---

### 3. Admin Dashboard (`sahayakh-admin-dashboard.html`)
**Who uses it:** Operations team managing the platform

**Key Features:**
- Real-time KPI dashboard with live metrics
- Helper verification & approval workflow
- Helper management (online/offline, suspend, reactivate)
- Task monitoring & assignment
- Dispute resolution interface
- Payout processing & management
- Dynamic pricing configuration
- Analytics & reporting
- Activity feed with real-time updates

**Key Screens:**
1. Overview - KPIs, activity feed, top performers, attention items
2. Approvals - Document verification, skill matching, approval workflow
3. Helpers - Search, filter, view profiles, manage status
4. Tasks - Live task tracking, status management, assignment
5. Disputes - Open disputes, message history, resolution options
6. Payouts - Pending/paid/failed requests, bulk payment
7. Pricing - Rate configuration, fare calculator

**Business Logic:**
- Multi-step verification process for new helpers
- Real-time task assignment optimization
- Dispute mediation & resolution
- Automated payout processing
- Dynamic pricing rules
- Performance monitoring & KPIs
- Fraud detection
- Compliance tracking

---

## 🔄 Core User Flows

### Helper Flow (Earning Money)
```
App Launch
  ↓
Toggle Online Status
  ↓
[Waiting for Task Request]
  ↓
New Task Arrives (Real-time notification)
  ↓
Accept/Decline
  ↓
Navigate to Location [If Accepted]
  ↓
Reach & Share OTP with Customer
  ↓
Complete Checklist & Upload Photos
  ↓
Submit & Get Paid
  ↓
Rate Customer
  ↓
View Earnings
```

### Customer Flow (Getting Help)
```
App Launch
  ↓
Choose Task Type (Personal/Business)
  ↓
Describe Task & Set Budget
  ↓
Add Photos & Preferences
  ↓
Find Helpers (Search & Filter)
  ↓
Review Helper Profile & Ratings
  ↓
Book Helper (Payment Method)
  ↓
Live Track Progress on Map
  ↓
Chat with Helper if Needed
  ↓
Verify Completion
  ↓
Pay & Rate Helper
  ↓
View Task Details
```

### Admin Flow (Managing Platform)
```
Dashboard Overview
  ↓
Check Attention Items (Approvals/Disputes/Payouts)
  ↓
[Parallel]
  ├─ Review Helper Applications
  ├─ Manage Disputes
  ├─ Process Payouts
  ├─ Monitor Live Tasks
  └─ Adjust Pricing
  ↓
Track Metrics & Performance
```

---

## 💾 Data Models (Overview)

### User Types
```
Helper {
  id, name, phone, area
  skills[], rating, tasks_count
  status (active/suspended), online
  bank_details, upi, kyc_docs
  verification_status, rating_history
}

Customer {
  id, name, phone, address
  payment_methods[]
  task_history[], rating
  preferred_helpers[]
}

Admin {
  id, name, role, permissions
  area_assigned, joined_date
}
```

### Task
```
Task {
  id, title, description, photos[]
  customer, helper, category
  type (personal/business)
  location, distance, estimated_time
  budget_range, final_amount
  status (unassigned/assigned/in_progress/completed/cancelled/disputed)
  otp, start_time, end_time
  distance_traveled, time_taken
  payment_status, ratings
}
```

### Payment/Transaction
```
Payment {
  id, task_id, amount
  breakdown (base + km_charge + time_charge - fee)
  method (upi/card/bank), status
  created_at, paid_at
}

Payout {
  id, helper_id, amount
  method, status (pending/paid/failed)
  requested_at, processed_at
}
```

### Dispute
```
Dispute {
  id, task_id, raised_by (customer/helper)
  against, issue, priority
  messages[], evidence[]
  resolution, refund_amount
  status (open/resolved)
}
```

---

## 🚀 Development Roadmap

### Phase 1: Prototype Refinement (Current)
- [x] Create interactive UI prototypes
- [x] User flow documentation
- [ ] Gather user feedback
- [ ] Finalize design system

### Phase 2: Backend Development (Q4 2025)
- [ ] API design & documentation
- [ ] Database schema
- [ ] User authentication (JWT/OAuth)
- [ ] Task matching algorithm
- [ ] Payment integration (Razorpay/Stripe)

### Phase 3: Frontend Development (Q1 2026)
- [ ] React/Vue web app
- [ ] React Native mobile app
- [ ] Real maps integration
- [ ] WebSocket for live updates
- [ ] Push notifications (FCM)

### Phase 4: Launch & Scale (Q2 2026)
- [ ] Beta testing
- [ ] Go-to-market strategy
- [ ] Performance optimization
- [ ] Analytics implementation
- [ ] Public launch

---

## 🎨 Design System

### Colors
```
Primary (Green):      #1B7A3E
Primary Deep:         #0F4D28
Primary Soft:         #E3F3E8
Business (Blue):      #1D58BD
Business Deep:        #144294
Business Soft:        #E2ECFA
Success:              #22C55E
Warning:              #F2A20C
Error:                #C0392B
Neutral (Text):       #0E2217
Neutral (Muted):      #57675E
```

### Typography
```
Font Family: Plus Jakarta Sans
Weights: 400, 500, 600, 700, 800
Scales: 14px base (mobile), 16px+ (desktop)
```

### Components
- Buttons (primary, outline, soft, danger)
- Cards & sheets
- Input fields & forms
- Lists & tables
- Pills & badges
- Progress bars
- Modals & drawers
- Toast notifications

---

## 📊 Key Metrics to Track

**For Helpers:**
- Tasks completed
- Earnings
- Rating
- Response time
- Acceptance rate
- Cancellation rate

**For Customers:**
- Tasks posted
- Helper utilization rate
- Average ratings given
- Repeat bookings
- Disputes raised

**For Admin:**
- GMV (Gross Merchandise Value)
- Active helpers online
- Task completion rate
- Average wait time
- Dispute resolution time
- Customer satisfaction

---

## 🔐 Security Considerations

- Phone number verification (OTP)
- Identity verification (Aadhaar/PAN)
- Background checks for helpers
- Payment encryption
- Data privacy compliance (local laws)
- Dispute mediation system
- Fraud detection

---

## 📞 Support Channels

- In-app chat support
- Phone support
- Email support
- Community forum
- Social media support

---

## 🎯 Success Metrics

- **User Growth:** 10% month-on-month
- **Helper Activation:** 80%+ of new helpers complete first task
- **Task Completion:** 95%+ of tasks completed successfully
- **Customer Satisfaction:** 4.5+ out of 5 average rating
- **Helper Satisfaction:** 4.7+ out of 5 average rating
- **Dispute Rate:** <2% of all tasks
- **Payment Success:** 99%+ payment success rate

---

**Created:** September 2026  
**Status:** Prototype Phase - Ready for Development
