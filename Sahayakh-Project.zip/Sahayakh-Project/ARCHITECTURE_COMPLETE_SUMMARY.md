# Sahayakh System Architecture - Complete Summary

**Document:** SAHAYAKH_SYSTEM_ARCHITECTURE.md  
**Size:** 82 KB, 2,322 lines, 3,500+ word document  
**Created:** September 2026  
**Status:** Complete & Ready for Implementation

---

## ✅ What This Document Covers

### 1. **System Architecture Overview**
- Complete multi-layer architecture diagram
- All components and how they connect
- Data flow between frontend, backend, database, and external services

### 2. **Component Details**
- **React Native Mobile App:** Two modes (Customer + Helper)
- **React Web Admin Dashboard:** All admin workflows
- **Node.js + Express Backend API:** REST endpoints + business logic
- **Socket.IO Real-Time Layer:** WebSocket for instant updates
- **PostgreSQL + Redis:** Data storage and caching
- **External Services:** Razorpay, Firebase, Google Maps

### 3. **API Design (REST)**

**30+ REST Endpoints Documented:**
- Auth: register, verify-otp, refresh, logout
- Helpers: register, documents, status, nearby search
- Tasks: create, list, accept, status update, cancel
- Payments: checkout, verify, refund
- Payouts: withdraw, list, get details
- Disputes: create, list, resolve, appeal
- Admin: dashboard, helper management, dispute resolution, pricing config

**Why REST over GraphQL:**
✅ Simpler for 1-3 developers  
✅ Better caching (HTTP native)  
✅ Easier monitoring  
✅ Proven at scale (Uber, Swiggy use REST)  
✅ Real-time via separate Socket.IO (doesn't need GraphQL subscriptions)  

### 4. **Real-Time Architecture**

**Socket.IO Namespaces & Events:**
- `/task` - Task notifications (45-second countdown, status updates)
- `/chat` - Customer-helper messages
- `/admin` - Real-time KPI dashboards

**Live Location Tracking (2-Second Updates):**
```
Helper App → GPS (every 2 sec)
  → Socket.IO location:update
  → Redis cache (tasks:locations:{task_id})
  → Broadcast to Customer
  → Map updates in real-time
```

Performance: 500 concurrent location updates = 75 KB/sec (plenty of headroom)

### 5. **OTP Verification - Secure Implementation**

**Complete Workflow:**
1. **Generation:** Random 6-digit, stored as hash in Redis (not plain text)
2. **Delivery:** SMS + push notification + in-app display (multi-channel)
3. **Verification:** Hash-based comparison (prevents timing attacks)
4. **Security:** Rate limiting (3 attempts), expiry (2 hours), one-time use

**Attack Prevention:**
- Brute force: Max 10 attempts per 2h window
- Replay attack: Delete on use (one-time)
- MITM: HTTPS + WSS encryption
- Phishing: No clickable links

**Fallback Methods:**
- SMS delivery (if app offline)
- In-app OTP display (always visible)
- Admin manual verification (if all fails)
- Customer confirmation button (no OTP needed as last resort)

### 6. **Payment Flow (Complete End-to-End)**

**Step-by-Step Process:**
1. Task posted (no charge)
2. Helper accepts (no charge)
3. Task completed (no charge)
4. Customer approves → Payment triggered
5. Razorpay order created → Customer pays via UPI/Card
6. Webhook webhook received → Payment confirmed
7. Helper payout scheduled (nightly batch)

**Split Calculation:**
```
Customer pays: ₹250
Platform keeps: ₹37.50 (15%)
Helper gets: ₹212.50 (85%)
```

**Webhook Security:**
- Signature verification (HMAC-SHA256)
- Idempotency (no double-charging)
- Polling fallback (if webhook missed)

**Refund Flow:**
- If disputed: Payment held until resolution
- Admin decides: Customer refund % + Helper payout %
- Razorpay integration for refunds

### 7. **Push Notifications (Firebase)**

**Flow:**
1. App registers → Gets FCM token
2. Backend stores token in DB + Redis
3. Backend sends notification via Firebase Admin SDK
4. Firebase delivers to device
5. App handles foreground/background/terminated states

**Notification Types:**
- Task available (to helpers)
- Task accepted (to customer)
- Helper arrived (to customer)
- OTP code (to customer)
- Payment confirmed (both parties)
- Dispute alerts (admin)

**Rate Limiting:** Max 5 notifications per user per hour

### 8. **Authentication & Authorization**

**Token Design:**
- **Access Token:** JWT, 1-hour expiry (short-lived, secure)
- **Refresh Token:** JWT, 30-day expiry (long-lived, used to refresh access)
- **Storage:** Mobile (Secure Enclave), Web (HTTP-only cookie)

**Authorization:**
- Role-based access control (RBAC)
- Customer only: /tasks/*, /payments/*
- Helper only: /helpers/*, /payouts/*
- Admin only: /admin/*, disputes resolve

**Security:**
- Token revocation list (Redis blacklist)
- Rate limiting (1000 req/min per user)
- CSRF protection (SameSite cookies)
- XSS prevention (CSP headers)

### 9. **Scalability & Performance**

**Current MVP (Single Server):**
- Railway backend: ~1000 concurrent users
- PostgreSQL: One instance
- Redis: One instance
- Cost: $7-15/month

**Future (10K+ concurrent users):**
- Load balancer (nginx)
- Multiple API servers
- PostgreSQL replica (read-only)
- Redis cluster
- Static asset CDN

**Performance Targets:**
- API responses: < 300ms
- WebSocket latency: < 1 second
- Location updates: < 100ms
- Database queries: < 50ms (with indexes)

### 10. **Security & Compliance**

**Layers:**
- Network: HTTPS + WSS
- Application: Input validation, SQL injection prevention, XSS prevention
- Data: Encryption at rest + in transit
- API: JWT auth, rate limiting, CORS

**GDPR & Data Privacy:**
- User can export data
- User can request deletion
- Minimal data collection
- Clear privacy policy
- Location deleted after task completion

**Vulnerability Management:**
- npm audit (dependency scanning)
- Snyk (SAST)
- No secrets in code (environment variables only)
- Code review before merge

### 11. **Deployment Architecture**

**CI/CD Pipeline:**
1. Git push → GitHub
2. GitHub Actions triggered
3. Lint → Type check → Security scan → Tests → Build
4. Docker image pushed to registry
5. Deploy to Railway (staging)
6. Health checks pass → Promote to production
7. Auto-rollback if failed

**Environments:**
- Dev: Auto-deploy every push
- Staging: Manual trigger
- Prod: After code review + tests passing

**Monitoring:**
- Error tracking: Sentry
- Performance: New Relic (if budget)
- Logs: Centralized (ELK)
- Alerts: Critical errors → Email

### 12. **Error Handling & Resilience**

**Network Failures:**
- Client: Queue locally, retry on reconnect
- Server: Detect heartbeat loss, flag as inactive

**Database Failures:**
- Read: Failover to replica
- Write: Queue in Redis, retry every 10 sec

**Payment Failures:**
- Timeout: Retry (exponential backoff)
- Duplicate: Idempotency key prevents double-charge

**OTP Failures:**
- SMS down: Use push notification + in-app display
- Delivery slow: Resend button (max 5x)

**Graceful Degradation:**
- Full system available: All features
- Redis down: Slower, but functional
- DB down: Read cached only, no writes

---

## 🚀 How to Use This Document

### By Role:

**Backend Engineers:**
- Read: REST API endpoints (all 30+)
- Read: OTP verification implementation
- Read: Payment webhook security
- Read: Auth & token design
- Implement: All endpoints from spec

**Mobile Engineers:**
- Read: Real-time location tracking
- Read: Socket.IO events
- Read: Push notification handling
- Read: Auth token management
- Implement: All screens with real-time updates

**DevOps / Infrastructure:**
- Read: Deployment architecture
- Read: Monitoring setup
- Read: Scalability considerations
- Implement: Railway setup, CI/CD, monitoring

**System Architects:**
- Read: Complete overview (first section)
- Read: Architecture decision matrix (last section)
- Reference: All details as needed

**Tech Leads:**
- Validate: Architecture choices
- Review: Security measures
- Plan: Team responsibilities
- Discuss: Scalability timeline

---

## 📊 Key Statistics

| Aspect | Detail |
|--------|--------|
| **REST Endpoints** | 30+ endpoints documented |
| **Socket.IO Events** | 15+ real-time events |
| **Database Tables** | 14 (from schema) |
| **Enums/Types** | 13 status types |
| **Security Layers** | 5 (network, app, data, API, process) |
| **Response Time Target** | < 300ms (API), < 1s (WebSocket) |
| **Concurrent Users** | 1000+ (MVP), 10K+ (with scaling) |
| **Infrastructure Cost** | $7-15/month (MVP) |

---

## 🔑 Key Architectural Decisions

| Decision | Choice | Why |
|----------|--------|-----|
| **API Style** | REST | Simplicity, caching, maturity, team size |
| **Real-Time** | Socket.IO | WebSocket built-in, easy deployment |
| **Location Tracking** | Socket.IO + Redis | Real-time, stateless, scalable |
| **OTP Verification** | Redis hashing | Secure, fast, distributed |
| **Payment Processing** | Razorpay + Webhooks | UPI support, fraud detection, settlement |
| **Push Notifications** | Firebase | Free tier, reliable, integrated |
| **Auth** | JWT (Access + Refresh) | Stateless, scalable, industry standard |
| **Caching** | Multi-level (Redis + HTTP) | Performance optimization |
| **Deployment** | Railway + Docker | Managed, simple, auto-scaling |

---

## ✅ Completeness Checklist

- ✅ **System Architecture Diagram** - Complete with all layers
- ✅ **REST API Specification** - 30+ endpoints fully documented
- ✅ **Real-Time Architecture** - Socket.IO namespaces & events
- ✅ **Location Tracking** - 2-second GPS updates explained
- ✅ **OTP Security** - Complete hashing & rate-limiting
- ✅ **Payment Flow** - Step-by-step with Razorpay integration
- ✅ **Push Notifications** - FCM setup & handling
- ✅ **Authentication** - JWT tokens & refresh mechanism
- ✅ **Scalability** - MVP + future horizontal scaling
- ✅ **Security** - 5-layer approach + GDPR compliance
- ✅ **Deployment** - CI/CD pipeline fully specified
- ✅ **Error Handling** - Graceful degradation for all failures

---

## 🎯 Next Steps for Implementation

### Backend Team (Week 1-2)
1. Set up Node.js + Express project
2. Implement database schema (from 001_sahayakh_initial_schema.sql)
3. Create auth endpoints (/auth/register, /auth/verify-otp, etc.)
4. Set up Socket.IO server
5. Implement location tracking handlers

### Mobile Team (Week 1-2)
1. Set up React Native project
2. Create auth screens
3. Set up Socket.IO client
4. Implement location tracking
5. Add Firebase setup

### DevOps (Week 1)
1. Create Railway account + set up PostgreSQL + Redis
2. Create GitHub Actions CI/CD
3. Configure Docker image
4. Set up Sentry for error tracking
5. Create deployment pipeline

### Integration (Week 3-4)
1. Connect mobile ↔ backend
2. Test location tracking end-to-end
3. Test OTP verification flow
4. Test payment integration with Razorpay (sandbox)
5. Test real-time notifications

---

## 📚 Related Documents

- **SAHAYAKH_PRD.md:** Feature specifications & user flows
- **SAHAYAKH_TECH_STACK.md:** Technology choices & justifications
- **001_sahayakh_initial_schema.sql:** Database schema (to implement)
- **SAHAYAKH_ER_DIAGRAM.md:** Database entity relationships

---

## 💬 Questions?

All details are in **SAHAYAKH_SYSTEM_ARCHITECTURE.md** (2,300+ lines). Use the table of contents to jump to relevant sections.

---

**Status:** Complete & Ready for Implementation  
**Architecture Version:** 1.0  
**Last Updated:** September 2026  
**Team Size:** 1-3 developers  
**Timeline to MVP:** 8 weeks
