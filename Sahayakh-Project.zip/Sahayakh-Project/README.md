# Sahayakh - Gig Economy Task Platform

## Project Overview

Sahayakh is a comprehensive gig economy platform that connects customers who need help with everyday tasks to verified helpers who can complete them. The platform includes three main applications:

1. **Helper App** - For people earning money by completing tasks
2. **Customer App** - For people booking helpers for their tasks
3. **Admin Dashboard** - For operations team to manage the platform

## Prototypes

This folder contains interactive HTML prototypes for all three applications:

- `sahayakh-helper-app.html` - Helper/Worker mobile app interface
- `sahayakh-app.html` - Customer mobile app interface
- `sahayakh-admin-dashboard.html` - Admin operations dashboard

## Features Overview

### Helper App (sahayakh-helper-app.html)
- Task acceptance and live tracking
- OTP verification system
- Real-time earnings dashboard
- Task history and performance metrics
- Location-based task discovery
- Payment withdrawal system

### Customer App (sahayakh-app.html)
- Task creation with multiple categories (Personal & Business)
- Helper discovery and filtering by rating/location/price
- Live task tracking with maps
- Task history and earnings tracking
- Support chat system
- Payment and withdrawal management

### Admin Dashboard (sahayakh-admin-dashboard.html)
- Real-time operations overview (KPIs, live activity feed)
- Helper approvals and document verification
- Helper management (suspend/reactivate)
- Task assignment and monitoring
- Dispute resolution system
- Payout management
- Dynamic pricing configuration

## Technology Stack

**Frontend:**
- Vanilla HTML5/CSS3/JavaScript (no frameworks)
- Responsive design with CSS Grid/Flexbox
- SVG-based icons and avatars
- Dark mode support
- Mobile-first approach

**Design System:**
- Custom CSS variables for theming
- Consistent color palette (brand green #1B7A3E, business blue #1D58BD)
- Reusable components (buttons, cards, chips, pills)
- Accessibility features (ARIA labels, semantic HTML)

## File Structure

```
Sahayakh-Project/
├── README.md (this file)
└── prototypes/
    ├── sahayakh-helper-app.html
    ├── sahayakh-app.html
    └── sahayakh-admin-dashboard.html
```

## How to Use the Prototypes

1. **Open any HTML file in a browser** - Simply drag and drop into your browser or double-click
2. **No dependencies** - All prototypes are self-contained single files
3. **Live simulation** - Admin dashboard has simulated live data updates
4. **Interactive elements** - All buttons and inputs are functional (demo-only)
5. **Dark mode** - Automatically respects system preferences, toggle with sun/moon button

## Key Interactions

### Helper App Demo Flow
1. View home with available tasks
2. Accept a task → Navigate to location
3. Enter OTP when you reach
4. Complete task with photos
5. Review earnings

### Customer App Demo Flow
1. Choose task type (Personal/Business)
2. Describe your task
3. Get helper recommendations
4. View helper profile
5. Confirm and track live

### Admin Dashboard Demo Flow
1. View overview with KPIs
2. Check helper approvals
3. Manage disputes
4. Process payouts
5. Adjust pricing rules

## Design Highlights

✅ **Multi-mode UI** - Helper app with green accent, Customer app with adaptive colors, Admin with dark sidebar  
✅ **Live location tracking** - Animated map with helper movement simulation  
✅ **Real-time updates** - Activity feed, KPI changes, notification badges  
✅ **Accessible forms** - All inputs have proper labels and error states  
✅ **Mobile responsive** - Hamburger menu on smaller screens, adaptive layouts  
✅ **Data persistence** - Demo state maintained during interactions  

## Next Steps for Development

1. **Backend API** - Build REST/GraphQL API for persistence
2. **Authentication** - Implement user registration and login
3. **Database** - Design schema for tasks, users, payments
4. **Real maps** - Integrate Google Maps or Mapbox for actual location tracking
5. **Payment gateway** - Connect Razorpay/Stripe for real payments
6. **Notifications** - Implement Firebase Cloud Messaging for push notifications
7. **Analytics** - Add event tracking and usage analytics

## Quick Reference - Key Components

### Data Objects
- **Helpers**: ID, name, rating, tasks, skills, location, online status
- **Tasks**: ID, title, customer, type, status, amount, helper assignment
- **Disputes**: ID, issue, raised by, against, priority, messages
- **Payouts**: ID, helper, amount, method, status

### Key Screens
- Home/Overview, Task creation, Task tracking, Earnings, Dispute resolution
- Helper profiles, Admin controls, Payment flows

## Color Palette

```
Primary Brand: #1B7A3E (Green)
Business Accent: #1D58BD (Blue)
Success: #22C55E (Green)
Warning: #F2A20C (Orange)
Error: #C0392B (Red)
```

---

**Project Status**: Prototype Phase  
**Last Updated**: September 2026  
**Version**: 1.0
