# Sahayakh Mobile App - Quick Start

## Get Running in 3 Minutes

```bash
# 1. Install
cd packages/mobile
npm install

# 2. Setup environment
cp .env.example .env

# 3. Run
npm start
# Scan QR code or press 'i' (iOS) or 'a' (Android)
```

## What You Get

**Home Screen** - Complete, production-ready
- Logo and branding
- Personal/Business mode selection
- Real theme switching (colors change instantly)
- Features grid
- Action buttons with working navigation
- Promotional banner

**Navigation** - 4 bottom tabs
- 🏠 Home
- 📋 My Tasks
- 💬 Support
- 👤 Account

**Design System** - Ready to use everywhere
```typescript
import { useTheme, colors } from '../theme';

const { mode } = useTheme(); // 'personal' | 'business'
const color = colors.light.accent[mode];
```

**State Management** - Persistent across app
```typescript
import { useAuthStore, useTheme } from '../store';

const { user, setUser, logout } = useAuthStore();
const { mode, setMode } = useTheme();
```

**API Client** - Pre-configured, ready to call
```typescript
import { apiClient } from '../api/client';

await apiClient.createTask(data);
await apiClient.getHelpers(taskId);
await apiClient.completeTask(taskId, data);
```

## Project Commands

```bash
# Development
npm start          # Start Expo dev server
npm run ios        # Run on iOS simulator
npm run android    # Run on Android emulator
npm run web        # Run in web browser

# Building
npm run build      # Build for both platforms
npm run build:ios
npm run build:android

# Code Quality
npm run lint       # Check for lint errors
npm run type-check # TypeScript check
npm test           # Run Jest tests

# Workspace (from monorepo root)
npm run dev:mobile # Start mobile dev
```

## File Locations (Remember These)

| Path | What |
|------|------|
| `packages/mobile/src/screens/HomeScreen.tsx` | Home screen (complete) |
| `packages/mobile/src/theme/` | Design system (colors, typography) |
| `packages/mobile/src/store/index.ts` | Zustand stores |
| `packages/mobile/src/api/client.ts` | Backend API client |
| `packages/mobile/src/components/` | Reusable UI components |
| `packages/mobile/app.json` | Expo configuration |
| `packages/mobile/.env` | Environment variables |

## Most Common Tasks

### Add a new screen
```typescript
// 1. Create: src/screens/MyScreen.tsx
export const MyScreen = ({ navigation }) => {
  const { mode } = useTheme();
  return <View>...</View>;
};

// 2. Export: src/screens/index.ts
export { MyScreen } from './MyScreen';

// 3. Add to RootNavigator: src/navigation/RootNavigator.tsx
<Tab.Screen name="MyTab" component={MyScreen} />
```

### Use theme in component
```typescript
import { useTheme, colors } from '../theme';

const Component = () => {
  const { mode } = useTheme();
  const palette = colors.light;
  const accentColor = palette.accent[mode];
  
  return <View style={{ backgroundColor: accentColor }} />;
};
```

### Call backend API
```typescript
import { apiClient } from '../api/client';

const data = await apiClient.createTask({
  title: 'Help with medicine',
  budget: 500,
  location: 'Hyderabad',
});
```

### Update global state
```typescript
import { useTheme, useAuthStore } from '../store';

const { setMode } = useTheme();
const { setUser } = useAuthStore();

setMode('business');
setUser({ id: '123', name: 'John', role: 'customer' });
```

## Colors Reference

**Personal Mode (Green)**
- Primary: `#1B7A3E`
- Soft: `#E8F5EA`
- Text: `#0D4620`

**Business Mode (Blue)**
- Primary: `#1D58BD`
- Soft: `#E3F2FD`
- Text: `#0D2A5C`

**Universal**
- Surface: `#FFFFFF`
- Surface2: `#F7F8F9`
- Ink (text): `#1A1A1A`
- Muted (light text): `#6B7280`
- Line (borders): `#E5E7EB`
- Success: `#22C55E`
- Error: `#EF4444`

## Configuration

### Environment
```env
# .env
EXPO_PUBLIC_API_URL=http://localhost:3000/api
EXPO_PUBLIC_SOCKET_URL=http://localhost:3000
EXPO_PUBLIC_APP_ENV=development
```

### App Info (app.json)
- Name: Sahayakh
- Bundle ID: com.sahayakh.app
- Package: com.sahayakh.app
- Scheme: sahayakh://

## Troubleshooting

**App won't start?**
```bash
npm start -- --clear
```

**Can't connect to backend?**
- Check `EXPO_PUBLIC_API_URL` in `.env`
- Ensure backend running on that port
- On Android: use `10.0.2.2` instead of `localhost`

**TypeScript errors?**
```bash
npm run type-check
```

**Stuck on splash screen?**
```bash
npm start -- --reset-cache
```

## What's Next?

1. **Create Task Screen** - Form with location, photos, budget
   - Create: `src/screens/CreateTaskScreen.tsx`
   - Add form validation
   - Call `apiClient.createTask()`

2. **Task List** - View active and completed tasks
   - Create: `src/screens/TasksScreen.tsx`
   - Call `apiClient.getTasks()`
   - Show status badges

3. **Helper Discovery** - Find and select helpers
   - Create: `src/screens/HelpersScreen.tsx`
   - Call `apiClient.getHelpers()`
   - Display helper cards

4. **Real-time Tracking** - Live task updates
   - Integrate Socket.io
   - Show map with location
   - Update status in real-time

## Key Dependencies

- **Expo** - Framework (build, dev, deployment)
- **React Navigation** - Tabs + screens
- **Zustand** - State management
- **Axios** - HTTP client
- **TypeScript** - Type safety

## Documentation

- Full Setup Guide: `MOBILE_APP_SETUP.md`
- Package README: `packages/mobile/README.md`
- Expo Docs: https://docs.expo.dev
- React Native: https://reactnative.dev

## Pro Tips

✨ **Use Zustand for all state** - Persists automatically
🎨 **Always use theme colors** - Supports mode switching
📱 **Test on both platforms** - Behavior varies slightly
🔒 **Keep API client updated** - Add new endpoints there
🚀 **Build early, build often** - Catch platform issues early

---

**Ready to build?** Start with the Create Task screen next. DM if questions!
