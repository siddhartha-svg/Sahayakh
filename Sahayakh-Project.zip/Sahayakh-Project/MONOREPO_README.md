# Sahayakh Monorepo

**A hyperlocal task/errand marketplace built with React Native, Node.js, and PostgreSQL.**

## 📁 Project Structure

```
sahayakh-monorepo/
├── packages/
│   ├── backend/                 # Node.js + Express API server
│   │   ├── src/
│   │   │   ├── routes/
│   │   │   ├── middleware/
│   │   │   ├── services/
│   │   │   ├── models/
│   │   │   ├── utils/
│   │   │   ├── config/
│   │   │   └── index.js
│   │   ├── tests/
│   │   ├── .env.example
│   │   ├── package.json
│   │   └── README.md
│   │
│   ├── shared/                  # Shared types, utilities, constants
│   │   ├── src/
│   │   │   ├── types/
│   │   │   │   ├── user.ts
│   │   │   │   ├── task.ts
│   │   │   │   ├── payment.ts
│   │   │   │   └── api.ts
│   │   │   ├── constants/
│   │   │   │   ├── errors.ts
│   │   │   │   ├── status.ts
│   │   │   │   └── config.ts
│   │   │   ├── utils/
│   │   │   │   ├── validation.ts
│   │   │   │   ├── formatting.ts
│   │   │   │   └── helpers.ts
│   │   │   └── index.ts
│   │   ├── package.json
│   │   └── README.md
│   │
│   ├── customer-app/            # React Native customer app
│   │   ├── src/
│   │   │   ├── screens/
│   │   │   │   ├── Auth/
│   │   │   │   ├── Home/
│   │   │   │   ├── TaskCreation/
│   │   │   │   ├── TaskTracking/
│   │   │   │   └── Profile/
│   │   │   ├── components/
│   │   │   ├── navigation/
│   │   │   ├── services/
│   │   │   ├── store/
│   │   │   ├── utils/
│   │   │   └── App.tsx
│   │   ├── .env.example
│   │   ├── package.json
│   │   └── README.md
│   │
│   ├── helper-app/              # React Native helper app
│   │   ├── src/
│   │   │   ├── screens/
│   │   │   │   ├── Auth/
│   │   │   │   ├── Home/
│   │   │   │   ├── TaskAcceptance/
│   │   │   │   ├── Navigation/
│   │   │   │   ├── TaskCompletion/
│   │   │   │   └── Earnings/
│   │   │   ├── components/
│   │   │   ├── navigation/
│   │   │   ├── services/
│   │   │   ├── store/
│   │   │   ├── utils/
│   │   │   └── App.tsx
│   │   ├── .env.example
│   │   ├── package.json
│   │   └── README.md
│   │
│   └── admin-dashboard/         # React web admin dashboard
│       ├── src/
│       │   ├── pages/
│       │   │   ├── Dashboard/
│       │   │   ├── HelperManagement/
│       │   │   ├── DisputeResolution/
│       │   │   ├── PayoutManagement/
│       │   │   └── Settings/
│       │   ├── components/
│       │   ├── hooks/
│       │   ├── services/
│       │   ├── store/
│       │   ├── styles/
│       │   ├── utils/
│       │   ├── App.tsx
│       │   └── main.tsx
│       ├── .env.example
│       ├── vite.config.ts
│       ├── package.json
│       └── README.md
│
├── .github/
│   └── workflows/
│       ├── ci.yml              # CI/CD pipeline (lint, test, build)
│       └── deploy.yml          # Deployment workflow (optional)
│
├── docs/                        # Documentation
│   ├── ARCHITECTURE.md
│   ├── API.md
│   ├── DATABASE.md
│   └── DEPLOYMENT.md
│
├── docker-compose.yml           # Local dev environment
├── .gitignore
├── .prettierrc
├── .eslintrc.json
├── tsconfig.base.json
├── package.json                 # Root workspace package.json
├── package-lock.json
└── README.md                    # This file
```

---

## 🚀 Quick Start

### Prerequisites
- **Node.js:** v18+ ([download](https://nodejs.org/))
- **npm:** v9+ (comes with Node.js)
- **PostgreSQL:** v15+ ([download](https://www.postgresql.org/download/))
- **Redis:** v7+ ([download](https://redis.io/download))
- **Docker & Docker Compose** (optional, for containerized local dev)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/sahayakh.git
   cd sahayakh
   ```

2. **Install dependencies** (monorepo)
   ```bash
   npm install
   ```
   This installs dependencies for all packages due to npm workspaces.

3. **Set up environment variables**
   ```bash
   # Backend
   cp packages/backend/.env.example packages/backend/.env
   
   # Customer app
   cp packages/customer-app/.env.example packages/customer-app/.env
   
   # Helper app
   cp packages/helper-app/.env.example packages/helper-app/.env
   
   # Admin dashboard
   cp packages/admin-dashboard/.env.example packages/admin-dashboard/.env
   ```

4. **Configure environment variables**
   - Edit each `.env` file with your local settings
   - For development, use defaults (localhost:3000, etc.)
   - Add your API keys (Razorpay, Firebase, etc.)

5. **Set up database**
   ```bash
   # Create PostgreSQL database
   createdb sahayakh_dev
   
   # Run migrations
   npm run db:migrate --workspace=packages/backend
   ```

6. **Start local services** (using Docker Compose)
   ```bash
   docker-compose up -d
   ```
   This starts PostgreSQL and Redis. Alternatively, start them manually if you have them installed.

---

## 📦 Monorepo Workspaces

### Backend (`packages/backend`)
**REST API server built with Node.js + Express**

```bash
# Start development server
npm run dev --workspace=packages/backend

# Run tests
npm run test --workspace=packages/backend

# Build for production
npm run build --workspace=packages/backend
```

**Runs on:** `http://localhost:3000`  
**Technology:**
- Node.js v18+
- Express.js
- TypeScript
- PostgreSQL (via pg)
- Redis (via ioredis)
- Socket.IO (real-time)
- Jest (testing)

**See:** [packages/backend/README.md](packages/backend/README.md)

---

### Shared (`packages/shared`)
**Shared types, constants, and utilities for all packages**

This package is consumed by all other packages for type safety and DRY principles.

```bash
# Build shared types
npm run build --workspace=packages/shared

# The built files are automatically consumed by other packages
```

**Contains:**
- TypeScript type definitions
- API response/request types
- Shared constants (status enums, error codes)
- Utility functions (validation, formatting)

**See:** [packages/shared/README.md](packages/shared/README.md)

---

### Customer App (`packages/customer-app`)
**Mobile app for customers (React Native)**

```bash
# Start development
npm run dev --workspace=packages/customer-app

# Run tests
npm run test --workspace=packages/customer-app

# Build for iOS
npm run ios --workspace=packages/customer-app

# Build for Android
npm run android --workspace=packages/customer-app
```

**Runs on:** iOS Simulator / Android Emulator / Physical device  
**Technology:**
- React Native v0.72+
- TypeScript
- React Navigation
- Redux or Context API (state management)
- Socket.IO Client (real-time)
- Axios (HTTP client)
- Firebase Cloud Messaging
- React Query (data fetching)

**Features:**
- Customer authentication
- Post tasks
- Search helpers
- Real-time task tracking
- Payments (Razorpay)
- Ratings

**See:** [packages/customer-app/README.md](packages/customer-app/README.md)

---

### Helper App (`packages/helper-app`)
**Mobile app for helpers/gig workers (React Native)**

```bash
# Start development
npm run dev --workspace=packages/helper-app

# Run tests
npm run test --workspace=packages/helper-app

# Build for iOS
npm run ios --workspace=packages/helper-app

# Build for Android
npm run android --workspace=packages/helper-app
```

**Runs on:** iOS Simulator / Android Emulator / Physical device  
**Technology:**
- React Native v0.72+
- TypeScript
- React Navigation
- Redux or Context API (state management)
- Socket.IO Client (real-time)
- Axios (HTTP client)
- Firebase Cloud Messaging
- Geolocation (native module)
- React Query (data fetching)

**Features:**
- Helper authentication
- Browse available tasks
- Accept/complete tasks
- OTP verification
- Live location tracking
- Earnings tracking
- Payouts

**See:** [packages/helper-app/README.md](packages/helper-app/README.md)

---

### Admin Dashboard (`packages/admin-dashboard`)
**Web admin dashboard built with React + Vite**

```bash
# Start development server
npm run dev --workspace=packages/admin-dashboard

# Run tests
npm run test --workspace=packages/admin-dashboard

# Build for production
npm run build --workspace=packages/admin-dashboard
```

**Runs on:** `http://localhost:5173`  
**Technology:**
- React 18+
- TypeScript
- Vite (fast build tool)
- React Router (routing)
- TanStack Query (data fetching)
- Axios (HTTP client)
- Socket.IO Client (real-time)
- TailwindCSS (styling)
- Recharts (dashboards/analytics)

**Features:**
- Real-time KPI metrics
- Helper management & approvals
- Task monitoring
- Dispute resolution
- Payout management
- Dynamic pricing configuration
- Admin audit logs

**See:** [packages/admin-dashboard/README.md](packages/admin-dashboard/README.md)

---

## 🛠️ Running Everything Locally

### Option 1: Run All Services Concurrently (Recommended)

```bash
# Terminal 1: Run all services
npm run dev

# This starts:
# - Backend API on http://localhost:3000
# - Customer app on iOS Simulator / Android Emulator
# - Helper app on iOS Simulator / Android Emulator
# - Admin dashboard on http://localhost:5173
```

### Option 2: Run Services Individually

```bash
# Terminal 1: Backend
npm run dev:backend

# Terminal 2: Customer App
npm run dev:customer

# Terminal 3: Helper App
npm run dev:helper

# Terminal 4: Admin Dashboard
npm run dev:admin
```

### Option 3: Use Docker Compose (Recommended for Clean Environment)

```bash
# Start PostgreSQL, Redis, and all services
docker-compose up

# View logs
docker-compose logs -f

# Stop all services
docker-compose down
```

---

## 🧪 Testing

### Run Tests for All Packages
```bash
npm run test
```

### Run Tests for Specific Package
```bash
npm run test --workspace=packages/backend
npm run test --workspace=packages/shared
```

### Watch Mode (Reruns on File Changes)
```bash
npm run test:watch
```

### Test Coverage
```bash
npm run test -- --coverage
```

---

## 📝 Linting & Code Quality

### Run Linter on All Packages
```bash
npm run lint
```

### Fix Linting Issues
```bash
npm run lint:fix
```

### Type Check (TypeScript)
```bash
npm run type-check
```

### Format Code with Prettier
```bash
npm run format
```

---

## 🏗️ Building for Production

### Build All Packages
```bash
npm run build
```

### Build Specific Package
```bash
npm run build --workspace=packages/backend
```

**Build Outputs:**
- **Backend:** `packages/backend/dist/` (Node.js code)
- **Shared:** `packages/shared/dist/` (Type definitions + compiled JS)
- **Customer App:** Use React Native CLI for APK/IPA
- **Helper App:** Use React Native CLI for APK/IPA
- **Admin Dashboard:** `packages/admin-dashboard/dist/` (Static HTML/CSS/JS)

---

## 🌍 Environment Variables

Each service has an `.env.example` file. Copy it to `.env` and fill in your values.

### Backend (packages/backend/.env)
```env
# Server
NODE_ENV=development
PORT=3000

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/sahayakh_dev

# Redis
REDIS_URL=redis://localhost:6379

# JWT
JWT_SECRET=your-secret-key-here
JWT_REFRESH_SECRET=your-refresh-secret-here

# External Services
RAZORPAY_KEY_ID=your-razorpay-key
RAZORPAY_KEY_SECRET=your-razorpay-secret

FIREBASE_PROJECT_ID=your-firebase-project
FIREBASE_PRIVATE_KEY=your-firebase-private-key
FIREBASE_CLIENT_EMAIL=your-firebase-email

# APIs
GOOGLE_MAPS_API_KEY=your-google-maps-key

# Email (optional, for notifications)
SENDGRID_API_KEY=your-sendgrid-key

# Logging
LOG_LEVEL=debug
```

### Customer App (packages/customer-app/.env)
```env
# API
REACT_APP_API_URL=http://localhost:3000/api
REACT_APP_SOCKET_URL=http://localhost:3000

# Firebase
REACT_APP_FIREBASE_API_KEY=your-firebase-api-key
REACT_APP_FIREBASE_PROJECT_ID=your-firebase-project
REACT_APP_FIREBASE_APP_ID=your-firebase-app-id

# Google Maps
REACT_APP_GOOGLE_MAPS_API_KEY=your-google-maps-key

# Razorpay
REACT_APP_RAZORPAY_KEY=your-razorpay-key

# Environment
REACT_APP_ENV=development
```

### Helper App (packages/helper-app/.env)
```env
# API
REACT_APP_API_URL=http://localhost:3000/api
REACT_APP_SOCKET_URL=http://localhost:3000

# Firebase
REACT_APP_FIREBASE_API_KEY=your-firebase-api-key
REACT_APP_FIREBASE_PROJECT_ID=your-firebase-project
REACT_APP_FIREBASE_APP_ID=your-firebase-app-id

# Google Maps
REACT_APP_GOOGLE_MAPS_API_KEY=your-google-maps-key

# Environment
REACT_APP_ENV=development
```

### Admin Dashboard (packages/admin-dashboard/.env)
```env
# API
VITE_API_URL=http://localhost:3000/api
VITE_SOCKET_URL=http://localhost:3000

# Environment
VITE_ENV=development
```

---

## 🔄 CI/CD Pipeline

This monorepo includes GitHub Actions workflows for continuous integration.

### `.github/workflows/ci.yml`
Runs on every push and pull request:
1. **Lint:** Check code style with ESLint
2. **Type Check:** Verify TypeScript types
3. **Unit Tests:** Run Jest tests
4. **Build:** Build all packages
5. **Code Coverage:** Generate coverage reports

**Status Badge:**
```markdown
[![CI](https://github.com/yourusername/sahayakh/actions/workflows/ci.yml/badge.svg)](https://github.com/yourusername/sahayakh/actions)
```

### `.github/workflows/deploy.yml` (Optional)
Deploy to production on merge to main branch.

---

## 📚 Documentation

- **[Architecture](./SAHAYAKH_SYSTEM_ARCHITECTURE.md)** - System design, API, real-time architecture
- **[API Documentation](./docs/API.md)** - REST endpoints, request/response examples
- **[Database Schema](./001_sahayakh_initial_schema.sql)** - PostgreSQL schema
- **[Tech Stack](./SAHAYAKH_TECH_STACK.md)** - Technology choices and justifications
- **[Deployment Guide](./docs/DEPLOYMENT.md)** - How to deploy to production

---

## 🐛 Troubleshooting

### Port Already in Use
```bash
# Change port in .env
PORT=3001
```

### Database Connection Error
```bash
# Check PostgreSQL is running
psql -c "SELECT 1"

# Check connection string in .env
DATABASE_URL=postgresql://user:password@localhost:5432/sahayakh_dev
```

### Dependencies Not Installing
```bash
# Clear npm cache
npm cache clean --force

# Remove node_modules
rm -rf node_modules

# Reinstall
npm install
```

### Socket.IO Connection Issues
```bash
# Check backend is running on correct port
npm run dev --workspace=packages/backend

# Check REACT_APP_SOCKET_URL in .env points to backend
```

---

## 👥 Contributing

1. Create a branch: `git checkout -b feature/my-feature`
2. Make changes and commit: `git commit -am 'Add my feature'`
3. Ensure tests pass: `npm run test`
4. Ensure linting passes: `npm run lint`
5. Push to branch: `git push origin feature/my-feature`
6. Create a Pull Request

**Pre-commit Hooks:**
This repo uses Husky + lint-staged to run linter and tests before commits. No need to manually run them!

---

## 📦 Tech Stack Summary

| Layer | Technology |
|-------|-----------|
| **Mobile** | React Native, TypeScript, React Navigation |
| **Web (Admin)** | React 18, TypeScript, Vite, TailwindCSS |
| **Backend API** | Node.js, Express, TypeScript, Socket.IO |
| **Database** | PostgreSQL, Redis |
| **Real-Time** | Socket.IO (WebSockets) |
| **Payments** | Razorpay |
| **Push Notifications** | Firebase Cloud Messaging |
| **Maps** | Google Maps API |
| **Testing** | Jest, React Testing Library |
| **Linting** | ESLint, Prettier |
| **CI/CD** | GitHub Actions |

---

## 🚀 Deployment

### Backend
```bash
# Deploy to Railway (or similar)
npm run build --workspace=packages/backend
railway up
```

### Admin Dashboard
```bash
# Deploy to Vercel
npm run build --workspace=packages/admin-dashboard
vercel
```

### Mobile Apps
- Use Expo for iOS/Android distribution
- Or use App Store / Google Play Store deployment

---

## 📞 Support

- **Issues:** [GitHub Issues](https://github.com/yourusername/sahayakh/issues)
- **Discussions:** [GitHub Discussions](https://github.com/yourusername/sahayakh/discussions)
- **Documentation:** See `/docs` folder

---

## 📄 License

MIT License - See LICENSE file for details.

---

## ✅ Checklist for Getting Started

- [ ] Clone repository
- [ ] Install Node.js v18+
- [ ] Run `npm install`
- [ ] Copy `.env.example` → `.env` for each package
- [ ] Set up PostgreSQL and Redis
- [ ] Run `npm run db:migrate` for backend
- [ ] Run `npm run dev` to start all services
- [ ] Test backend on `http://localhost:3000`
- [ ] Test admin dashboard on `http://localhost:5173`
- [ ] Test customer app on iOS Simulator
- [ ] Test helper app on Android Emulator
- [ ] Run `npm run test` to verify tests pass
- [ ] Run `npm run lint` to verify code style

---

**Happy coding! 🎉**

For detailed information about each service, see the individual README files in each package directory.
