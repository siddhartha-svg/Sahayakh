# Prisma Quick Reference

**Get started with Sahayakh database models in 5 minutes**

---

## 🚀 Installation & Setup

```bash
# 1. Install dependencies
npm install

# 2. Generate Prisma client
npx prisma generate

# 3. Create/migrate database
npx prisma migrate dev --name initial_schema

# 4. Seed sample data
npm run db:seed

# 5. View data in GUI
npx prisma studio
```

---

## 📝 Common Queries

### Find User by Phone
```typescript
import prisma from '../config/prisma';

const user = await prisma.user.findFirst({
  where: {
    phone_number: '+919876543210',
    deleted_at: null,
  },
});
```

### Get Helper Profile with Documents
```typescript
const helper = await prisma.helper.findUnique({
  where: { id: helperId },
  include: {
    user: true,
    documents: true,
    tasks: { take: 10 },
    payouts: { where: { status: 'completed' } },
  },
});
```

### List Tasks by Status
```typescript
const tasks = await prisma.task.findMany({
  where: {
    status: 'unassigned',
    task_type: 'personal',
  },
  orderBy: { created_at: 'desc' },
  take: 20,
  skip: 0, // pagination
  include: {
    customer: true,
    payment: true,
  },
});
```

### Create Task with Relations
```typescript
const task = await prisma.task.create({
  data: {
    task_id_display: 'SKT00023',
    customer_id: customerId,
    task_type: 'personal',
    category: 'pickup_delivery',
    status: 'unassigned',
    description: 'Pick up medicine from Apollo Pharmacy',
    location_name: 'Hanamkonda, Warangal',
    budget_min: 150,
    budget_max: 300,
  },
});
```

### Assign Helper to Task
```typescript
const task = await prisma.task.update({
  where: { id: taskId },
  data: {
    helper_id: helperId,
    status: 'assigned',
  },
});

// Create notification
await prisma.notification.create({
  data: {
    user_id: helperId,
    notification_type: 'task_assigned',
    title: 'New task assigned',
    body: `Task ${task.task_id_display} from customer`,
    related_task_id: taskId,
  },
});
```

### Complete Task and Create Payment
```typescript
const updatedTask = await prisma.task.update({
  where: { id: taskId },
  data: {
    status: 'completed',
    final_amount: 220,
    completed_at: new Date(),
  },
});

const payment = await prisma.payment.create({
  data: {
    task_id: taskId,
    customer_id: task.customer_id,
    final_amount: 220,
    task_amount: 200,
    distance_surcharge: 10,
    time_surcharge: 10,
    peak_multiplier: 1.0,
    platform_fee_amount: 33,
    helper_payout_amount: 187,
    payment_method: 'upi',
    status: 'completed',
  },
});
```

### Create Payout
```typescript
const payout = await prisma.payout.create({
  data: {
    payout_id_display: 'P-004',
    helper_id: helperId,
    total_amount: 500,
    payout_method: 'bank_transfer',
    status: 'pending',
    bank_account_number: 'XXXXXX1234',
    task_ids: [taskId1, taskId2, taskId3],
  },
});
```

### Get Helper Ratings
```typescript
const helper = await prisma.helper.findUnique({
  where: { id: helperId },
  include: {
    reviews_received: true,
  },
});

// Calculate average
const avgRating = helper.reviews_received.length > 0
  ? helper.reviews_received.reduce((sum, r) => sum + (r.customer_to_helper_rating === 'five' ? 5 : 3), 0) / helper.reviews_received.length
  : 0;
```

### Update Task Status with History
```typescript
const task = await prisma.task.findUnique({
  where: { id: taskId },
});

// Log status change
await prisma.taskStatusHistory.create({
  data: {
    task_id: taskId,
    previous_status: task.status,
    new_status: 'in_progress',
  },
});

// Update task
await prisma.task.update({
  where: { id: taskId },
  data: { status: 'in_progress', started_at: new Date() },
});
```

### Create Dispute
```typescript
const dispute = await prisma.dispute.create({
  data: {
    dispute_id_display: 'D-003',
    task_id: taskId,
    raised_by: customerId,
    category: 'pricing',
    status: 'open',
    evidence_urls: ['https://example.com/screenshot.jpg'],
    messages: ['Customer: Amount is higher than quoted'],
  },
});
```

### Get Pricing Configuration
```typescript
const pricing = await prisma.pricingConfig.findUnique({
  where: { config_key: 'current' },
});

// Calculate fare
const fare =
  Math.max(
    pricing.minimum_fare_rupees,
    pricing.base_fare_rupees +
      distanceKm * pricing.per_km_rate +
      minutesElapsed * pricing.per_minute_rate
  ) * (isBusinessTask ? pricing.business_task_multiplier : 1.0);
```

### Get Helper Statistics
```typescript
const stats = await prisma.helper.aggregate({
  where: { verification_status: 'verified' },
  _count: true,
  _avg: { rating: true },
});

console.log(`${stats._count} verified helpers, avg rating: ${stats._avg.rating}`);
```

---

## 🔄 Transaction Example

```typescript
const result = await prisma.$transaction(async (tx) => {
  // All queries in this block are atomic
  const task = await tx.task.update({
    where: { id: taskId },
    data: { status: 'completed', final_amount: 220 },
  });

  const payment = await tx.payment.create({
    data: {
      task_id: taskId,
      customer_id: task.customer_id,
      final_amount: 220,
      // ... all payment fields
    },
  });

  const notification = await tx.notification.create({
    data: {
      user_id: task.helper_id,
      notification_type: 'payment_received',
      title: 'Payment received',
      body: `₹187 for task ${task.task_id_display}`,
    },
  });

  return { task, payment, notification };
});
```

---

## 🧪 Test Setup

```typescript
import prisma from '../config/prisma';

describe('Task operations', () => {
  beforeAll(async () => {
    // Migrations already run by docker-compose
  });

  afterEach(async () => {
    // Clean data
    await prisma.chatMessage.deleteMany({});
    await prisma.notification.deleteMany({});
    await prisma.dispute.deleteMany({});
    await prisma.review.deleteMany({});
    await prisma.payout.deleteMany({});
    await prisma.payment.deleteMany({});
    await prisma.task.deleteMany({});
    await prisma.user.deleteMany({});
  });

  it('should create task and assign helper', async () => {
    const customer = await prisma.user.create({
      data: { phone_number: '+919999999999', name: 'Test', role: 'customer' },
    });

    const helper = await prisma.user.create({
      data: { phone_number: '+918888888888', name: 'Test Helper', role: 'helper' },
      include: { helper: { create: { rating: 4.5 } } },
    });

    const task = await prisma.task.create({
      data: {
        task_id_display: 'SKT99999',
        customer_id: customer.id,
        task_type: 'personal',
        category: 'pickup_delivery',
        status: 'unassigned',
        description: 'Test task',
        location_name: 'Test Location',
        budget_min: 100,
        budget_max: 200,
      },
    });

    expect(task.status).toBe('unassigned');
  });
});
```

---

## 📚 Model Reference

| Model | Purpose | Key Fields |
|-------|---------|-----------|
| **User** | Accounts (customer/helper/admin) | phone_number, email, role, status |
| **Helper** | Helper profile | rating, verification_status, helper_status |
| **Task** | Task/errand posting | task_id_display, status, category, budget |
| **Payment** | Per-task payment | task_id, amount, platform_fee, helper_payout |
| **Payout** | Helper earnings | helper_id, total_amount, method |
| **Dispute** | Disagreement resolution | task_id, category, status |
| **Review** | Post-task ratings | task_id, customer_rating, helper_rating |
| **HelperDocument** | KYC docs | helper_id, document_type, status |
| **TaskStatusHistory** | Audit trail | task_id, previous/new status, OTP info |
| **Notification** | User alerts | user_id, notification_type, body |
| **ChatMessage** | Direct messaging | task_id, sender_id, receiver_id, message |
| **AuditLog** | Admin actions | admin_id, action, old_values, new_values |
| **PricingConfig** | Dynamic pricing | base_fare, per_km, multipliers |
| **HelperSuspensionLog** | Suspension audit | helper_id, reason, timestamps |

---

## 🎯 Common Patterns

### Pagination
```typescript
const page = 1;
const pageSize = 20;

const tasks = await prisma.task.findMany({
  skip: (page - 1) * pageSize,
  take: pageSize,
  orderBy: { created_at: 'desc' },
});
```

### Filtering
```typescript
const tasks = await prisma.task.findMany({
  where: {
    AND: [
      { status: 'unassigned' },
      { task_type: 'personal' },
      { budget_min: { lte: 300 } },
    ],
  },
});
```

### Counting
```typescript
const count = await prisma.task.count({
  where: { status: 'completed' },
});

const total = await prisma.task.count();
```

### Soft Delete
```typescript
// Soft delete
await prisma.user.update({
  where: { id: userId },
  data: { deleted_at: new Date() },
});

// Restore
await prisma.user.update({
  where: { id: userId },
  data: { deleted_at: null },
});

// Query active only
const activeUsers = await prisma.user.findMany({
  where: { deleted_at: null },
});
```

### Increment/Decrement
```typescript
await prisma.helper.update({
  where: { id: helperId },
  data: {
    total_tasks: { increment: 1 },
    rating: { increment: 0.1 },
  },
});
```

### Upsert
```typescript
const config = await prisma.pricingConfig.upsert({
  where: { config_key: 'current' },
  update: { base_fare_rupees: 50 },
  create: {
    config_key: 'current',
    base_fare_rupees: 50,
    // ... all required fields
  },
});
```

---

## 🔍 Data Inspection

### Prisma Studio
```bash
npx prisma studio
# Opens http://localhost:5555
# Visual editor for all models
```

### Direct Query
```typescript
// Explore any model
const user = await prisma.user.findFirst();
console.log(user);

// List all of a model
const allTasks = await prisma.task.findMany();
console.log(allTasks.length);
```

---

## ⚡ Performance Tips

1. **Use include for relations, not separate queries**
   ```typescript
   // ✅ Good: Single query
   const helper = await prisma.helper.findUnique({
     where: { id: id },
     include: { documents: true, tasks: true },
   });

   // ❌ Bad: Multiple queries (N+1 problem)
   const helper = await prisma.helper.findUnique({ where: { id } });
   const docs = await prisma.helperDocument.findMany({ where: { helper_id: id } });
   const tasks = await prisma.task.findMany({ where: { helper_id: id } });
   ```

2. **Use take/skip for pagination, not all()**
   ```typescript
   // ✅ Good: Limited query
   const tasks = await prisma.task.findMany({ take: 20, skip: 0 });

   // ❌ Bad: Loads all records
   const tasks = await prisma.task.findMany();
   ```

3. **Use where for filtering**
   ```typescript
   // ✅ Good: Filter at database
   const tasks = await prisma.task.findMany({
     where: { status: 'completed' },
   });

   // ❌ Bad: Filter in JavaScript
   const tasks = await prisma.task.findMany();
   const filtered = tasks.filter(t => t.status === 'completed');
   ```

---

## 🆘 Debugging

### Enable Logs
```typescript
// In config/prisma.ts, set log level
const prisma = new PrismaClient({
  log: ['query', 'error', 'warn', 'info'],
});
```

### Raw Query Debugging
```typescript
// Execute raw SQL to verify
const result = await prisma.$queryRaw`
  SELECT COUNT(*) as count FROM users WHERE deleted_at IS NULL
`;
console.log(result);
```

---

## 📖 Resources

- **Prisma Docs:** https://www.prisma.io/docs/
- **API Reference:** https://www.prisma.io/docs/reference/api-reference/prisma-client-reference
- **Query Examples:** https://www.prisma.io/docs/concepts/components/prisma-client
- **Data Guide:** See PRISMA_ORM_GUIDE.md (2000+ lines)

---

**Ready to code!** Start with the patterns above and refer to PRISMA_ORM_GUIDE.md for deeper details.
