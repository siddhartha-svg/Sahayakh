# Environment Variables Reference

Complete reference for all environment variables across Sahayakh services

---

## 📋 Overview

| Service | File | Staging | Production | Notes |
|---------|------|---------|------------|-------|
| Backend | `.env.staging`, `.env.production` | ✅ | ✅ | Database, Redis, API config |
| Admin Web | `packages/admin-web/.env*` | ✅ | ✅ | Vite build config, API URLs |
| Mobile | `packages/mobile/.env*` | ✅ | ✅ | EAS config, API URLs |
| Helper App | `packages/mobile-helper/.env*` | ✅ | ✅ | EAS config, API URLs |

---

## 🖥️ Backend Environment Variables

### Server Configuration

```env
# Core
NODE_ENV=production|staging|development
ENVIRONMENT=production|staging|development
APP_NAME=Sahayakh|Sahayakh Staging
LOG_LEVEL=info|debug|error|warn
DEBUG=true|false
TIMEZONE=Asia/Kolkata

# Server
API_PORT=3000                    # Port backend listens on
API_HOST=0.0.0.0               # Host to bind to
CORS_ORIGINS=url1,url2,url3    # Comma-separated allowed origins
```

### Database

```env
# Primary Database
DATABASE_URL=postgresql://user:pass@host:5432/dbname
DATABASE_POOL_MIN=2             # Minimum connections
DATABASE_POOL_MAX=10            # Maximum connections (prod: 20)
DATABASE_SSL=true               # Require SSL (prod: true)
DATABASE_LOGGING=false          # Log SQL queries

# Example:
# DATABASE_URL=postgresql://sahayakh:pass@db.railway.app:5432/sahayakh
```

### Cache

```env
# Redis
REDIS_URL=redis://:password@host:6379/0
REDIS_KEY_PREFIX=sahayakh:staging:  # Namespace for keys
REDIS_POOL_MIN=1
REDIS_POOL_MAX=10

# Example:
# REDIS_URL=redis://:password@redis-staging.railway.app:6379
```

### Authentication

```env
# JWT Tokens
JWT_SECRET=<long-random-string>                    # Access token secret (min 32 chars)
JWT_EXPIRY=1h                                      # Token expiry (1h = 1 hour)
JWT_REFRESH_SECRET=<different-long-random-string> # Refresh token secret
JWT_REFRESH_EXPIRY=30d                            # Refresh token expiry (30d = 30 days)

# Generate random strings:
# node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### Payment Gateway (Razorpay)

```env
# Test Keys (Staging)
RAZORPAY_KEY_ID=rzp_test_xxxxxxxxxxxxx
RAZORPAY_KEY_SECRET=<test-secret-key>

# Live Keys (Production)
RAZORPAY_KEY_ID=rzp_live_xxxxxxxxxxxxx
RAZORPAY_KEY_SECRET=<live-secret-key>

# Get from: https://dashboard.razorpay.com/app/keys
```

### Firebase (Notifications)

```env
FIREBASE_PROJECT_ID=sahayakh-staging|sahayakh-prod
FIREBASE_API_KEY=<firebase-api-key>
FIREBASE_AUTH_DOMAIN=<project>.firebaseapp.com
FIREBASE_DATABASE_URL=https://<project>.firebaseio.com
FIREBASE_STORAGE_BUCKET=<project>.appspot.com
FIREBASE_MESSAGING_SENDER_ID=<sender-id>
FIREBASE_APP_ID=<app-id>

# Get from: Firebase Console → Project Settings → Service Accounts
```

### Email Service (SendGrid)

```env
SENDGRID_API_KEY=<sendgrid-api-key>
SENDGRID_FROM_EMAIL=noreply@sahayakh.com|noreply-staging@sahayakh.com
SENDGRID_FROM_NAME=Sahayakh|Sahayakh Staging

# Get from: https://app.sendgrid.com/settings/api_keys
```

### SMS Service (Twilio)

```env
TWILIO_ACCOUNT_SID=<twilio-sid>
TWILIO_AUTH_TOKEN=<twilio-auth-token>
TWILIO_PHONE_NUMBER=+1234567890
TWILIO_VERIFY_SID=<verify-service-sid>

# Get from: https://www.twilio.com/console
```

### Maps (Google Maps)

```env
GOOGLE_MAPS_API_KEY=<google-maps-api-key>

# Get from: Google Cloud Console → APIs & Services → Credentials
# Enable: Maps JavaScript API, Distance Matrix API, Geocoding API
```

### Cloud Storage (AWS S3)

```env
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=<aws-access-key>
AWS_SECRET_ACCESS_KEY=<aws-secret-key>
AWS_S3_BUCKET=sahayakh-staging|sahayakh-prod

# Get from: AWS IAM → Access keys
# Permissions needed: s3:GetObject, s3:PutObject, s3:DeleteObject
```

### Error Tracking (Sentry)

```env
SENTRY_DSN=https://key@sentry.io/project-id
SENTRY_ENVIRONMENT=staging|production
SENTRY_TRACES_SAMPLE_RATE=0.5|1.0  # 50% or 100% of requests

# Get from: https://sentry.io → Project → Settings → Client Keys (DSN)
```

### Monitoring (New Relic)

```env
NEW_RELIC_LICENSE_KEY=<newrelic-license-key>
NEW_RELIC_APP_NAME=Sahayakh Backend|Sahayakh Backend Staging
NEW_RELIC_ENABLED=true

# Get from: https://one.newrelic.com → Account → License keys
```

### Platform Configuration

```env
# Task Management
PLATFORM_FEE_PERCENT=15                  # Platform fee as percentage
TASK_REQUEST_EXPIRY_SECONDS=45           # Request timeout (45 seconds)
HELPER_MAX_CONCURRENT_TASKS=1            # Max parallel tasks per helper
TASK_AUTO_CANCEL_MINUTES=30              # Auto-cancel after 30 mins

# Pricing
BASE_FARE_RUPEES=40
PER_KM_RATE=15
PER_MINUTE_RATE=2.5
MINIMUM_FARE_RUPEES=80
CANCELLATION_FEE_RUPEES=30
BUSINESS_MULTIPLIER=1.25

# Matching
HELPER_SEARCH_RADIUS_KM=25               # Default radius for helper search
HELPER_BATCH_SIZE=5                      # Helpers to send request to simultaneously
```

### Rate Limiting

```env
RATE_LIMIT_WINDOW_MS=900000              # 15 minutes in milliseconds
RATE_LIMIT_MAX_REQUESTS=100              # Max requests in window
RATE_LIMIT_ENABLED=true

# Results: 100 requests per 15 minutes = ~6.7 req/sec
```

### Features (Feature Flags)

```env
ENABLE_EMAIL_VERIFICATION=true           # Require email verification
ENABLE_PHONE_VERIFICATION=true           # Require phone verification
ENABLE_BACKGROUND_CHECKS=true            # Background check requirement
ENABLE_LOCATION_TRACKING=true            # GPS tracking enabled
ENABLE_PAYMENT_PROCESSING=true           # Payment gateway enabled
ENABLE_NOTIFICATIONS=true                # Push notifications enabled
ENABLE_SMS_FALLBACK=true|false           # SMS fallback for notifications (false in prod)
ENABLE_DISPUTE_SYSTEM=true               # Dispute resolution enabled
ENABLE_RATING_SYSTEM=true                # Rating/review system enabled
```

---

## 🎨 Admin Dashboard Environment Variables

### Build Configuration

```env
# Vite Build
VITE_COMMAND_PREFIX=npm run             # Build command prefix

# API Configuration
VITE_API_URL=https://api-staging.sahayakh.com|https://api.sahayakh.com
VITE_SOCKET_URL=wss://api-staging.sahayakh.com|wss://api.sahayakh.com

# UI Configuration
VITE_DEFAULT_PAGE_SIZE=20                # Items per page
VITE_KPI_REFRESH_INTERVAL=5000           # 5 seconds
VITE_DISPUTES_REFRESH_INTERVAL=10000     # 10 seconds
VITE_ACTIVITY_REFRESH_INTERVAL=4500      # 4.5 seconds
```

### File Location

```
packages/admin-web/.env.staging          # Staging environment
packages/admin-web/.env.production       # Production environment
packages/admin-web/.env.local (ignored)  # Local overrides
```

### Set in Vercel

All admin dashboard environment variables should be set in Vercel:

```bash
vercel env add VITE_API_URL
vercel env add VITE_SOCKET_URL
vercel env list
```

---

## 📱 Mobile Apps Environment Variables

### Customer App (packages/mobile)

```env
# API Configuration
EXPO_PUBLIC_API_URL=https://api-staging.sahayakh.com|https://api.sahayakh.com
EXPO_PUBLIC_SOCKET_URL=wss://api-staging.sahayakh.com|wss://api.sahayakh.com

# Environment
EXPO_PUBLIC_ENVIRONMENT=staging|production
EXPO_PUBLIC_LOG_LEVEL=debug|info

# Firebase
EXPO_PUBLIC_FIREBASE_PROJECT_ID=sahayakh-staging|sahayakh-prod
EXPO_PUBLIC_FIREBASE_API_KEY=<key>
EXPO_PUBLIC_FIREBASE_APP_ID=<app-id>

# Google Maps
EXPO_PUBLIC_GOOGLE_MAPS_API_KEY=<key>

# Location Services
EXPO_PUBLIC_LOCATION_UPDATE_INTERVAL=2000   # 2 seconds
EXPO_PUBLIC_LOCATION_MAX_DISTANCE_KM=50     # Max tracking distance

# Notifications
EXPO_PUBLIC_NOTIFICATIONS_ENABLED=true
EXPO_PUBLIC_NOTIFICATIONS_SOUND=true
EXPO_PUBLIC_NOTIFICATIONS_VIBRATE=true
```

### Helper App (packages/mobile-helper)

```env
# Same as customer app but for helper-specific endpoints
EXPO_PUBLIC_API_URL=https://api-staging.sahayakh.com
EXPO_PUBLIC_SOCKET_URL=wss://api-staging.sahayakh.com

# Specific to helper
EXPO_PUBLIC_NOTIFICATION_TIMEOUT_SECONDS=45
EXPO_PUBLIC_MAX_CONCURRENT_TASKS=1
```

### Set via EAS

Mobile environment variables are set in `.eas.json`:

```json
{
  "build": {
    "staging": {
      "android": {
        "env": {
          "EXPO_PUBLIC_API_URL": "https://api-staging.sahayakh.com"
        }
      }
    },
    "production": {
      "android": {
        "env": {
          "EXPO_PUBLIC_API_URL": "https://api.sahayakh.com"
        }
      }
    }
  }
}
```

---

## 🔐 GitHub Secrets Setup

All secrets should be set in GitHub repository settings:

### Backend Secrets

```
RAILWAY_API_TOKEN
RAILWAY_PROJECT_ID_STAGING
RAILWAY_PROJECT_ID_PROD
DATABASE_URL_STAGING
DATABASE_URL_PROD
REDIS_URL_STAGING
REDIS_URL_PROD
JWT_SECRET_STAGING
JWT_SECRET_PROD
RAZORPAY_KEY_ID_STAGING
RAZORPAY_KEY_ID_PROD
RAZORPAY_KEY_SECRET_STAGING
RAZORPAY_KEY_SECRET_PROD
FIREBASE_API_KEY_STAGING
FIREBASE_API_KEY_PROD
SENTRY_DSN_STAGING
SENTRY_DSN_PROD
NEW_RELIC_LICENSE_KEY_PROD
```

### Vercel Secrets

```
VERCEL_TOKEN
VERCEL_PROJECT_ID
VERCEL_ORG_ID
```

### Mobile Secrets

```
EXPO_TOKEN
FIREBASE_ANDROID_APP_ID
FIREBASE_ANDROID_HELPER_APP_ID
FIREBASE_SERVICE_ACCOUNT_JSON
GOOGLE_PLAY_KEY_FILE
ASC_PROVIDER
```

### Notification Secrets

```
SLACK_WEBHOOK_URL
```

---

## ✅ Environment Variable Validation

### Required for Backend to Start

```
DATABASE_URL
REDIS_URL
JWT_SECRET
API_PORT
NODE_ENV
```

### Required for Admin Dashboard Build

```
VITE_API_URL
VITE_SOCKET_URL
```

### Required for Mobile Build

```
EXPO_PUBLIC_API_URL
EXPO_PUBLIC_FIREBASE_PROJECT_ID
```

### Validation Script

```bash
# Check if required variables are set
required_vars=(
  "DATABASE_URL"
  "REDIS_URL"
  "JWT_SECRET"
  "API_PORT"
)

for var in "${required_vars[@]}"; do
  if [ -z "${!var}" ]; then
    echo "Error: $var is not set"
    exit 1
  fi
done

echo "All required variables are set"
```

---

## 🔄 Updating Environment Variables

### For Railway Backend

```bash
# Via Railway Dashboard
railway env:show
railway env:update KEY VALUE

# Via GitHub Secrets (auto-deployed)
# Change secret → Push to main → Auto-deploys to Railway
```

### For Vercel Admin Dashboard

```bash
# Via Vercel CLI
vercel env add VITE_API_URL
vercel env list
vercel env remove VARIABLE_NAME

# Via Vercel Dashboard
# Settings → Environment Variables
```

### For Mobile Apps

Update `.eas.json` and rebuild:

```bash
eas build --platform android,ios
```

---

## 🔒 Security Best Practices

### Secrets Management

- ✅ Never commit `.env` files to git
- ✅ Use `.gitignore` for all `.env*` files
- ✅ Use environment-specific files (staging vs prod)
- ✅ Rotate secrets quarterly
- ✅ Use strong random values (min 32 chars for secrets)
- ✅ Different secrets per environment
- ✅ Different secrets per service

### What Should Be in `.env`

```
❌ Database passwords      → Use Railway managed DB
❌ API keys               → Use GitHub Secrets
❌ JWT secrets            → Use GitHub Secrets
✅ Feature flags          → Safe defaults
✅ API URLs              → Public endpoints
✅ Configuration values   → Non-sensitive settings
```

### What Should Be in GitHub Secrets

```
✅ All credentials
✅ API keys and tokens
✅ Database URLs with passwords
✅ Private encryption keys
✅ Service account keys
```

---

## 📝 Variable Naming Convention

- `UPPERCASE_WITH_UNDERSCORES` for backend (`NODE_ENV`, `DATABASE_URL`)
- `EXPO_PUBLIC_*` prefix for mobile public variables
- `VITE_*` prefix for admin dashboard frontend variables
- `REACT_APP_*` prefix if using Create React App
- Environment-specific suffixes: `_STAGING`, `_PROD`

---

## 📚 Service-Specific References

- **Razorpay**: https://razorpay.com/docs/
- **Firebase**: https://firebase.google.com/docs
- **SendGrid**: https://sendgrid.com/docs/
- **Twilio**: https://www.twilio.com/docs
- **Google Maps**: https://developers.google.com/maps/documentation
- **AWS S3**: https://docs.aws.amazon.com/s3/
- **Sentry**: https://docs.sentry.io/
- **New Relic**: https://docs.newrelic.com/

---

**Build Date**: September 2026
**Status**: ✅ Complete Reference
**Last Updated**: September 2026
