# Sahayakh Deployment Guide

**Status**: ✅ Complete CI/CD and Deployment Infrastructure

---

## 🏗️ Architecture Overview

### Services & Platforms

| Service | Platform | Environment | URL |
|---------|----------|-------------|-----|
| **Backend API** | Railway | Staging | https://api-staging.sahayakh.com |
| **Backend API** | Railway | Production | https://api.sahayakh.com |
| **Admin Dashboard** | Vercel | Staging | https://admin-staging.sahayakh.com |
| **Admin Dashboard** | Vercel | Production | https://admin.sahayakh.com |
| **Customer App** | EAS/Google Play/App Store | Production | Play Store & App Store |
| **Helper App** | EAS/Google Play/App Store | Production | Play Store & App Store |

### Deployment Flow

```
Code Push → GitHub Actions (CI)
   ↓
✅ All Checks Pass (lint, tests, build)
   ↓
develop branch → Deploy to Staging
   ↓
main branch → Deploy to Production (manual approval)
   ↓
git tags (v*) → Release mobile apps to stores
```

---

## 🚀 Quick Start: First Deployment

### Prerequisites

1. **GitHub Secrets Setup**
   - Go to: Repository → Settings → Secrets and variables → Actions
   - Add all required secrets (see Secrets Reference below)

2. **Railway Setup**
   - Create Railway project for staging: `sahayakh-staging`
   - Create Railway project for production: `sahayakh-prod`
   - Get `RAILWAY_API_TOKEN` from Railway dashboard
   - Get project IDs and set as secrets

3. **Vercel Setup**
   - Create Vercel project for admin dashboard
   - Get `VERCEL_TOKEN`, `VERCEL_PROJECT_ID`, `VERCEL_ORG_ID`
   - Set as GitHub secrets

4. **Expo/EAS Setup**
   - Create Expo account
   - Generate `EXPO_TOKEN`
   - Configure EAS in `.eas.json`
   - Set as GitHub secret

### Deploy Staging (Automatic)

```bash
# Push to develop branch
git checkout develop
git push origin develop

# GitHub Actions will automatically:
# 1. Run tests and linting
# 2. Build Docker image
# 3. Deploy backend to Railway staging
# 4. Deploy admin to Vercel staging
# 5. Build mobile apps (internal distribution)
```

Monitor in GitHub: Actions tab → deploy-backend.yml / deploy-admin.yml / build-mobile.yml

### Deploy Production (Manual)

```bash
# Create release tag
git tag -a v1.0.0 -m "Release v1.0.0"
git push origin v1.0.0

# OR merge main branch
git checkout main
git pull
git merge develop
git push origin main

# GitHub Actions will:
# 1. Wait for manual approval in Actions tab
# 2. Approve and deploy to production
# 3. Health checks verify deployment
# 4. Slack notification sent
```

---

## 🔐 GitHub Secrets Reference

### Backend Secrets

```yaml
RAILWAY_API_TOKEN: <your-railway-api-token>
RAILWAY_PROJECT_ID_STAGING: <staging-project-id>
RAILWAY_PROJECT_ID_PROD: <production-project-id>

DATABASE_URL_STAGING: postgresql://user:pass@host/sahayakh
DATABASE_URL_PROD: postgresql://user:pass@host/sahayakh

REDIS_URL_STAGING: redis://:password@host:6379
REDIS_URL_PROD: redis://:password@host:6379

JWT_SECRET_STAGING: <long-random-string>
JWT_SECRET_PROD: <different-long-random-string>

RAZORPAY_KEY_ID_STAGING: rzp_test_xxxxx
RAZORPAY_KEY_ID_PROD: rzp_live_xxxxx
RAZORPAY_KEY_SECRET_STAGING: <staging-secret>
RAZORPAY_KEY_SECRET_PROD: <prod-secret>

SENTRY_DSN_STAGING: <sentry-staging-dsn>
SENTRY_DSN_PROD: <sentry-prod-dsn>
```

### Admin Dashboard Secrets

```yaml
VERCEL_TOKEN: <vercel-api-token>
VERCEL_PROJECT_ID: <admin-web-project-id>
VERCEL_ORG_ID: <organization-id>
```

### Mobile App Secrets

```yaml
EXPO_TOKEN: <expo-cli-token>

FIREBASE_ANDROID_APP_ID: <firebase-app-id>
FIREBASE_ANDROID_HELPER_APP_ID: <firebase-helper-app-id>
FIREBASE_SERVICE_ACCOUNT_JSON: <firebase-service-account-json>

GOOGLE_PLAY_KEY_FILE: <base64-encoded-service-account>

ASC_PROVIDER: <apple-app-store-provider-id>
```

### Notifications

```yaml
SLACK_WEBHOOK_URL: <slack-webhook-for-notifications>

SNYK_TOKEN: <snyk-security-scan-token> (optional)
```

### How to Generate Secrets

**Railway Token**:
```bash
railway login
# Get token from: https://railway.app/account/tokens
```

**Vercel Token**:
```bash
vercel login
# Get token from: https://vercel.com/account/tokens
```

**Expo Token**:
```bash
expo login
expo tokens:select
# Or generate from: https://expo.dev/settings/access-tokens
```

---

## 📋 Branch Protection Rules

### Main Branch
- ✅ Require PR review (1+ approvals)
- ✅ Require status checks to pass
- ✅ Require branches to be up to date
- ✅ Require code owners review
- ✅ Auto-delete head branches

### Develop Branch
- ✅ Require status checks to pass
- ✅ Allow auto-merge
- ✅ Squash and merge preferred

```bash
# Set via GitHub CLI
gh repo edit --branch-protection \
  --require-pull-request-reviews \
  --required-review-count 1 \
  --require-status-checks
```

---

## 🔄 CI/CD Workflows

### 1. CI Workflow (ci.yml)

**Triggers**: All branches on push/PR

**Jobs**:
1. **Lint** - ESLint + Prettier check
2. **Type Check** - TypeScript strict mode
3. **Test** - Jest with coverage
4. **Security** - npm audit + Snyk scan
5. **Build** - Build all packages
6. **All Checks** - Aggregation job (required for merge)

**Status Requirements**: All green ✅

### 2. Backend Deployment (deploy-backend.yml)

**Triggers**: Push to develop or main

**Staging** (develop branch):
- Automatic deployment
- Health checks
- Smoke tests
- Slack notification

**Production** (main branch):
- Manual approval required
- Full test suite
- Docker build
- Health checks
- Slack notification

### 3. Admin Dashboard (deploy-admin.yml)

**Triggers**: Push to develop or main, PR to either

**PR**: Preview deployment with comment
**Develop**: Deploy to staging alias
**Main**: Deploy to production

### 4. Mobile Apps (build-mobile.yml)

**Triggers**: Push to develop or main

**Staging** (develop):
- Build with EAS
- Upload to Firebase App Distribution
- Available to QA team

**Production** (main):
- Build with EAS
- Submit to Google Play (beta → production)
- Submit to App Store (TestFlight → production)

---

## 📊 Environment Variables

### Staging Environment (`.env.staging`)

```env
NODE_ENV=staging
ENVIRONMENT=staging
LOG_LEVEL=debug
DEBUG=true

DATABASE_URL=postgresql://user:pass@db-staging.railway.app:5432/sahayakh
REDIS_URL=redis://:pass@redis-staging.railway.app:6379

API_KEY_RAZORPAY=rzp_test_xxxxx
FIREBASE_PROJECT_ID=sahayakh-staging
CORS_ORIGINS=https://admin-staging.sahayakh.com,http://localhost:3000

ENABLE_EMAIL_VERIFICATION=true
ENABLE_PAYMENT_PROCESSING=true
```

### Production Environment (`.env.production`)

```env
NODE_ENV=production
ENVIRONMENT=production
LOG_LEVEL=info
DEBUG=false

DATABASE_URL=${DATABASE_URL_PROD}  # Set in Railway
REDIS_URL=${REDIS_URL_PROD}        # Set in Railway

API_KEY_RAZORPAY=${RAZORPAY_KEY_ID_PROD}
FIREBASE_PROJECT_ID=sahayakh-prod
CORS_ORIGINS=https://admin.sahayakh.com

ENABLE_EMAIL_VERIFICATION=true
ENABLE_PAYMENT_PROCESSING=true
```

---

## 🔍 Monitoring Deployments

### Real-Time Logs

```bash
# Watch deployment logs
railway logs --follow

# Watch Vercel deployment
vercel logs

# Monitor Slack notifications
# Channel: #deployments (configure webhook)
```

### Health Checks

```bash
# Backend health
curl https://api-staging.sahayakh.com/health
curl https://api.sahayakh.com/health

# Admin dashboard
curl https://admin-staging.sahayakh.com
curl https://admin.sahayakh.com
```

### Status Dashboard

- GitHub Actions: https://github.com/your-org/sahayakh-project/actions
- Railway Dashboard: https://railway.app
- Vercel Dashboard: https://vercel.com/dashboard
- Expo Dashboard: https://expo.dev

---

## 🚨 Rollback Procedures

### Backend Rollback

```bash
# If staging deployment fails:
# 1. Check logs in Railway dashboard
# 2. Fix issue and push to develop again
# 3. Re-deploy automatically

# If production deployment fails:
# 1. Manually revert to previous Railway deployment
#    Railway → Production → Deployments → Click previous version
# 2. Click "Redeploy" on the previous working version
# 3. Investigate issue
# 4. Deploy fix to staging first
# 5. Merge to main and deploy to production again
```

### Admin Dashboard Rollback

```bash
# Vercel automatically keeps deployment history
# 1. Go to Vercel dashboard
# 2. Select deployment to revert to
# 3. Click "Promote to production"
# 4. Confirm rollback
```

### Mobile App Rollback

```bash
# Internal Testing (Firebase):
# 1. Distribute previous build via Firebase Console

# Production (App Stores):
# 1. Google Play: Rollout management → Reduce percentage to 0%
# 2. App Store: Version Release Notes → Revert to previous version
```

---

## ⚠️ Troubleshooting

### Deployment Fails Due to Tests

```bash
# 1. Check test output in Actions
# 2. Run tests locally
npm test

# 3. Fix failing tests
# 4. Commit and push
git add .
git commit -m "Fix failing tests"
git push
```

### Database Migration Issues

```bash
# 1. Check Prisma migration status
cd packages/backend
npx prisma migrate status

# 2. If migration is pending:
npx prisma migrate deploy

# 3. If migration fails, check Railway logs
railway logs --tail

# 4. Manually rollback if needed:
npx prisma migrate resolve --rolled-back migration_name
```

### Health Check Failing

```bash
# 1. Check application logs
railway logs

# 2. Verify environment variables are set
railway env:show

# 3. Check database connection
psql $DATABASE_URL -c "SELECT 1"

# 4. Check Redis connection
redis-cli -u $REDIS_URL PING

# 5. Restart service if needed
railway up --detach
```

### Slack Notifications Not Sending

```bash
# 1. Verify SLACK_WEBHOOK_URL is set correctly
# 2. Test webhook manually:
curl -X POST -H 'Content-type: application/json' \
  --data '{"text":"Test"}' \
  $SLACK_WEBHOOK_URL

# 3. Check GitHub Actions logs for errors
```

---

## 📱 Mobile App Release Process

### Beta/Internal Testing

```bash
# Automatic on develop branch
# Apps built and distributed via:
# - Firebase App Distribution (Android)
# - TestFlight (iOS)

# Team members download via invite links
```

### Production Release

### Production Release

```bash
# 1. Tag release
git tag -a v1.0.0 -m "Release v1.0.0"
git push origin v1.0.0

# 2. GitHub Actions builds and submits
# - Waits for manual approval
# - Builds signed APK/App Bundle
# - Submits to Google Play (internal → beta → production)
# - Submits to App Store (TestFlight → production)

# 3. Monitor approval process
# - Google Play: 2-4 hours typical
# - App Store: 24-48 hours typical

# 4. Verify live on stores
```

---

## 🔒 Security Best Practices

### Secrets Management

- ✅ Never commit `.env` files
- ✅ All production secrets in GitHub Secrets (encrypted)
- ✅ Rotate secrets quarterly
- ✅ Use different secrets for staging vs production
- ✅ Remove old tokens from GitHub when no longer needed

### Code Review

- ✅ Require PR review before merge
- ✅ Run all checks (lint, tests, build)
- ✅ Never push directly to main
- ✅ Use semantic commits

### Deployment Safety

- ✅ Always deploy to staging first
- ✅ Smoke test before production
- ✅ Keep rollback procedure handy
- ✅ Monitor logs after deployment
- ✅ Notify team of production deployments

---

## 📞 Support & Escalation

### Common Issues

| Issue | Solution | Docs |
|-------|----------|------|
| Deploy fails | Check Actions logs | See Troubleshooting section |
| Health check timeout | Restart service on Railway | Railway docs |
| Database connection | Verify DATABASE_URL | .env.production |
| Mobile build fails | Check EAS build logs | EAS documentation |

### Resources

- Railway Docs: https://docs.railway.app
- Vercel Docs: https://vercel.com/docs
- EAS Docs: https://docs.expo.dev/build
- GitHub Actions: https://docs.github.com/en/actions

### Escalation

1. **First Response**: Check logs and Slack notifications
2. **Development Team**: Review code changes in PR
3. **DevOps**: Check infrastructure (Railway, Vercel, EAS)
4. **Emergency**: Rollback to previous version immediately

---

## 📝 Deployment Checklist

Before every production deployment:

- [ ] All tests pass locally
- [ ] Code reviewed and approved
- [ ] Staging deployment successful
- [ ] Smoke tests pass on staging
- [ ] Team notified of deployment
- [ ] Rollback plan reviewed
- [ ] Post-deployment monitoring plan

After deployment:

- [ ] Health checks pass
- [ ] Smoke tests pass
- [ ] Monitor logs for errors
- [ ] Verify features work end-to-end
- [ ] Team confirms functionality
- [ ] Update deployment status
- [ ] Document any issues

---

**Build Date**: September 2026
**Status**: ✅ Production Ready
**Last Updated**: September 2026
