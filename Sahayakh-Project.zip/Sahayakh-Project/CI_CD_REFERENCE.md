# CI/CD Reference Guide

**Complete reference for GitHub Actions workflows and deployment pipelines**

---

## 📊 Workflow Overview

### Workflow Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        GitHub Push Event                          │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
        ┌──────────────────────────────────────┐
        │      GitHub Actions: CI Workflow      │
        │  (All branches, all push/PR events)   │
        ├──────────────────────────────────────┤
        │ ✓ Lint (ESLint, Prettier)           │
        │ ✓ Type Check (TypeScript)           │
        │ ✓ Tests (Jest + Coverage)           │
        │ ✓ Security Scan (npm audit, Snyk)   │
        │ ✓ Build (all packages)              │
        │ ✓ All Checks (aggregation)          │
        └──────┬───────────────────┬──────────┘
               │                   │
               │ FAIL              │ PASS
               ▼                   ▼
         ❌ Block Merge       Continue
                             │
                    ┌────────┴────────┐
                    │                 │
        Develop Branch          Main Branch
                    │                 │
         ┌──────────▼──────┐ ┌────────▼────────┐
         │  Staging Deploy  │ │ Production Deploy│
         ├──────────────────┤ ├─────────────────┤
         │ Backend          │ │ Manual Approval  │
         │ ├ Railway        │ │ ├ Railway       │
         │ ├ Health checks  │ │ ├ Health checks │
         │ └ Smoke tests    │ │ └ Tests         │
         │                  │ │                 │
         │ Admin Dashboard  │ │ Admin Dashboard │
         │ ├ Vercel         │ │ ├ Vercel        │
         │ └ Verify deploy  │ │ └ Verify deploy │
         │                  │ │                 │
         │ Mobile Apps      │ │ Mobile Apps     │
         │ ├ EAS build      │ │ ├ EAS build     │
         │ └ Firebase dist. │ │ └ Store submit  │
         │                  │ │                 │
         │ Slack Notify     │ │ Slack Notify    │
         └──────────────────┘ └─────────────────┘
```

---

## 🔧 Workflow Specifications

### 1. CI Workflow (ci.yml)

**File**: `.github/workflows/ci.yml`

**Triggers**:
- `push` to branches: main, develop, staging
- `pull_request` to branches: main, develop, staging

**Jobs**:

#### Job: Lint
```yaml
name: Lint & Format Check
runs-on: ubuntu-latest

steps:
  - Checkout code
  - Setup Node 18 with npm cache
  - Run: npm run lint --workspaces
  - Run: npm run format:check
```

**Success**: All files pass ESLint and Prettier rules

#### Job: Type Check
```yaml
name: TypeScript Type Check
runs-on: ubuntu-latest

steps:
  - Checkout code
  - Setup Node 18 with npm cache
  - Run: npm run type-check --workspaces
```

**Success**: No TypeScript errors

#### Job: Test
```yaml
name: Unit Tests
runs-on: ubuntu-latest

services:
  postgres:
    image: postgres:15-alpine
    env: POSTGRES_PASSWORD=test, POSTGRES_DB=sahayakh_test
    health: pg_isready

  redis:
    image: redis:7-alpine
    health: redis-cli ping

steps:
  - Checkout code
  - Setup Node 18 with npm cache
  - Run: npm ci
  - Run: npm test --workspaces
    env: DATABASE_URL, REDIS_URL, NODE_ENV=test
  - Upload coverage to codecov
```

**Success**: All tests pass, coverage > 80%

#### Job: Security
```yaml
name: Security Scan
runs-on: ubuntu-latest

steps:
  - Checkout code
  - Setup Node 18
  - Run: npm ci
  - Run: npm audit --audit-level=moderate
  - Run: Snyk security scan (optional)
```

**Success**: No critical/high vulnerabilities

#### Job: Build
```yaml
name: Build All Packages
runs-on: ubuntu-latest

steps:
  - Checkout code
  - Setup Node 18 with cache
  - Run: npm run build --workspace=packages/backend
  - Run: npm run build --workspace=packages/admin-web
    env: VITE_API_URL=https://api-staging.sahayakh.com
  - Run: npm run type-check --workspaces
```

**Success**: All packages build without errors

#### Job: All Checks
```yaml
name: All Checks Passed
needs: [lint, type-check, test, build]
runs-on: ubuntu-latest
if: always()

steps:
  - Verify all previous jobs passed
  - Exit 0 if all passed, exit 1 if any failed
```

**Success**: Required for merging to main/develop

---

### 2. Backend Deployment (deploy-backend.yml)

**File**: `.github/workflows/deploy-backend.yml`

**Triggers**:
- `push` to develop (automatic staging deploy)
- `push` to main (automatic production deploy with approval)

**Jobs**:

#### Job: Test
```yaml
Runs full backend test suite with PostgreSQL and Redis
Status: Must pass before build
```

#### Job: Build
```yaml
Builds Docker image with multi-stage Dockerfile
Registry: GitHub Container Registry (ghcr.io)
Tags: branch name, semver, SHA
Pushes to registry
```

#### Job: Deploy to Staging
**Trigger**: develop branch only

```yaml
- Install Railway CLI
- Login to Railway
- Switch to staging project
- Deploy service
- Wait for deployment
- Health check: GET /health
- Smoke tests
- Slack notification (success/failure)

Environment: staging
URL: https://api-staging.sahayakh.com
```

#### Job: Deploy to Production
**Trigger**: main branch only
**Requirement**: Manual approval in GitHub Actions UI

```yaml
- Same as staging but with production details
- Manual approval gate
- Production health checks
- Create GitHub release
- Slack notification (success/failure)

Environment: production
URL: https://api.sahayakh.com
```

---

### 3. Admin Dashboard Deployment (deploy-admin.yml)

**File**: `.github/workflows/deploy-admin.yml`

**Triggers**:
- `pull_request` to develop/main (preview deployment)
- `push` to develop (staging deployment)
- `push` to main (production deployment)

**Jobs**:

#### Job: Preview (PR only)
```yaml
- Install Vercel CLI
- Deploy preview (--preview flag)
- Comment on PR with preview URL
- Test preview deployment

Environment: preview
URL: https://[project]-git-[branch]-[org].vercel.app
```

#### Job: Staging (develop push)
```yaml
- Install Vercel CLI
- Build with Vite
- Deploy with staging environment variables
- Set alias: admin-staging.sahayakh.com
- Verify deployment
- Slack notification

Environment: staging
URL: https://admin-staging.sahayakh.com
```

#### Job: Production (main push)
```yaml
- Install Vercel CLI
- Build with Vite
- Deploy to production (--prod flag)
- Environment variables: VITE_API_URL=https://api.sahayakh.com
- Verify deployment
- Run tests
- Slack notification

Environment: production
URL: https://admin.sahayakh.com
```

---

### 4. Mobile App Build (build-mobile.yml)

**File**: `.github/workflows/build-mobile.yml`

**Triggers**:
- `push` to develop/main (automatic build)
- `workflow_dispatch` (manual trigger with app selection)

**Jobs**:

#### Job: Build Android Customer
```yaml
- Install Node + Expo CLI + EAS CLI
- Install dependencies (packages/mobile)
- Run: eas build --platform android --wait
- Upload to Firebase App Distribution (if staging)

Environment: staging
Distribution: Firebase App Distribution
Groups: qa-team
```

#### Job: Build iOS Customer
```yaml
- Install Node + Expo CLI + EAS CLI
- Install dependencies (packages/mobile)
- Run: eas build --platform ios --wait
- Submit to TestFlight (if staging)

Environment: staging
Distribution: TestFlight / Firebase
```

#### Job: Build Android Helper
```yaml
Same as customer but for packages/mobile-helper
Distribution groups: qa-team, helpers
```

#### Job: Build iOS Helper
```yaml
Same as customer but for packages/mobile-helper
Distribution: TestFlight / Firebase
```

#### Job: Release to Stores (main branch only)
```yaml
- Install EAS CLI
- Submit Customer App:
  - Android: eas submit --platform android --latest
    → Google Play (internal → beta → production)
  - iOS: eas submit --platform ios --latest
    → App Store
- Submit Helper App (same process)
- Slack notification

Requires:
- GOOGLE_PLAY_KEY_FILE (service account)
- ASC_PROVIDER (Apple credentials)
- Manual review on app stores
```

---

## 🔑 Required Secrets

### Backend Deployment
```
RAILWAY_API_TOKEN              # Railway API access token
RAILWAY_PROJECT_ID_STAGING     # Staging project ID
RAILWAY_PROJECT_ID_PROD        # Production project ID
DATABASE_URL_STAGING           # PostgreSQL connection string
DATABASE_URL_PROD              # PostgreSQL connection string
REDIS_URL_STAGING              # Redis connection string
REDIS_URL_PROD                 # Redis connection string
```

### Admin Dashboard
```
VERCEL_TOKEN                   # Vercel API token
VERCEL_PROJECT_ID              # Admin-web project ID
VERCEL_ORG_ID                  # Organization ID
```

### Mobile Apps
```
EXPO_TOKEN                     # Expo CLI token
FIREBASE_ANDROID_APP_ID        # Firebase app ID
FIREBASE_ANDROID_HELPER_APP_ID # Firebase helper app ID
FIREBASE_SERVICE_ACCOUNT_JSON  # Firebase service account
GOOGLE_PLAY_KEY_FILE           # Google Play service account
ASC_PROVIDER                   # Apple credentials provider ID
```

### Notifications
```
SLACK_WEBHOOK_URL              # Slack webhook for notifications
```

---

## 📈 Job Dependencies

```
CI Workflow:
  ├─ Lint ──────┐
  ├─ TypeCheck ─┼─ All Checks (required for merge)
  ├─ Test ──────┤
  ├─ Security ──┤
  └─ Build ─────┘

Deploy Backend:
  Test ─────┬─ Build ─────┬─ Deploy to Staging (develop)
            │             └─ Deploy to Production (main, with approval)

Deploy Admin:
  ├─ Preview (PR) ────────┐
  ├─ Staging (develop) ───┼─ Done
  └─ Production (main) ───┘

Build Mobile:
  ├─ Build Android Customer ──┐
  ├─ Build iOS Customer ──────┼─ Build Summary ─────┬─ Done (staging)
  ├─ Build Android Helper ────┤                     └─ Release to Stores (main)
  └─ Build iOS Helper ────────┘
```

---

## 🎯 Merge Requirements

### For main branch
1. ✅ All CI checks pass (lint, type-check, test, build)
2. ✅ At least 1 PR review approval
3. ✅ Branches up to date with main
4. ✅ No conflicts with main
5. ✅ Status checks required

```bash
# These rules are set in GitHub repository settings
# Branch: main → Settings → Branch protection rules
```

### For develop branch
1. ✅ All CI checks pass
2. ✅ Auto-merge enabled (optionally)
3. ✅ Squash and merge preferred

```bash
# Create branch protection rule
gh repo edit --default-branch develop \
  --require-status-checks-to-pass
```

---

## 🚀 Deployment Status Indicators

### GitHub Actions UI
- 🟢 Green: All jobs passed
- 🔴 Red: At least one job failed
- 🟡 Yellow: Jobs running
- ⚪ White: Queued or waiting

### Vercel Deployment
- ✅ Ready: Deployment complete and live
- ⏳ Building: Currently building
- ❌ Failed: Deployment failed

### Railway Deployment
- 🟢 Active: Service running
- 🟡 Deploying: Deployment in progress
- 🔴 Failed: Deployment failed
- Check logs for details

---

## 📊 Workflow Times

Average execution times (can vary):

| Workflow | Time | Notes |
|----------|------|-------|
| CI | 5-8 min | Depends on test duration |
| Backend Deploy | 10-15 min | Includes health checks |
| Admin Deploy | 3-5 min | Vercel caches builds |
| Mobile Build | 15-25 min | EAS queues builds |
| Total Staging | 20-30 min | Parallel jobs |
| Total Production | 30-40 min | Includes approval wait |

---

## 🔄 Retry Logic

### Automatic Retries
- Failed health check: 30 attempts (5 min total)
- Failed deployment: None (shows error)
- Failed tests: None (shows error)

### Manual Retries
```bash
# Re-run failed job
# GitHub Actions UI: Click "Re-run failed jobs"

# Redeploy manually
railway up --detach          # Backend
vercel deploy --prod         # Admin
eas build --platform android # Mobile
```

---

## 🔐 Security Considerations

### Secrets Injection
- Secrets injected at runtime (not in logs)
- Masked in workflow logs
- Separate secrets per environment
- Rotated quarterly

### Access Control
- Only organization members can access secrets
- Production deployments require manual approval
- All deployments create audit logs
- GitHub logs retained for 90 days

### Code Protection
- All code reviewed before merge
- Status checks required
- Branch protection enforced
- No direct pushes to main

---

## 📝 Manual Commands

If GitHub Actions fails, deploy manually:

```bash
# Backend (Railway)
cd packages/backend
npx @railway/cli deploy --token $RAILWAY_API_TOKEN

# Admin (Vercel)
cd packages/admin-web
vercel deploy --prod

# Mobile (EAS)
eas build --platform android,ios
eas submit --platform android,ios
```

---

## ✅ Verification Checklist

After each deployment:

**Staging**
- [ ] Backend health check passes
- [ ] Admin dashboard loads
- [ ] Can create task (backend connectivity)
- [ ] Can view admin dashboard (API connectivity)
- [ ] Mobile apps distributed to Firebase

**Production**
- [ ] All staging checks pass
- [ ] Production API responds
- [ ] Production admin dashboard loads
- [ ] Production monitoring shows healthy
- [ ] Team notified via Slack

---

**Reference**: Complete GitHub Actions documentation
- GitHub Actions: https://docs.github.com/en/actions
- Workflows: https://docs.github.com/en/actions/using-workflows
- Secrets: https://docs.github.com/en/actions/security-guides/encrypted-secrets

**Build Date**: September 2026
**Status**: ✅ Production Ready
