# Sahayakh PRD - Decision Checklist

## Quick Decision Guide

Use this checklist to track which ambiguities you've clarified. Each item links to the full discussion in `SAHAYAKH_PRD.md`.

---

## 🚨 CRITICAL - Must Decide Before Development Starts

### 1. OTP System Behavior
```
Question: How should OTP verification work exactly?

Current Prototype Shows:
- 6-digit OTP sent to customer
- Helper enters OTP to verify arrival
- Max 3 wrong attempts before escalation

You Must Decide:
- [ ] OTP valid for how long? (Suggested: 2 hours)
- [ ] Can OTP be regenerated? Max how many times?
- [ ] What if customer doesn't have SMS/can't access OTP?
- [ ] Fallback verification method if OTP fails 3x?
- [ ] Can same OTP be used by different helpers on retry?

Impact: Affects trust model, customer UX, support burden
Timeline: HIGH - Affects core verification flow
```

---

### 2. Payment Timing - When to Charge Customer?
```
Question: At what point is customer charged?

Current Prototype Shows:
- Two buttons: "Pay After Completion" vs "Pay Now"
- Unclear when payment is actually taken

You Must Decide:
- [ ] "Pay After" triggers when?
  - ☐ When helper submits task?
  - ☐ When customer approves/confirms?
  - ☐ 24 hours after submission (auto-approve)?
- [ ] If payment fails, what happens?
- [ ] How long is refund window?
- [ ] Can customer dispute AFTER payment is processed?
- [ ] Is refund immediate or batch-processed?

Impact: Affects cash flow, refund complexity, customer trust
Timeline: CRITICAL - Must be clear before payment integration
```

---

### 3. Cancellation Fees - When & How Much?
```
Question: When can customer/helper cancel, and at what cost?

Current Prototype Shows:
- Mentions "₹30 cancellation fee" once
- Unclear exactly when it applies

You Must Decide:
- [ ] Customer cancellation fees by stage:
  - Before assignment: ₹0 (free)?
  - After assignment, before helper moves: ₹30?
  - After helper is moving: ₹30 or more?
  - After helper reached location: ₹30 or 100%?
- [ ] Helper cancellation penalties:
  - Same as customer or different?
  - Does helper lose partial earnings?
- [ ] Is there a free window? (First 30 sec? 5 min?)
- [ ] Who gets the ₹30 cancellation fee?
  - Goes to helper as compensation?
  - Goes to platform?
  - Returned to customer if they cancel?

Impact: Affects revenue, completion rates, system gaming
Timeline: HIGH - Affects incentive structure
```

---

### 4. Dynamic Pricing - How Exactly?
```
Question: How is final task amount calculated?

Current Prototype Shows:
- Budget range (e.g., "₹150-300")
- References distance + time charges
- Base fare + per-km + per-minute
- Business tasks at 1.25x multiplier

You Must Decide:
- [ ] Is budget range a hard cap or soft estimate?
- [ ] Distance calculation:
  - Google Maps route distance (actual road)?
  - Straight-line distance?
  - Real distance traveled (GPS tracked)?
- [ ] Time calculation:
  - Estimated time before task?
  - Actual time after completion?
- [ ] When are surcharges applied?
  - Shown as estimate when posting?
  - Calculated exactly after completion?
  - Can differ from estimate by how much?
- [ ] Can customer negotiate price after task?
  - For quality issues?
  - For time/distance discrepancies?
  - Never (fixed price)?
- [ ] Business task multiplier:
  - Always 1.25x or variable?
  - Applied to what (base, or final)?
  - Any exceptions?

Impact: Affects pricing transparency, dispute rate, fairness perception
Timeline: CRITICAL - Affects all task valuations
```

---

### 5. Rating Visibility & Timeliness
```
Question: When do ratings become visible?

Current Prototype Shows:
- Ratings appear after 24-hour delay
- Unclear if immediate or batched

You Must Decide:
- [ ] Rating visibility delay:
  - Immediate (visible right away)?
  - 24-hour delay (current prototype)?
  - Only after dispute resolved?
- [ ] Can ratings be edited after submission?
- [ ] What if one party rates but other doesn't?
  - Can task still show incomplete?
  - Is there a default review?
- [ ] If task is disputed:
  - Are ratings hidden until dispute resolved?
  - Hidden permanently?
  - Do ratings stay if dispute resolved in helper's favor?
- [ ] Can platform (admin) delete ratings?
  - For false/abusive reviews?
  - For disputed tasks?

Impact: Affects reputation system, incentive to rate
Timeline: MEDIUM - Can be adjusted post-launch
```

---

### 6. Helper Suspension & Reactivation
```
Question: How does suspension/reactivation work?

Current Prototype Shows:
- Admin can suspend helpers
- Unclear criteria & process

You Must Decide:
- [ ] What triggers automatic suspension?
  - Number of complaints (e.g., 3 in 30 days)?
  - Specific violation (e.g., low rating)?
  - Manual admin decision?
  - Combination of above?
- [ ] Can helper appeal suspension?
- [ ] What's required for reactivation?
  - Wait period (e.g., 30 days)?
  - Submit new documents?
  - Admin manual review?
  - Conditions to meet (e.g., fix bad rating)?
- [ ] Is there permanent ban?
  - For what violations?
  - Or always a path back?
- [ ] What about repeated violations?
  - Escalating suspensions?
  - Lifetime ban after X?

Impact: Affects helper retention, quality control, fairness
Timeline: HIGH - Affects platform safety policy
```

---

### 7. Dispute Resolution Patterns
```
Question: How are disputes actually decided?

Current Prototype Shows:
- Admin reviews and makes decision
- Mentions options: Customer Win / Helper Win / Partial

You Must Decide:
- [ ] What are common resolution patterns?
  - Always 0/100 or 100/0 decisions?
  - Often 50/50 splits?
  - Document 5-10 example cases
- [ ] How are subjective disputes judged?
  - "Helper was rude" - how to determine?
  - "Quality was poor" - what's the standard?
  - Is photo evidence sufficient alone?
- [ ] What's the tie-breaker if evidence is unclear?
  - Default to customer (they paid)?
  - Default to helper (protect worker)?
  - Mutual split?
- [ ] How much weight on history/rating?
  - Helper with 4.9 rating gets benefit of doubt?
  - Helper with 3.2 rating loses by default?
  - Is history actually considered or just current evidence?
- [ ] Can disputes be appealed?
  - Once resolved, is that final?
  - Can they appeal with new evidence?
  - Who does second review?

Impact: Affects trust, fairness, system gaming
Timeline: HIGH - Must be documented for staff
```

---

## 🟡 MEDIUM PRIORITY - Clarify Before Launch

### 8. OTP Backup & Recovery
```
[ ] What if customer doesn't get OTP?
    - [ ] Fallback: Phone call to read OTP aloud?
    - [ ] Fallback: Email OTP?
    - [ ] Fallback: Admin verifies manually?
    - [ ] Fallback: Timeout after X min?

[ ] What if app notifications are disabled?
    - [ ] SMS-only fallback?
    - [ ] Manual entry of phone number for SMS?

Impact: Customer support volume, UX friction
Timeline: MEDIUM - Can improve post-launch
```

---

### 9. Task Lifecycle Timing Details
```
[ ] 30-minute reach deadline:
    - [ ] Hard cutoff (auto-cancel after 30 min)?
    - [ ] Soft warning (notify customer, wait for OK)?

[ ] Extra time charges:
    - [ ] Charged if exceed estimate by X minutes?
    - [ ] Only if customer approves extra time?
    - [ ] Automatic surcharge regardless?

[ ] Time tracking:
    - [ ] Start from task accepted?
    - [ ] Start from OTP verified?
    - [ ] Start from checklist begun?

Impact: Task pricing fairness, dispute triggers
Timeline: MEDIUM
```

---

### 10. Photo Quality & Requirements
```
[ ] Minimum photo count:
    - [ ] 1 photo sufficient?
    - [ ] Must be 2-3 photos?
    - [ ] Minimum per task type?

[ ] Photo quality standards:
    - [ ] Any requirement (e.g., clear, dated)?
    - [ ] Metadata required (timestamps)?
    - [ ] Must be timestamped by app?

[ ] Photo disputes:
    - [ ] If photo doesn't show proof, what happens?
    - [ ] Customer can reject and request new?
    - [ ] Photo revisit/retake process?

[ ] Photo retention:
    - [ ] Delete after task closed?
    - [ ] Keep for X days?
    - [ ] Keep indefinitely?

Impact: Dispute prevention, storage costs
Timeline: MEDIUM
```

---

### 11. Weekend & Holiday Handling
```
[ ] Weekend rate multiplier?
    - [ ] Saturday-Sunday: 1.0x, 1.1x, 1.2x?
    - [ ] No multiplier?

[ ] Holiday availability:
    - [ ] Full service on all holidays?
    - [ ] Restricted service?
    - [ ] List of holidays? (Diwali, Holi, etc.)

[ ] Same-day turnaround:
    - [ ] Always available?
    - [ ] Only weekdays?
    - [ ] Surcharge for rush?

Impact: Revenue patterns, demand management
Timeline: LOW - Can adjust monthly
```

---

### 12. GST Bill Handling (Business Tasks)
```
[ ] GST bill mandatory or best-effort?
    - [ ] Task fails if bill not collected?
    - [ ] Task succeeds but flagged if no bill?

[ ] Who collects the bill?
    - [ ] Helper asks vendor for bill?
    - [ ] Customer arranges bill separately?
    - [ ] Both responsible?

[ ] If bill not available:
    - [ ] Task marked incomplete?
    - [ ] Task marked complete but partial refund?
    - [ ] Full refund to customer?
    - [ ] Helper still gets paid?

[ ] Admin verification:
    - [ ] Random audit of GST bills?
    - [ ] All business tasks audited?
    - [ ] Photo verification of bill?

Impact: Business customer satisfaction, tax compliance
Timeline: MEDIUM - Specific to business segment
```

---

## 🟢 LOWER PRIORITY - Post-MVP or Later

- [ ] Referral bonus system (if any)
- [ ] Insurance/liability coverage model
- [ ] Rating aggregation weights (recent vs. all)
- [ ] Minimum rating threshold for visibility
- [ ] Category-specific rating display

---

## Decision Meeting Template

### Use This in Your Planning Meeting

**Date:** ___________  
**Attendees:** _________________________________

| Ambiguity | Decision | Owner | Approval |
|-----------|----------|-------|----------|
| OTP validity | 2 hours, regenerate max 3x, SMS fallback | [Name] | ☐ |
| Payment timing | Charge on customer approval, auto-approve after 24h | [Name] | ☐ |
| Cancellation | ₹30 after assignment, free before 5 min | [Name] | ☐ |
| Pricing | Google Maps distance, actual time, fixed cap at budget max | [Name] | ☐ |
| Ratings | 24h delay, hidden if disputed, editable, no admin delete | [Name] | ☐ |
| Suspension | 3 strikes, 30-day temp ban, must reapply | [Name] | ☐ |
| Disputes | Evidence-first, 50/50 on ties, appealable once | [Name] | ☐ |
| ... | ... | ... | ... |

---

## Next Steps

1. **Schedule decision meeting** with stakeholders (Product, Ops, Finance, Eng)
2. **Fill out decision template above**
3. **Update SAHAYAKH_PRD.md** with your decisions
4. **Create admin guidelines document** with dispute resolution examples
5. **Brief engineering team** on implications of each decision
6. **Begin development** once all critical items are decided

---

**This checklist version:** 1.0  
**Last updated:** September 2026  
**Maintained by:** Product Management
