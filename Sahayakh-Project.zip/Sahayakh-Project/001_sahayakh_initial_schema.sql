-- Sahayakh Initial Schema Migration
-- PostgreSQL with PostGIS support
-- Run with: psql -d sahayakh_db -f 001_sahayakh_initial_schema.sql

-- Enable PostGIS extension for location queries
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- ============================================================================
-- ENUMS - Define all status types as enums for type safety
-- ============================================================================

CREATE TYPE user_role AS ENUM ('customer', 'helper', 'admin');
CREATE TYPE user_status AS ENUM ('active', 'suspended', 'deleted');
CREATE TYPE helper_status AS ENUM ('active', 'online', 'offline', 'suspended', 'inactive');
CREATE TYPE helper_verification_status AS ENUM ('pending', 'verified', 'rejected', 'expired');
CREATE TYPE document_type AS ENUM ('aadhaar', 'pan', 'dl', 'selfie', 'bank_account');
CREATE TYPE document_status AS ENUM ('pending', 'verified', 'rejected', 'expired');
CREATE TYPE background_check_status AS ENUM ('pending', 'in_progress', 'cleared', 'red_flag');
CREATE TYPE task_type AS ENUM ('personal', 'business');
CREATE TYPE task_category AS ENUM (
  -- Personal
  'pickup_delivery', 'local_visit', 'document_work', 'other_personal',
  -- Business
  'vendor_pickup', 'client_delivery', 'site_visit', 'bank_gst_visit', 'other_business'
);
CREATE TYPE task_status AS ENUM (
  'unassigned', 'assigned', 'on_the_way', 'reached', 'in_progress',
  'review', 'completed', 'cancelled', 'disputed'
);
CREATE TYPE payment_status AS ENUM ('pending', 'processing', 'completed', 'failed', 'refunded');
CREATE TYPE payment_method AS ENUM ('upi', 'card', 'netbanking', 'wallet');
CREATE TYPE payout_status AS ENUM ('pending', 'processing', 'completed', 'failed');
CREATE TYPE payout_method AS ENUM ('bank_transfer', 'upi');
CREATE TYPE dispute_status AS ENUM ('open', 'investigating', 'resolved', 'appealed');
CREATE TYPE dispute_category AS ENUM ('quality', 'pricing', 'behavior', 'otp', 'non_completion');
CREATE TYPE dispute_resolution AS ENUM ('customer_win', 'helper_win', 'partial', 'mutual', 'dismissed');
CREATE TYPE review_rating AS ENUM ('1', '2', '3', '4', '5');

-- ============================================================================
-- USERS TABLE - Base user table (customer, helper, admin)
-- ============================================================================

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  phone_number VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE,
  role user_role NOT NULL,
  status user_status NOT NULL DEFAULT 'active',
  location_name VARCHAR(255),  -- e.g., "Hanamkonda, Warangal"
  location_point GEOGRAPHY(POINT, 4326),  -- PostGIS point for location
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_users_phone ON users(phone_number);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_status ON users(status);
CREATE INDEX idx_users_location ON users USING GIST(location_point);

-- ============================================================================
-- HELPERS TABLE - Extended helper profile
-- ============================================================================

CREATE TABLE helpers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,

  -- Profile
  rating NUMERIC(3, 2) DEFAULT 0,  -- 0.00 to 5.00
  total_tasks INTEGER DEFAULT 0,
  average_response_time_minutes INTEGER DEFAULT 0,

  -- Status & Verification
  helper_status helper_status NOT NULL DEFAULT 'offline',
  verification_status helper_verification_status NOT NULL DEFAULT 'pending',
  background_check_status background_check_status NOT NULL DEFAULT 'pending',

  -- Bank Details for Payouts
  bank_account_holder_name VARCHAR(255),
  bank_account_number VARCHAR(20),
  bank_ifsc_code VARCHAR(20),
  bank_name VARCHAR(255),
  upi_id VARCHAR(255),

  -- Task Preferences
  accepts_personal_tasks BOOLEAN DEFAULT true,
  accepts_business_tasks BOOLEAN DEFAULT false,
  preferred_categories task_category[] DEFAULT ARRAY[]::task_category[],

  -- Service Area
  service_radius_km INTEGER DEFAULT 5,

  -- Metadata
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  last_online_at TIMESTAMP WITH TIME ZONE,
  suspension_reason VARCHAR(500),
  suspension_start_at TIMESTAMP WITH TIME ZONE,
  suspension_end_at TIMESTAMP WITH TIME ZONE,
  total_complaints INTEGER DEFAULT 0,

  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_helpers_user_id ON helpers(user_id);
CREATE INDEX idx_helpers_status ON helpers(helper_status);
CREATE INDEX idx_helpers_rating ON helpers(rating DESC);
CREATE INDEX idx_helpers_verification ON helpers(verification_status);

-- ============================================================================
-- HELPER_DOCUMENTS TABLE - Document verification for helpers
-- ============================================================================

CREATE TABLE helper_documents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  helper_id UUID NOT NULL REFERENCES helpers(id) ON DELETE CASCADE,

  document_type document_type NOT NULL,
  status document_status NOT NULL DEFAULT 'pending',

  document_number VARCHAR(255),  -- Aadhaar number, PAN, etc.
  document_url VARCHAR(500),  -- S3 URL or similar

  verified_at TIMESTAMP WITH TIME ZONE,
  verified_by UUID REFERENCES users(id),  -- Admin who verified
  rejection_reason VARCHAR(500),

  expires_at TIMESTAMP WITH TIME ZONE,  -- For documents like licenses

  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_helper_documents_helper_id ON helper_documents(helper_id);
CREATE INDEX idx_helper_documents_status ON helper_documents(status);
CREATE INDEX idx_helper_documents_type ON helper_documents(document_type);

-- ============================================================================
-- TASKS TABLE - Main task/errand posting
-- ============================================================================

CREATE TABLE tasks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  task_id_display VARCHAR(20) UNIQUE NOT NULL,  -- SKT74811 format for user display

  -- Customer & Helper
  customer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  helper_id UUID REFERENCES helpers(id) ON DELETE SET NULL,

  -- Task Details
  task_type task_type NOT NULL,  -- personal or business
  category task_category NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,

  -- Location
  location_name VARCHAR(255) NOT NULL,
  location_point GEOGRAPHY(POINT, 4326) NOT NULL,  -- Where task happens

  -- Timing
  preferred_date DATE NOT NULL,
  preferred_time TIME,

  -- Pricing
  budget_min NUMERIC(8, 2) NOT NULL,  -- Customer's min budget (e.g., 150)
  budget_max NUMERIC(8, 2) NOT NULL,  -- Customer's max budget (e.g., 300)
  final_amount NUMERIC(8, 2),  -- Actual amount after completion

  -- Status
  status task_status NOT NULL DEFAULT 'unassigned',

  -- Payment
  payment_method payment_method NOT NULL DEFAULT 'upi',
  payment_timing VARCHAR(20) NOT NULL,  -- 'pay_now' or 'pay_after'
  payment_id UUID REFERENCES payments(id),

  -- Business Task Fields
  business_name VARCHAR(255),  -- If business task
  gst_bill_required BOOLEAN DEFAULT false,

  -- Photos
  photo_urls VARCHAR(500)[],  -- Array of S3 URLs

  -- Additional Details
  special_instructions TEXT,
  cancellation_reason VARCHAR(500),

  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  assigned_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  cancelled_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_tasks_customer_id ON tasks(customer_id);
CREATE INDEX idx_tasks_helper_id ON tasks(helper_id);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_tasks_created_at ON tasks(created_at DESC);
CREATE INDEX idx_tasks_location ON tasks USING GIST(location_point);
CREATE INDEX idx_tasks_preferred_date ON tasks(preferred_date);

-- ============================================================================
-- TASK_STATUS_HISTORY TABLE - Track all status changes for a task
-- ============================================================================

CREATE TABLE task_status_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,

  previous_status task_status,
  new_status task_status NOT NULL,
  changed_by UUID REFERENCES users(id),  -- Helper, customer, or admin
  reason VARCHAR(500),

  -- For reached status: OTP verification
  otp_generated VARCHAR(6),
  otp_entered VARCHAR(6),
  otp_verified BOOLEAN DEFAULT false,
  otp_attempts INTEGER DEFAULT 0,

  -- Time tracking (for pricing)
  time_started_at TIMESTAMP WITH TIME ZONE,
  time_completed_at TIMESTAMP WITH TIME ZONE,
  elapsed_minutes INTEGER,

  -- Distance tracking
  distance_traveled_km NUMERIC(6, 2),

  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_task_status_history_task_id ON task_status_history(task_id);
CREATE INDEX idx_task_status_history_status ON task_status_history(new_status);
CREATE INDEX idx_task_status_history_created_at ON task_status_history(created_at DESC);

-- ============================================================================
-- PAYMENTS TABLE - Payment records (per task)
-- ============================================================================

CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  customer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,

  -- Amount Breakdown
  task_amount NUMERIC(8, 2) NOT NULL,  -- Base task amount
  distance_surcharge NUMERIC(8, 2) DEFAULT 0,
  time_surcharge NUMERIC(8, 2) DEFAULT 0,
  peak_multiplier NUMERIC(3, 2) DEFAULT 1.0,
  final_amount NUMERIC(8, 2) NOT NULL,

  -- Platform Fee
  platform_fee_percent NUMERIC(4, 2) DEFAULT 15.00,  -- 15%
  platform_fee_amount NUMERIC(8, 2) NOT NULL,
  helper_payout_amount NUMERIC(8, 2) NOT NULL,  -- final_amount - platform_fee_amount

  -- Payment Method & Status
  payment_method payment_method NOT NULL,
  payment_status payment_status NOT NULL DEFAULT 'pending',

  -- Transaction References
  razorpay_order_id VARCHAR(255),
  razorpay_payment_id VARCHAR(255),
  razorpay_signature VARCHAR(255),

  -- Refunds
  refund_status VARCHAR(50),  -- pending, completed, failed
  refund_amount NUMERIC(8, 2),
  refund_reason VARCHAR(500),
  refund_at TIMESTAMP WITH TIME ZONE,

  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  completed_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_payments_task_id ON payments(task_id);
CREATE INDEX idx_payments_customer_id ON payments(customer_id);
CREATE INDEX idx_payments_status ON payments(payment_status);
CREATE INDEX idx_payments_created_at ON payments(created_at DESC);

-- ============================================================================
-- PAYOUTS TABLE - Helper earnings & withdrawals
-- ============================================================================

CREATE TABLE payouts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  payout_id_display VARCHAR(20) UNIQUE NOT NULL,  -- P-901, P-902, etc.

  helper_id UUID NOT NULL REFERENCES helpers(id) ON DELETE CASCADE,

  -- Payout Details
  total_amount NUMERIC(8, 2) NOT NULL,
  payout_method payout_method NOT NULL,  -- bank_transfer or upi

  -- Destination
  bank_account_number VARCHAR(20),
  upi_id VARCHAR(255),

  -- Status
  payout_status payout_status NOT NULL DEFAULT 'pending',

  -- Failure Tracking
  failure_reason VARCHAR(500),
  failure_count INTEGER DEFAULT 0,
  last_failure_at TIMESTAMP WITH TIME ZONE,

  -- Linked Tasks (for reference)
  task_ids UUID[] DEFAULT ARRAY[]::UUID[],

  -- Timestamps
  requested_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  processed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_payouts_helper_id ON payouts(helper_id);
CREATE INDEX idx_payouts_status ON payouts(payout_status);
CREATE INDEX idx_payouts_requested_at ON payouts(requested_at DESC);

-- ============================================================================
-- DISPUTES TABLE - Customer <-> Helper disagreements
-- ============================================================================

CREATE TABLE disputes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  dispute_id_display VARCHAR(20) UNIQUE NOT NULL,  -- D-201, D-202, etc.

  task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  raised_by UUID NOT NULL REFERENCES users(id),  -- Customer or Helper ID

  -- Dispute Details
  category dispute_category NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,

  -- Resolution
  status dispute_status NOT NULL DEFAULT 'open',
  resolution_type dispute_resolution,
  resolution_notes TEXT,

  -- Refunds/Payouts Affected by Dispute
  customer_refund_amount NUMERIC(8, 2),
  helper_payout_amount NUMERIC(8, 2),

  -- Evidence
  evidence_urls VARCHAR(500)[],  -- Photos, screenshots

  -- Communication
  messages TEXT[],  -- Array of messages in conversation

  -- Admin Assignment
  assigned_to UUID REFERENCES users(id),  -- Admin who's handling

  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  investigating_started_at TIMESTAMP WITH TIME ZONE,
  resolved_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

  -- Appeal
  appealed_at TIMESTAMP WITH TIME ZONE,
  appeal_notes TEXT
);

CREATE INDEX idx_disputes_task_id ON disputes(task_id);
CREATE INDEX idx_disputes_raised_by ON disputes(raised_by);
CREATE INDEX idx_disputes_status ON disputes(status);
CREATE INDEX idx_disputes_created_at ON disputes(created_at DESC);
CREATE INDEX idx_disputes_assigned_to ON disputes(assigned_to);

-- ============================================================================
-- REVIEWS TABLE - Ratings after task completion
-- ============================================================================

CREATE TABLE reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  task_id UUID NOT NULL UNIQUE REFERENCES tasks(id) ON DELETE CASCADE,

  -- Ratings (both directions)
  customer_to_helper_rating review_rating,
  customer_to_helper_text TEXT,
  helper_to_customer_rating review_rating,
  helper_to_customer_text TEXT,

  -- Timestamps
  customer_review_at TIMESTAMP WITH TIME ZONE,
  helper_review_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_reviews_task_id ON reviews(task_id);
CREATE INDEX idx_reviews_customer_rating ON reviews(customer_to_helper_rating);
CREATE INDEX idx_reviews_helper_rating ON reviews(helper_to_customer_rating);

-- ============================================================================
-- PRICING_CONFIG TABLE - Dynamic pricing rules (admin-configurable)
-- ============================================================================

CREATE TABLE pricing_config (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  config_key VARCHAR(100) UNIQUE NOT NULL,

  -- Base Pricing
  base_fare_rupees NUMERIC(8, 2),  -- Starting price
  per_km_rate NUMERIC(8, 2),  -- Charge per kilometer
  per_minute_rate NUMERIC(8, 2),  -- Charge per minute
  minimum_fare_rupees NUMERIC(8, 2),  -- Lowest possible charge

  -- Fee Structure
  platform_fee_percent NUMERIC(4, 2) DEFAULT 15.00,  -- Platform commission
  cancellation_fee_rupees NUMERIC(8, 2),  -- If task cancelled

  -- Multipliers
  business_task_multiplier NUMERIC(3, 2) DEFAULT 1.25,  -- 1.25x for business tasks
  peak_hour_start TIME,  -- e.g., 18:00 (6pm)
  peak_hour_end TIME,    -- e.g., 23:00 (11pm)
  peak_hour_multiplier NUMERIC(3, 2),  -- e.g., 1.1x

  -- Rules
  max_wait_time_minutes INTEGER DEFAULT 30,
  daily_bonus_tasks_required INTEGER DEFAULT 5,
  daily_bonus_amount NUMERIC(8, 2) DEFAULT 100,

  -- Metadata
  active BOOLEAN DEFAULT true,
  effective_from TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  effective_until TIMESTAMP WITH TIME ZONE,

  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_pricing_config_active ON pricing_config(active);
CREATE INDEX idx_pricing_config_key ON pricing_config(config_key);

-- ============================================================================
-- HELPER_SUSPENSION_LOG TABLE - Audit trail for suspensions
-- ============================================================================

CREATE TABLE helper_suspension_log (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  helper_id UUID NOT NULL REFERENCES helpers(id) ON DELETE CASCADE,

  reason VARCHAR(500) NOT NULL,
  triggered_by UUID REFERENCES users(id),  -- Admin who suspended

  -- Duration
  suspended_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  unsuspended_at TIMESTAMP WITH TIME ZONE,

  -- Appeal
  appeal_submitted_at TIMESTAMP WITH TIME ZONE,
  appeal_decision VARCHAR(50),  -- approved, rejected

  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_suspension_log_helper_id ON helper_suspension_log(helper_id);
CREATE INDEX idx_suspension_log_suspended_at ON helper_suspension_log(suspended_at DESC);

-- ============================================================================
-- NOTIFICATIONS TABLE - Real-time notifications for users
-- ============================================================================

CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,

  notification_type VARCHAR(100) NOT NULL,  -- 'new_task', 'task_accepted', etc.
  title VARCHAR(255) NOT NULL,
  body TEXT,

  related_task_id UUID REFERENCES tasks(id),
  related_dispute_id UUID REFERENCES disputes(id),

  is_read BOOLEAN DEFAULT false,
  read_at TIMESTAMP WITH TIME ZONE,

  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);
CREATE INDEX idx_notifications_created_at ON notifications(created_at DESC);

-- ============================================================================
-- CHAT_MESSAGES TABLE - Direct messages between customer and helper
-- ============================================================================

CREATE TABLE chat_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,

  sender_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  receiver_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,

  message_text TEXT NOT NULL,

  read_at TIMESTAMP WITH TIME ZONE,

  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_chat_messages_task_id ON chat_messages(task_id);
CREATE INDEX idx_chat_messages_sender_id ON chat_messages(sender_id);
CREATE INDEX idx_chat_messages_receiver_id ON chat_messages(receiver_id);
CREATE INDEX idx_chat_messages_created_at ON chat_messages(created_at DESC);

-- ============================================================================
-- AUDIT_LOG TABLE - Track admin actions
-- ============================================================================

CREATE TABLE audit_log (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  admin_id UUID NOT NULL REFERENCES users(id),

  action VARCHAR(100) NOT NULL,  -- 'approved_helper', 'suspended_helper', 'resolved_dispute'
  resource_type VARCHAR(100),  -- 'helper', 'dispute', 'pricing'
  resource_id UUID,

  old_values JSONB,  -- Previous values before change
  new_values JSONB,  -- New values after change

  ip_address VARCHAR(45),
  user_agent VARCHAR(500),

  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_audit_log_admin_id ON audit_log(admin_id);
CREATE INDEX idx_audit_log_action ON audit_log(action);
CREATE INDEX idx_audit_log_created_at ON audit_log(created_at DESC);

-- ============================================================================
-- SUMMARY VIEWS - For common queries
-- ============================================================================

-- Helper with basic stats (useful for discovery)
CREATE VIEW helper_summary_view AS
SELECT
  h.id,
  u.id as user_id,
  u.name,
  u.phone_number,
  u.location_name,
  u.location_point,
  h.rating,
  h.total_tasks,
  h.average_response_time_minutes,
  h.helper_status,
  h.verification_status,
  (SELECT COUNT(*) FROM tasks WHERE helper_id = h.id AND status = 'completed') as completed_tasks,
  (SELECT COUNT(*) FROM tasks WHERE helper_id = h.id AND status = 'disputed') as disputed_tasks
FROM helpers h
JOIN users u ON h.user_id = u.id
WHERE u.status = 'active' AND h.helper_status != 'suspended';

-- Task with calculated earnings
CREATE VIEW task_earnings_view AS
SELECT
  t.id,
  t.task_id_display,
  t.final_amount,
  ROUND(t.final_amount * (100 - COALESCE(pc.platform_fee_percent, 15)) / 100, 2) as helper_earns,
  ROUND(t.final_amount * COALESCE(pc.platform_fee_percent, 15) / 100, 2) as platform_earns
FROM tasks t
LEFT JOIN pricing_config pc ON pc.active = true AND pc.config_key = 'current'
WHERE t.status = 'completed';

-- ============================================================================
-- Run final checks
-- ============================================================================

-- Verify all enums and tables created
SELECT 'Schema creation complete!' as status;
