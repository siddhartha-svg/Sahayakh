# Sahayakh Monorepo - Quick Start Guide

**Get up and running in 5 minutes with Docker Compose!**

---

## ⚡ 5-Minute Setup

### 1. Prerequisites (1 min)
```bash
# Check you have:
node --version    # Should be v18+
npm --version     # Should be v9+
docker --version  # For Docker Compose
git --version
```

### 2. Clone & Install (1 min)
```bash
git clone <repo-url>
cd sahayakh
npm install
```

### 3. Copy Environment Files (1 min)
```bash
cp packages/backend/.env.example packages/backend/.env
cp packages/customer-app/.env.example packages/customer-app/.env
cp packages/helper-app/.env.example packages/helper-app/.env
cp packages/admin-dashboard/.env.example packages/admin-dashboard/.env
```

### 4. Start Services (1 min)
```bash
docker-compose up
```

### 5. Verify Services (1 min)
```bash
# In another terminal:
curl http://localhost:3000/health          # Backend
open http://localhost:5173                 # Admin Dashboard
npm run dev:customer                       # Customer App (Expo)
```

**Done! Services are running. ✅**

---

## 🎯 Service URLs

| Service | URL | Technology |
|---------|-----|-----------|
| Backend API | http://localhost:3000 | Node.js + Express |
| Admin Dashboard | http://localhost:5173 | React + Vite |
| Customer App | Expo QR Code | React Native |
| Helper App | Expo QR Code | React Native |
| PostgreSQL | localhost:5432 | Database |
| Redis | localhost:6379 | Cache |

---

## 📱 Testing the Apps

### Test Backend API
```bash
# Health check
curl http://localhost:3000/health

# Register user
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"phone_number": "+919876543210", "name": "Test User"}'
```

### Test Mobile Apps
1. Install Expo Go on your phone or use simulator
2. Run: `npm run dev:customer`
3. Scan the QR code with your phone
4. App opens in Expo Go

### Test Admin Dashboard
- Open http://localhost:5173 in browser
- Default login (setup if needed)
- View real-time KPI dashboard

---

## 📁 Directory Structure

```
sahayakh/
├── packages/
│   ├── backend/              # Node.js API
│   ├── shared/               # Shared types
│   ├── customer-app/         # React Native
│   ├── helper-app/           # React Native
│   └── admin-dashboard/      # React + Vite
├── .github/
│   └── workflows/
│       └── ci.yml            # CI/CD pipeline
├── docker-compose.yml        # Local services
├── package.json              # Root workspace
└── MONOREPO_README.md        # Full documentation
```

---

## 🚀 Common Commands

```bash
# Start all services
npm run dev

# Start specific service
npm run dev:backend        # Backend only
npm run dev:admin         # Admin dashboard
npm run dev:customer      # Customer app
npm run dev:helper        # Helper app

# Build all packages
npm run build

# Run tests
npm run test

# Lint and fix code
npm run lint
npm run lint:fix

# Type check
npm run type-check
```

---

## 🛠️ Development Workflow

### 1. Create Feature Branch
```bash
git checkout -b feature/my-feature
```

### 2. Make Changes
```bash
# Edit files in packages/backend, packages/customer-app, etc.
```

### 3. Run Tests & Linter
```bash
npm run lint
npm run test
npm run type-check
```

### 4. Commit Changes
```bash
git add .
git commit -m "feat: add my feature"
```

### 5. Push & Create PR
```bash
git push origin feature/my-feature
gh pr create
```

---

## 📝 Environment Variables

### Backend (.env)
```env
NODE_ENV=development
PORT=3000
DATABASE_URL=postgresql://sahayakh:password@postgres:5432/sahayakh_dev
REDIS_URL=redis://redis:6379
JWT_SECRET=dev-secret-key
```

### Mobile Apps (.env)
```env
REACT_APP_API_URL=http://localhost:3000/api
REACT_APP_SOCKET_URL=http://localhost:3000
REACT_APP_ENV=development
```

### Admin Dashboard (.env)
```env
VITE_API_URL=http://localhost:3000/api
VITE_SOCKET_URL=http://localhost:3000
VITE_ENV=development
```

---

## 🐛 Troubleshooting

### Port Already in Use
```bash
# Change port in packages/backend/.env
PORT=3001
```

### Cannot Connect to Database
```bash
# Check PostgreSQL is running
docker-compose ps

# Or check Docker logs
docker-compose logs postgres
```

### Node Modules Error
```bash
# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

### Socket.IO Connection Failed
- Verify backend is running: `npm run dev:backend`
- Check REACT_APP_SOCKET_URL in .env files

---

## 📚 Full Documentation

For detailed information, see:

- **[MONOREPO_README.md](./MONOREPO_README.md)** - Complete overview and usage
- **[MONOREPO_SETUP_GUIDE.md](./MONOREPO_SETUP_GUIDE.md)** - Detailed setup steps
- **[SAHAYAKH_SYSTEM_ARCHITECTURE.md](./SAHAYAKH_SYSTEM_ARCHITECTURE.md)** - System design
- **[001_sahayakh_initial_schema.sql](./001_sahayakh_initial_schema.sql)** - Database schema

---

## ✅ Checklist

- [ ] Node.js v18+ installed
- [ ] Docker & Docker Compose installed
- [ ] Repository cloned
- [ ] `npm install` completed
- [ ] `.env` files created
- [ ] `docker-compose up` running
- [ ] Services accessible:
  - [ ] http://localhost:3000 (Backend)
  - [ ] http://localhost:5173 (Admin)
  - [ ] Customer app (Expo)
  - [ ] Helper app (Expo)

---

## 🎓 Next Steps

1. **Read MONOREPO_README.md** for complete usage guide
2. **Explore packages/** to understand the structure
3. **Check GitHub Actions** CI/CD pipeline in `.github/workflows/ci.yml`
4. **Review SAHAYAKH_SYSTEM_ARCHITECTURE.md** for system design
5. **Start building features!**

---

**Happy coding! 🚀**

Questions? Check the full documentation in MONOREPO_README.md or MONOREPO_SETUP_GUIDE.md.
