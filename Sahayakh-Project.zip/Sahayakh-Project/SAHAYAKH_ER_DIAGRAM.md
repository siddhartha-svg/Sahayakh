# Sahayakh Database ER Diagram

## Entity-Relationship Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          SAHAYAKH RELATIONAL SCHEMA                         │
│                          (PostgreSQL + PostGIS)                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Core Tables & Relationships

### 1. USERS (Base User Table)
```
┌──────────────────────────────────────┐
│           USERS                      │
├──────────────────────────────────────┤
│ id (UUID) PRIMARY KEY                │
│ phone_number VARCHAR UNIQUE          │
│ name VARCHAR                         │
│ email VARCHAR UNIQUE                 │
│ role user_role                       │ → 'customer' | 'helper' | 'admin'
│ status user_status                   │ → 'active' | 'suspended' | 'deleted'
│ location_name VARCHAR                │
│ location_point GEOGRAPHY (PostGIS)   │
│ created_at TIMESTAMP                 │
│ updated_at TIMESTAMP                 │
│ deleted_at TIMESTAMP (soft delete)   │
└──────────────────────────────────────┘
      │
      ├─→ PRIMARY KEY for HELPERS (1-to-1, CASCADE)
      ├─→ PRIMARY KEY for HELPER_DOCUMENTS (1-to-many)
      ├─→ FK in TASKS (customer_id) - 1-to-many
      ├─→ FK in TASKS (helper_id) - 1-to-many
      ├─→ FK in PAYMENTS (customer_id) - 1-to-many
      ├─→ FK in DISPUTES (raised_by) - 1-to-many
      ├─→ FK in CHAT_MESSAGES (sender_id, receiver_id) - 1-to-many
      └─→ FK in AUDIT_LOG (admin_id) - 1-to-many
```

**Indexes:**
- phone_number (for login)
- role (for filtering user types)
- status (for active user queries)
- location_point (GIST for geographic proximity)

---

### 2. HELPERS (Extended Helper Profile)
```
┌──────────────────────────────────────┐
│          HELPERS                     │
├──────────────────────────────────────┤
│ id (UUID) PRIMARY KEY                │
│ user_id UUID UNIQUE FK → USERS       │ (1-to-1, CASCADE)
│ rating NUMERIC (0.00-5.00)           │
│ total_tasks INTEGER                  │
│ average_response_time_minutes INT    │
│ helper_status helper_status          │ → 'online'|'offline'|'suspended'
│ verification_status helper_verification_status │
│ background_check_status background_check_status│
│ bank_account_holder_name VARCHAR     │
│ bank_account_number VARCHAR          │
│ bank_ifsc_code VARCHAR               │
│ upi_id VARCHAR                       │
│ accepts_personal_tasks BOOLEAN       │
│ accepts_business_tasks BOOLEAN       │
│ preferred_categories task_category[] │ (ARRAY)
│ service_radius_km INTEGER            │
│ joined_at TIMESTAMP                  │
│ last_online_at TIMESTAMP             │
│ suspension_reason VARCHAR            │
│ suspension_start_at TIMESTAMP        │
│ suspension_end_at TIMESTAMP          │
│ total_complaints INTEGER             │
└──────────────────────────────────────┘
      │
      ├─→ 1-to-many to HELPER_DOCUMENTS
      ├─→ 1-to-many to TASKS (helper_id, SET NULL on delete)
      ├─→ 1-to-many to PAYOUTS
      ├─→ 1-to-many to DISPUTES (as raised_by, SET NULL on delete)
      └─→ 1-to-many to HELPER_SUSPENSION_LOG
```

**Indexes:**
- user_id (for profile lookup)
- status (for filtering active helpers)
- rating (DESC for sorting by rating)
- verification_status (for approval workflows)

---

### 3. HELPER_DOCUMENTS (Document Verification)
```
┌──────────────────────────────────────┐
│       HELPER_DOCUMENTS               │
├──────────────────────────────────────┤
│ id (UUID) PRIMARY KEY                │
│ helper_id UUID FK → HELPERS          │ (1-to-many, CASCADE)
│ document_type document_type          │ → 'aadhaar'|'pan'|'dl'|'selfie'|'bank'
│ status document_status               │ → 'pending'|'verified'|'rejected'
│ document_number VARCHAR              │
│ document_url VARCHAR                 │ (S3 URL)
│ verified_at TIMESTAMP                │
│ verified_by UUID FK → USERS(id)      │ (admin who verified)
│ rejection_reason VARCHAR             │
│ expires_at TIMESTAMP                 │
│ created_at TIMESTAMP                 │
│ updated_at TIMESTAMP                 │
└──────────────────────────────────────┘
```

**Indexes:**
- helper_id (for finding docs by helper)
- status (for approval queue)
- document_type (for specific doc lookups)

---

### 4. TASKS (Main Task/Errand Table)
```
┌──────────────────────────────────────┐
│           TASKS                      │
├──────────────────────────────────────┤
│ id (UUID) PRIMARY KEY                │
│ task_id_display VARCHAR UNIQUE       │ → 'SKT74811' for display
│ customer_id UUID FK → USERS          │ (1-to-many, CASCADE)
│ helper_id UUID FK → HELPERS          │ (1-to-many, SET NULL)
│ task_type task_type                  │ → 'personal' | 'business'
│ category task_category               │ → 'pickup_delivery'|'local_visit'...
│ title VARCHAR                        │
│ description TEXT                     │
│ location_name VARCHAR                │
│ location_point GEOGRAPHY (PostGIS)   │ → WHERE task happens
│ preferred_date DATE                  │
│ preferred_time TIME                  │
│ budget_min NUMERIC                   │ → ₹150 (example)
│ budget_max NUMERIC                   │ → ₹300 (example)
│ final_amount NUMERIC                 │ → Actual amount after completion
│ status task_status                   │ → 'unassigned'|'assigned'|...|'completed'
│ payment_method payment_method        │ → 'upi'|'card'|'netbanking'|'wallet'
│ payment_timing VARCHAR               │ → 'pay_now' | 'pay_after'
│ payment_id UUID FK → PAYMENTS        │ (1-to-1, optional)
│ business_name VARCHAR                │
│ gst_bill_required BOOLEAN            │
│ photo_urls VARCHAR[]                 │ (ARRAY of S3 URLs)
│ special_instructions TEXT            │
│ cancellation_reason VARCHAR          │
│ created_at TIMESTAMP                 │
│ updated_at TIMESTAMP                 │
│ assigned_at TIMESTAMP                │
│ completed_at TIMESTAMP               │
│ cancelled_at TIMESTAMP               │
└──────────────────────────────────────┘
      │
      ├─→ 1-to-1 to PAYMENTS (optional)
      ├─→ 1-to-many to TASK_STATUS_HISTORY
      ├─→ 1-to-1 to REVIEWS
      ├─→ 1-to-many to DISPUTES
      └─→ 1-to-many to CHAT_MESSAGES
```

**Indexes:**
- customer_id (for finding customer's tasks)
- helper_id (for finding helper's tasks)
- status (for filtering by state)
- created_at DESC (for recent tasks)
- location_point (GIST for geo queries: "find nearby tasks")
- preferred_date (for scheduling queries)

---

### 5. TASK_STATUS_HISTORY (Audit Trail for Task Status Changes)
```
┌──────────────────────────────────────┐
│     TASK_STATUS_HISTORY              │
├──────────────────────────────────────┤
│ id (UUID) PRIMARY KEY                │
│ task_id UUID FK → TASKS              │ (1-to-many, CASCADE)
│ previous_status task_status          │
│ new_status task_status               │
│ changed_by UUID FK → USERS           │ (helper/customer/admin)
│ reason VARCHAR                       │
│ otp_generated VARCHAR(6)             │
│ otp_entered VARCHAR(6)               │
│ otp_verified BOOLEAN                 │
│ otp_attempts INTEGER                 │
│ time_started_at TIMESTAMP            │
│ time_completed_at TIMESTAMP          │
│ elapsed_minutes INTEGER              │ → For pricing calculation
│ distance_traveled_km NUMERIC         │ → For pricing calculation
│ created_at TIMESTAMP                 │
└──────────────────────────────────────┘
```

**Indexes:**
- task_id (for finding task's history)
- new_status (for tracking specific transitions)
- created_at DESC (for recent changes)

**Key Insight:** This table is crucial for:
1. **OTP Tracking** - Each attempt logged
2. **Pricing** - Elapsed time & distance from status changes
3. **Dispute Evidence** - Who changed what, when
4. **Auditing** - Complete task journey

---

### 6. PAYMENTS (Per-Task Payment Records)
```
┌──────────────────────────────────────┐
│         PAYMENTS                     │
├──────────────────────────────────────┤
│ id (UUID) PRIMARY KEY                │
│ task_id UUID UNIQUE FK → TASKS       │ (1-to-1, CASCADE)
│ customer_id UUID FK → USERS          │ (1-to-many, CASCADE)
│ task_amount NUMERIC                  │ → Base amount
│ distance_surcharge NUMERIC           │
│ time_surcharge NUMERIC               │
│ peak_multiplier NUMERIC (1.0-1.5)    │
│ final_amount NUMERIC                 │
│ platform_fee_percent NUMERIC (15%)   │
│ platform_fee_amount NUMERIC          │
│ helper_payout_amount NUMERIC         │ → final - platform_fee
│ payment_method payment_method        │
│ payment_status payment_status        │ → 'pending'|'processing'|'completed'
│ razorpay_order_id VARCHAR            │ (Razorpay ref)
│ razorpay_payment_id VARCHAR          │
│ razorpay_signature VARCHAR           │
│ refund_status VARCHAR                │ → 'pending'|'completed'|'failed'
│ refund_amount NUMERIC                │
│ refund_reason VARCHAR                │
│ refund_at TIMESTAMP                  │
│ created_at TIMESTAMP                 │
│ completed_at TIMESTAMP               │
│ updated_at TIMESTAMP                 │
└──────────────────────────────────────┘
```

**Indexes:**
- task_id (unique, for finding payment by task)
- customer_id (for customer payment history)
- payment_status (for reconciliation)
- created_at DESC (for recent payments)

**Business Logic:**
- helper_payout_amount = final_amount - (final_amount * platform_fee_percent / 100)
- Example: ₹100 final, 15% fee → helper gets ₹85, platform gets ₹15

---

### 7. PAYOUTS (Helper Earnings & Withdrawals)
```
┌──────────────────────────────────────┐
│         PAYOUTS                      │
├──────────────────────────────────────┤
│ id (UUID) PRIMARY KEY                │
│ payout_id_display VARCHAR UNIQUE     │ → 'P-901' for display
│ helper_id UUID FK → HELPERS          │ (1-to-many, CASCADE)
│ total_amount NUMERIC                 │ → Sum of earnings
│ payout_method payout_method          │ → 'bank_transfer' | 'upi'
│ bank_account_number VARCHAR          │
│ upi_id VARCHAR                       │
│ payout_status payout_status          │ → 'pending'|'processing'|'completed'
│ failure_reason VARCHAR               │ (if payout failed)
│ failure_count INTEGER                │ (retry counter)
│ last_failure_at TIMESTAMP            │
│ task_ids UUID[]                      │ (ARRAY - linked tasks)
│ requested_at TIMESTAMP               │
│ processed_at TIMESTAMP               │
│ created_at TIMESTAMP                 │
│ updated_at TIMESTAMP                 │
└──────────────────────────────────────┘
```

**Indexes:**
- helper_id (for helper's payout history)
- payout_status (for processing queue)
- requested_at DESC (for recent payouts)

**Key Insight:** Weekly payouts aggregated from PAYMENTS table. Each payout references multiple tasks via `task_ids` array.

---

### 8. DISPUTES (Customer ↔ Helper Disagreements)
```
┌──────────────────────────────────────┐
│        DISPUTES                      │
├──────────────────────────────────────┤
│ id (UUID) PRIMARY KEY                │
│ dispute_id_display VARCHAR UNIQUE    │ → 'D-201' for display
│ task_id UUID FK → TASKS              │ (1-to-many, CASCADE)
│ raised_by UUID FK → USERS            │ (customer or helper ID)
│ category dispute_category            │ → 'quality'|'pricing'|'behavior'...
│ title VARCHAR                        │
│ description TEXT                     │
│ status dispute_status                │ → 'open'|'investigating'|'resolved'
│ resolution_type dispute_resolution   │ → 'customer_win'|'helper_win'|'partial'
│ resolution_notes TEXT                │
│ customer_refund_amount NUMERIC       │
│ helper_payout_amount NUMERIC         │ (may be different from original)
│ evidence_urls VARCHAR[]              │ (ARRAY - S3 URLs)
│ messages TEXT[]                      │ (ARRAY - conversation log)
│ assigned_to UUID FK → USERS          │ (admin handling)
│ created_at TIMESTAMP                 │
│ investigating_started_at TIMESTAMP   │
│ resolved_at TIMESTAMP                │
│ updated_at TIMESTAMP                 │
│ appealed_at TIMESTAMP                │
│ appeal_notes TEXT                    │
└──────────────────────────────────────┘
```

**Indexes:**
- task_id (for finding dispute by task)
- raised_by (for disputes by user)
- status (for workflow queue: 'open', 'investigating')
- created_at DESC (for recent disputes)
- assigned_to (for admin's case queue)

**Business Rules:**
- Triggered by rating, cancellation, or explicit complaint
- Original payment paused until resolved
- Refund/adjusted payout issued after resolution

---

### 9. REVIEWS (Post-Task Ratings)
```
┌──────────────────────────────────────┐
│         REVIEWS                      │
├──────────────────────────────────────┤
│ id (UUID) PRIMARY KEY                │
│ task_id UUID UNIQUE FK → TASKS       │ (1-to-1, CASCADE)
│ customer_to_helper_rating review_rating  │ → '1'|'2'|'3'|'4'|'5'
│ customer_to_helper_text TEXT         │
│ helper_to_customer_rating review_rating  │
│ helper_to_customer_text TEXT         │
│ customer_review_at TIMESTAMP         │
│ helper_review_at TIMESTAMP           │
│ created_at TIMESTAMP                 │
│ updated_at TIMESTAMP                 │
└──────────────────────────────────────┘
```

**Indexes:**
- task_id (unique, for finding review)
- customer_to_helper_rating (for rating aggregation)
- helper_to_customer_rating (for bidirectional tracking)

**Key Insight:** Bidirectional ratings. Each task has two ratings: customer→helper & helper→customer.

---

### 10. PRICING_CONFIG (Dynamic Pricing Rules - Admin Configurable)
```
┌──────────────────────────────────────┐
│      PRICING_CONFIG                  │
├──────────────────────────────────────┤
│ id (UUID) PRIMARY KEY                │
│ config_key VARCHAR UNIQUE            │ → 'current', 'weekday', etc.
│ base_fare_rupees NUMERIC             │ → Starting price (₹50)
│ per_km_rate NUMERIC                  │ → ₹5/km
│ per_minute_rate NUMERIC              │ → ₹0.5/min
│ minimum_fare_rupees NUMERIC          │ → Lowest charge (₹30)
│ platform_fee_percent NUMERIC (15%)   │
│ cancellation_fee_rupees NUMERIC      │ → ₹30
│ business_task_multiplier (1.25x)     │
│ peak_hour_start TIME                 │ → 18:00 (6pm)
│ peak_hour_end TIME                   │ → 23:00 (11pm)
│ peak_hour_multiplier NUMERIC         │ → 1.1x
│ max_wait_time_minutes INTEGER        │ → 30 min before cancel
│ daily_bonus_tasks_required INTEGER   │ → 5 tasks
│ daily_bonus_amount NUMERIC           │ → ₹100
│ active BOOLEAN                       │
│ effective_from TIMESTAMP             │
│ effective_until TIMESTAMP            │
│ created_at TIMESTAMP                 │
│ updated_at TIMESTAMP                 │
└──────────────────────────────────────┘
```

**Indexes:**
- active (for fetching current config)
- config_key (unique, for named configs)

**Key Insight:** Enables rapid A/B testing of pricing. Switch pricing by changing `active` flag. No code changes needed.

---

### 11. HELPER_SUSPENSION_LOG (Audit Trail)
```
┌──────────────────────────────────────┐
│    HELPER_SUSPENSION_LOG             │
├──────────────────────────────────────┤
│ id (UUID) PRIMARY KEY                │
│ helper_id UUID FK → HELPERS          │ (1-to-many, CASCADE)
│ reason VARCHAR                       │
│ triggered_by UUID FK → USERS         │ (admin ID)
│ suspended_at TIMESTAMP               │
│ unsuspended_at TIMESTAMP             │
│ appeal_submitted_at TIMESTAMP        │
│ appeal_decision VARCHAR              │ → 'approved'|'rejected'
│ created_at TIMESTAMP                 │
└──────────────────────────────────────┘
```

**Indexes:**
- helper_id (for finding suspensions)
- suspended_at DESC (for recent suspensions)

---

### 12. NOTIFICATIONS (Real-Time Alerts)
```
┌──────────────────────────────────────┐
│      NOTIFICATIONS                   │
├──────────────────────────────────────┤
│ id (UUID) PRIMARY KEY                │
│ user_id UUID FK → USERS              │ (1-to-many, CASCADE)
│ notification_type VARCHAR            │ → 'new_task'|'task_accepted'...
│ title VARCHAR                        │
│ body TEXT                            │
│ related_task_id UUID FK → TASKS      │ (optional)
│ related_dispute_id UUID FK → DISPUTES│ (optional)
│ is_read BOOLEAN                      │
│ read_at TIMESTAMP                    │
│ created_at TIMESTAMP                 │
└──────────────────────────────────────┘
```

**Indexes:**
- user_id (for finding user's notifications)
- is_read (for unread count)
- created_at DESC (for inbox ordering)

---

### 13. CHAT_MESSAGES (Direct Messages)
```
┌──────────────────────────────────────┐
│      CHAT_MESSAGES                   │
├──────────────────────────────────────┤
│ id (UUID) PRIMARY KEY                │
│ task_id UUID FK → TASKS              │ (1-to-many, CASCADE)
│ sender_id UUID FK → USERS            │
│ receiver_id UUID FK → USERS          │
│ message_text TEXT                    │
│ read_at TIMESTAMP                    │
│ created_at TIMESTAMP                 │
└──────────────────────────────────────┘
```

**Indexes:**
- task_id (for finding task chat)
- sender_id (for sent messages)
- receiver_id (for received messages)
- created_at DESC (for message ordering)

---

### 14. AUDIT_LOG (Admin Actions)
```
┌──────────────────────────────────────┐
│        AUDIT_LOG                     │
├──────────────────────────────────────┤
│ id (UUID) PRIMARY KEY                │
│ admin_id UUID FK → USERS             │
│ action VARCHAR                       │ → 'approved_helper'|'suspended_helper'...
│ resource_type VARCHAR                │ → 'helper'|'dispute'|'pricing'
│ resource_id UUID                     │
│ old_values JSONB                     │ (previous state)
│ new_values JSONB                     │ (new state)
│ ip_address VARCHAR                   │
│ user_agent VARCHAR                   │
│ created_at TIMESTAMP                 │
└──────────────────────────────────────┘
```

**Indexes:**
- admin_id (for admin actions)
- action (for filtering by action type)
- created_at DESC (for recent changes)

---

## Summary Views (For Common Queries)

### VIEW 1: helper_summary_view
```sql
SELECT
  h.id,
  u.id as user_id,
  u.name,
  u.phone_number,
  u.location_name,
  u.location_point,
  h.rating,
  h.total_tasks,
  h.average_response_time_minutes,
  h.helper_status,
  h.verification_status,
  (SELECT COUNT(*) FROM tasks WHERE helper_id = h.id AND status = 'completed') 
    as completed_tasks,
  (SELECT COUNT(*) FROM tasks WHERE helper_id = h.id AND status = 'disputed') 
    as disputed_tasks
FROM helpers h
JOIN users u ON h.user_id = u.id
WHERE u.status = 'active' AND h.helper_status != 'suspended';
```

**Use Case:** Helper discovery - shows available helpers with ratings and stats.

---

### VIEW 2: task_earnings_view
```sql
SELECT
  t.id,
  t.task_id_display,
  t.final_amount,
  ROUND(t.final_amount * (100 - COALESCE(pc.platform_fee_percent, 15)) / 100, 2) 
    as helper_earns,
  ROUND(t.final_amount * COALESCE(pc.platform_fee_percent, 15) / 100, 2) 
    as platform_earns
FROM tasks t
LEFT JOIN pricing_config pc ON pc.active = true AND pc.config_key = 'current'
WHERE t.status = 'completed';
```

**Use Case:** Dashboard KPIs - shows platform revenue, helper earnings split.

---

## Key Relationship Patterns

### 1. **Three-Sided Marketplace**
```
USERS (customers)    ─── TASKS ──→    HELPERS (workers)
    │                                      │
    │                                      │
    └─→ REVIEWS ←─────────────────────────┘
        └─→ RATINGS (bidirectional)
```

### 2. **Payment Flow**
```
TASKS → PAYMENTS (1-to-1)
         └─→ PAYOUTS (aggregated weekly)
         └─→ DISPUTES (if contested)
                └─→ REFUNDS or ADJUSTED PAYOUTS
```

### 3. **Task Lifecycle Tracking**
```
TASKS → TASK_STATUS_HISTORY (1-to-many)
        ├─→ Tracks: OTP, time, distance
        ├─→ Used for: Pricing calculation, dispute evidence
        └─→ Creates audit trail
```

### 4. **Helper Verification**
```
HELPERS → HELPER_DOCUMENTS (1-to-many)
          ├─→ aadhaar, pan, dl, selfie, bank_account
          ├─→ Status: pending → verified → expired
          └─→ Verified by: USERS (admin)
```

### 5. **Dispute Resolution**
```
DISPUTES ← TASKS
 ├─→ raised_by: USERS
 ├─→ assigned_to: USERS (admin)
 ├─→ evidence_urls: ARRAY of S3 paths
 └─→ messages: ARRAY of message logs
```

---

## Foreign Key Relationships (Summary)

| From Table | To Table | Relationship | Delete Behavior |
|------------|----------|--------------|-----------------|
| HELPERS | USERS | user_id | CASCADE |
| HELPER_DOCUMENTS | HELPERS | helper_id | CASCADE |
| TASKS | USERS | customer_id | CASCADE |
| TASKS | HELPERS | helper_id | SET NULL |
| TASKS | PAYMENTS | payment_id | (optional) |
| TASK_STATUS_HISTORY | TASKS | task_id | CASCADE |
| PAYMENTS | TASKS | task_id | CASCADE |
| PAYMENTS | USERS | customer_id | CASCADE |
| PAYOUTS | HELPERS | helper_id | CASCADE |
| DISPUTES | TASKS | task_id | CASCADE |
| DISPUTES | USERS | raised_by, assigned_to | (no cascade) |
| REVIEWS | TASKS | task_id | CASCADE |
| NOTIFICATIONS | USERS | user_id | CASCADE |
| NOTIFICATIONS | TASKS | related_task_id | (optional) |
| CHAT_MESSAGES | TASKS | task_id | CASCADE |
| CHAT_MESSAGES | USERS | sender_id, receiver_id | (no cascade) |
| AUDIT_LOG | USERS | admin_id | (no cascade) |
| HELPER_SUSPENSION_LOG | HELPERS | helper_id | CASCADE |

---

## Enum Types (PostgreSQL Type Safety)

```sql
-- User Management
user_role                     → 'customer' | 'helper' | 'admin'
user_status                   → 'active' | 'suspended' | 'deleted'
helper_status                 → 'active' | 'online' | 'offline' | 'suspended'
helper_verification_status    → 'pending' | 'verified' | 'rejected' | 'expired'

-- Documents
document_type                 → 'aadhaar' | 'pan' | 'dl' | 'selfie' | 'bank_account'
document_status               → 'pending' | 'verified' | 'rejected' | 'expired'
background_check_status       → 'pending' | 'in_progress' | 'cleared' | 'red_flag'

-- Tasks
task_type                     → 'personal' | 'business'
task_category                 → 'pickup_delivery' | 'local_visit' | ... (11 types)
task_status                   → 'unassigned' | 'assigned' | 'on_the_way' | 'reached' |
                               'in_progress' | 'review' | 'completed' | 'cancelled' | 'disputed'

-- Payments
payment_method                → 'upi' | 'card' | 'netbanking' | 'wallet'
payment_status                → 'pending' | 'processing' | 'completed' | 'failed' | 'refunded'
payout_method                 → 'bank_transfer' | 'upi'
payout_status                 → 'pending' | 'processing' | 'completed' | 'failed'

-- Disputes
dispute_status                → 'open' | 'investigating' | 'resolved' | 'appealed'
dispute_category              → 'quality' | 'pricing' | 'behavior' | 'otp' | 'non_completion'
dispute_resolution            → 'customer_win' | 'helper_win' | 'partial' | 'mutual' | 'dismissed'

-- Reviews
review_rating                 → '1' | '2' | '3' | '4' | '5'
```

---

## Indexing Strategy

### High-Priority Indexes (Frequently Queried)
```
-- User Lookups
users(phone_number)           → for login
users(role)                   → for role-based filtering
users(status)                 → for active user queries

-- Helper Discovery
helpers(status)               → find online helpers
helpers(rating DESC)          → sort by rating
helpers(verification_status)  → for approval workflow

-- Task Queries
tasks(customer_id)            → customer's task history
tasks(helper_id)              → helper's assigned tasks
tasks(status)                 → filter by task state
tasks(created_at DESC)        → recent tasks
tasks(location_point) GIST    → "find tasks near me" (PostGIS)

-- Payment Processing
payments(task_id)             → lookup payment by task
payments(payment_status)      → for reconciliation
payments(created_at DESC)     → recent payments

-- Dispute Workflow
disputes(status)              → queue management
disputes(assigned_to)         → admin's caseload
disputes(created_at DESC)     → recent disputes
```

### Medium-Priority Indexes
```
tasks(preferred_date)         → scheduling queries
helper_documents(status)      → approval queues
notifications(is_read)        → unread count
chat_messages(created_at DESC)→ inbox ordering
payouts(payout_status)        → processing queue
```

---

## Scalability Considerations

### Partitioning Strategy (for 1M+ tasks)
```sql
-- Partition TASKS by created_at (monthly)
PARTITION BY RANGE (YEAR(created_at), MONTH(created_at))

-- Partition TASK_STATUS_HISTORY by created_at (monthly)
-- Partition PAYMENTS by created_at (monthly)
```

### Archival Strategy
```
-- Move completed tasks to archive after 1 year
-- Archive queries to cheaper storage (S3)
-- Keep indexes on active partition only
```

---

## Constraints Summary

### NOT NULL Constraints (Data Integrity)
- All PK fields: `NOT NULL`
- All FK fields (except optional): `NOT NULL`
- All core fields: phone_number, name, role, status, title, description, etc.

### UNIQUE Constraints (Data Validity)
- `users.phone_number` - Each user has one phone
- `users.email` - Email is unique (optional field, but unique if present)
- `helpers.user_id` - Each helper profile belongs to one user
- `tasks.task_id_display` - Display ID for user-facing URLs
- `payouts.payout_id_display` - Payout reference number
- `disputes.dispute_id_display` - Dispute reference number
- `helper_documents.(helper_id, document_type)` - One doc of each type per helper
- `reviews.task_id` - One review per task (but can have two ratings in it)
- `pricing_config.config_key` - One config per name

### CHECK Constraints (Business Rules)
- `budget_max >= budget_min` - Max budget ≥ min budget
- `final_amount >= 0` - No negative amounts
- `rating >= 0 AND rating <= 5` - Valid rating range
- `platform_fee_percent >= 0 AND <= 100` - Valid percentage

---

## Sample Queries

### 1. Find Available Helpers Near Customer Location
```sql
SELECT * FROM helper_summary_view
WHERE ST_DWithin(location_point, $1::geography, $2)  -- within X km
  AND helper_status = 'online'
  AND verification_status = 'verified'
ORDER BY rating DESC, last_online_at DESC
LIMIT 10;
```

### 2. Get Task with Full Status History
```sql
SELECT 
  t.*,
  json_agg(tsh.* ORDER BY tsh.created_at) as status_history
FROM tasks t
LEFT JOIN task_status_history tsh ON t.id = tsh.task_id
WHERE t.id = $1
GROUP BY t.id;
```

### 3. Calculate Helper's Weekly Earnings
```sql
SELECT
  p.helper_id,
  DATE_TRUNC('week', p.created_at) as week,
  SUM(p.helper_payout_amount) as total_earnings,
  COUNT(p.task_id) as task_count,
  AVG((SELECT rating FROM reviews WHERE task_id = p.task_id AND customer_to_helper_rating IS NOT NULL)) as avg_rating
FROM payments p
WHERE p.payment_status = 'completed'
  AND p.created_at >= NOW() - INTERVAL '1 week'
GROUP BY p.helper_id, DATE_TRUNC('week', p.created_at);
```

### 4. Find Disputed Tasks Awaiting Resolution
```sql
SELECT
  d.*,
  t.task_id_display,
  t.final_amount,
  (SELECT name FROM users WHERE id = t.customer_id) as customer_name,
  (SELECT name FROM users WHERE id = t.helper_id) as helper_name
FROM disputes d
JOIN tasks t ON d.task_id = t.id
WHERE d.status IN ('open', 'investigating')
  AND d.assigned_to = $1  -- admin's caseload
ORDER BY d.created_at ASC;
```

---

## Performance Optimization Tips

1. **Use ANALYZE regularly** - Helps query planner optimize
2. **Monitor slow queries** - Log queries > 100ms
3. **Index ARRAY fields carefully** - GIN indexes for `photo_urls`, `messages`
4. **Partition by time** - For 1M+ records, partition TASKS, PAYMENTS, TASK_STATUS_HISTORY monthly
5. **Cache PRICING_CONFIG** - Read-heavy, rarely changes, cache in Redis
6. **Vacuum regularly** - PostgreSQL maintenance

---

## Migration Notes

### Step 1: Create Enums
Run all CREATE TYPE statements first.

### Step 2: Create Base Tables
Create USERS first, then HELPERS and other tables that reference USERS.

### Step 3: Create Foreign Keys
Add all FKs after base tables exist.

### Step 4: Create Indexes
Add all indexes for optimal query performance.

### Step 5: Create Views
Create summary views for common queries.

### Step 6: Seed Initial Data
- Create default PRICING_CONFIG with current rates
- Create admin user
- Set up extensions (PostGIS, uuid-ossp)

---

**Schema Version:** 1.0  
**Last Updated:** September 2026  
**Status:** Ready for Migration
